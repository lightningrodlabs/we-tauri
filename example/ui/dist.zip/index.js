/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ii = window, ps = ii.ShadowRoot && (ii.ShadyCSS === void 0 || ii.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, fs = Symbol(), $s = /* @__PURE__ */ new WeakMap();
let Un = class {
  constructor(A, e, i) {
    if (this._$cssResult$ = !0, i !== fs)
      throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = A, this.t = e;
  }
  get styleSheet() {
    let A = this.o;
    const e = this.t;
    if (ps && A === void 0) {
      const i = e !== void 0 && e.length === 1;
      i && (A = $s.get(e)), A === void 0 && ((this.o = A = new CSSStyleSheet()).replaceSync(this.cssText), i && $s.set(e, A));
    }
    return A;
  }
  toString() {
    return this.cssText;
  }
};
const wl = (t) => new Un(typeof t == "string" ? t : t + "", void 0, fs), z = (t, ...A) => {
  const e = t.length === 1 ? t[0] : A.reduce((i, o, s) => i + ((r) => {
    if (r._$cssResult$ === !0)
      return r.cssText;
    if (typeof r == "number")
      return r;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + r + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(o) + t[s + 1], t[0]);
  return new Un(e, t, fs);
}, ml = (t, A) => {
  ps ? t.adoptedStyleSheets = A.map((e) => e instanceof CSSStyleSheet ? e : e.styleSheet) : A.forEach((e) => {
    const i = document.createElement("style"), o = ii.litNonce;
    o !== void 0 && i.setAttribute("nonce", o), i.textContent = e.cssText, t.appendChild(i);
  });
}, qs = ps ? (t) => t : (t) => t instanceof CSSStyleSheet ? ((A) => {
  let e = "";
  for (const i of A.cssRules)
    e += i.cssText;
  return wl(e);
})(t) : t;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var io;
const ci = window, Ps = ci.trustedTypes, vl = Ps ? Ps.emptyScript : "", zs = ci.reactiveElementPolyfillSupport, Ro = { toAttribute(t, A) {
  switch (A) {
    case Boolean:
      t = t ? vl : null;
      break;
    case Object:
    case Array:
      t = t == null ? t : JSON.stringify(t);
  }
  return t;
}, fromAttribute(t, A) {
  let e = t;
  switch (A) {
    case Boolean:
      e = t !== null;
      break;
    case Number:
      e = t === null ? null : Number(t);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(t);
      } catch {
        e = null;
      }
  }
  return e;
} }, Fn = (t, A) => A !== t && (A == A || t == t), oo = { attribute: !0, type: String, converter: Ro, reflect: !1, hasChanged: Fn };
let vt = class extends HTMLElement {
  constructor() {
    super(), this._$Ei = /* @__PURE__ */ new Map(), this.isUpdatePending = !1, this.hasUpdated = !1, this._$El = null, this.u();
  }
  static addInitializer(A) {
    var e;
    this.finalize(), ((e = this.h) !== null && e !== void 0 ? e : this.h = []).push(A);
  }
  static get observedAttributes() {
    this.finalize();
    const A = [];
    return this.elementProperties.forEach((e, i) => {
      const o = this._$Ep(i, e);
      o !== void 0 && (this._$Ev.set(o, i), A.push(o));
    }), A;
  }
  static createProperty(A, e = oo) {
    if (e.state && (e.attribute = !1), this.finalize(), this.elementProperties.set(A, e), !e.noAccessor && !this.prototype.hasOwnProperty(A)) {
      const i = typeof A == "symbol" ? Symbol() : "__" + A, o = this.getPropertyDescriptor(A, i, e);
      o !== void 0 && Object.defineProperty(this.prototype, A, o);
    }
  }
  static getPropertyDescriptor(A, e, i) {
    return { get() {
      return this[e];
    }, set(o) {
      const s = this[A];
      this[e] = o, this.requestUpdate(A, s, i);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(A) {
    return this.elementProperties.get(A) || oo;
  }
  static finalize() {
    if (this.hasOwnProperty("finalized"))
      return !1;
    this.finalized = !0;
    const A = Object.getPrototypeOf(this);
    if (A.finalize(), A.h !== void 0 && (this.h = [...A.h]), this.elementProperties = new Map(A.elementProperties), this._$Ev = /* @__PURE__ */ new Map(), this.hasOwnProperty("properties")) {
      const e = this.properties, i = [...Object.getOwnPropertyNames(e), ...Object.getOwnPropertySymbols(e)];
      for (const o of i)
        this.createProperty(o, e[o]);
    }
    return this.elementStyles = this.finalizeStyles(this.styles), !0;
  }
  static finalizeStyles(A) {
    const e = [];
    if (Array.isArray(A)) {
      const i = new Set(A.flat(1 / 0).reverse());
      for (const o of i)
        e.unshift(qs(o));
    } else
      A !== void 0 && e.push(qs(A));
    return e;
  }
  static _$Ep(A, e) {
    const i = e.attribute;
    return i === !1 ? void 0 : typeof i == "string" ? i : typeof A == "string" ? A.toLowerCase() : void 0;
  }
  u() {
    var A;
    this._$E_ = new Promise((e) => this.enableUpdating = e), this._$AL = /* @__PURE__ */ new Map(), this._$Eg(), this.requestUpdate(), (A = this.constructor.h) === null || A === void 0 || A.forEach((e) => e(this));
  }
  addController(A) {
    var e, i;
    ((e = this._$ES) !== null && e !== void 0 ? e : this._$ES = []).push(A), this.renderRoot !== void 0 && this.isConnected && ((i = A.hostConnected) === null || i === void 0 || i.call(A));
  }
  removeController(A) {
    var e;
    (e = this._$ES) === null || e === void 0 || e.splice(this._$ES.indexOf(A) >>> 0, 1);
  }
  _$Eg() {
    this.constructor.elementProperties.forEach((A, e) => {
      this.hasOwnProperty(e) && (this._$Ei.set(e, this[e]), delete this[e]);
    });
  }
  createRenderRoot() {
    var A;
    const e = (A = this.shadowRoot) !== null && A !== void 0 ? A : this.attachShadow(this.constructor.shadowRootOptions);
    return ml(e, this.constructor.elementStyles), e;
  }
  connectedCallback() {
    var A;
    this.renderRoot === void 0 && (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (A = this._$ES) === null || A === void 0 || A.forEach((e) => {
      var i;
      return (i = e.hostConnected) === null || i === void 0 ? void 0 : i.call(e);
    });
  }
  enableUpdating(A) {
  }
  disconnectedCallback() {
    var A;
    (A = this._$ES) === null || A === void 0 || A.forEach((e) => {
      var i;
      return (i = e.hostDisconnected) === null || i === void 0 ? void 0 : i.call(e);
    });
  }
  attributeChangedCallback(A, e, i) {
    this._$AK(A, i);
  }
  _$EO(A, e, i = oo) {
    var o;
    const s = this.constructor._$Ep(A, i);
    if (s !== void 0 && i.reflect === !0) {
      const r = (((o = i.converter) === null || o === void 0 ? void 0 : o.toAttribute) !== void 0 ? i.converter : Ro).toAttribute(e, i.type);
      this._$El = A, r == null ? this.removeAttribute(s) : this.setAttribute(s, r), this._$El = null;
    }
  }
  _$AK(A, e) {
    var i;
    const o = this.constructor, s = o._$Ev.get(A);
    if (s !== void 0 && this._$El !== s) {
      const r = o.getPropertyOptions(s), n = typeof r.converter == "function" ? { fromAttribute: r.converter } : ((i = r.converter) === null || i === void 0 ? void 0 : i.fromAttribute) !== void 0 ? r.converter : Ro;
      this._$El = s, this[s] = n.fromAttribute(e, r.type), this._$El = null;
    }
  }
  requestUpdate(A, e, i) {
    let o = !0;
    A !== void 0 && (((i = i || this.constructor.getPropertyOptions(A)).hasChanged || Fn)(this[A], e) ? (this._$AL.has(A) || this._$AL.set(A, e), i.reflect === !0 && this._$El !== A && (this._$EC === void 0 && (this._$EC = /* @__PURE__ */ new Map()), this._$EC.set(A, i))) : o = !1), !this.isUpdatePending && o && (this._$E_ = this._$Ej());
  }
  async _$Ej() {
    this.isUpdatePending = !0;
    try {
      await this._$E_;
    } catch (e) {
      Promise.reject(e);
    }
    const A = this.scheduleUpdate();
    return A != null && await A, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var A;
    if (!this.isUpdatePending)
      return;
    this.hasUpdated, this._$Ei && (this._$Ei.forEach((o, s) => this[s] = o), this._$Ei = void 0);
    let e = !1;
    const i = this._$AL;
    try {
      e = this.shouldUpdate(i), e ? (this.willUpdate(i), (A = this._$ES) === null || A === void 0 || A.forEach((o) => {
        var s;
        return (s = o.hostUpdate) === null || s === void 0 ? void 0 : s.call(o);
      }), this.update(i)) : this._$Ek();
    } catch (o) {
      throw e = !1, this._$Ek(), o;
    }
    e && this._$AE(i);
  }
  willUpdate(A) {
  }
  _$AE(A) {
    var e;
    (e = this._$ES) === null || e === void 0 || e.forEach((i) => {
      var o;
      return (o = i.hostUpdated) === null || o === void 0 ? void 0 : o.call(i);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(A)), this.updated(A);
  }
  _$Ek() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$E_;
  }
  shouldUpdate(A) {
    return !0;
  }
  update(A) {
    this._$EC !== void 0 && (this._$EC.forEach((e, i) => this._$EO(i, this[i], e)), this._$EC = void 0), this._$Ek();
  }
  updated(A) {
  }
  firstUpdated(A) {
  }
};
vt.finalized = !0, vt.elementProperties = /* @__PURE__ */ new Map(), vt.elementStyles = [], vt.shadowRootOptions = { mode: "open" }, zs?.({ ReactiveElement: vt }), ((io = ci.reactiveElementVersions) !== null && io !== void 0 ? io : ci.reactiveElementVersions = []).push("1.6.1");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var so;
const hi = window, Mt = hi.trustedTypes, Vs = Mt ? Mt.createPolicy("lit-html", { createHTML: (t) => t }) : void 0, Mo = "$lit$", $A = `lit$${(Math.random() + "").slice(9)}$`, Gn = "?" + $A, bl = `<${Gn}>`, _t = document, me = () => _t.createComment(""), ve = (t) => t === null || typeof t != "object" && typeof t != "function", Rn = Array.isArray, Dl = (t) => Rn(t) || typeof t?.[Symbol.iterator] == "function", ro = `[ 	
\f\r]`, oe = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, js = /-->/g, Zs = />/g, tt = RegExp(`>|${ro}(?:([^\\s"'>=/]+)(${ro}*=${ro}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Ws = /'/g, Xs = /"/g, Mn = /^(?:script|style|textarea|title)$/i, kl = (t) => (A, ...e) => ({ _$litType$: t, strings: A, values: e }), p = kl(1), GA = Symbol.for("lit-noChange"), J = Symbol.for("lit-nothing"), Ar = /* @__PURE__ */ new WeakMap(), xt = _t.createTreeWalker(_t, 129, null, !1), Sl = (t, A) => {
  const e = t.length - 1, i = [];
  let o, s = A === 2 ? "<svg>" : "", r = oe;
  for (let l = 0; l < e; l++) {
    const a = t[l];
    let h, g, c = -1, C = 0;
    for (; C < a.length && (r.lastIndex = C, g = r.exec(a), g !== null); )
      C = r.lastIndex, r === oe ? g[1] === "!--" ? r = js : g[1] !== void 0 ? r = Zs : g[2] !== void 0 ? (Mn.test(g[2]) && (o = RegExp("</" + g[2], "g")), r = tt) : g[3] !== void 0 && (r = tt) : r === tt ? g[0] === ">" ? (r = o ?? oe, c = -1) : g[1] === void 0 ? c = -2 : (c = r.lastIndex - g[2].length, h = g[1], r = g[3] === void 0 ? tt : g[3] === '"' ? Xs : Ws) : r === Xs || r === Ws ? r = tt : r === js || r === Zs ? r = oe : (r = tt, o = void 0);
    const B = r === tt && t[l + 1].startsWith("/>") ? " " : "";
    s += r === oe ? a + bl : c >= 0 ? (i.push(h), a.slice(0, c) + Mo + a.slice(c) + $A + B) : a + $A + (c === -2 ? (i.push(void 0), l) : B);
  }
  const n = s + (t[e] || "<?>") + (A === 2 ? "</svg>" : "");
  if (!Array.isArray(t) || !t.hasOwnProperty("raw"))
    throw Error("invalid template strings array");
  return [Vs !== void 0 ? Vs.createHTML(n) : n, i];
};
let _o = class _n {
  constructor({ strings: A, _$litType$: e }, i) {
    let o;
    this.parts = [];
    let s = 0, r = 0;
    const n = A.length - 1, l = this.parts, [a, h] = Sl(A, e);
    if (this.el = _n.createElement(a, i), xt.currentNode = this.el.content, e === 2) {
      const g = this.el.content, c = g.firstChild;
      c.remove(), g.append(...c.childNodes);
    }
    for (; (o = xt.nextNode()) !== null && l.length < n; ) {
      if (o.nodeType === 1) {
        if (o.hasAttributes()) {
          const g = [];
          for (const c of o.getAttributeNames())
            if (c.endsWith(Mo) || c.startsWith($A)) {
              const C = h[r++];
              if (g.push(c), C !== void 0) {
                const B = o.getAttribute(C.toLowerCase() + Mo).split($A), Q = /([.?@])?(.*)/.exec(C);
                l.push({ type: 1, index: s, name: Q[2], strings: B, ctor: Q[1] === "." ? Nl : Q[1] === "?" ? Fl : Q[1] === "@" ? Gl : Hi });
              } else
                l.push({ type: 6, index: s });
            }
          for (const c of g)
            o.removeAttribute(c);
        }
        if (Mn.test(o.tagName)) {
          const g = o.textContent.split($A), c = g.length - 1;
          if (c > 0) {
            o.textContent = Mt ? Mt.emptyScript : "";
            for (let C = 0; C < c; C++)
              o.append(g[C], me()), xt.nextNode(), l.push({ type: 2, index: ++s });
            o.append(g[c], me());
          }
        }
      } else if (o.nodeType === 8)
        if (o.data === Gn)
          l.push({ type: 2, index: s });
        else {
          let g = -1;
          for (; (g = o.data.indexOf($A, g + 1)) !== -1; )
            l.push({ type: 7, index: s }), g += $A.length - 1;
        }
      s++;
    }
  }
  static createElement(A, e) {
    const i = _t.createElement("template");
    return i.innerHTML = A, i;
  }
};
function Lt(t, A, e = t, i) {
  var o, s, r, n;
  if (A === GA)
    return A;
  let l = i !== void 0 ? (o = e._$Co) === null || o === void 0 ? void 0 : o[i] : e._$Cl;
  const a = ve(A) ? void 0 : A._$litDirective$;
  return l?.constructor !== a && ((s = l?._$AO) === null || s === void 0 || s.call(l, !1), a === void 0 ? l = void 0 : (l = new a(t), l._$AT(t, e, i)), i !== void 0 ? ((r = (n = e)._$Co) !== null && r !== void 0 ? r : n._$Co = [])[i] = l : e._$Cl = l), l !== void 0 && (A = Lt(t, l._$AS(t, A.values), l, i)), A;
}
let xl = class {
  constructor(A, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = A, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(A) {
    var e;
    const { el: { content: i }, parts: o } = this._$AD, s = ((e = A?.creationScope) !== null && e !== void 0 ? e : _t).importNode(i, !0);
    xt.currentNode = s;
    let r = xt.nextNode(), n = 0, l = 0, a = o[0];
    for (; a !== void 0; ) {
      if (n === a.index) {
        let h;
        a.type === 2 ? h = new ys(r, r.nextSibling, this, A) : a.type === 1 ? h = new a.ctor(r, a.name, a.strings, this, A) : a.type === 6 && (h = new Rl(r, this, A)), this._$AV.push(h), a = o[++l];
      }
      n !== a?.index && (r = xt.nextNode(), n++);
    }
    return s;
  }
  v(A) {
    let e = 0;
    for (const i of this._$AV)
      i !== void 0 && (i.strings !== void 0 ? (i._$AI(A, i, e), e += i.strings.length - 2) : i._$AI(A[e])), e++;
  }
}, ys = class Ln {
  constructor(A, e, i, o) {
    var s;
    this.type = 2, this._$AH = J, this._$AN = void 0, this._$AA = A, this._$AB = e, this._$AM = i, this.options = o, this._$Cp = (s = o?.isConnected) === null || s === void 0 || s;
  }
  get _$AU() {
    var A, e;
    return (e = (A = this._$AM) === null || A === void 0 ? void 0 : A._$AU) !== null && e !== void 0 ? e : this._$Cp;
  }
  get parentNode() {
    let A = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && A?.nodeType === 11 && (A = e.parentNode), A;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(A, e = this) {
    A = Lt(this, A, e), ve(A) ? A === J || A == null || A === "" ? (this._$AH !== J && this._$AR(), this._$AH = J) : A !== this._$AH && A !== GA && this._(A) : A._$litType$ !== void 0 ? this.g(A) : A.nodeType !== void 0 ? this.$(A) : Dl(A) ? this.T(A) : this._(A);
  }
  k(A) {
    return this._$AA.parentNode.insertBefore(A, this._$AB);
  }
  $(A) {
    this._$AH !== A && (this._$AR(), this._$AH = this.k(A));
  }
  _(A) {
    this._$AH !== J && ve(this._$AH) ? this._$AA.nextSibling.data = A : this.$(_t.createTextNode(A)), this._$AH = A;
  }
  g(A) {
    var e;
    const { values: i, _$litType$: o } = A, s = typeof o == "number" ? this._$AC(A) : (o.el === void 0 && (o.el = _o.createElement(o.h, this.options)), o);
    if (((e = this._$AH) === null || e === void 0 ? void 0 : e._$AD) === s)
      this._$AH.v(i);
    else {
      const r = new xl(s, this), n = r.u(this.options);
      r.v(i), this.$(n), this._$AH = r;
    }
  }
  _$AC(A) {
    let e = Ar.get(A.strings);
    return e === void 0 && Ar.set(A.strings, e = new _o(A)), e;
  }
  T(A) {
    Rn(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let i, o = 0;
    for (const s of A)
      o === e.length ? e.push(i = new Ln(this.k(me()), this.k(me()), this, this.options)) : i = e[o], i._$AI(s), o++;
    o < e.length && (this._$AR(i && i._$AB.nextSibling, o), e.length = o);
  }
  _$AR(A = this._$AA.nextSibling, e) {
    var i;
    for ((i = this._$AP) === null || i === void 0 || i.call(this, !1, !0, e); A && A !== this._$AB; ) {
      const o = A.nextSibling;
      A.remove(), A = o;
    }
  }
  setConnected(A) {
    var e;
    this._$AM === void 0 && (this._$Cp = A, (e = this._$AP) === null || e === void 0 || e.call(this, A));
  }
}, Hi = class {
  constructor(A, e, i, o, s) {
    this.type = 1, this._$AH = J, this._$AN = void 0, this.element = A, this.name = e, this._$AM = o, this.options = s, i.length > 2 || i[0] !== "" || i[1] !== "" ? (this._$AH = Array(i.length - 1).fill(new String()), this.strings = i) : this._$AH = J;
  }
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(A, e = this, i, o) {
    const s = this.strings;
    let r = !1;
    if (s === void 0)
      A = Lt(this, A, e, 0), r = !ve(A) || A !== this._$AH && A !== GA, r && (this._$AH = A);
    else {
      const n = A;
      let l, a;
      for (A = s[0], l = 0; l < s.length - 1; l++)
        a = Lt(this, n[i + l], e, l), a === GA && (a = this._$AH[l]), r || (r = !ve(a) || a !== this._$AH[l]), a === J ? A = J : A !== J && (A += (a ?? "") + s[l + 1]), this._$AH[l] = a;
    }
    r && !o && this.j(A);
  }
  j(A) {
    A === J ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, A ?? "");
  }
}, Nl = class extends Hi {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(A) {
    this.element[this.name] = A === J ? void 0 : A;
  }
};
const Ul = Mt ? Mt.emptyScript : "";
let Fl = class extends Hi {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(A) {
    A && A !== J ? this.element.setAttribute(this.name, Ul) : this.element.removeAttribute(this.name);
  }
};
class Gl extends Hi {
  constructor(A, e, i, o, s) {
    super(A, e, i, o, s), this.type = 5;
  }
  _$AI(A, e = this) {
    var i;
    if ((A = (i = Lt(this, A, e, 0)) !== null && i !== void 0 ? i : J) === GA)
      return;
    const o = this._$AH, s = A === J && o !== J || A.capture !== o.capture || A.once !== o.once || A.passive !== o.passive, r = A !== J && (o === J || s);
    s && this.element.removeEventListener(this.name, this, o), r && this.element.addEventListener(this.name, this, A), this._$AH = A;
  }
  handleEvent(A) {
    var e, i;
    typeof this._$AH == "function" ? this._$AH.call((i = (e = this.options) === null || e === void 0 ? void 0 : e.host) !== null && i !== void 0 ? i : this.element, A) : this._$AH.handleEvent(A);
  }
}
let Rl = class {
  constructor(A, e, i) {
    this.element = A, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = i;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(A) {
    Lt(this, A);
  }
};
const tr = hi.litHtmlPolyfillSupport;
tr?.(_o, ys), ((so = hi.litHtmlVersions) !== null && so !== void 0 ? so : hi.litHtmlVersions = []).push("2.7.3");
const Ci = (t, A, e) => {
  var i, o;
  const s = (i = e?.renderBefore) !== null && i !== void 0 ? i : A;
  let r = s._$litPart$;
  if (r === void 0) {
    const n = (o = e?.renderBefore) !== null && o !== void 0 ? o : null;
    s._$litPart$ = r = new ys(A.insertBefore(me(), n), n, void 0, e ?? {});
  }
  return r._$AI(t), r;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var no, ao;
let F = class extends vt {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var A, e;
    const i = super.createRenderRoot();
    return (A = (e = this.renderOptions).renderBefore) !== null && A !== void 0 || (e.renderBefore = i.firstChild), i;
  }
  update(A) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(A), this._$Do = Ci(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var A;
    super.connectedCallback(), (A = this._$Do) === null || A === void 0 || A.setConnected(!0);
  }
  disconnectedCallback() {
    var A;
    super.disconnectedCallback(), (A = this._$Do) === null || A === void 0 || A.setConnected(!1);
  }
  render() {
    return GA;
  }
};
F.finalized = !0, F._$litElement$ = !0, (no = globalThis.litElementHydrateSupport) === null || no === void 0 || no.call(globalThis, { LitElement: F });
const er = globalThis.litElementPolyfillSupport;
er?.({ LitElement: F });
((ao = globalThis.litElementVersions) !== null && ao !== void 0 ? ao : globalThis.litElementVersions = []).push("3.3.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const H = (t) => (A) => typeof A == "function" ? ((e, i) => (customElements.define(e, i), i))(t, A) : ((e, i) => {
  const { kind: o, elements: s } = i;
  return { kind: o, elements: s, finisher(r) {
    customElements.define(e, r);
  } };
})(t, A);
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Ml = (t, A) => A.kind === "method" && A.descriptor && !("value" in A.descriptor) ? { ...A, finisher(e) {
  e.createProperty(A.key, t);
} } : { kind: "field", key: Symbol(), placement: "own", descriptor: {}, originalKey: A.key, initializer() {
  typeof A.initializer == "function" && (this[A.key] = A.initializer.call(this));
}, finisher(e) {
  e.createProperty(A.key, t);
} };
function y(t) {
  return (A, e) => e !== void 0 ? ((i, o, s) => {
    o.constructor.createProperty(s, i);
  })(t, A, e) : Ml(t, A);
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function _A(t) {
  return y({ ...t, state: !0 });
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const zt = ({ finisher: t, descriptor: A }) => (e, i) => {
  var o;
  if (i === void 0) {
    const s = (o = e.originalKey) !== null && o !== void 0 ? o : e.key, r = A != null ? { kind: "method", placement: "prototype", key: s, descriptor: A(e.key) } : { ...e, key: s };
    return t != null && (r.finisher = function(n) {
      t(n, s);
    }), r;
  }
  {
    const s = e.constructor;
    A !== void 0 && Object.defineProperty(e, i, A(i)), t?.(s, i);
  }
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function _l(t) {
  return zt({ finisher: (A, e) => {
    Object.assign(A.prototype[e], t);
  } });
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function dt(t, A) {
  return zt({ descriptor: (e) => {
    const i = { get() {
      var o, s;
      return (s = (o = this.renderRoot) === null || o === void 0 ? void 0 : o.querySelector(t)) !== null && s !== void 0 ? s : null;
    }, enumerable: !0, configurable: !0 };
    if (A) {
      const o = typeof e == "symbol" ? Symbol() : "__" + e;
      i.get = function() {
        var s, r;
        return this[o] === void 0 && (this[o] = (r = (s = this.renderRoot) === null || s === void 0 ? void 0 : s.querySelector(t)) !== null && r !== void 0 ? r : null), this[o];
      };
    }
    return i;
  } });
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function Ll(t) {
  return zt({ descriptor: (A) => ({ async get() {
    var e;
    return await this.updateComplete, (e = this.renderRoot) === null || e === void 0 ? void 0 : e.querySelector(t);
  }, enumerable: !0, configurable: !0 }) });
}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var lo;
const Jl = ((lo = window.HTMLSlotElement) === null || lo === void 0 ? void 0 : lo.prototype.assignedElements) != null ? (t, A) => t.assignedElements(A) : (t, A) => t.assignedNodes(A).filter((e) => e.nodeType === Node.ELEMENT_NODE);
function Jn(t) {
  const { slot: A, selector: e } = t ?? {};
  return zt({ descriptor: (i) => ({ get() {
    var o;
    const s = "slot" + (A ? `[name=${A}]` : ":not([name])"), r = (o = this.renderRoot) === null || o === void 0 ? void 0 : o.querySelector(s), n = r != null ? Jl(r, t) : [];
    return e ? n.filter((l) => l.matches(e)) : n;
  }, enumerable: !0, configurable: !0 }) });
}
function oi() {
}
function Yl(t, A) {
  return t != t ? A == A : t !== A || t && typeof t == "object" || typeof t == "function";
}
function Hl(t, ...A) {
  if (t == null)
    return oi;
  const e = t.subscribe(...A);
  return e.unsubscribe ? () => e.unsubscribe() : e;
}
function Tl(t) {
  let A;
  return Hl(t, (e) => A = e)(), A;
}
const Ol = [
  "allowfullscreen",
  "allowpaymentrequest",
  "async",
  "autofocus",
  "autoplay",
  "checked",
  "controls",
  "default",
  "defer",
  "disabled",
  "formnovalidate",
  "hidden",
  "inert",
  "ismap",
  "loop",
  "multiple",
  "muted",
  "nomodule",
  "novalidate",
  "open",
  "playsinline",
  "readonly",
  "required",
  "reversed",
  "selected"
];
[...Ol];
const ft = [];
function Yn(t, A) {
  return {
    subscribe: Kl(t, A).subscribe
  };
}
function Kl(t, A = oi) {
  let e;
  const i = /* @__PURE__ */ new Set();
  function o(n) {
    if (Yl(t, n) && (t = n, e)) {
      const l = !ft.length;
      for (const a of i)
        a[1](), ft.push(a, t);
      if (l) {
        for (let a = 0; a < ft.length; a += 2)
          ft[a][0](ft[a + 1]);
        ft.length = 0;
      }
    }
  }
  function s(n) {
    o(n(t));
  }
  function r(n, l = oi) {
    const a = [n, l];
    return i.add(a), i.size === 1 && (e = A(o) || oi), n(t), () => {
      i.delete(a), i.size === 0 && e && (e(), e = null);
    };
  }
  return { set: o, update: s, subscribe: r };
}
function $l() {
  this.__data__ = [], this.size = 0;
}
function Hn(t, A) {
  return t === A || t !== t && A !== A;
}
function Ti(t, A) {
  for (var e = t.length; e--; )
    if (Hn(t[e][0], A))
      return e;
  return -1;
}
var ql = Array.prototype, Pl = ql.splice;
function zl(t) {
  var A = this.__data__, e = Ti(A, t);
  if (e < 0)
    return !1;
  var i = A.length - 1;
  return e == i ? A.pop() : Pl.call(A, e, 1), --this.size, !0;
}
function Vl(t) {
  var A = this.__data__, e = Ti(A, t);
  return e < 0 ? void 0 : A[e][1];
}
function jl(t) {
  return Ti(this.__data__, t) > -1;
}
function Zl(t, A) {
  var e = this.__data__, i = Ti(e, t);
  return i < 0 ? (++this.size, e.push([t, A])) : e[i][1] = A, this;
}
function TA(t) {
  var A = -1, e = t == null ? 0 : t.length;
  for (this.clear(); ++A < e; ) {
    var i = t[A];
    this.set(i[0], i[1]);
  }
}
TA.prototype.clear = $l;
TA.prototype.delete = zl;
TA.prototype.get = Vl;
TA.prototype.has = jl;
TA.prototype.set = Zl;
function Wl() {
  this.__data__ = new TA(), this.size = 0;
}
function Xl(t) {
  var A = this.__data__, e = A.delete(t);
  return this.size = A.size, e;
}
function Ag(t) {
  return this.__data__.get(t);
}
function tg(t) {
  return this.__data__.has(t);
}
var eg = typeof global == "object" && global && global.Object === Object && global;
const Tn = eg;
var ig = typeof self == "object" && self && self.Object === Object && self, og = Tn || ig || Function("return this")();
const OA = og;
var sg = OA.Symbol;
const Jt = sg;
var On = Object.prototype, rg = On.hasOwnProperty, ng = On.toString, se = Jt ? Jt.toStringTag : void 0;
function ag(t) {
  var A = rg.call(t, se), e = t[se];
  try {
    t[se] = void 0;
    var i = !0;
  } catch {
  }
  var o = ng.call(t);
  return i && (A ? t[se] = e : delete t[se]), o;
}
var lg = Object.prototype, gg = lg.toString;
function Ig(t) {
  return gg.call(t);
}
var cg = "[object Null]", hg = "[object Undefined]", ir = Jt ? Jt.toStringTag : void 0;
function Me(t) {
  return t == null ? t === void 0 ? hg : cg : ir && ir in Object(t) ? ag(t) : Ig(t);
}
function Kn(t) {
  var A = typeof t;
  return t != null && (A == "object" || A == "function");
}
var Cg = "[object AsyncFunction]", dg = "[object Function]", Bg = "[object GeneratorFunction]", Qg = "[object Proxy]";
function $n(t) {
  if (!Kn(t))
    return !1;
  var A = Me(t);
  return A == dg || A == Bg || A == Cg || A == Qg;
}
var Eg = OA["__core-js_shared__"];
const go = Eg;
var or = function() {
  var t = /[^.]+$/.exec(go && go.keys && go.keys.IE_PROTO || "");
  return t ? "Symbol(src)_1." + t : "";
}();
function ug(t) {
  return !!or && or in t;
}
var pg = Function.prototype, fg = pg.toString;
function Bt(t) {
  if (t != null) {
    try {
      return fg.call(t);
    } catch {
    }
    try {
      return t + "";
    } catch {
    }
  }
  return "";
}
var yg = /[\\^$.*+?()[\]{}|]/g, wg = /^\[object .+?Constructor\]$/, mg = Function.prototype, vg = Object.prototype, bg = mg.toString, Dg = vg.hasOwnProperty, kg = RegExp(
  "^" + bg.call(Dg).replace(yg, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function Sg(t) {
  if (!Kn(t) || ug(t))
    return !1;
  var A = $n(t) ? kg : wg;
  return A.test(Bt(t));
}
function xg(t, A) {
  return t?.[A];
}
function Vt(t, A) {
  var e = xg(t, A);
  return Sg(e) ? e : void 0;
}
var Ng = Vt(OA, "Map");
const be = Ng;
var Ug = Vt(Object, "create");
const De = Ug;
function Fg() {
  this.__data__ = De ? De(null) : {}, this.size = 0;
}
function Gg(t) {
  var A = this.has(t) && delete this.__data__[t];
  return this.size -= A ? 1 : 0, A;
}
var Rg = "__lodash_hash_undefined__", Mg = Object.prototype, _g = Mg.hasOwnProperty;
function Lg(t) {
  var A = this.__data__;
  if (De) {
    var e = A[t];
    return e === Rg ? void 0 : e;
  }
  return _g.call(A, t) ? A[t] : void 0;
}
var Jg = Object.prototype, Yg = Jg.hasOwnProperty;
function Hg(t) {
  var A = this.__data__;
  return De ? A[t] !== void 0 : Yg.call(A, t);
}
var Tg = "__lodash_hash_undefined__";
function Og(t, A) {
  var e = this.__data__;
  return this.size += this.has(t) ? 0 : 1, e[t] = De && A === void 0 ? Tg : A, this;
}
function gt(t) {
  var A = -1, e = t == null ? 0 : t.length;
  for (this.clear(); ++A < e; ) {
    var i = t[A];
    this.set(i[0], i[1]);
  }
}
gt.prototype.clear = Fg;
gt.prototype.delete = Gg;
gt.prototype.get = Lg;
gt.prototype.has = Hg;
gt.prototype.set = Og;
function Kg() {
  this.size = 0, this.__data__ = {
    hash: new gt(),
    map: new (be || TA)(),
    string: new gt()
  };
}
function $g(t) {
  var A = typeof t;
  return A == "string" || A == "number" || A == "symbol" || A == "boolean" ? t !== "__proto__" : t === null;
}
function Oi(t, A) {
  var e = t.__data__;
  return $g(A) ? e[typeof A == "string" ? "string" : "hash"] : e.map;
}
function qg(t) {
  var A = Oi(this, t).delete(t);
  return this.size -= A ? 1 : 0, A;
}
function Pg(t) {
  return Oi(this, t).get(t);
}
function zg(t) {
  return Oi(this, t).has(t);
}
function Vg(t, A) {
  var e = Oi(this, t), i = e.size;
  return e.set(t, A), this.size += e.size == i ? 0 : 1, this;
}
function Qt(t) {
  var A = -1, e = t == null ? 0 : t.length;
  for (this.clear(); ++A < e; ) {
    var i = t[A];
    this.set(i[0], i[1]);
  }
}
Qt.prototype.clear = Kg;
Qt.prototype.delete = qg;
Qt.prototype.get = Pg;
Qt.prototype.has = zg;
Qt.prototype.set = Vg;
var jg = 200;
function Zg(t, A) {
  var e = this.__data__;
  if (e instanceof TA) {
    var i = e.__data__;
    if (!be || i.length < jg - 1)
      return i.push([t, A]), this.size = ++e.size, this;
    e = this.__data__ = new Qt(i);
  }
  return e.set(t, A), this.size = e.size, this;
}
function PA(t) {
  var A = this.__data__ = new TA(t);
  this.size = A.size;
}
PA.prototype.clear = Wl;
PA.prototype.delete = Xl;
PA.prototype.get = Ag;
PA.prototype.has = tg;
PA.prototype.set = Zg;
var Wg = "__lodash_hash_undefined__";
function Xg(t) {
  return this.__data__.set(t, Wg), this;
}
function AI(t) {
  return this.__data__.has(t);
}
function di(t) {
  var A = -1, e = t == null ? 0 : t.length;
  for (this.__data__ = new Qt(); ++A < e; )
    this.add(t[A]);
}
di.prototype.add = di.prototype.push = Xg;
di.prototype.has = AI;
function tI(t, A) {
  for (var e = -1, i = t == null ? 0 : t.length; ++e < i; )
    if (A(t[e], e, t))
      return !0;
  return !1;
}
function eI(t, A) {
  return t.has(A);
}
var iI = 1, oI = 2;
function qn(t, A, e, i, o, s) {
  var r = e & iI, n = t.length, l = A.length;
  if (n != l && !(r && l > n))
    return !1;
  var a = s.get(t), h = s.get(A);
  if (a && h)
    return a == A && h == t;
  var g = -1, c = !0, C = e & oI ? new di() : void 0;
  for (s.set(t, A), s.set(A, t); ++g < n; ) {
    var B = t[g], Q = A[g];
    if (i)
      var E = r ? i(Q, B, g, A, t, s) : i(B, Q, g, t, A, s);
    if (E !== void 0) {
      if (E)
        continue;
      c = !1;
      break;
    }
    if (C) {
      if (!tI(A, function(f, w) {
        if (!eI(C, w) && (B === f || o(B, f, e, i, s)))
          return C.push(w);
      })) {
        c = !1;
        break;
      }
    } else if (!(B === Q || o(B, Q, e, i, s))) {
      c = !1;
      break;
    }
  }
  return s.delete(t), s.delete(A), c;
}
var sI = OA.Uint8Array;
const sr = sI;
function rI(t) {
  var A = -1, e = Array(t.size);
  return t.forEach(function(i, o) {
    e[++A] = [o, i];
  }), e;
}
function nI(t) {
  var A = -1, e = Array(t.size);
  return t.forEach(function(i) {
    e[++A] = i;
  }), e;
}
var aI = 1, lI = 2, gI = "[object Boolean]", II = "[object Date]", cI = "[object Error]", hI = "[object Map]", CI = "[object Number]", dI = "[object RegExp]", BI = "[object Set]", QI = "[object String]", EI = "[object Symbol]", uI = "[object ArrayBuffer]", pI = "[object DataView]", rr = Jt ? Jt.prototype : void 0, Io = rr ? rr.valueOf : void 0;
function fI(t, A, e, i, o, s, r) {
  switch (e) {
    case pI:
      if (t.byteLength != A.byteLength || t.byteOffset != A.byteOffset)
        return !1;
      t = t.buffer, A = A.buffer;
    case uI:
      return !(t.byteLength != A.byteLength || !s(new sr(t), new sr(A)));
    case gI:
    case II:
    case CI:
      return Hn(+t, +A);
    case cI:
      return t.name == A.name && t.message == A.message;
    case dI:
    case QI:
      return t == A + "";
    case hI:
      var n = rI;
    case BI:
      var l = i & aI;
      if (n || (n = nI), t.size != A.size && !l)
        return !1;
      var a = r.get(t);
      if (a)
        return a == A;
      i |= lI, r.set(t, A);
      var h = qn(n(t), n(A), i, o, s, r);
      return r.delete(t), h;
    case EI:
      if (Io)
        return Io.call(t) == Io.call(A);
  }
  return !1;
}
function yI(t, A) {
  for (var e = -1, i = A.length, o = t.length; ++e < i; )
    t[o + e] = A[e];
  return t;
}
var wI = Array.isArray;
const Bi = wI;
function mI(t, A, e) {
  var i = A(t);
  return Bi(t) ? i : yI(i, e(t));
}
function vI(t, A) {
  for (var e = -1, i = t == null ? 0 : t.length, o = 0, s = []; ++e < i; ) {
    var r = t[e];
    A(r, e, t) && (s[o++] = r);
  }
  return s;
}
function bI() {
  return [];
}
var DI = Object.prototype, kI = DI.propertyIsEnumerable, nr = Object.getOwnPropertySymbols, SI = nr ? function(t) {
  return t == null ? [] : (t = Object(t), vI(nr(t), function(A) {
    return kI.call(t, A);
  }));
} : bI;
const xI = SI;
function NI(t, A) {
  for (var e = -1, i = Array(t); ++e < t; )
    i[e] = A(e);
  return i;
}
function ke(t) {
  return t != null && typeof t == "object";
}
var UI = "[object Arguments]";
function ar(t) {
  return ke(t) && Me(t) == UI;
}
var Pn = Object.prototype, FI = Pn.hasOwnProperty, GI = Pn.propertyIsEnumerable, RI = ar(function() {
  return arguments;
}()) ? ar : function(t) {
  return ke(t) && FI.call(t, "callee") && !GI.call(t, "callee");
};
const MI = RI;
function _I() {
  return !1;
}
var zn = typeof exports == "object" && exports && !exports.nodeType && exports, lr = zn && typeof module == "object" && module && !module.nodeType && module, LI = lr && lr.exports === zn, gr = LI ? OA.Buffer : void 0, JI = gr ? gr.isBuffer : void 0, YI = JI || _I;
const Lo = YI;
var HI = 9007199254740991, TI = /^(?:0|[1-9]\d*)$/;
function OI(t, A) {
  var e = typeof t;
  return A = A ?? HI, !!A && (e == "number" || e != "symbol" && TI.test(t)) && t > -1 && t % 1 == 0 && t < A;
}
var KI = 9007199254740991;
function Vn(t) {
  return typeof t == "number" && t > -1 && t % 1 == 0 && t <= KI;
}
var $I = "[object Arguments]", qI = "[object Array]", PI = "[object Boolean]", zI = "[object Date]", VI = "[object Error]", jI = "[object Function]", ZI = "[object Map]", WI = "[object Number]", XI = "[object Object]", Ac = "[object RegExp]", tc = "[object Set]", ec = "[object String]", ic = "[object WeakMap]", oc = "[object ArrayBuffer]", sc = "[object DataView]", rc = "[object Float32Array]", nc = "[object Float64Array]", ac = "[object Int8Array]", lc = "[object Int16Array]", gc = "[object Int32Array]", Ic = "[object Uint8Array]", cc = "[object Uint8ClampedArray]", hc = "[object Uint16Array]", Cc = "[object Uint32Array]", _ = {};
_[rc] = _[nc] = _[ac] = _[lc] = _[gc] = _[Ic] = _[cc] = _[hc] = _[Cc] = !0;
_[$I] = _[qI] = _[oc] = _[PI] = _[sc] = _[zI] = _[VI] = _[jI] = _[ZI] = _[WI] = _[XI] = _[Ac] = _[tc] = _[ec] = _[ic] = !1;
function dc(t) {
  return ke(t) && Vn(t.length) && !!_[Me(t)];
}
function Bc(t) {
  return function(A) {
    return t(A);
  };
}
var jn = typeof exports == "object" && exports && !exports.nodeType && exports, Qe = jn && typeof module == "object" && module && !module.nodeType && module, Qc = Qe && Qe.exports === jn, co = Qc && Tn.process, Ec = function() {
  try {
    var t = Qe && Qe.require && Qe.require("util").types;
    return t || co && co.binding && co.binding("util");
  } catch {
  }
}();
const Ir = Ec;
var cr = Ir && Ir.isTypedArray, uc = cr ? Bc(cr) : dc;
const Zn = uc;
var pc = Object.prototype, fc = pc.hasOwnProperty;
function yc(t, A) {
  var e = Bi(t), i = !e && MI(t), o = !e && !i && Lo(t), s = !e && !i && !o && Zn(t), r = e || i || o || s, n = r ? NI(t.length, String) : [], l = n.length;
  for (var a in t)
    (A || fc.call(t, a)) && !(r && // Safari 9 has enumerable `arguments.length` in strict mode.
    (a == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    o && (a == "offset" || a == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    s && (a == "buffer" || a == "byteLength" || a == "byteOffset") || // Skip index properties.
    OI(a, l))) && n.push(a);
  return n;
}
var wc = Object.prototype;
function mc(t) {
  var A = t && t.constructor, e = typeof A == "function" && A.prototype || wc;
  return t === e;
}
function vc(t, A) {
  return function(e) {
    return t(A(e));
  };
}
var bc = vc(Object.keys, Object);
const Dc = bc;
var kc = Object.prototype, Sc = kc.hasOwnProperty;
function xc(t) {
  if (!mc(t))
    return Dc(t);
  var A = [];
  for (var e in Object(t))
    Sc.call(t, e) && e != "constructor" && A.push(e);
  return A;
}
function Nc(t) {
  return t != null && Vn(t.length) && !$n(t);
}
function Uc(t) {
  return Nc(t) ? yc(t) : xc(t);
}
function hr(t) {
  return mI(t, Uc, xI);
}
var Fc = 1, Gc = Object.prototype, Rc = Gc.hasOwnProperty;
function Mc(t, A, e, i, o, s) {
  var r = e & Fc, n = hr(t), l = n.length, a = hr(A), h = a.length;
  if (l != h && !r)
    return !1;
  for (var g = l; g--; ) {
    var c = n[g];
    if (!(r ? c in A : Rc.call(A, c)))
      return !1;
  }
  var C = s.get(t), B = s.get(A);
  if (C && B)
    return C == A && B == t;
  var Q = !0;
  s.set(t, A), s.set(A, t);
  for (var E = r; ++g < l; ) {
    c = n[g];
    var f = t[c], w = A[c];
    if (i)
      var v = r ? i(w, f, c, A, t, s) : i(f, w, c, t, A, s);
    if (!(v === void 0 ? f === w || o(f, w, e, i, s) : v)) {
      Q = !1;
      break;
    }
    E || (E = c == "constructor");
  }
  if (Q && !E) {
    var x = t.constructor, N = A.constructor;
    x != N && "constructor" in t && "constructor" in A && !(typeof x == "function" && x instanceof x && typeof N == "function" && N instanceof N) && (Q = !1);
  }
  return s.delete(t), s.delete(A), Q;
}
var _c = Vt(OA, "DataView");
const Jo = _c;
var Lc = Vt(OA, "Promise");
const Yo = Lc;
var Jc = Vt(OA, "Set");
const Ho = Jc;
var Yc = Vt(OA, "WeakMap");
const To = Yc;
var Cr = "[object Map]", Hc = "[object Object]", dr = "[object Promise]", Br = "[object Set]", Qr = "[object WeakMap]", Er = "[object DataView]", Tc = Bt(Jo), Oc = Bt(be), Kc = Bt(Yo), $c = Bt(Ho), qc = Bt(To), it = Me;
(Jo && it(new Jo(new ArrayBuffer(1))) != Er || be && it(new be()) != Cr || Yo && it(Yo.resolve()) != dr || Ho && it(new Ho()) != Br || To && it(new To()) != Qr) && (it = function(t) {
  var A = Me(t), e = A == Hc ? t.constructor : void 0, i = e ? Bt(e) : "";
  if (i)
    switch (i) {
      case Tc:
        return Er;
      case Oc:
        return Cr;
      case Kc:
        return dr;
      case $c:
        return Br;
      case qc:
        return Qr;
    }
  return A;
});
const ur = it;
var Pc = 1, pr = "[object Arguments]", fr = "[object Array]", Oe = "[object Object]", zc = Object.prototype, yr = zc.hasOwnProperty;
function Vc(t, A, e, i, o, s) {
  var r = Bi(t), n = Bi(A), l = r ? fr : ur(t), a = n ? fr : ur(A);
  l = l == pr ? Oe : l, a = a == pr ? Oe : a;
  var h = l == Oe, g = a == Oe, c = l == a;
  if (c && Lo(t)) {
    if (!Lo(A))
      return !1;
    r = !0, h = !1;
  }
  if (c && !h)
    return s || (s = new PA()), r || Zn(t) ? qn(t, A, e, i, o, s) : fI(t, A, l, e, i, o, s);
  if (!(e & Pc)) {
    var C = h && yr.call(t, "__wrapped__"), B = g && yr.call(A, "__wrapped__");
    if (C || B) {
      var Q = C ? t.value() : t, E = B ? A.value() : A;
      return s || (s = new PA()), o(Q, E, e, i, s);
    }
  }
  return c ? (s || (s = new PA()), Mc(t, A, e, i, o, s)) : !1;
}
function Wn(t, A, e, i, o) {
  return t === A ? !0 : t == null || A == null || !ke(t) && !ke(A) ? t !== t && A !== A : Vc(t, A, e, i, Wn, o);
}
function Xn(t, A) {
  return Wn(t, A);
}
class Et {
  constructor(A, e, i) {
    this.host = A, this.getStore = e, this.resubscribeIfChanged = i, A.addController(this);
  }
  hostUpdate() {
    const A = this.store();
    this.shouldResubscribe(A) && (this.unsubscribe(), A && (this._unsubscribe = A.subscribe((e) => {
      this.value = e, this.host.requestUpdate();
    })), this._previousStore = A);
  }
  hostDisconnected() {
    this.unsubscribe();
  }
  unsubscribe() {
    this._unsubscribe && (this._unsubscribe(), this._unsubscribe = void 0);
  }
  shouldResubscribe(A) {
    if (this.resubscribeIfChanged) {
      const e = this.resubscribeIfChanged(), i = this._previousArgs;
      return this._previousArgs = e, !Xn(e, i);
    } else
      return !(A === this._previousStore || A && this._previousStore && Tl(A) === this.value);
  }
  store() {
    return this.getStore();
  }
}
const Aa = new Array(32).fill(void 0);
Aa.push(void 0, null, !0, !1);
Aa.length;
const ho = new TextEncoder("utf-8");
ho.encodeInto;
const jc = new TextDecoder("utf-8", { ignoreBOM: !0, fatal: !0 });
jc.decode();
const Zc = [62, 0, 0, 0, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 0, 0, 0, 0, 0, 0, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51];
function Ke(t) {
  return Zc[t - 43];
}
function Wc(t) {
  let A = t.endsWith("==") ? 2 : t.endsWith("=") ? 1 : 0, e = t.length, i = new Uint8Array(3 * (e / 4)), o;
  for (let s = 0, r = 0; s < e; s += 4, r += 3)
    o = Ke(t.charCodeAt(s)) << 18 | Ke(t.charCodeAt(s + 1)) << 12 | Ke(t.charCodeAt(s + 2)) << 6 | Ke(t.charCodeAt(s + 3)), i[r] = o >> 16, i[r + 1] = o >> 8 & 255, i[r + 2] = o & 255;
  return i.subarray(0, i.length - A);
}
Wc("AGFzbQEAAAABrAEYYAJ/fwF/YAN/f38Bf2ABfwF/YAJ/fwBgAX8AYAN/f38AYAABf2AFf39/f38AYAR/f39/AGAAAGABfwF+YAZ/f39/f38AYAR/f39/AX9gBX9/f39/AX9gBn9/f39/fwF/YAl/f39/f39+fn4AYAd/f39/f39/AX9gA35/fwF/YAV/f35/fwBgBH9+f38AYAV/f3x/fwBgBH98f38AYAV/f31/fwBgBH99f38AArAJJAN3YmcaX193YmluZGdlbl9vYmplY3RfZHJvcF9yZWYABAN3YmcVX193YmluZGdlbl9zdHJpbmdfZ2V0AAMDd2JnFF9fd2JpbmRnZW5faXNfb2JqZWN0AAIDd2JnFF9fd2JpbmRnZW5fZXJyb3JfbmV3AAADd2JnEl9fd2JpbmRnZW5faXNfbnVsbAACA3diZxdfX3diaW5kZ2VuX2lzX3VuZGVmaW5lZAACA3diZxZfX3diaW5kZ2VuX2Jvb2xlYW5fZ2V0AAIDd2JnFV9fd2JpbmRnZW5fbnVtYmVyX2dldAADA3diZx1fX3diZ19TdHJpbmdfOWFhMTdkNjI0OGQ1MTlhNQADA3diZxpfX3diZ19nZXRfNzIzZjgzYmEwYzM0ODcxYQAAA3diZxtfX3diaW5kZ2VuX29iamVjdF9jbG9uZV9yZWYAAgN3YmcWX193YmluZGdlbl9pc19mdW5jdGlvbgACA3diZxtfX3diZ19uZXh0XzU3OWU1ODNkMzM1NjZhODYAAgN3YmcbX193YmdfbmV4dF9hYWVmN2M4YWE1ZTIxMmFjAAIDd2JnG19fd2JnX2RvbmVfMWI3M2IwNjcyZTE1ZjIzNAACA3diZxxfX3diZ192YWx1ZV8xY2NjMzZiYzAzNDYyZDcxAAIDd2JnH19fd2JnX2l0ZXJhdG9yXzZmOWQ0ZjI4ODQ1ZjQyNmMABgN3YmcaX193YmdfZ2V0Xzc2NTIwMTU0NGEyYjY4NjkAAAN3YmcbX193YmdfY2FsbF85N2FlOWQ4NjQ1ZGMzODhiAAADd2JnFV9fd2JpbmRnZW5fc3RyaW5nX25ldwAAA3diZx5fX3diZ19pc0FycmF5XzI3YzQ2YzY3ZjQ5OGUxNWQAAgN3YmctX193YmdfaW5zdGFuY2VvZl9BcnJheUJ1ZmZlcl9lNWU0OGY0NzYyYzU2MTBiAAIDd2JnHV9fd2JnX3ZhbHVlc19lNDI2NzFhY2JmMTFlYzA0AAIDd2JnGl9fd2JnX25ld184ZDJhZjAwYmMxZTMyOWVlAAADd2JnJF9fd2JnX2lzU2FmZUludGVnZXJfZGZhMDU5M2U4ZDdhYzM1YQACA3diZx1fX3diZ19idWZmZXJfM2YzZDc2NGQ0NzQ3ZDU2NAACA3diZxpfX3diZ19uZXdfOGMzZjAwNTIyNzJhNDU3YQACA3diZxpfX3diZ19zZXRfODNkYjk2OTBmOTM1M2U3OQAFA3diZx1fX3diZ19sZW5ndGhfOWUxYWUxOTAwY2IwZmJkNQACA3diZyxfX3diZ19pbnN0YW5jZW9mX1VpbnQ4QXJyYXlfOTcxZWVkYTY5ZWI3NTAwMwACA3diZxpfX3diZ19uZXdfYWJkYTc2ZTg4M2JhOGE1ZgAGA3diZxxfX3diZ19zdGFja182NTgyNzlmZTQ0NTQxY2Y2AAMDd2JnHF9fd2JnX2Vycm9yX2Y4NTE2NjdhZjcxYmNmYzYAAwN3YmcXX193YmluZGdlbl9kZWJ1Z19zdHJpbmcAAwN3YmcQX193YmluZGdlbl90aHJvdwADA3diZxFfX3diaW5kZ2VuX21lbW9yeQAGA9IB0AECAAQBAAABAwUOCAEBAAMFAQMDAQAPCwALAhAAAAARAAEDBAAGAwIHAAACAgAFBQUDDAcICAMCAwsDAAMAAwIGBwABAAAFAAADBQAAAAADAAMAAAAAAAAAAAQJAQEBAQUDAA0JCQMCBAAAAAAAAwUFAwQEBAEFAA4DABIUBxYNAwQIAAECAAIDAAEAAAwAAwIAAAcAAAQAAAMCAAICAgICAgMCAAAFBQUAAwEAAAIAAAkAAAICAgIDAQABAQEAAAAAAAAAAAIGAAACAgMKCgoEBAcBcAGJAYkBBQMBABEGCQF/AUGAgMAACweSAQcGbWVtb3J5AgAMaGFzaFpvbWVDYWxsAFsRX193YmluZGdlbl9tYWxsb2MAigESX193YmluZGdlbl9yZWFsbG9jAJgBH19fd2JpbmRnZW5fYWRkX3RvX3N0YWNrX3BvaW50ZXIA0QEPX193YmluZGdlbl9mcmVlALIBFF9fd2JpbmRnZW5fZXhuX3N0b3JlALkBCfABAQBBAQuIAfMBugHiAdIB5QHkAecB4QHmAeMBtQEotwHMAaQBggFBdvMBrgGkAYIBQfMBUGCkAYIBQfMBmgHzAfMB8wHvAe8B7wGRAZEBgQFAbl7zAYEBQG+1AaQBggFBd/MBT/MBjwGsAaIBXKABogGbAacBpQGgAaABoQGfAZ4B8wGBAUBwpAGCAUF48wGxAZYB8wGNAfMBqQFlefMBqQHVAbcBpgHPAZ0BhQFHuwFy8wF/P3GOAdYBpAHxAfABlwFJWYQBvAHyAYsBkAHzAYABxwFzyAFntAG+AbUBamg78wHyAdABN016zgFMdd0BCquLBdAB3yECD38BfiMAQRBrIggkAAJAAkAgAEH1AU8EQEEIQQgQrwEhAkEUQQgQrwEhA0EQQQgQrwEhBUEAQRBBCBCvAUECdGsiBEGAgHwgBSACIANqamtBd3FBA2siAiACIARLGyAATQ0CIABBBGpBCBCvASEEQZTnwAAoAgBFDQFBACAEayEBAkACQAJ/QQAgBEGAAkkNABpBHyAEQf///wdLDQAaIARBBiAEQQh2ZyIAa3ZBAXEgAEEBdGtBPmoLIgdBAnRBoOnAAGooAgAiAARAIAQgBxCqAXQhBkEAIQNBACECA0ACQCAAENcBIgUgBEkNACAFIARrIgUgAU8NACAAIQIgBSIBDQBBACEBDAMLIABBFGooAgAiBSADIAUgACAGQR12QQRxakEQaigCACIARxsgAyAFGyEDIAZBAXQhBiAADQALIAMEQCADIQAMAgsgAg0CC0EAIQJBASAHdBCzAUGU58AAKAIAcSIARQ0DIAAQwwFoQQJ0QaDpwABqKAIAIgBFDQMLA0AgACACIAAQ1wEiAiAETyACIARrIgMgAUlxIgUbIQIgAyABIAUbIQEgABCoASIADQALIAJFDQILIARBoOrAACgCACIATSABIAAgBGtPcQ0BIAIgBBDrASEAIAIQRgJAQRBBCBCvASABTQRAIAIgBBDFASAAIAEQqwEgAUGAAk8EQCAAIAEQRQwCCyABQXhxQZjnwABqIQMCf0GQ58AAKAIAIgVBASABQQN2dCIBcQRAIAMoAggMAQtBkOfAACABIAVyNgIAIAMLIQEgAyAANgIIIAEgADYCDCAAIAM2AgwgACABNgIIDAELIAIgASAEahCjAQsgAhDtASIBRQ0BDAILQRAgAEEEakEQQQgQrwFBBWsgAEsbQQgQrwEhBAJAAkACQAJ/AkACQEGQ58AAKAIAIgUgBEEDdiIBdiIAQQNxRQRAIARBoOrAACgCAE0NByAADQFBlOfAACgCACIARQ0HIAAQwwFoQQJ0QaDpwABqKAIAIgIQ1wEgBGshASACEKgBIgAEQANAIAAQ1wEgBGsiAyABIAEgA0siAxshASAAIAIgAxshAiAAEKgBIgANAAsLIAIgBBDrASEFIAIQRkEQQQgQrwEgAUsNBSACIAQQxQEgBSABEKsBQaDqwAAoAgAiBkUNBCAGQXhxQZjnwABqIQBBqOrAACgCACEDQZDnwAAoAgAiB0EBIAZBA3Z0IgZxRQ0CIAAoAggMAwsCQCAAQX9zQQFxIAFqIgBBA3QiA0Gg58AAaigCACIBQQhqKAIAIgIgA0GY58AAaiIDRwRAIAIgAzYCDCADIAI2AggMAQtBkOfAACAFQX4gAHdxNgIACyABIABBA3QQowEgARDtASEBDAcLAkBBASABQR9xIgF0ELMBIAAgAXRxEMMBaCIAQQN0IgNBoOfAAGooAgAiAkEIaigCACIBIANBmOfAAGoiA0cEQCABIAM2AgwgAyABNgIIDAELQZDnwABBkOfAACgCAEF+IAB3cTYCAAsgAiAEEMUBIAIgBBDrASIFIABBA3QgBGsiBBCrAUGg6sAAKAIAIgMEQCADQXhxQZjnwABqIQBBqOrAACgCACEBAn9BkOfAACgCACIGQQEgA0EDdnQiA3EEQCAAKAIIDAELQZDnwAAgAyAGcjYCACAACyEDIAAgATYCCCADIAE2AgwgASAANgIMIAEgAzYCCAtBqOrAACAFNgIAQaDqwAAgBDYCACACEO0BIQEMBgtBkOfAACAGIAdyNgIAIAALIQYgACADNgIIIAYgAzYCDCADIAA2AgwgAyAGNgIIC0Go6sAAIAU2AgBBoOrAACABNgIADAELIAIgASAEahCjAQsgAhDtASIBDQELAkACQAJAAkACQAJAAkACQCAEQaDqwAAoAgAiAUsEQEGk6sAAKAIAIgAgBEsNAkEIQQgQrwEgBGpBFEEIEK8BakEQQQgQrwFqQYCABBCvASIBQRB2QAAhACAIQQA2AgggCEEAIAFBgIB8cSAAQX9GIgEbNgIEIAhBACAAQRB0IAEbNgIAIAgoAgAiAQ0BQQAhAQwJC0Go6sAAKAIAIQBBEEEIEK8BIAEgBGsiAUsEQEGo6sAAQQA2AgBBoOrAACgCACEBQaDqwABBADYCACAAIAEQowEgABDtASEBDAkLIAAgBBDrASECQaDqwAAgATYCAEGo6sAAIAI2AgAgAiABEKsBIAAgBBDFASAAEO0BIQEMCAsgCCgCCCEFQbDqwAAgCCgCBCIDQbDqwAAoAgBqIgA2AgBBtOrAAEG06sAAKAIAIgIgACAAIAJJGzYCAAJAAkBBrOrAACgCAARAQbjqwAAhAANAIAAQxgEgAUYNAiAAKAIIIgANAAsMAgtBzOrAACgCACIARSAAIAFLcg0DDAcLIAAQ2QENACAAENoBIAVHDQAgACgCACICQazqwAAoAgAiBk0EfyACIAAoAgRqIAZLBUEACw0DC0HM6sAAQczqwAAoAgAiACABIAAgAUkbNgIAIAEgA2ohAkG46sAAIQACQAJAA0AgAiAAKAIARwRAIAAoAggiAA0BDAILCyAAENkBDQAgABDaASAFRg0BC0Gs6sAAKAIAIQJBuOrAACEAAkADQCACIAAoAgBPBEAgABDGASACSw0CCyAAKAIIIgANAAtBACEACyACIAAQxgEiD0EUQQgQrwEiDmtBF2siABDtASIGQQgQrwEgBmsgAGoiACAAQRBBCBCvASACakkbIgYQ7QEhByAGIA4Q6wEhAEEIQQgQrwEhCUEUQQgQrwEhC0EQQQgQrwEhDEGs6sAAIAEgARDtASIKQQgQrwEgCmsiDRDrASIKNgIAQaTqwAAgA0EIaiAMIAkgC2pqIA1qayIJNgIAIAogCUEBcjYCBEEIQQgQrwEhC0EUQQgQrwEhDEEQQQgQrwEhDSAKIAkQ6wEgDSAMIAtBCGtqajYCBEHI6sAAQYCAgAE2AgAgBiAOEMUBQbjqwAApAgAhECAHQQhqQcDqwAApAgA3AgAgByAQNwIAQcTqwAAgBTYCAEG86sAAIAM2AgBBuOrAACABNgIAQcDqwAAgBzYCAANAIABBBBDrASAAQQc2AgQiAEEEaiAPSQ0ACyACIAZGDQcgAiAGIAJrIgAgAiAAEOsBEJkBIABBgAJPBEAgAiAAEEUMCAsgAEF4cUGY58AAaiEBAn9BkOfAACgCACIDQQEgAEEDdnQiAHEEQCABKAIIDAELQZDnwAAgACADcjYCACABCyEAIAEgAjYCCCAAIAI2AgwgAiABNgIMIAIgADYCCAwHCyAAKAIAIQUgACABNgIAIAAgACgCBCADajYCBCABEO0BIgBBCBCvASECIAUQ7QEiA0EIEK8BIQYgASACIABraiICIAQQ6wEhASACIAQQxQEgBSAGIANraiIAIAIgBGprIQRBrOrAACgCACAARwRAIABBqOrAACgCAEYNBCAAKAIEQQNxQQFHDQUCQCAAENcBIgNBgAJPBEAgABBGDAELIABBDGooAgAiBSAAQQhqKAIAIgZHBEAgBiAFNgIMIAUgBjYCCAwBC0GQ58AAQZDnwAAoAgBBfiADQQN2d3E2AgALIAMgBGohBCAAIAMQ6wEhAAwFC0Gs6sAAIAE2AgBBpOrAAEGk6sAAKAIAIARqIgA2AgAgASAAQQFyNgIEIAIQ7QEhAQwHC0Gk6sAAIAAgBGsiATYCAEGs6sAAQazqwAAoAgAiACAEEOsBIgI2AgAgAiABQQFyNgIEIAAgBBDFASAAEO0BIQEMBgtBzOrAACABNgIADAMLIAAgACgCBCADajYCBEGk6sAAKAIAIANqIQFBrOrAACgCACIAIAAQ7QEiAEEIEK8BIABrIgIQ6wEhAEGk6sAAIAEgAmsiATYCAEGs6sAAIAA2AgAgACABQQFyNgIEQQhBCBCvASECQRRBCBCvASEDQRBBCBCvASEFIAAgARDrASAFIAMgAkEIa2pqNgIEQcjqwABBgICAATYCAAwDC0Go6sAAIAE2AgBBoOrAAEGg6sAAKAIAIARqIgA2AgAgASAAEKsBIAIQ7QEhAQwDCyABIAQgABCZASAEQYACTwRAIAEgBBBFIAIQ7QEhAQwDCyAEQXhxQZjnwABqIQACf0GQ58AAKAIAIgNBASAEQQN2dCIFcQRAIAAoAggMAQtBkOfAACADIAVyNgIAIAALIQMgACABNgIIIAMgATYCDCABIAA2AgwgASADNgIIIAIQ7QEhAQwCC0HQ6sAAQf8fNgIAQcTqwAAgBTYCAEG86sAAIAM2AgBBuOrAACABNgIAQaTnwABBmOfAADYCAEGs58AAQaDnwAA2AgBBoOfAAEGY58AANgIAQbTnwABBqOfAADYCAEGo58AAQaDnwAA2AgBBvOfAAEGw58AANgIAQbDnwABBqOfAADYCAEHE58AAQbjnwAA2AgBBuOfAAEGw58AANgIAQcznwABBwOfAADYCAEHA58AAQbjnwAA2AgBB1OfAAEHI58AANgIAQcjnwABBwOfAADYCAEHc58AAQdDnwAA2AgBB0OfAAEHI58AANgIAQeTnwABB2OfAADYCAEHY58AAQdDnwAA2AgBB4OfAAEHY58AANgIAQeznwABB4OfAADYCAEHo58AAQeDnwAA2AgBB9OfAAEHo58AANgIAQfDnwABB6OfAADYCAEH858AAQfDnwAA2AgBB+OfAAEHw58AANgIAQYTowABB+OfAADYCAEGA6MAAQfjnwAA2AgBBjOjAAEGA6MAANgIAQYjowABBgOjAADYCAEGU6MAAQYjowAA2AgBBkOjAAEGI6MAANgIAQZzowABBkOjAADYCAEGY6MAAQZDowAA2AgBBpOjAAEGY6MAANgIAQazowABBoOjAADYCAEGg6MAAQZjowAA2AgBBtOjAAEGo6MAANgIAQajowABBoOjAADYCAEG86MAAQbDowAA2AgBBsOjAAEGo6MAANgIAQcTowABBuOjAADYCAEG46MAAQbDowAA2AgBBzOjAAEHA6MAANgIAQcDowABBuOjAADYCAEHU6MAAQcjowAA2AgBByOjAAEHA6MAANgIAQdzowABB0OjAADYCAEHQ6MAAQcjowAA2AgBB5OjAAEHY6MAANgIAQdjowABB0OjAADYCAEHs6MAAQeDowAA2AgBB4OjAAEHY6MAANgIAQfTowABB6OjAADYCAEHo6MAAQeDowAA2AgBB/OjAAEHw6MAANgIAQfDowABB6OjAADYCAEGE6cAAQfjowAA2AgBB+OjAAEHw6MAANgIAQYzpwABBgOnAADYCAEGA6cAAQfjowAA2AgBBlOnAAEGI6cAANgIAQYjpwABBgOnAADYCAEGc6cAAQZDpwAA2AgBBkOnAAEGI6cAANgIAQZjpwABBkOnAADYCAEEIQQgQrwEhAkEUQQgQrwEhBUEQQQgQrwEhBkGs6sAAIAEgARDtASIAQQgQrwEgAGsiARDrASIANgIAQaTqwAAgA0EIaiAGIAIgBWpqIAFqayIBNgIAIAAgAUEBcjYCBEEIQQgQrwEhAkEUQQgQrwEhA0EQQQgQrwEhBSAAIAEQ6wEgBSADIAJBCGtqajYCBEHI6sAAQYCAgAE2AgALQQAhAUGk6sAAKAIAIgAgBE0NAEGk6sAAIAAgBGsiATYCAEGs6sAAQazqwAAoAgAiACAEEOsBIgI2AgAgAiABQQFyNgIEIAAgBBDFASAAEO0BIQELIAhBEGokACABC5wJAQd/AkAgAUH/CU0EQCABQQV2IQUCQAJAAkAgACgCACIEBEAgACAEQQJ0aiECIAAgBCAFakECdGohBiAEQQFrIgNBJ0shBANAIAQNBCADIAVqIgdBKE8NAiAGIAIoAgA2AgAgBkEEayEGIAJBBGshAiADQQFrIgNBf0cNAAsLIAFBIEkNBCAAQQA2AgQgAUHAAE8NAQwECyAHQShBtN7AABBpAAsgAEEIakEANgIAIAVBASAFQQFLGyICQQJGDQIgAEEMakEANgIAIAJBA0YNAiAAQRBqQQA2AgAgAkEERg0CIABBFGpBADYCACACQQVGDQIgAEEYakEANgIAIAJBBkYNAiAAQRxqQQA2AgAgAkEHRg0CIABBIGpBADYCACACQQhGDQIgAEEkakEANgIAIAJBCUYNAiAAQShqQQA2AgAgAkEKRg0CIABBLGpBADYCACACQQtGDQIgAEEwakEANgIAIAJBDEYNAiAAQTRqQQA2AgAgAkENRg0CIABBOGpBADYCACACQQ5GDQIgAEE8akEANgIAIAJBD0YNAiAAQUBrQQA2AgAgAkEQRg0CIABBxABqQQA2AgAgAkERRg0CIABByABqQQA2AgAgAkESRg0CIABBzABqQQA2AgAgAkETRg0CIABB0ABqQQA2AgAgAkEURg0CIABB1ABqQQA2AgAgAkEVRg0CIABB2ABqQQA2AgAgAkEWRg0CIABB3ABqQQA2AgAgAkEXRg0CIABB4ABqQQA2AgAgAkEYRg0CIABB5ABqQQA2AgAgAkEZRg0CIABB6ABqQQA2AgAgAkEaRg0CIABB7ABqQQA2AgAgAkEbRg0CIABB8ABqQQA2AgAgAkEcRg0CIABB9ABqQQA2AgAgAkEdRg0CIABB+ABqQQA2AgAgAkEeRg0CIABB/ABqQQA2AgAgAkEfRg0CIABBgAFqQQA2AgAgAkEgRg0CIABBhAFqQQA2AgAgAkEhRg0CIABBiAFqQQA2AgAgAkEiRg0CIABBjAFqQQA2AgAgAkEjRg0CIABBkAFqQQA2AgAgAkEkRg0CIABBlAFqQQA2AgAgAkElRg0CIABBmAFqQQA2AgAgAkEmRg0CIABBnAFqQQA2AgAgAkEnRg0CIABBoAFqQQA2AgAgAkEoRg0CQShBKEG03sAAEGkACyADQShBtN7AABBpAAtB3t7AAEEdQbTewAAQgwEACyAAKAIAIAVqIQIgAUEfcSIHRQRAIAAgAjYCACAADwsCQCACQQFrIgNBJ00EQCACIQQgACADQQJ0akEEaigCACIGQQAgAWsiAXYiA0UNASACQSdNBEAgACACQQJ0akEEaiADNgIAIAJBAWohBAwCCyACQShBtN7AABBpAAsgA0EoQbTewAAQaQALAkAgAiAFQQFqIghLBEAgAUEfcSEBIAJBAnQgAGpBBGshAwNAIAJBAmtBKE8NAiADQQRqIAYgB3QgAygCACIGIAF2cjYCACADQQRrIQMgCCACQQFrIgJJDQALCyAAIAVBAnRqQQRqIgEgASgCACAHdDYCACAAIAQ2AgAgAA8LQX9BKEG03sAAEGkAC5EHAQV/IAAQ7gEiACAAENcBIgIQ6wEhAQJAAkACQCAAENgBDQAgACgCACEDAkAgABDEAUUEQCACIANqIQIgACADEOwBIgBBqOrAACgCAEcNASABKAIEQQNxQQNHDQJBoOrAACACNgIAIAAgAiABEJkBDwsgAiADakEQaiEADAILIANBgAJPBEAgABBGDAELIABBDGooAgAiBCAAQQhqKAIAIgVHBEAgBSAENgIMIAQgBTYCCAwBC0GQ58AAQZDnwAAoAgBBfiADQQN2d3E2AgALAkAgARC9AQRAIAAgAiABEJkBDAELAkACQAJAQazqwAAoAgAgAUcEQCABQajqwAAoAgBHDQFBqOrAACAANgIAQaDqwABBoOrAACgCACACaiIBNgIAIAAgARCrAQ8LQazqwAAgADYCAEGk6sAAQaTqwAAoAgAgAmoiATYCACAAIAFBAXI2AgQgAEGo6sAAKAIARg0BDAILIAEQ1wEiAyACaiECAkAgA0GAAk8EQCABEEYMAQsgAUEMaigCACIEIAFBCGooAgAiAUcEQCABIAQ2AgwgBCABNgIIDAELQZDnwABBkOfAACgCAEF+IANBA3Z3cTYCAAsgACACEKsBIABBqOrAACgCAEcNAkGg6sAAIAI2AgAMAwtBoOrAAEEANgIAQajqwABBADYCAAtByOrAACgCACABTw0BQQhBCBCvASEAQRRBCBCvASEBQRBBCBCvASEDQQBBEEEIEK8BQQJ0ayICQYCAfCADIAAgAWpqa0F3cUEDayIAIAAgAksbRQ0BQazqwAAoAgBFDQFBCEEIEK8BIQBBFEEIEK8BIQFBEEEIEK8BIQJBAAJAQaTqwAAoAgAiBCACIAEgAEEIa2pqIgJNDQBBrOrAACgCACEBQbjqwAAhAAJAA0AgASAAKAIATwRAIAAQxgEgAUsNAgsgACgCCCIADQALQQAhAAsgABDZAQ0AIABBDGooAgAaDAALQQAQSGtHDQFBpOrAACgCAEHI6sAAKAIATQ0BQcjqwABBfzYCAA8LIAJBgAJJDQEgACACEEVB0OrAAEHQ6sAAKAIAQQFrIgA2AgAgAA0AEEgaDwsPCyACQXhxQZjnwABqIQECf0GQ58AAKAIAIgNBASACQQN2dCICcQRAIAEoAggMAQtBkOfAACACIANyNgIAIAELIQMgASAANgIIIAMgADYCDCAAIAE2AgwgACADNgIIC40HAQh/AkACQCAAKAIIIgpBAUcgACgCECIDQQFHcUUEQAJAIANBAUcNACABIAJqIQkgAEEUaigCAEEBaiEHIAEhBANAAkAgBCEDIAdBAWsiB0UNACADIAlGDQICfyADLAAAIgVBAE4EQCAFQf8BcSEFIANBAWoMAQsgAy0AAUE/cSEIIAVBH3EhBCAFQV9NBEAgBEEGdCAIciEFIANBAmoMAQsgAy0AAkE/cSAIQQZ0ciEIIAVBcEkEQCAIIARBDHRyIQUgA0EDagwBCyAEQRJ0QYCA8ABxIAMtAANBP3EgCEEGdHJyIgVBgIDEAEYNAyADQQRqCyIEIAYgA2tqIQYgBUGAgMQARw0BDAILCyADIAlGDQAgAywAACIEQQBOIARBYElyIARBcElyRQRAIARB/wFxQRJ0QYCA8ABxIAMtAANBP3EgAy0AAkE/cUEGdCADLQABQT9xQQx0cnJyQYCAxABGDQELAkACQCAGRQ0AIAIgBk0EQEEAIQMgAiAGRg0BDAILQQAhAyABIAZqLAAAQUBIDQELIAEhAwsgBiACIAMbIQIgAyABIAMbIQELIApFDQIgAEEMaigCACEGAkAgAkEQTwRAIAEgAhApIQQMAQsgAkUEQEEAIQQMAQsgAkEDcSEFAkAgAkEBa0EDSQRAQQAhBCABIQMMAQsgAkF8cSEHQQAhBCABIQMDQCAEIAMsAABBv39KaiADLAABQb9/SmogAywAAkG/f0pqIAMsAANBv39KaiEEIANBBGohAyAHQQRrIgcNAAsLIAVFDQADQCAEIAMsAABBv39KaiEEIANBAWohAyAFQQFrIgUNAAsLIAQgBkkEQCAGIARrIgQhBgJAAkACQEEAIAAtACAiAyADQQNGG0EDcSIDQQFrDgIAAQILQQAhBiAEIQMMAQsgBEEBdiEDIARBAWpBAXYhBgsgA0EBaiEDIABBHGooAgAhBCAAQRhqKAIAIQUgACgCBCEAAkADQCADQQFrIgNFDQEgBSAAIAQoAhARAABFDQALQQEPC0EBIQMgAEGAgMQARg0CIAUgASACIAQoAgwRAQANAkEAIQMDQCADIAZGBEBBAA8LIANBAWohAyAFIAAgBCgCEBEAAEUNAAsgA0EBayAGSQ8LDAILIAAoAhggASACIABBHGooAgAoAgwRAQAhAwsgAw8LIAAoAhggASACIABBHGooAgAoAgwRAQAL0wgBAX8jAEEwayICJAACfwJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAALQAAQQFrDhEBAgMEBQYHCAkKCwwNDg8QEQALIAIgAC0AAToACCACQSxqQQE2AgAgAkICNwIcIAJBpKHAADYCGCACQdsANgIUIAIgAkEQajYCKCACIAJBCGo2AhAgASACQRhqEGsMEQsgAiAAKQMINwMIIAJBLGpBATYCACACQgI3AhwgAkGIocAANgIYIAJB3AA2AhQgAiACQRBqNgIoIAIgAkEIajYCECABIAJBGGoQawwQCyACIAApAwg3AwggAkEsakEBNgIAIAJCAjcCHCACQYihwAA2AhggAkHdADYCFCACIAJBEGo2AiggAiACQQhqNgIQIAEgAkEYahBrDA8LIAIgACsDCDkDCCACQSxqQQE2AgAgAkICNwIcIAJB7KDAADYCGCACQd4ANgIUIAIgAkEQajYCKCACIAJBCGo2AhAgASACQRhqEGsMDgsgAiAAKAIENgIIIAJBLGpBATYCACACQgI3AhwgAkHMoMAANgIYIAJB3wA2AhQgAiACQRBqNgIoIAIgAkEIajYCECABIAJBGGoQawwNCyACIAApAgQ3AwggAkEsakEBNgIAIAJCATcCHCACQbigwAA2AhggAkHgADYCFCACIAJBEGo2AiggAiACQQhqNgIQIAEgAkEYahBrDAwLIAJBLGpBADYCACACQdiewAA2AiggAkIBNwIcIAJBqKDAADYCGCABIAJBGGoQawwLCyACQSxqQQA2AgAgAkHYnsAANgIoIAJCATcCHCACQZSgwAA2AhggASACQRhqEGsMCgsgAkEsakEANgIAIAJB2J7AADYCKCACQgE3AhwgAkGAoMAANgIYIAEgAkEYahBrDAkLIAJBLGpBADYCACACQdiewAA2AiggAkIBNwIcIAJB7J/AADYCGCABIAJBGGoQawwICyACQSxqQQA2AgAgAkHYnsAANgIoIAJCATcCHCACQdSfwAA2AhggASACQRhqEGsMBwsgAkEsakEANgIAIAJB2J7AADYCKCACQgE3AhwgAkHEn8AANgIYIAEgAkEYahBrDAYLIAJBLGpBADYCACACQdiewAA2AiggAkIBNwIcIAJBuJ/AADYCGCABIAJBGGoQawwFCyACQSxqQQA2AgAgAkHYnsAANgIoIAJCATcCHCACQayfwAA2AhggASACQRhqEGsMBAsgAkEsakEANgIAIAJB2J7AADYCKCACQgE3AhwgAkGYn8AANgIYIAEgAkEYahBrDAMLIAJBLGpBADYCACACQdiewAA2AiggAkIBNwIcIAJBgJ/AADYCGCABIAJBGGoQawwCCyACQSxqQQA2AgAgAkHYnsAANgIoIAJCATcCHCACQeiewAA2AhggASACQRhqEGsMAQsgASAAKAIEIABBCGooAgAQrQELIAJBMGokAAvYBgEIfwJAAkAgAEEDakF8cSICIABrIgQgAUsgBEEES3INACABIARrIgZBBEkNACAGQQNxIQdBACEBAkAgACACRg0AIARBA3EhAwJAIAIgAEF/c2pBA0kEQCAAIQIMAQsgBEF8cSEIIAAhAgNAIAEgAiwAAEG/f0pqIAIsAAFBv39KaiACLAACQb9/SmogAiwAA0G/f0pqIQEgAkEEaiECIAhBBGsiCA0ACwsgA0UNAANAIAEgAiwAAEG/f0pqIQEgAkEBaiECIANBAWsiAw0ACwsgACAEaiEAAkAgB0UNACAAIAZBfHFqIgIsAABBv39KIQUgB0EBRg0AIAUgAiwAAUG/f0pqIQUgB0ECRg0AIAUgAiwAAkG/f0pqIQULIAZBAnYhBCABIAVqIQMDQCAAIQEgBEUNAiAEQcABIARBwAFJGyIFQQNxIQYgBUECdCEIAkAgBUH8AXEiB0UEQEEAIQIMAQsgASAHQQJ0aiEJQQAhAgNAIABFDQEgAiAAKAIAIgJBf3NBB3YgAkEGdnJBgYKECHFqIABBBGooAgAiAkF/c0EHdiACQQZ2ckGBgoQIcWogAEEIaigCACICQX9zQQd2IAJBBnZyQYGChAhxaiAAQQxqKAIAIgJBf3NBB3YgAkEGdnJBgYKECHFqIQIgAEEQaiIAIAlHDQALCyAEIAVrIQQgASAIaiEAIAJBCHZB/4H8B3EgAkH/gfwHcWpBgYAEbEEQdiADaiEDIAZFDQALAn9BACABRQ0AGiABIAdBAnRqIgEoAgAiAEF/c0EHdiAAQQZ2ckGBgoQIcSIAIAZBAUYNABogACABKAIEIgBBf3NBB3YgAEEGdnJBgYKECHFqIgAgBkECRg0AGiAAIAEoAggiAEF/c0EHdiAAQQZ2ckGBgoQIcWoLIgBBCHZB/4EccSAAQf+B/AdxakGBgARsQRB2IANqDwsgAUUEQEEADwsgAUEDcSECAkAgAUEBa0EDSQRADAELIAFBfHEhAQNAIAMgACwAAEG/f0pqIAAsAAFBv39KaiAALAACQb9/SmogACwAA0G/f0pqIQMgAEEEaiEAIAFBBGsiAQ0ACwsgAkUNAANAIAMgACwAAEG/f0pqIQMgAEEBaiEAIAJBAWsiAg0ACwsgAwu0BwEOfwJAAkAgAigCGCILQSIgAkEcaigCACINKAIQIg4RAABFBEACQCABRQRADAELIAAgAWohDyAAIQcCQANAAkAgBywAACICQQBOBEAgB0EBaiEJIAJB/wFxIQQMAQsgBy0AAUE/cSEFIAJBH3EhBCACQV9NBEAgBEEGdCAFciEEIAdBAmohCQwBCyAHLQACQT9xIAVBBnRyIQUgB0EDaiEJIAJBcEkEQCAFIARBDHRyIQQMAQsgBEESdEGAgPAAcSAJLQAAQT9xIAVBBnRyciIEQYCAxABGDQIgB0EEaiEJC0EwIQVBgoDEACECAkACfwJAAkACQAJAAkACQAJAIAQOIwgBAQEBAQEBAQIEAQEDAQEBAQEBAQEBAQEBAQEBAQEBAQEFAAsgBEHcAEYNBAsgBBA9RQ0EIARBAXJnQQJ2QQdzDAULQfQAIQUMBQtB8gAhBQwEC0HuACEFDAMLIAQhBQwCC0GBgMQAIQIgBCEFIAQQTg0BIARBAXJnQQJ2QQdzCyEFIAQhAgsCQAJAIAJBgIDEAGsiCkEDIApBA0kbQQFGDQAgAyAGSw0BAkAgA0UNACABIANNBEAgASADRg0BDAMLIAAgA2osAABBQEgNAgsCQCAGRQ0AIAEgBk0EQCABIAZHDQMMAQsgACAGaiwAAEG/f0wNAgsgCyAAIANqIAYgA2sgDSgCDBEBAARAQQEPC0EFIQgDQCAIIQwgAiEKQYGAxAAhAkHcACEDAkACQAJAAkACQAJAIApBgIDEAGsiEEEDIBBBA0kbQQFrDgMBBQACC0EAIQhB/QAhAyAKIQICQAJAAkAgDEH/AXFBAWsOBQcFAAECBAtBAiEIQfsAIQMMBQtBAyEIQfUAIQMMBAtBBCEIQdwAIQMMAwtBgIDEACECIAUiA0GAgMQARw0DCwJ/QQEgBEGAAUkNABpBAiAEQYAQSQ0AGkEDQQQgBEGAgARJGwsgBmohAwwECyAMQQEgBRshCEEwQdcAIAogBUECdHZBD3EiAkEKSRsgAmohAyAFQQFrQQAgBRshBQsgCiECCyALIAMgDhEAAEUNAAtBAQ8LIAYgB2sgCWohBiAJIgcgD0cNAQwCCwsgACABIAMgBkGgzsAAELYBAAsgA0UEQEEAIQMMAQsgASADTQRAIAEgA0YNAQwECyAAIANqLAAAQb9/TA0DCyALIAAgA2ogASADayANKAIMEQEARQ0BC0EBDwsgC0EiIA4RAAAPCyAAIAEgAyABQbDOwAAQtgEAC7YGAgJ+BX8CQAJAAkACQAJAAkAgAUEHcSIEBEACQAJAIAAoAgAiBUEpSQRAIAVFBEBBACEFDAMLIARBAnRBqLDAAGo1AgAhAyAAQQRqIQQgBUEBa0H/////A3EiB0EBaiIGQQNxIQggB0EDSQ0BIAZB/P///wdxIQcDQCAEIAQ1AgAgA34gAnwiAj4CACAEQQRqIgYgBjUCACADfiACQiCIfCICPgIAIARBCGoiBiAGNQIAIAN+IAJCIIh8IgI+AgAgBEEMaiIGIAY1AgAgA34gAkIgiHwiAj4CACACQiCIIQIgBEEQaiEEIAdBBGsiBw0ACwwBCyAFQShBtN7AABDKAQALIAgEQANAIAQgBDUCACADfiACfCICPgIAIARBBGohBCACQiCIIQIgCEEBayIIDQALCyACpyIERQ0AIAVBJ0sNAiAAIAVBAnRqQQRqIAQ2AgAgBUEBaiEFCyAAIAU2AgALIAFBCHFFDQQgACgCACIFQSlPDQEgBUUEQEEAIQUMBAsgAEEEaiEEIAVBAWtB/////wNxIgdBAWoiBkEDcSEIIAdBA0kEQEIAIQIMAwsgBkH8////B3EhB0IAIQIDQCAEIAQ1AgBCgMLXL34gAnwiAj4CACAEQQRqIgYgBjUCAEKAwtcvfiACQiCIfCICPgIAIARBCGoiBiAGNQIAQoDC1y9+IAJCIIh8IgI+AgAgBEEMaiIGIAY1AgBCgMLXL34gAkIgiHwiAj4CACACQiCIIQIgBEEQaiEEIAdBBGsiBw0ACwwCCyAFQShBtN7AABBpAAsgBUEoQbTewAAQygEACyAIBEADQCAEIAQ1AgBCgMLXL34gAnwiAj4CACAEQQRqIQQgAkIgiCECIAhBAWsiCA0ACwsgAqciBEUNACAFQSdLDQIgACAFQQJ0akEEaiAENgIAIAVBAWohBQsgACAFNgIACyABQRBxBEAgAEH4sMAAQQIQLAsgAUEgcQRAIABBgLHAAEEEECwLIAFBwABxBEAgAEGQscAAQQcQLAsgAUGAAXEEQCAAQayxwABBDhAsCyABQYACcQRAIABB5LHAAEEbECwLDwsgBUEoQbTewAAQaQAL8wUCDH8CfiMAQaABayIDJAAgA0EAQaABEN4BIQkCQAJAIAIgACgCACIFTQRAIAVBKUkEQCABIAJBAnRqIQsgBUUNAiAFQQFqIQwgAEEEaiENIAVBAnQhDgNAIAkgB0ECdGohBANAIAchAiAEIQMgASALRg0FIANBBGohBCACQQFqIQcgASgCACEGIAFBBGoiCiEBIAZFDQALIAatIRBCACEPIA4hBiACIQEgDSEEAkACQANAIAFBJ0sNASADIA8gAzUCAHwgBDUCACAQfnwiDz4CACAPQiCIIQ8gA0EEaiEDIAFBAWohASAEQQRqIQQgBkEEayIGDQALIAUhAyAPpyIBRQ0BIAIgBWoiA0EnTQRAIAkgA0ECdGogATYCACAMIQMMAgsgA0EoQbTewAAQaQALIAFBKEG03sAAEGkACyAIIAIgA2oiASABIAhJGyEIIAohAQwACwALIAVBKEG03sAAEMoBAAsgBUEpSQRAIABBBGoiBCAFQQJ0aiELIAJBAnQhDCACQQFqIQ1BACEFA0AgCSAFQQJ0aiEHA0AgBSEKIAchAyAEIAtGDQQgA0EEaiEHIApBAWohBSAEKAIAIQYgBEEEaiIOIQQgBkUNAAsgBq0hEEIAIQ8gDCEGIAohBCABIQcCQAJAA0AgBEEnSw0BIAMgDyADNQIAfCAHNQIAIBB+fCIPPgIAIA9CIIghDyADQQRqIQMgBEEBaiEEIAdBBGohByAGQQRrIgYNAAsgAiEDIA+nIgRFDQEgAiAKaiIDQSdNBEAgCSADQQJ0aiAENgIAIA0hAwwCCyADQShBtN7AABBpAAsgBEEoQbTewAAQaQALIAggAyAKaiIDIAMgCEkbIQggDiEEDAALAAsgBUEoQbTewAAQygEAC0EAIQMDQCABIAtGDQEgA0EBaiEDIAEoAgAgAUEEaiEBRQ0AIAggA0EBayICIAIgCEkbIQgMAAsACyAAQQRqIAlBoAEQ4AEaIAAgCDYCACAJQaABaiQAC4AGAQd/An8gAQRAQStBgIDEACAAKAIAIghBAXEiARshCiABIAVqDAELIAAoAgAhCEEtIQogBUEBagshBwJAIAhBBHFFBEBBACECDAELAkAgA0EQTwRAIAIgAxApIQYMAQsgA0UEQAwBCyADQQNxIQkCQCADQQFrQQNJBEAgAiEBDAELIANBfHEhCyACIQEDQCAGIAEsAABBv39KaiABLAABQb9/SmogASwAAkG/f0pqIAEsAANBv39KaiEGIAFBBGohASALQQRrIgsNAAsLIAlFDQADQCAGIAEsAABBv39KaiEGIAFBAWohASAJQQFrIgkNAAsLIAYgB2ohBwsCQAJAIAAoAghFBEBBASEBIABBGGooAgAiByAAQRxqKAIAIgAgCiACIAMQhgENAQwCCwJAAkACQAJAIAcgAEEMaigCACIGSQRAIAhBCHENBCAGIAdrIgYhB0EBIAAtACAiASABQQNGG0EDcSIBQQFrDgIBAgMLQQEhASAAQRhqKAIAIgcgAEEcaigCACIAIAogAiADEIYBDQQMBQtBACEHIAYhAQwBCyAGQQF2IQEgBkEBakEBdiEHCyABQQFqIQEgAEEcaigCACEGIABBGGooAgAhCCAAKAIEIQACQANAIAFBAWsiAUUNASAIIAAgBigCEBEAAEUNAAtBAQ8LQQEhASAAQYCAxABGDQEgCCAGIAogAiADEIYBDQEgCCAEIAUgBigCDBEBAA0BQQAhAQJ/A0AgByABIAdGDQEaIAFBAWohASAIIAAgBigCEBEAAEUNAAsgAUEBawsgB0khAQwBCyAAKAIEIQsgAEEwNgIEIAAtACAhDEEBIQEgAEEBOgAgIABBGGooAgAiCCAAQRxqKAIAIgkgCiACIAMQhgENACAGIAdrQQFqIQECQANAIAFBAWsiAUUNASAIQTAgCSgCEBEAAEUNAAtBAQ8LQQEhASAIIAQgBSAJKAIMEQEADQAgACAMOgAgIAAgCzYCBEEADwsgAQ8LIAcgBCAFIAAoAgwRAQALlAUBBn8jAEEgayIIJAACQAJAAkAgA0EgTwRAIANBgAJJDQEgA0GAgARJDQIgCEESOwEQIAhBEGoQSiEJIAEoAgQiBiABKAIIIgRGBEAgASAEQQEQUiABKAIEIQYgASgCCCEECyABIARBAWoiBTYCCCABKAIAIgcgBGogCToAACAGIAVrQQNNBEAgASAFQQQQUiABKAIAIQcgASgCCCEFCyABIAVBBGoiBDYCCCAFIAdqIANBCHRBgID8B3EgA0EYdHIgA0EIdkGA/gNxIANBGHZycjYAAAwDCyAIIANBCHRBD3I7AQAgCBBKIQYgASgCCCIFIAEoAgRGBEAgASAFQQEQUiABKAIIIQULIAEgBUEBaiIENgIIIAEoAgAiByAFaiAGOgAADAILIAhBEDsBCCAIQQhqEEohCSABKAIEIgYgASgCCCIERgRAIAEgBEEBEFIgASgCBCEGIAEoAgghBAsgASAEQQFqIgU2AgggASgCACIHIARqIAk6AAAgBSAGRgRAIAEgBkEBEFIgASgCACEHIAEoAgghBQsgASAFQQFqIgQ2AgggBSAHaiADOgAADAELIAhBETsBGCAIQRhqEEohCSABKAIEIgYgASgCCCIERgRAIAEgBEEBEFIgASgCBCEGIAEoAgghBAsgASAEQQFqIgU2AgggASgCACIHIARqIAk6AAAgBiAFa0EBTQRAIAEgBUECEFIgASgCACEHIAEoAgghBQsgASAFQQJqIgQ2AgggBSAHaiADQQh0IANBgP4DcUEIdnI7AAALIAMgASgCBCAEa0sEQCABIAQgAxBSIAEoAgAhByABKAIIIQQLIAQgB2ogAiADEOABGiAAQQI2AgAgASADIARqNgIIIAhBIGokAAv8BAEIfyMAQRBrIgckAAJ/IAIoAgQiBARAQQEgACACKAIAIAQgASgCDBEBAA0BGgtBACACQQxqKAIAIgNFDQAaIAIoAggiBCADQQxsaiEIIAdBDGohCQNAAkACQAJAAkAgBC8BAEEBaw4CAgEACwJAIAQoAgQiAkHBAE8EQCABQQxqKAIAIQMDQEEBIABBxM3AAEHAACADEQEADQcaIAJBQGoiAkHAAEsNAAsMAQsgAkUNAwsCQCACQT9NBEAgAkHEzcAAaiwAAEG/f0wNAQsgAEHEzcAAIAIgAUEMaigCABEBAEUNA0EBDAULQcTNwABBwABBACACQYTOwAAQtgEACyAAIAQoAgQgBEEIaigCACABQQxqKAIAEQEARQ0BQQEMAwsgBC8BAiECIAlBADoAACAHQQA2AggCQAJAAn8CQAJAAkAgBC8BAEEBaw4CAQACCyAEQQhqDAILIAQvAQIiA0HoB08EQEEEQQUgA0GQzgBJGyEFDAMLQQEhBSADQQpJDQJBAkEDIANB5ABJGyEFDAILIARBBGoLKAIAIgVBBkkEQCAFDQFBACEFDAILIAVBBUG0zcAAEMoBAAsgB0EIaiAFaiEGAkAgBUEBcUUEQCACIQMMAQsgBkEBayIGIAIgAkEKbiIDQQpsa0EwcjoAAAsgBUEBRg0AIAZBAmshAgNAIAIgA0H//wNxIgZBCm4iCkEKcEEwcjoAACACQQFqIAMgCkEKbGtBMHI6AAAgBkHkAG4hAyACIAdBCGpGIAJBAmshAkUNAAsLIAAgB0EIaiAFIAFBDGooAgARAQBFDQBBAQwCCyAEQQxqIgQgCEcNAAtBAAsgB0EQaiQAC/8EAQp/IwBBMGsiAyQAIANBJGogATYCACADQQM6ACggA0KAgICAgAQ3AwggAyAANgIgIANBADYCGCADQQA2AhACfwJAAkAgAigCCCIKRQRAIAJBFGooAgAiAEUNASACKAIQIQEgAEEDdCEFIABBAWtB/////wFxQQFqIQcgAigCACEAA0AgAEEEaigCACIEBEAgAygCICAAKAIAIAQgAygCJCgCDBEBAA0ECyABKAIAIANBCGogAUEEaigCABEAAA0DIAFBCGohASAAQQhqIQAgBUEIayIFDQALDAELIAJBDGooAgAiAEUNACAAQQV0IQsgAEEBa0H///8/cUEBaiEHIAIoAgAhAANAIABBBGooAgAiAQRAIAMoAiAgACgCACABIAMoAiQoAgwRAQANAwsgAyAFIApqIgRBHGotAAA6ACggAyAEQQRqKQIAQiCJNwMIIARBGGooAgAhBiACKAIQIQhBACEJQQAhAQJAAkACQCAEQRRqKAIAQQFrDgIAAgELIAZBA3QgCGoiDEEEaigCAEH3AEcNASAMKAIAKAIAIQYLQQEhAQsgAyAGNgIUIAMgATYCECAEQRBqKAIAIQECQAJAAkAgBEEMaigCAEEBaw4CAAIBCyABQQN0IAhqIgZBBGooAgBB9wBHDQEgBigCACgCACEBC0EBIQkLIAMgATYCHCADIAk2AhggCCAEKAIAQQN0aiIBKAIAIANBCGogASgCBBEAAA0CIABBCGohACALIAVBIGoiBUcNAAsLIAIoAgQgB0sEQCADKAIgIAIoAgAgB0EDdGoiACgCACAAKAIEIAMoAiQoAgwRAQANAQtBAAwBC0EBCyADQTBqJAAL8AQBCX8jAEEQayIEJAACQAJAAn8CQCAAKAIIQQFGBEAgAEEMaigCACEHIARBDGogAUEMaigCACIFNgIAIAQgASgCCCICNgIIIAQgASgCBCIDNgIEIAQgASgCACIBNgIAIAAtACAhCSAAKAIEIQogAC0AAEEIcQ0BIAohCCAJIQYgAwwCCyAAQRhqKAIAIABBHGooAgAgARAvIQIMAwsgACgCGCABIAMgAEEcaigCACgCDBEBAA0BQQEhBiAAQQE6ACBBMCEIIABBMDYCBCAEQQA2AgQgBEHIr8AANgIAQQAgByADayIDIAMgB0sbIQdBAAshASAFBEAgBUEMbCEDA0ACfwJAAkACQCACLwEAQQFrDgICAQALIAJBBGooAgAMAgsgAkEIaigCAAwBCyACQQJqLwEAIgVB6AdPBEBBBEEFIAVBkM4ASRsMAQtBASAFQQpJDQAaQQJBAyAFQeQASRsLIQUgAkEMaiECIAEgBWohASADQQxrIgMNAAsLAn8CQCABIAdJBEAgByABayIBIQMCQAJAAkAgBkEDcSICQQFrDgMAAQACC0EAIQMgASECDAELIAFBAXYhAiABQQFqQQF2IQMLIAJBAWohAiAAQRxqKAIAIQEgAEEYaigCACEGA0AgAkEBayICRQ0CIAYgCCABKAIQEQAARQ0ACwwDCyAAQRhqKAIAIABBHGooAgAgBBAvDAELIAYgASAEEC8NAUEAIQIDQEEAIAIgA0YNARogAkEBaiECIAYgCCABKAIQEQAARQ0ACyACQQFrIANJCyECIAAgCToAICAAIAo2AgQMAQtBASECCyAEQRBqJAAgAgvVBAEEfyAAIAEQ6wEhAgJAAkACQCAAENgBDQAgACgCACEDAkAgABDEAUUEQCABIANqIQEgACADEOwBIgBBqOrAACgCAEcNASACKAIEQQNxQQNHDQJBoOrAACABNgIAIAAgASACEJkBDwsgASADakEQaiEADAILIANBgAJPBEAgABBGDAELIABBDGooAgAiBCAAQQhqKAIAIgVHBEAgBSAENgIMIAQgBTYCCAwBC0GQ58AAQZDnwAAoAgBBfiADQQN2d3E2AgALIAIQvQEEQCAAIAEgAhCZAQwCCwJAQazqwAAoAgAgAkcEQCACQajqwAAoAgBHDQFBqOrAACAANgIAQaDqwABBoOrAACgCACABaiIBNgIAIAAgARCrAQ8LQazqwAAgADYCAEGk6sAAQaTqwAAoAgAgAWoiATYCACAAIAFBAXI2AgQgAEGo6sAAKAIARw0BQaDqwABBADYCAEGo6sAAQQA2AgAPCyACENcBIgMgAWohAQJAIANBgAJPBEAgAhBGDAELIAJBDGooAgAiBCACQQhqKAIAIgJHBEAgAiAENgIMIAQgAjYCCAwBC0GQ58AAQZDnwAAoAgBBfiADQQN2d3E2AgALIAAgARCrASAAQajqwAAoAgBHDQFBoOrAACABNgIACw8LIAFBgAJPBEAgACABEEUPCyABQXhxQZjnwABqIQICf0GQ58AAKAIAIgNBASABQQN2dCIBcQRAIAIoAggMAQtBkOfAACABIANyNgIAIAILIQEgAiAANgIIIAEgADYCDCAAIAI2AgwgACABNgIIC4kEAQV/IwBBIGsiBiQAAn8CQCACQYACTwRAIAJBgIAESQ0BIAZBFTsBECAGQRBqEEohByABKAIEIgUgASgCCCIDRgRAIAEgA0EBEFIgASgCBCEFIAEoAgghAwsgASADQQFqIgQ2AgggAyABKAIAIgNqIAc6AAAgBSAEa0EDTQRAIAEgBEEEEFIgASgCACEDIAEoAgghBAsgASAEQQRqNgIIIAMgBGogAkEIdEGAgPwHcSACQRh0ciACQQh2QYD+A3EgAkEYdnJyNgAAQRUMAgsgBkETOwEIIAZBCGoQSiEHIAEoAgQiBSABKAIIIgNGBEAgASADQQEQUiABKAIEIQUgASgCCCEDCyABIANBAWoiBDYCCCADIAEoAgAiA2ogBzoAACAEIAVGBEAgASAFQQEQUiABKAIAIQMgASgCCCEECyABIARBAWo2AgggAyAEaiACOgAAQRMMAQsgBkEUOwEYIAZBGGoQSiEHIAEoAgQiBSABKAIIIgNGBEAgASADQQEQUiABKAIEIQUgASgCCCEDCyABIANBAWoiBDYCCCADIAEoAgAiA2ogBzoAACAFIARrQQFNBEAgASAEQQIQUiABKAIAIQMgASgCCCEECyABIARBAmo2AgggAyAEaiACQQh0IAJBgP4DcUEIdnI7AABBFAshASAAQQI2AgAgACABOgAEIAZBIGokAAuqBQMFfwF+AXwjAEHQAGsiAyQAQQchBgJAAkAgACgCACIFEARBAUYNACAFEAVBAUYNAAJAAkACQCAFEAYOAgEAAgtBASEEC0EAIQBBACEGDAILIANBEGogBRAHIAMoAhAEQEEDIQYgAysDGCEJQQAhAAwCCyADQQhqIAUQAQJ/IAMoAggiBQRAIAMoAgwhBCADIAU2AiAgAyAENgIoIAMgBDYCJEEFIQZBAQwBCwJAAkAgABDCAUUEQCAAEMEBRQ0CIAMgABDpATYCICADQThqIANBIGoQXyADKQI8IQggAygCOCEFIAMoAiAiBEEkSQ0BIAQQAAwBCyADQThqIAAQXyADKQI8IQggAygCOCEFCyAFRQ0AIAhCIIinIQRBASEHQQYhBkEADAELIANBKzYCNCADIAA2AjAgA0EBNgJMIANCATcCPCADQdCQwAA2AjggAyADQTBqNgJIIANBIGogA0E4ahA1QREhBiADKAIgIQUgAygCKCEEQQELIQAgBK2/IQkMAQtBACEACyADIAk5A0AgAyAFNgI8IAMgBDoAOSADIAY6ADgjAEEwayIEJAAgBCACNgIEIAQgATYCACAEQRRqQTA2AgAgBEEMNgIMIAQgA0E4ajYCCCAEIAQ2AhAgBEECNgIsIARCAjcCHCAEQciSwAA2AhggBCAEQQhqNgIoAn8jAEFAaiIBJAAgAUEANgIIIAFCATcDACABQRBqIgIgAUHwkMAAEJIBIARBGGogAhBqRQRAIAEoAgAgASgCCBDoASABKAIEBEAgASgCABAmCyABQUBrJAAMAQtBiJHAAEE3IAFBOGpBwJHAAEGcksAAEGQACyAEQTBqJAAgB0UgCKdFckUEQCAFECYLAkAgAEUNACADKAIkRQ0AIAUQJgsgA0HQAGokAAvoAwEGfyMAQTBrIgUkAAJAAkACQAJAAkAgASgCBCIDBEAgASgCACEHIANBAWtB/////wFxIgNBAWoiBkEHcSEEAn8gA0EHSQRAQQAhAyAHDAELIAdBPGohAiAGQfj///8DcSEGQQAhAwNAIAIoAgAgAkEIaygCACACQRBrKAIAIAJBGGsoAgAgAkEgaygCACACQShrKAIAIAJBMGsoAgAgAkE4aygCACADampqampqamohAyACQUBrIQIgBkEIayIGDQALIAJBPGsLIQIgBARAIAJBBGohAgNAIAIoAgAgA2ohAyACQQhqIQIgBEEBayIEDQALCyABQRRqKAIADQEgAyEEDAMLQQAhAyABQRRqKAIADQFBASECDAQLIAcoAgQNACADQRBJDQILIAMgA2oiBCADSQ0BCyAERQ0AAkAgBEEATgRAIARBARC4ASICRQ0BIAQhAwwDCxCIAQALIARBARDbAQALQQEhAkEAIQMLIABBADYCCCAAIAM2AgQgACACNgIAIAUgADYCDCAFQSBqIAFBEGopAgA3AwAgBUEYaiABQQhqKQIANwMAIAUgASkCADcDECAFQQxqQfytwAAgBUEQahAwBEBB3K7AAEEzIAVBKGpBkK/AAEG4r8AAEGQACyAFQTBqJAALxgUCCX8BfiMAQdAAayICJAAgASgCACEJAkACQAJAAkAgAUEIaigCACIDQVhGBEAQYyEDIABBADYCACAAIAM2AgQMAQsgA0UNAyADQQBIDQEgA0EBELgBIgRFDQIgBCAJIAMQ4AEhByADQQJNDQMgAkEoaiEEIwBBIGsiBiQAIAZBEGoiBUEDNgIEIAVBzJjAADYCAAJAAkACQAJAAkAgBigCFEEDRgRAIAcgBigCEEEDEN8BRQ0BCyAGQQhqIgVBCzYCBCAFQc+YwAA2AgAgBigCCCEKAkAgBigCDCIFRQRAQQEhCAwBCyAFQQBIDQMgBUEBELgBIghFDQQLIAggCiAFEOABIQggBCAFNgIMIAQgBTYCCCAEIAg2AgQgBEEDOgAAIAQgBy8AADsAASAEQQNqIAdBAmotAAA6AAAMAQsgBEEGOgAACyAGQSBqJAAMAgsQiAEACyAFQQEQ2wEACyACLQAoIgRBBkYEQCAAIAM2AgggACADNgIEIAAgBzYCAAwBCyACQQZqIgMgAi0AKzoAACACIAIvACk7AQQgAikCLCELIAIoAjQhBiAHECYgAiAEOgAIIAIgAi8BBDsACSACIAMtAAA6AAsgAiAGNgIUIAIgCzcCDCACQRo2AkQgAiACQQhqNgJAIAJBATYCPCACQgE3AiwgAkGcicAANgIoIAIgAkFAayIDNgI4IAJBGGogAkEoaiIEEDUgAkHIAGogAkEgaigCADYCACACIAIpAxg3A0AgBCADEHQgAigCKCIDIAIoAjAQ6AEhBCACKAIsBEAgAxAmCyACKAJEBEAgAigCQBAmCwJAIAItAAhBA0cNACACKAIQRQ0AIAIoAgwQJgsgAEEANgIAIAAgBDYCBAsgAUEEaigCAARAIAkQJgsgAkHQAGokAA8LEIgBAAsgA0EBENsBAAtBAyADQbyNwAAQygEAC7QFAQt/IwBBMGsiBSQAIAVBCjYCKCAFQoqAgIAQNwMgIAUgAjYCHCAFQQA2AhggBSACNgIUIAUgATYCECAFIAI2AgwgBUEANgIIIAAoAgQhCiAAKAIAIQsgACgCCCEMAn8DQAJAIAZFBEACQCACIAhJDQADQCABIAhqIQcCfyACIAhrIgRBCE8EQAJAAkACQAJAIAdBA2pBfHEiACAHRg0AIAAgB2siACAEIAAgBEkbIgNFDQBBACEAQQEhBgNAIAAgB2otAABBCkYNBCADIABBAWoiAEcNAAsgAyAEQQhrIgBLDQIMAQsgBEEIayEAQQAhAwsDQAJAIAMgB2oiDSgCAEGKlKjQAHMiBkF/cyAGQYGChAhrcUGAgYKEeHENACANQQRqKAIAQYqUqNAAcyIGQX9zIAZBgYKECGtxQYCBgoR4cQ0AIANBCGoiAyAATQ0BCwsgAyAETQ0AIAMgBEHkzsAAEMkBAAtBACEGIAMgBEcEQANAIAMgB2otAABBCkYEQCADIQBBASEGDAMLIAQgA0EBaiIDRw0ACwsgBCEACyAFIAA2AgQgBSAGNgIAIAUoAgQhACAFKAIADAELQQAhAEEAIARFDQAaA0BBASAAIAdqLQAAQQpGDQEaIAQgAEEBaiIARw0ACyAEIQBBAAtBAUcEQCACIQgMAgsCQCAAIAhqIgBBAWoiCEUgAiAISXINACAAIAFqLQAAQQpHDQBBACEGIAgiBCEADAQLIAIgCE8NAAsLQQEhBiACIgAgCSIERw0BC0EADAILAkAgDC0AAARAIAtB5MrAAEEEIAooAgwRAQANAQsgASAJaiEDIAAgCWshByAMIAAgCUcEfyADIAdqQQFrLQAAQQpGBUEACzoAACAEIQkgCyADIAcgCigCDBEBAEUNAQsLQQELIAVBMGokAAuPAwEFfwJAAkACQAJAIAFBCU8EQEEQQQgQrwEgAUsNAQwCCyAAECQhBAwCC0EQQQgQrwEhAQtBCEEIEK8BIQNBFEEIEK8BIQJBEEEIEK8BIQVBAEEQQQgQrwFBAnRrIgZBgIB8IAUgAiADamprQXdxQQNrIgMgAyAGSxsgAWsgAE0NACABQRAgAEEEakEQQQgQrwFBBWsgAEsbQQgQrwEiA2pBEEEIEK8BakEEaxAkIgJFDQAgAhDuASEAAkAgAUEBayIEIAJxRQRAIAAhAQwBCyACIARqQQAgAWtxEO4BIQJBEEEIEK8BIQQgABDXASACQQAgASACIABrIARLG2oiASAAayICayEEIAAQxAFFBEAgASAEEJQBIAAgAhCUASAAIAIQMgwBCyAAKAIAIQAgASAENgIEIAEgACACajYCAAsgARDEAQ0BIAEQ1wEiAkEQQQgQrwEgA2pNDQEgASADEOsBIQAgASADEJQBIAAgAiADayIDEJQBIAAgAxAyDAELIAQPCyABEO0BIAEQxAEaC/UCAQN/AkACQAJAAkACQAJAAkAgByAIVgRAIAcgCH0gCFgNByAGIAcgBn1UIAcgBkIBhn0gCEIBhlpxDQEgBiAIVgRAIAcgBiAIfSIGfSAGWA0DCwwHCwwGCyACIANJDQEMBAsgAiADSQ0BIAEhCwJAA0AgAyAJRg0BIAlBAWohCSALQQFrIgsgA2oiCi0AAEE5Rg0ACyAKIAotAABBAWo6AAAgAyAJa0EBaiADTw0DIApBAWpBMCAJQQFrEN4BGgwDCwJ/QTEgA0UNABogAUExOgAAQTAgA0EBRg0AGiABQQFqQTAgA0EBaxDeARpBMAshCSAEQRB0QYCABGpBEHUiBCAFQRB0QRB1TCACIANNcg0CIAEgA2ogCToAACADQQFqIQMMAgsgAyACQdzFwAAQygEACyADIAJB7MXAABDKAQALIAIgA08NACADIAJB/MXAABDKAQALIAAgBDsBCCAAIAM2AgQgACABNgIADwsgAEEANgIAC5cDAQJ/AkACQAJAIAIEQCABLQAAQTFJDQECQCADQRB0QRB1IgdBAEoEQCAFIAE2AgRBAiEGIAVBAjsBACADQf//A3EiAyACTw0BIAVBAjsBGCAFQQI7AQwgBSADNgIIIAVBIGogAiADayICNgIAIAVBHGogASADajYCACAFQRRqQQE2AgAgBUEQakGqx8AANgIAQQMhBiACIARPDQUgBCACayEEDAQLIAVBAjsBGCAFQQA7AQwgBUECNgIIIAVBqMfAADYCBCAFQQI7AQAgBUEgaiACNgIAIAVBHGogATYCACAFQRBqQQAgB2siATYCAEEDIQYgAiAETw0EIAEgBCACayICTw0EIAIgB2ohBAwDCyAFQQA7AQwgBSACNgIIIAVBEGogAyACazYCACAERQ0DIAVBAjsBGCAFQSBqQQE2AgAgBUEcakGqx8AANgIADAILQYzEwABBIUGwxsAAEIMBAAtBwMbAAEEhQeTGwAAQgwEACyAFQQA7ASQgBUEoaiAENgIAQQQhBgsgACAGNgIEIAAgBTYCAAvTAwEHf0EBIQMCQCABKAIYIgZBJyABQRxqKAIAKAIQIgcRAAANAEGCgMQAIQFBMCECAkACfwJAAkACQAJAAkACQAJAIAAoAgAiAA4oCAEBAQEBAQEBAgQBAQMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBBQALIABB3ABGDQQLIAAQPUUNBCAAQQFyZ0ECdkEHcwwFC0H0ACECDAULQfIAIQIMBAtB7gAhAgwDCyAAIQIMAgtBgYDEACEBIAAQTgRAIAAhAgwCCyAAQQFyZ0ECdkEHcwshAiAAIQELQQUhBANAIAQhBSABIQBBgYDEACEBQdwAIQMCQAJAAkACQAJAAkAgAEGAgMQAayIIQQMgCEEDSRtBAWsOAwEFAAILQQAhBEH9ACEDIAAhAQJAAkACQCAFQf8BcUEBaw4FBwUAAQIEC0ECIQRB+wAhAwwFC0EDIQRB9QAhAwwEC0EEIQRB3AAhAwwDC0GAgMQAIQEgAiEDIAJBgIDEAEcNAwsgBkEnIAcRAAAhAwwECyAFQQEgAhshBEEwQdcAIAAgAkECdHZBD3EiAUEKSRsgAWohAyACQQFrQQAgAhshAgsgACEBCyAGIAMgBxEAAEUNAAtBAQ8LIAMLvwIBAX8jAEHwAGsiBiQAIAYgATYCDCAGIAA2AgggBiADNgIUIAYgAjYCECAGQbXJwAA2AhggBkECNgIcAkAgBCgCAEUEQCAGQcwAakH7ADYCACAGQcQAakH7ADYCACAGQewAakEDNgIAIAZCBDcCXCAGQZjKwAA2AlggBkH6ADYCPCAGIAZBOGo2AmgMAQsgBkEwaiAEQRBqKQIANwMAIAZBKGogBEEIaikCADcDACAGIAQpAgA3AyAgBkHsAGpBBDYCACAGQdQAakH8ADYCACAGQcwAakH7ADYCACAGQcQAakH7ADYCACAGQgQ3AlwgBkH0ycAANgJYIAZB+gA2AjwgBiAGQThqNgJoIAYgBkEgajYCUAsgBiAGQRBqNgJIIAYgBkEIajYCQCAGIAZBGGo2AjggBkHYAGogBRCJAQAL9wIBBX8gAEELdCEEQSEhAkEhIQMCQANAAkACQEF/IAJBAXYgAWoiAkECdEHA38AAaigCAEELdCIFIARHIAQgBUsbIgVBAUYEQCACIQMMAQsgBUH/AXFB/wFHDQEgAkEBaiEBCyADIAFrIQIgASADSQ0BDAILCyACQQFqIQELAkACQCABQSBNBEAgAUECdCEFQdcFIQMgAUEgRwRAIAVBxN/AAGooAgBBFXYhAwtBACECIAEgAUEBayIETwRAIARBIU8NAiAEQQJ0QcDfwABqKAIAQf///wBxIQILIAMgBUHA38AAaigCAEEVdiIBQX9zakUNAiAAIAJrIQQgAUHXBSABQdcFSxshAiADQQFrIQBBACEDA0ACQCABIAJHBEAgAyABQcTgwABqLQAAaiIDIARNDQEMBQsgAkHXBUGc5sAAEGkACyAAIAFBAWoiAUcNAAsgACEBDAILIAFBIUGc5sAAEGkACyAEQSFBhN7AABBpAAsgAUEBcQvdAgEHf0EBIQkCQAJAIAJFDQAgASACQQF0aiEKIABBgP4DcUEIdiELIABB/wFxIQ0DQCABQQJqIQwgByABLQABIgJqIQggCyABLQAAIgFHBEAgASALSw0CIAghByAMIgEgCkYNAgwBCwJAAkAgByAITQRAIAQgCEkNASADIAdqIQEDQCACRQ0DIAJBAWshAiABLQAAIAFBAWohASANRw0AC0EAIQkMBQsgByAIQcDSwAAQywEACyAIIARBwNLAABDKAQALIAghByAMIgEgCkcNAAsLIAZFDQAgBSAGaiEDIABB//8DcSEBA0ACQCAFQQFqIQAgBS0AACICQRh0QRh1IgRBAE4EfyAABSAAIANGDQEgBS0AASAEQf8AcUEIdHIhAiAFQQJqCyEFIAEgAmsiAUEASA0CIAlBAXMhCSADIAVHDQEMAgsLQa3EwABBK0HQ0sAAEIMBAAsgCUEBcQuYBAEFfyMAQRBrIgMkACAAKAIAIQACQAJ/AkAgAUGAAU8EQCADQQA2AgwgAUGAEE8NASADIAFBP3FBgAFyOgANIAMgAUEGdkHAAXI6AAxBAgwCCyAAKAIIIgIgACgCBEYEQCMAQSBrIgQkAAJAAkAgAkEBaiICRQ0AIABBBGooAgAiBUEBdCIGIAIgAiAGSRsiAkEIIAJBCEsbIgJBf3NBH3YhBgJAIAUEQCAEQQE2AhggBCAFNgIUIAQgACgCADYCEAwBCyAEQQA2AhgLIAQgAiAGIARBEGoQWCAEKAIEIQUgBCgCAEUEQCAAIAU2AgAgAEEEaiACNgIADAILIARBCGooAgAiAkGBgICAeEYNASACRQ0AIAUgAhDbAQALEIgBAAsgBEEgaiQAIAAoAgghAgsgACACQQFqNgIIIAAoAgAgAmogAToAAAwCCyABQYCABE8EQCADIAFBP3FBgAFyOgAPIAMgAUEGdkE/cUGAAXI6AA4gAyABQQx2QT9xQYABcjoADSADIAFBEnZBB3FB8AFyOgAMQQQMAQsgAyABQT9xQYABcjoADiADIAFBDHZB4AFyOgAMIAMgAUEGdkE/cUGAAXI6AA1BAwshASABIABBBGooAgAgACgCCCICa0sEQCAAIAIgARBTIAAoAgghAgsgACgCACACaiADQQxqIAEQ4AEaIAAgASACajYCCAsgA0EQaiQAQQAL1QIBAn8jAEEQayICJAAgACgCACEAAkACfwJAIAFBgAFPBEAgAkEANgIMIAFBgBBPDQEgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAgsgACgCCCIDIAAoAgRGBH8gACADEFQgACgCCAUgAwsgACgCAGogAToAACAAIAAoAghBAWo2AggMAgsgAUGAgARPBEAgAiABQT9xQYABcjoADyACIAFBBnZBP3FBgAFyOgAOIAIgAUEMdkE/cUGAAXI6AA0gAiABQRJ2QQdxQfABcjoADEEEDAELIAIgAUE/cUGAAXI6AA4gAiABQQx2QeABcjoADCACIAFBBnZBP3FBgAFyOgANQQMLIQEgASAAKAIEIAAoAggiA2tLBEAgACADIAEQUiAAKAIIIQMLIAAoAgAgA2ogAkEMaiABEOABGiAAIAEgA2o2AggLIAJBEGokAEEAC84CAQJ/IwBBEGsiAiQAAkACfwJAIAFBgAFPBEAgAkEANgIMIAFBgBBPDQEgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAgsgACgCCCIDIAAoAgRGBH8gACADEFQgACgCCAUgAwsgACgCAGogAToAACAAIAAoAghBAWo2AggMAgsgAUGAgARPBEAgAiABQT9xQYABcjoADyACIAFBBnZBP3FBgAFyOgAOIAIgAUEMdkE/cUGAAXI6AA0gAiABQRJ2QQdxQfABcjoADEEEDAELIAIgAUE/cUGAAXI6AA4gAiABQQx2QeABcjoADCACIAFBBnZBP3FBgAFyOgANQQMLIQEgASAAKAIEIAAoAggiA2tLBEAgACADIAEQUiAAKAIIIQMLIAAoAgAgA2ogAkEMaiABEOABGiAAIAEgA2o2AggLIAJBEGokAEEAC8ACAgV/AX4jAEEwayIFJABBJyEDAkAgAEKQzgBUBEAgACEIDAELA0AgBUEJaiADaiIEQQRrIAAgAEKQzgCAIghCkM4Afn2nIgZB//8DcUHkAG4iB0EBdEG2y8AAai8AADsAACAEQQJrIAYgB0HkAGxrQf//A3FBAXRBtsvAAGovAAA7AAAgA0EEayEDIABC/8HXL1YgCCEADQALCyAIpyIEQeMASwRAIANBAmsiAyAFQQlqaiAIpyIEIARB//8DcUHkAG4iBEHkAGxrQf//A3FBAXRBtsvAAGovAAA7AAALAkAgBEEKTwRAIANBAmsiAyAFQQlqaiAEQQF0QbbLwABqLwAAOwAADAELIANBAWsiAyAFQQlqaiAEQTBqOgAACyACIAFByK/AAEEAIAVBCWogA2pBJyADaxAtIAVBMGokAAvBAgEDfyMAQYABayIEJAACQAJAAkACQCABKAIAIgJBEHFFBEAgAkEgcQ0BIAA1AgBBASABEEIhAAwECyAAKAIAIQBBACECA0AgAiAEakH/AGpBMEHXACAAQQ9xIgNBCkkbIANqOgAAIAJBAWshAiAAQQ9LIABBBHYhAA0ACyACQYABaiIAQYEBTw0BIAFBAUG0y8AAQQIgAiAEakGAAWpBACACaxAtIQAMAwsgACgCACEAQQAhAgNAIAIgBGpB/wBqQTBBNyAAQQ9xIgNBCkkbIANqOgAAIAJBAWshAiAAQQ9LIABBBHYhAA0ACyACQYABaiIAQYEBTw0BIAFBAUG0y8AAQQIgAiAEakGAAWpBACACaxAtIQAMAgsgAEGAAUGky8AAEMkBAAsgAEGAAUGky8AAEMkBAAsgBEGAAWokACAAC9cCAgR/An4jAEFAaiIDJAAgAAJ/IAAtAAgEQCAAKAIEIQVBAQwBCyAAKAIEIQUgACgCACIEKAIAIgZBBHFFBEBBASAEKAIYQerKwABBgcvAACAFG0ECQQEgBRsgBEEcaigCACgCDBEBAA0BGiABIAQgAigCDBEAAAwBCyAFRQRAIAQoAhhB/8rAAEECIARBHGooAgAoAgwRAQAEQEEAIQVBAQwCCyAEKAIAIQYLIANBAToAFyADQTRqQczKwAA2AgAgAyAGNgIYIAMgBCkCGDcDCCADIANBF2o2AhAgBCkCCCEHIAQpAhAhCCADIAQtACA6ADggAyAEKAIENgIcIAMgCDcDKCADIAc3AyAgAyADQQhqNgIwQQEgASADQRhqIAIoAgwRAAANABogAygCMEHoysAAQQIgAygCNCgCDBEBAAs6AAggACAFQQFqNgIEIANBQGskACAAC6MCAQR/IABCADcCECAAAn9BACABQYACSQ0AGkEfIAFB////B0sNABogAUEGIAFBCHZnIgJrdkEBcSACQQF0a0E+agsiAjYCHCACQQJ0QaDpwABqIQMCQAJAAkACQEGU58AAKAIAIgRBASACdCIFcQRAIAMoAgAhAyACEKoBIQIgAxDXASABRw0BIAMhAgwCC0GU58AAIAQgBXI2AgAgAyAANgIADAMLIAEgAnQhBANAIAMgBEEddkEEcWpBEGoiBSgCACICRQ0CIARBAXQhBCACIgMQ1wEgAUcNAAsLIAIoAggiASAANgIMIAIgADYCCCAAIAI2AgwgACABNgIIIABBADYCGA8LIAUgADYCAAsgACADNgIYIAAgADYCCCAAIAA2AgwLtgIBBX8gACgCGCEEAkACQCAAIAAoAgxGBEAgAEEUQRAgAEEUaiIBKAIAIgMbaigCACICDQFBACEBDAILIAAoAggiAiAAKAIMIgE2AgwgASACNgIIDAELIAEgAEEQaiADGyEDA0AgAyEFIAIiAUEUaiIDKAIAIgJFBEAgAUEQaiEDIAEoAhAhAgsgAg0ACyAFQQA2AgALAkAgBEUNAAJAIAAgACgCHEECdEGg6cAAaiICKAIARwRAIARBEEEUIAQoAhAgAEYbaiABNgIAIAENAQwCCyACIAE2AgAgAQ0AQZTnwABBlOfAACgCAEF+IAAoAhx3cTYCAA8LIAEgBDYCGCAAKAIQIgIEQCABIAI2AhAgAiABNgIYCyAAQRRqKAIAIgBFDQAgAUEUaiAANgIAIAAgATYCGAsLmAIBAX8jAEEQayICJAAgACgCACEAAn8CQCABKAIIQQFHBEAgASgCEEEBRw0BCyACQQA2AgwgASACQQxqAn8gAEGAAU8EQCAAQYAQTwRAIABBgIAETwRAIAIgAEE/cUGAAXI6AA8gAiAAQRJ2QfABcjoADCACIABBBnZBP3FBgAFyOgAOIAIgAEEMdkE/cUGAAXI6AA1BBAwDCyACIABBP3FBgAFyOgAOIAIgAEEMdkHgAXI6AAwgAiAAQQZ2QT9xQYABcjoADUEDDAILIAIgAEE/cUGAAXI6AA0gAiAAQQZ2QcABcjoADEECDAELIAIgADoADEEBCxAnDAELIAEoAhggACABQRxqKAIAKAIQEQAACyACQRBqJAALYAEMf0HA6sAAKAIAIgIEQEG46sAAIQYDQCACIgEoAgghAiABKAIEIQMgASgCACEEIAFBDGooAgAaIAEhBiAFQQFqIQUgAg0ACwtB0OrAACAFQf8fIAVB/x9LGzYCACAIC4sCAgR/AX4jAEEwayICJAAgAUEEaiEEIAEoAgRFBEAgASgCACEDIAJBEGoiBUEANgIAIAJCATcDCCACIAJBCGo2AhQgAkEoaiADQRBqKQIANwMAIAJBIGogA0EIaikCADcDACACIAMpAgA3AxggAkEUakHAocAAIAJBGGoQMBogBEEIaiAFKAIANgIAIAQgAikDCDcCAAsgAkEgaiIDIARBCGooAgA2AgAgAUEMakEANgIAIAQpAgAhBiABQgE3AgQgAiAGNwMYQQxBBBC4ASIBRQRAQQxBBBDbAQALIAEgAikDGDcCACABQQhqIAMoAgA2AgAgAEGAp8AANgIEIAAgATYCACACQTBqJAALzwIBAX9BwAEhAQJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAALQAAQQJrDiMjAQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0eHyAhIgALIAAtAAEPC0HDAQ8LQcIBDwtBzAEPC0HNAQ8LQc4BDwtBzwEPC0HQAQ8LQdEBDwtB0gEPC0HTAQ8LQcoBDwtBywEPCyAALQABQR9xQaB/cg8LQdkBDwtB2gEPC0HbAQ8LQcQBDwtBxQEPC0HGAQ8LIAAtAAFBD3FBkH9yDwtB3AEPC0HdAQ8LIAAtAAFBD3FBgH9yDwtB3gEPC0HfAQ8LQdQBDwtB1QEPC0HWAQ8LQdcBDwtB2AEPC0HHAQ8LQcgBDwtByQEPC0HBASEBCyABC4kCAQJ/IwBBIGsiBSQAIAVBEGogASACIAMQLgJAIAUoAhAiAkECRgRAIAQoAgAhBiAFQRBqIAEgBEEIaigCACICEDMgBSgCECIDQQJGBEAgAiABKAIEIAEoAggiA2tLBH8gASADIAIQUiABKAIIBSADCyABKAIAaiAGIAIQ4AEaIABBBTYCACABIAEoAgggAmo2AggMAgsgBUEMaiAFQRpqIgEvAQAiAjsBACAFIAUoARYiBDYCCCAFLwEUIQYgASACOwEAIAUgBjsBFCAFIAM2AhAgBSAENgEWIAAgBUEQahCcAQwBCyAFIAUpAhQ3AhQgBSACNgIQIAAgBUEQahCcAQsgBUEgaiQAC+UBAQF/IwBBEGsiAiQAIAAoAgAgAkEANgIMIAJBDGoCfyABQYABTwRAIAFBgBBPBEAgAUGAgARPBEAgAiABQT9xQYABcjoADyACIAFBBnZBP3FBgAFyOgAOIAIgAUEMdkE/cUGAAXI6AA0gAiABQRJ2QQdxQfABcjoADEEEDAMLIAIgAUE/cUGAAXI6AA4gAiABQQx2QeABcjoADCACIAFBBnZBP3FBgAFyOgANQQMMAgsgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAQsgAiABOgAMQQELEDcgAkEQaiQAC+IBAQF/IwBBEGsiAiQAIAJBADYCDCAAIAJBDGoCfyABQYABTwRAIAFBgBBPBEAgAUGAgARPBEAgAiABQT9xQYABcjoADyACIAFBBnZBP3FBgAFyOgAOIAIgAUEMdkE/cUGAAXI6AA0gAiABQRJ2QQdxQfABcjoADEEEDAMLIAIgAUE/cUGAAXI6AA4gAiABQQx2QeABcjoADCACIAFBBnZBP3FBgAFyOgANQQMMAgsgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAQsgAiABOgAMQQELEDcgAkEQaiQAC+EBAAJAIABBIEkNAAJAAn9BASAAQf8ASQ0AGiAAQYCABEkNAQJAIABBgIAITwRAIABBsMcMa0HQuitJIABBy6YMa0EFSXINBCAAQZ70C2tB4gtJIABB4dcLa0GfGElyDQQgAEF+cUGe8ApGIABBop0La0EOSXINBCAAQWBxQeDNCkcNAQwECyAAQf7XwABBLEHW2MAAQcQBQZrawABBwgMQPg8LQQAgAEG67gprQQZJDQAaIABBgIDEAGtB8IN0SQsPCyAAQeDSwABBKEGw08AAQZ8CQc/VwABBrwIQPg8LQQALyAMCA34GfyMAQSBrIgckAAJAQbTmwAAoAgANAEHgksAAIQQCf0EAIABFDQAaIAAoAgAhBSAAQQA2AgBBACAFQQFHDQAaIAAoAhQhBiAAKAIMIQQgACgCCCEIIAAoAgQhCSAAKAIQCyEAQbTmwAApAgAhAUG05sAAQQE2AgBBuObAACAJNgIAQbzmwAApAgAhAkG85sAAIAg2AgBBwObAACAENgIAQcTmwAApAgAhA0HE5sAAIAA2AgBByObAACAGNgIAIAdBGGogAzcDACAHQRBqIgAgAjcDACAHIAE3AwggAadFDQACQCAAKAIAIghFDQACQCAAKAIMIgVFBEAgAEEEaigCACEADAELIAAoAgQiAEEIaiEGIAApAwBCf4VCgIGChIiQoMCAf4MhASAAIQQDQCABUARAA0AgBEHgAGshBCAGKQMAIAZBCGohBkJ/hUKAgYKEiJCgwIB/gyIBUA0ACwsgBUEBayEFIAQgAXqnQQN2QXRsakEEaygCACIJQSRPBEAgCRAACyABQgF9IAGDIQEgBQ0ACwsgCCAIQQFqrUIMfqdBB2pBeHEiBGpBd0YNACAAIARrECYLCyAHQSBqJABBuObAAAvpAQECfyMAQSBrIgIkACACIAA2AgwgAiABKAIYQajfwABBESABQRxqKAIAKAIMEQEAOgAYIAIgATYCECACQQA6ABkgAkEANgIUIAJBEGogAkEMakGY38AAEEQhAAJ/IAItABgiASACKAIUIgNFDQAaIAFB/wFxIQFBASABDQAaIAAoAgAhAAJAIANBAUcNACACLQAZRQ0AIAAtAABBBHENAEEBIAAoAhhBgsvAAEEBIABBHGooAgAoAgwRAQANARoLIAAoAhhB7MfAAEEBIABBHGooAgAoAgwRAQALIAJBIGokAEH/AXFBAEcL4QEAAkAgASgCAEECRgRAIAAgAikCADcCACAAQQhqIAJBCGooAgA2AgAMAQsgACABKQIANwIAIABBCGogAUEIaigCADYCAAJAAkACQAJAIAIoAgAOAwABBAELIAItAARBA0cNAyACQQhqIgAoAgAiASgCACABKAIEKAIAEQQAIAEoAgQiAkEEaigCAA0BDAILIAItAARBA0cNAiACQQhqIgAoAgAiASgCACABKAIEKAIAEQQAIAEoAgQiAkEEaigCAEUNAQsgAkEIaigCABogASgCABAmIAAoAgAhAQsgARAmCwvOAQECfyMAQSBrIgMkAAJAAkAgASABIAJqIgFLDQAgAEEEaigCACICQQF0IgQgASABIARJGyIBQQggAUEISxsiAUF/c0EfdiEEAkAgAgRAIANBATYCGCADIAI2AhQgAyAAKAIANgIQDAELIANBADYCGAsgAyABIAQgA0EQahBXIAMoAgQhAiADKAIARQRAIAAgAjYCACAAQQRqIAE2AgAMAgsgA0EIaigCACIAQYGAgIB4Rg0BIABFDQAgAiAAENsBAAsQiAEACyADQSBqJAALzgEBAn8jAEEgayIDJAACQAJAIAEgASACaiIBSw0AIABBBGooAgAiAkEBdCIEIAEgASAESRsiAUEIIAFBCEsbIgFBf3NBH3YhBAJAIAIEQCADQQE2AhggAyACNgIUIAMgACgCADYCEAwBCyADQQA2AhgLIAMgASAEIANBEGoQWCADKAIEIQIgAygCAEUEQCAAIAI2AgAgAEEEaiABNgIADAILIANBCGooAgAiAEGBgICAeEYNASAARQ0AIAIgABDbAQALEIgBAAsgA0EgaiQAC8wBAQN/IwBBIGsiAiQAAkACQCABQQFqIgFFDQAgAEEEaigCACIDQQF0IgQgASABIARJGyIBQQggAUEISxsiAUF/c0EfdiEEAkAgAwRAIAJBATYCGCACIAM2AhQgAiAAKAIANgIQDAELIAJBADYCGAsgAiABIAQgAkEQahBXIAIoAgQhAyACKAIARQRAIAAgAzYCACAAQQRqIAE2AgAMAgsgAkEIaigCACIAQYGAgIB4Rg0BIABFDQAgAyAAENsBAAsQiAEACyACQSBqJAAL0gEBAX8jAEEQayIEJAAgBCAAKAIYIAEgAiAAQRxqKAIAKAIMEQEAOgAIIAQgADYCACAEIAJFOgAJIARBADYCBCAEIANB6JzAABBEIQACfyAELQAIIgEgBCgCBCICRQ0AGkEBIAENABogACgCACEAAkAgAkEBRw0AIAQtAAlFDQAgAC0AAEEEcQ0AQQEgACgCGEGCy8AAQQEgAEEcaigCACgCDBEBAA0BGgsgACgCGEHsx8AAQQEgAEEcaigCACgCDBEBAAsgBEEQaiQAQf8BcUEARwuIAgECfyMAQSBrIgUkAEGE58AAQYTnwAAoAgAiBkEBajYCAAJAAkAgBkEASA0AQdzqwABB3OrAACgCAEEBaiIGNgIAIAZBAksNACAFIAQ6ABggBSADNgIUIAUgAjYCECAFQcinwAA2AgwgBUHYocAANgIIQfTmwAAoAgAiAkEASA0AQfTmwAAgAkEBaiICNgIAQfTmwABB/ObAACgCAAR/IAUgACABKAIQEQMAIAUgBSkDADcDCEH85sAAKAIAIAVBCGpBgOfAACgCACgCFBEDAEH05sAAKAIABSACC0EBazYCACAGQQFLDQAgBA0BCwALIwBBEGsiAiQAIAIgATYCDCACIAA2AggAC7oBAAJAIAIEQAJAAkACfwJAAkAgAUEATgRAIAMoAggNASABDQJBASECDAQLDAYLIAMoAgQiAkUEQCABRQRAQQEhAgwECyABQQEQuAEMAgsgAygCACACQQEgARCwAQwBCyABQQEQuAELIgJFDQELIAAgAjYCBCAAQQhqIAE2AgAgAEEANgIADwsgACABNgIEIABBCGpBATYCACAAQQE2AgAPCyAAIAE2AgQLIABBCGpBADYCACAAQQE2AgALrQEBAX8CQCACBEACfwJAAkACQCABQQBOBEAgAygCCEUNAiADKAIEIgQNASABDQMgAgwECyAAQQhqQQA2AgAMBQsgAygCACAEIAIgARCwAQwCCyABDQAgAgwBCyABIAIQuAELIgMEQCAAIAM2AgQgAEEIaiABNgIAIABBADYCAA8LIAAgATYCBCAAQQhqIAI2AgAMAQsgACABNgIEIABBCGpBADYCAAsgAEEBNgIAC6wBAQN/IwBBMGsiAiQAIAFBBGohAyABKAIERQRAIAEoAgAhASACQRBqIgRBADYCACACQgE3AwggAiACQQhqNgIUIAJBKGogAUEQaikCADcDACACQSBqIAFBCGopAgA3AwAgAiABKQIANwMYIAJBFGpBwKHAACACQRhqEDAaIANBCGogBCgCADYCACADIAIpAwg3AgALIABBgKfAADYCBCAAIAM2AgAgAkEwaiQAC6YBAQF/IwBB4ABrIgEkACABQRhqIABBEGopAgA3AwAgAUEQaiAAQQhqKQIANwMAIAEgACkCADcDCCABQQA2AiggAUIBNwMgIAFBMGoiACABQSBqQaiDwAAQkgEgAUEIaiAAEGpFBEAgASgCICABKAIoEOgBIAEoAiQEQCABKAIgECYLIAFB4ABqJAAPC0HAg8AAQTcgAUHYAGpB+IPAAEHUhMAAEGQAC9qtAQMyfip/AXwjAEEQayJPJAAgASE0IwBBgANrIkQkAEHM5sAAKAIAQQNHBEAgREEBOgAAIEQgRDYCuAEgREG4AWohPSMAQSBrIkUkACBFQQhqQQJyITtBzObAACgCACEBA0ACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIAEiNQ4EAAMCAQILQczmwABBAkHM5sAAKAIAIgEgASA1RiI4GzYCACA4RQ0NIEUgNUEBRjoADCBFQQM2AgggPSBFQQhqQbSOwAAoAgARAwBBzObAACgCACE1QczmwAAgRSgCCDYCACBFIDVBA3EiATYCACABQQJHDQggNUECayIBRQ0AA0AgASgCACE+IAFBADYCACA+RQ0KIAEoAgQgAUEBOgAIQQAhQyMAQSBrIj0kACA+QRhqIjsoAgAhASA7QQI2AgACQAJAAkAgAQ4DAgECAAsgPUEcakEANgIAID1B2KHAADYCGCA9QgE3AgwgPUHQrMAANgIIID1BCGpB2KzAABCJAQALIDstAAQhASA7QQE6AAQgPSABQQFxIgE6AAcCQAJAIAFFBEAgO0EEaiE4AkBBhOfAACgCAEH/////B3EEQBDqASEBIDstAAUEQCABQQFzIUMMAgsgAUUNBAwDCyA7LQAFRQ0CCyA9IEM6AAwgPSA4NgIIQceiwABBKyA9QQhqQfiqwABB6KzAABBkAAsgPUEANgIcID1B2KHAADYCGCA9QgE3AgwgPUHkqMAANgIIID1BB2ogPUEIahBsAAtBhOfAACgCAEH/////B3FFDQAQ6gENACA7QQE6AAULIDhBADoAAAsgPUEgaiQAID4gPigCACIBQQFrNgIAIAFBAUYEQCA+EH0LIgENAAsLIEVBIGokAAwLCyA1QQNxQQJGBEADQEHU6sAAKAIADQNB1OrAAEF/NgIAQdjqwAAoAgAiAUUEQEEgQQgQuAEiAUUNBSABQoGAgIAQNwMAIAFBEGpBADYCAEGI58AAKQMAIQIDQCACQgF8IgRQDQdBiOfAACAEQYjnwAApAwAiAyACIANRIjgbNwMAIAMhAiA4RQ0ACyABQQA7ARwgASAENwMIQdjqwAAgATYCACABQRhqQQA2AgALIAEgASgCACI4QQFqNgIAIDhBAEgNBiA1IThB1OrAAEHU6sAAKAIAQQFqNgIAQczmwAAgO0HM5sAAKAIAIjUgNSA4RiI+GzYCACBFQQA6ABAgRSABNgIIIEUgOEF8cTYCDCA+BEAgRS0AEEUNCAwLCwJAIEUoAggiAUUNACABIAEoAgAiAUEBazYCACABQQFHDQAgRSgCCBB9CyA1QQNxQQJGDQAMCwsAC0G0qcAAQcAAQcCQwAAQgwEACyBFQRxqQQA2AgAgRUHYocAANgIYIEVCATcCDCBFQaCqwAA2AgggRUEIakHAkMAAEIkBAAtB2KHAAEEQIEVB6KHAAEGMpcAAEGQAC0EgQQgQ2wEACxCHAQALAAsDQCMAQSBrIj4kAAJAAkACQAJAAkACQAJ/IwBBEGsiOCQAAkACQAJAQdTqwAAoAgBFBEBB1OrAAEF/NgIAQdjqwAAoAgAiNUUEQEEgQQgQuAEiNUUNAiA1QoGAgIAQNwMAIDVBEGpBADYCAEGI58AAKQMAIQIDQCACQgF8IgRQDQRBiOfAACAEQYjnwAApAwAiAyACIANRIgEbNwMAIAMhAiABRQ0ACyA1QQA7ARwgNSAENwMIQdjqwAAgNTYCACA1QRhqQQA2AgALIDUgNSgCACIBQQFqNgIAIAFBAEgNA0HU6sAAQdTqwAAoAgBBAWo2AgAgOEEQaiQAIDUMBAtB2KHAAEEQIDhBCGpB6KHAAEGMpcAAEGQAC0EgQQgQ2wEACxCHAQALAAsiOARAIDhBGGoiAUEAIAEoAgAiASABQQJGIgEbNgIAIAFFBEAgOEEcaiI1LQAAIQEgNUEBOgAAID4gAUEBcSIBOgAEIAENAkEAIUNBhOfAACgCAEH/////B3EEQBDqAUEBcyFDCyA4LQAdDQMgOCA4KAIYIgFBASABGzYCGCABRQ0GIAFBAkcNBCA4KAIYIQEgOEEANgIYID4gATYCBCABQQJHDQUCQCBDDQBBhOfAACgCAEH/////B3FFDQAQ6gENACA4QQE6AB0LIDVBADoAAAsgOCA4KAIAIgFBAWs2AgAgAUEBRgRAIDgQfQsgPkEgaiQADAYLIwBBEGsiACQAIABB3gA2AgwgAEH9osAANgIIIwBBIGsiASQAIAFBFGpBATYCACABQgE3AgQgAUGUycAANgIAIAFB+gA2AhwgASAAQQhqNgIYIAEgAUEYajYCECABQfijwAAQiQEACyA+QQA2AhwgPkHYocAANgIYID5CATcCDCA+QeSowAA2AgggPkEEaiA+QQhqEGwACyA+IEM6AAwgPiA1NgIIQceiwABBKyA+QQhqQfiqwABBvKvAABBkAAsgPkEcakEANgIAID5B2KHAADYCGCA+QgE3AgwgPkHkq8AANgIIID5BCGpB7KvAABCJAQALID5BADYCHCA+QdihwAA2AhggPkIBNwIMID5BnKzAADYCCCA+QQRqID5BCGpBpKzAABBtAAsgPkEcakEANgIAID5B2KHAADYCGCA+QgE3AgwgPkH0p8AANgIIID5BCGpBtKjAABCJAQALIEUtABBFDQALDAILIEVBADYCCCBFIEVBCGpB2KrAABBtAAtBnKLAAEErQeiqwAAQgwEACyBFKAIIIgFFDQAgASABKAIAIgFBAWs2AgAgAUEBRw0AIEUoAggQfUHM5sAAKAIAIQEMAgtBzObAACgCACEBDAELCwsgREG4AWohP0EAITVBACE+QQAhOEEAIUVBACE9IwBBsAJrIjYkACA2IDQ2AiwCQAJAAkACQAJAAkACQAJAAkACQAJAAn8CQAJAIDQQAkEBRgRAIDZBCDYCOCA2QdiLwAA2AjQgNiA0NgIwIDZBqAFqIU0gNkGgAWpBAXIhXUECIUMDQCA0IQEgNigCNCI6KAIAITsgNkEgaiI0IDooAgQ2AgQgNCA7NgIAIDZBoAFqITsgNigCICE0An8CQAJAAkACQAJAAkACQAJAAkAgNigCJEEFaw4GBgcBBwIABwsgNEGEi8AAQQoQ3wENA0EADAgLIDRBjovAAEEHEN8BDQFBAQwHCyA0QZWLwABBCRDfAQ0EQQIMBgsgNEGei8AAQQcQ3wENAUEDDAULIDRBpYvAAEEKEN8BDQNBBAwECyA0Qa+LwABBBxDfAQ0BQQUMAwtBCEEGIDRBtovAAEEFEN8BGwwCC0EIDAELQQhBByA0QbuLwABBChDfARsLITQgO0EAOgAAIDsgNDoAAQJAAkACfwJAIDYtAKABBEAgNigCpAEhNCA/QQI6AFAgPyA0NgIADAELAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIDYtAKEBDggIBwYFBAMCAQALIDYoAjgiNEUNIyA2KAI0IjtFDSMgNiA0QQFrNgI4IDYgO0EIajYCNCA2QTBqIDsoAgAgOygCBBCMARDTASI0QSRJDRMgNBAADBMLIAinDQkgNigCOCI8RQ0iIDYoAjQiNEUNIiA2IDxBAWs2AjggNiA0QQhqNgI0IDYgNkEwaiA0KAIAIDQoAgQQjAEQ0wE2AqABIDZBEGohO0IAIQJCACEIIwBBEGsiOiQAIDogNkGgAWoiNCgCABAHAkAgOigCAEUNACA6KwMIIV4gNCgCABAYRQ0AIF5EAAAAAAAA4MNmITRCAEL///////////8AAn4gXplEAAAAAAAA4ENjBEAgXrAMAQtCgICAgICAgICAfwtCgICAgICAgICAfyA0GyBeRP///////99DZBsgXiBeYhshCEIBIQILIDsgCDcDCCA7IAI3AwAgOkEQaiQAAkAgNikDEEL/////D4MiAlAEQCA2QaABaiA2QagCakG8gcAAEDQhPAwBCyA2KQMYIQkLIDYoAqABIjRBJE8EQCA0EAALQgEhCCACUEUNEiA/QQI6AFAgPyA8NgIADBALIEkNBiA2KAI4IjRFDSEgNigCNCI7RQ0hIDYgNEEBazYCOCA2IDtBCGo2AjQgNiA2QTBqIDsoAgAgOygCBBCMARDTATYChAIgNkGIAmogNkGEAmoQXQJAIDYoAogCBEAgNkGgAmogNkGQAmooAgA2AgAgNiA2KQOIAjcDmAIgNkGgAWohUSMAQUBqIkkkACA2QZgCaiJCKAIAITwCQCBCQQhqKAIAIjtBIEYEQCBRQQA6AAAgUSA8KQAANwABIFFBGWogPEEYaikAADcAACBRQRFqIDxBEGopAAA3AAAgUUEJaiA8QQhqKQAANwAADAELIElBHGpBDjYCACBJQR82AhQgSUHEjMAANgIQIEkgOzYCJCBJIElBJGo2AhggSUECNgI8IElCAzcCLCBJQayMwAA2AiggSSBJQRBqIjo2AjggSSBJQShqIjQQNSBJQTBqIDs2AgAgSSA8NgIsIElBBjoAKCBJIEkoAgg2AhQgSSBJKAIAIjs2AhAgNCA6QciMwAAQZiE0IFFBAToAACBRIDQ2AgQgSSgCBEUNACA7ECYLIEJBBGooAgAEQCA8ECYLIElBQGskAAwBCyA2QYQCaiA2QagCakHsgMAAEDQhNCA2QQE6AKABIDYgNDYCpAELIDYoAoQCIjRBJE8EQCA0EAALIDYtAKABRQRAIDZBngFqIF1BAmotAAA6AAAgNkH4AWogTUEQaikCACICNwMAIDZBiAFqIE1BCGopAgA3AwAgNkGQAWogAjcDACA2QZgBaiBNQRhqLQAAOgAAIDYgXS8AADsBnAEgNiBNKQIANwOAASA2KAKkASFRQQEhSQwSCyA2KAKkASE0ID9BAjoAUCA/IDQ2AgAMDwsgUEUNDUH3gcAAQQcQfCE0ID9BAjoAUCA/IDQ2AgAMDgsgQ0ECRg0LQe2BwABBChB8ITQgP0ECOgBQID8gNDYCAAwNCyBORQ0IQeaBwABBBxB8ITQgP0ECOgBQID8gNDYCAAwMCyBUDQMgNigCOCI0RQ0dIDYoAjQiO0UNHSA2IDRBAWs2AjggNiA7QQhqNgI0IDYgNkEwaiA7KAIAIDsoAgQQjAEQ0wEiPDYCoAEgNiA8EAECQCA2KAIAIjQEQCA2NQIEQoGAgIAQfiECDAELIDZBoAFqIDZBqAJqQbyAwAAQNK0hAkEAITQgNigCoAEhPAsgPEEkTwRAIDwQAAsgNARAIFZFIFRFIAFFcnJFBEAgARAmCyACQiCIpyFaIAKnIVZBASFUDA8LID9BAjoAUCA/IAI+AgAMCwsgSEUNBUHWgcAAQQcQfCE0ID9BAjoAUCA/IDQ2AgAMCgsgNUUNA0HMgcAAQQoQfCE0ID9BAjoAUCA/IDQ2AgAMCQtB/oHAAEEFEHwhNCA/QQI6AFAgPyA0NgIADAgLQd2BwABBCRB8ITQgP0ECOgBQID8gNDYCAEEAIUJBASFUQQEhPiA1DAgLQYOCwABBChB8ITQgP0ECOgBQID8gNDYCAAwGCwJAIDYoAjgiNUUNACA2KAI0IjRFDQAgNiA1QQFrNgI4IDYgNEEIajYCNCA2IDZBMGogNCgCACA0KAIEEIwBENMBNgKIAiA2QegBaiA2QYgCahBdAkAgNigC6AEEQCBNIDZB8AFqKAIANgIAIDYgNikD6AE3A6ABIDZBmAJqIDZBoAFqEDYMAQsgNkGIAmogNkGoAmpBzIDAABA0ITUgNkEANgKYAiA2IDU2ApwCCyA2KAKIAiI1QSRPBEAgNRAACyA2KAKcAiE7IDYoApgCIjUEQCA2KAKgAiFbIAEhNCA7IUUMCgsgP0ECOgBQID8gOzYCAAwNCwwXCwJAIDYoAjgiNEUNACA2KAI0IjtFDQAgNiA0QQFrNgI4IDYgO0EIajYCNCA2QaABaiFSIDZBMGogOygCACA7KAIEEIwBENMBITQjAEHgAGsiQCQAIEAgNDYCJAJAAkAgQEEkaigCABAUBEAgQEEkaigCABAWITsgQEEYaiI0QQA6AAQgNCA7NgIAIEAtABwhNCBAKAIYIUgMAQsgQEHQAGohTCMAQRBrIjwkABAQITogQEEkaigCACI7IDoQESE0IDxBCGoQlQEgPCgCDCA0IDwoAggiNBshSwJAAkACQAJAIDRFBEAgSxALQQFGDQEgTEECOgAEIEtBJEkNAiBLEAAMAgsgTEEDOgAEIEwgSzYCAAwBCyBLIDsQEiE0IDwQlQEgPCgCBCA0IDwoAgAiNBshQgJAAkACQAJAIDRFBEAgQhACQQFHDQMgQhAMIjsQCyE0IDtBJEkNASA7EAAgNEEBRg0CDAMLIExBAzoABCBMIEI2AgAMAwsgNEEBRw0BCyBMQQA6AAQgTCBCNgIAIEtBJE8EQCBLEAALIDpBI0sNAwwECyBMQQI6AAQgQkEkSQ0AIEIQAAsgS0EkSQ0AIEsQAAsgOkEjTQ0BCyA6EAALIDxBEGokACBAKAJQIUgCfwJAAkAgQC0AVCI0QQJrDgIBAAMLIEgMAQsgQEEkaiBAQdAAakH8gMAAEDQLITQgUkEANgIAIFIgNDYCBAwBCyBAIEg2AiggQCA0QQFxOgAsIEBBEGogQEEoahBhIEAoAhQhSAJAAkACQAJAAkACQAJAIEAoAhBBAWsOAgMBAAsgQCBINgI8IEBBQGsgQEE8ahBdAkAgQCgCQARAIEBB2ABqIEBByABqKAIANgIAIEAgQCkDQDcDUCBAQTBqIUgjAEHQAGsiRiQAIEBB0ABqIjwoAgAhQgJAAkACQAJAAkAgPEEIaigCACJBQVhGBEAQYyE0IEhBADYCACBIIDQ2AgQMAQsgQUUNAyBBQQBIDQEgQUEBELgBIjRFDQIgNCBCIEEQ4AEhTCBBQQJNDQMgRkEoaiFKIwBBIGsiSyQAIEtBEGoiNEEDNgIEIDRB2pjAADYCAAJAAkACQAJAAkAgSygCFEEDRgRAIEwgSygCEEEDEN8BRQ0BCyBLQQhqIjRBBzYCBCA0Qd2YwAA2AgAgSygCCCE0AkAgSygCDCI6RQRAQQEhOwwBCyA6QQBIDQMgOkEBELgBIjtFDQQLIDsgNCA6EOABITQgSiA6NgIMIEogOjYCCCBKIDQ2AgQgSkEDOgAAIEogTC8AADsAASBKQQNqIExBAmotAAA6AAAMAQsgSkEGOgAACyBLQSBqJAAMAgsQiAEACyA6QQEQ2wEACyBGLQAoIjpBBkYEQCBIIEE2AgggSCBBNgIEIEggTDYCAAwBCyBGQQZqIjsgRi0AKzoAACBGIEYvACk7AQQgRikCLCECIEYoAjQhNCBMECYgRiA6OgAIIEYgRi8BBDsACSBGIDstAAA6AAsgRiA0NgIUIEYgAjcCDCBGQRo2AkQgRiBGQQhqNgJAIEZBATYCPCBGQgE3AiwgRkGcicAANgIoIEYgRkFAayI7NgI4IEZBGGogRkEoaiI0EDUgRkHIAGogRkEgaigCADYCACBGIEYpAxg3A0AgNCA7EHQgRigCKCI7IEYoAjAQ6AEhNCBGKAIsBEAgOxAmCyBGKAJEBEAgRigCQBAmCwJAIEYtAAhBA0cNACBGKAIQRQ0AIEYoAgwQJgsgSEEANgIAIEggNDYCBAsgPEEEaigCAARAIEIQJgsgRkHQAGokAAwDCxCIAQALIEFBARDbAQALQQMgQUG8jcAAEMoBAAsMAQsgQEE8aiBAQdAAakGcgcAAEDQhNCBAQQA2AjAgQCA0NgI0CyBAKAI8IjRBJE8EQCA0EAALIEAoAjAiOw0BIEAoAjQhSAwCC0EAEGIhSAwBCyBAKQI0IQIgQEEIaiBAQShqEGEgQCgCDCE0AkACQAJAAkAgQCgCCEEBaw4CAwEACyBAIDQ2AjwgQEFAayBAQTxqEF0CQCBAKAJABEAgQEHYAGogQEHIAGooAgA2AgAgQCBAKQNANwNQIEBBMGogQEHQAGoQNgwBCyBAQTxqIEBB0ABqQcyAwAAQNCE0IEBBADYCMCBAIDQ2AjQLIEAoAjwiNEEkTwRAIDQQAAsgQCgCMCI0DQEgQCgCNCE0DAILQQEQYiE0DAELIFIgQCkCNDcCECBSIDQ2AgwgUiACNwIEIFIgOzYCACBAKAIoIjxBJEkNBAwDCyBSQQA2AgAgUiA0NgIEIAKnRQ0BIDsQJgwBCyBSQQA2AgAgUiBINgIECyBAKAIoIjxBI00NAQsgPBAACwsgQCgCJCI0QSNLBEAgNBAACyBAQeAAaiQAIDYoAqQBITsgNigCoAEiSARAIDYoArQBIUsgNigCsAEhVyA2KAKsASFYIDYoAqgBIUwgASE0IDshRwwJCyA/QQI6AFAgPyA7NgIAQQAhSAwCCwwWCyA2KAI4IjRFDRUgNigCNCI+RQ0VIDYgNEEBazYCOCA2ID5BCGo2AjQgNiA2QTBqID4oAgAgPigCBBCMARDTASI0NgKgASA2QQhqIDQQAQJAIDYoAggiTgRAIDYoAgwhPgwBCyA2QaABaiA2QagCakG8gMAAEDQhPkEAIU4gNigCoAEhNAsgNEEkTwRAIDQQAAsgTgRAID4hPQwGCyA/QQI6AFAgPyA+NgIAQQAhTgsgNSE4QQEMCgsCQCA2KAI4IjRFDQAgNigCNCI7RQ0AIDYgNEEBazYCOCA2IDtBCGo2AjQgNkGgAWohSiA2QTBqIDsoAgAgOygCBBCMARDTASE0IwBB4AFrIkEkACBBIDQ2AgQCQCBBQQRqKAIAIjQQBEEBRwR/IDQQBUEBRgVBAQtFBEAgQSBBKAIENgLMASBBQdABaiBBQcwBahBdAkAgQSgC0AEEQCBBQRBqIEFB2AFqKAIANgIAIEEgQSkD0AE3AwggQUGIAWohPCMAQUBqIjkkACBBQQhqIjooAgAhQgJAIDpBCGooAgAiO0HAAEcEQCA5QRxqQQ42AgAgOUEONgIUIDlB+I3AADYCECA5IDs2AiQgOSA5QSRqNgIYIDlBAjYCPCA5QgM3AiwgOUHgjcAANgIoIDkgOUEQaiJDNgI4IDkgOUEoaiI0EDUgOUEwaiA7NgIAIDkgQjYCLCA5QQY6ACggOSA5KAIINgIUIDkgOSgCACI7NgIQIDQgQ0H8jcAAEGYhNCA8QQE6AAAgPCA0NgIEIDkoAgRFDQEgOxAmDAELIDxBADoAACA8IEIpAAA3AAEgPEE5aiBCQThqKQAANwAAIDxBMWogQkEwaikAADcAACA8QSlqIEJBKGopAAA3AAAgPEEhaiBCQSBqKQAANwAAIDxBGWogQkEYaikAADcAACA8QRFqIEJBEGopAAA3AAAgPEEJaiBCQQhqKQAANwAACyA6QQRqKAIABEAgQhAmCyA5QUBrJAAMAQsgQUHMAWogQUEIakGsgcAAEDQhNCBBQQE6AIgBIEEgNDYCjAELIEEoAswBIjRBJE8EQCA0EAALIEoCfyBBLQCIAUUEQCBKQQRqIEEtAIsBOgAAIEpBAmogQS8AiQE7AAAgQUHQAGoiNyBBQZgBaikDADcDACBBQdgAaiI5IEFBoAFqKQMANwMAIEFB4ABqIjwgQUGoAWopAwA3AwAgQUHoAGoiQiBBQbABaikDADcDACBBQfAAaiI6IEFBuAFqKQMANwMAIEFB+ABqIjQgQUHAAWopAwA3AwAgQUGAAWoiQyBBQcgBai0AADoAACBBIEFBkAFqKQMANwNIIEEoAowBITsgQUEQaiA3KQMAIgo3AwAgQUEYaiA5KQMAIgY3AwAgQUEgaiA8KQMAIgc3AwAgQUEoaiBCKQMAIgU3AwAgQUEwaiA6KQMAIgQ3AwAgQUE4aiA0KQMAIgM3AwAgQUFAayI0IEMtAAA6AAAgQSBBKQNIIgI3AwggSkEFaiA7NgAAIEpBCWogAjcAACBKQRFqIAo3AAAgSkEZaiAGNwAAIEpBIWogBzcAACBKQSlqIAU3AAAgSkExaiAENwAAIEpBOWogAzcAACBKQcEAaiA0LQAAOgAAIEpBAToAAUEADAELIEogQSgCjAE2AgRBAQs6AAAMAQsgSkEAOwEAIEEoAgQiNEEkSQ0AIDQQAAsgQUHgAWokACA2LQCgAUUEQCA2QcgAaiBNQQhqKQAANwMAIDZB0ABqIE1BEGopAAA3AwAgNkHYAGogTUEYaikAADcDACA2QeAAaiBNQSBqKQAANwMAIDZB6ABqIE1BKGopAAA3AwAgNkHwAGogTUEwaikAADcDACA2QfgAaiBNQThqLwAAOwEAIDYgTSkAADcDQCA2KAKkASE3IDYvAaIBITkgNi0AoQEhQwwFCyA/QQI6AFAgPyA2KAKkATYCAAwCCwwTCwJAIDYoAjgiNEUNACA2KAI0IjtFDQAgNiA0QQFrNgI4IDYgO0EIajYCNCA2IDZBMGogOygCACA7KAIEEIwBENMBNgKYAiA2QaABaiA2QZgCahBdAn8gNigCoAEiOwRAIDYoAqgBIVAgNigCpAEMAQsgNkGYAmogNkGoAmpBjIHAABA0CyFVIDYoApgCIjRBJE8EQCA0EAALAkAgO0UNACA2IFA2AqgBIDYgVTYCpAEgNiA7NgKgASA2QegBaiI7IDZBoAFqIjQpAgA3AgAgO0EIaiA0QQhqKAIANgIAIDYoAuwBIVUgNigC6AEiUEUNACA2KALwASFcDAQLID9BAjoAUCA/IFU2AgBBASFDQQAhQkEBITpBASE8DBALDBILQQAhQkEBIT4gNQshOEEBITxBASE6QQEhQwwMCyABITQLIDYoAjgNAAsMAQsgNkEsaiA2QagCakHcgMAAEDQhASA/QQI6AFAgPyABNgIAIDYoAiwiAUEkSQ0LIAEQAAwLCyA1RQRAIDQhAUHMgcAAQQoQeyE1ID9BAjoAUCA/IDU2AgAMAQsCQAJAAkACQAJAIEgEQCBURQ0BIE5FDQJBACEBIENBAkcEQCA2QdgBaiA2QfgAai8BADsBACA2QdABaiA2QfAAaikDADcDACA2QcgBaiA2QegAaikDADcDACA2QcABaiA2QeAAaikDADcDACA2QbgBaiA2QdgAaikDADcDACA2QbABaiA2QdAAaikDADcDACA2QagBaiA2QcgAaikDADcDACA2IDYpA0A3A6ABIEMhAQsgUEUNAyBJRQ0EIAhQDQUgPyA3NgBTID8gOTsAUSA/ID42AkAgPyA9NgI8ID8gTjYCOCA/IFs2AhAgPyBFNgIMID8gNTYCCCA/IDYpA6ABNwBXID9B3wBqIDZBqAFqKQMANwAAID9B5wBqIDZBsAFqKQMANwAAID9B7wBqIDZBuAFqKQMANwAAID9B9wBqIDZBwAFqKQMANwAAID9B/wBqIDZByAFqKQMANwAAID9BhwFqIDZB0AFqKQMANwAAID9BjwFqIDZB2AFqLwEAOwAAID8gUTYAlAEgPyAJNwMAID8gSDYCFCA/IEc2AhggPyBMNgIcID8gWDYCICA/IFc2AiQgPyBLNgIoID8gNDYCLCA/IFY2AjAgPyBaNgI0ID8gUDYCRCA/IFU2AkggPyBcNgJMID8gAToAUCA/QZMBaiA2QZ4Bai0AADoAACA/IDYvAZwBOwCRASA/IDYpA4ABNwCYASA/QaABaiA2QYgBaikDADcAACA/QagBaiA2QZABaikDADcAACA/QbABaiA2QZgBai0AADoAAAwPC0HWgcAAQQcQeyEBID9BAjoAUCA/IAE2AgBBASE+QQEhPEEBIToMCwtB3YHAAEEJEHshASA/QQI6AFAgPyABNgIAQQEhPkEBITwMCQtB5oHAAEEHEHshASA/QQI6AFAgPyABNgIAQQEhPgwHC0H3gcAAQQcQeyEBID9BAjoAUCA/IAE2AgAMBQtB/oHAAEEFEHshAQwDC0GDgsAAQQoQeyEBDAILQQELIT5BASE8QQEhOkEBIUNBACFCDAULID9BAjoAUCA/IAE2AgAgVUUNACBQECYLIFBFIT4gPUUNACBOECYLIE5FITwgNEUgVkVyDQAgNBAmCyBHBEAgSBAmCyBURSE6IFdFDQAgWBAmCyBIRSFDQQEhQgJAIEVFBEBBACFFDAELIDUQJgsgNCEBIDUhOAsgUEUEQCA4ITUMAQsgPkUEQCA4ITUMAQsgVUUEQCA4ITUMAQsgUBAmIDghNQsgPUUgTkUgPEVyckUEQCBOECYLIFZFIDogVHFFIAFFcnJFBEAgARAmCwJAIEhFIENBAXNyDQAgRwRAIEgQJgsgV0UNACBYECYLIEVFIEIgNUVyckUEQCA1ECYLCyA2KAIwIgFBI00NACABEAALIDZBsAJqJAAMAQtBjYLAAEErQZiDwAAQgwEACyBEKAK4ASE1AkACQAJAIEQtAIgCIgFBAkcEQCBEQQRyIERBuAFqQQRyQcwAEOABGiBEQdEAaiBEQYkCakHnABDgARogRCABOgBQIEQgNTYCACBEQfACaiFFIwBBgAFrIjwkAAJAAkACQEGAAUEBELgBIgEEQCA8QYAINgIUIDxCgAE3AgwgPCABNgIIIwBBMGsiOSQAIwBBIGsiNSQAIDVBmRA7AQggNUEIahBKIQEgPEEIaiI3KAIIIjggNygCBEYEQCA3IDhBARBSIDcoAgghOAsgPEEYaiFDIDcgOEEBajYCCCA3KAIAIDhqIAE6AAAgOUEgaiIBQRk6AAQgAUECNgIAIAFBBWpBCDoAACA1QSBqJAACQAJAAkACQAJAAkACQAJAAkAgOSgCICI+QQJHBEAgOUEcaiA5QSpqIjgvAQAiNDsBACA5IDkoASYiNTYCGCA5LwEkIQEgOCA0OwEAIDkgATsBJCA5ID42AiAgOSA1NgEmIDlBCGogOUEgahCcASA5KAIIIjVBBUcNAQsgOUEIaiA3QYSLwABBCiBEQQhqEEsgOSgCCEEFRw0BIDlBIGogN0GOi8AAQQcQLgJAIDkoAiAiAUECRgRAIwBBMGsiOiQAIDpBlgQ7AQggOkEIahBKIQEgOUEIaiE9IDcoAggiOCA3KAIERgRAIDcgOEEBEFIgNygCCCE4CyA3IDhBAWo2AgggNygCACA4aiABOgAAIERBFGoiOygCACEBIDpBIGogNyA7QQhqKAIAIjUQMwJAAkACQAJAAkACQCA6KAIgIj5BAkYEQCA1IDcoAgQgNygCCCJHa0sEQCA3IEcgNRBSIDcoAgghRwsgNygCACBHaiABIDUQ4AEaIDcgNSBHajYCCAwBCyA6QRxqIDpBKmoiOC8BACI0OwEAIDogOigBJiI1NgIYIDovASQhASA4IDQ7AQAgOiABOwEkIDogPjYCICA6IDU2ASYgOkEIaiA6QSBqEJwBIDooAghBBUcNAQsgO0EMaigCACEBIDpBIGogNyA7QRRqKAIAIjUQMyA6KAIgIj5BAkcNASA1IDcoAgQgNygCCCI4a0sEQCA3IDggNRBSIDcoAgghOAsgNygCACA4aiABIDUQ4AEaIDcgNSA4ajYCCAwCCyA9IDopAwg3AgAgPUEIaiA6QRBqKQMANwIADAMLIDpBHGogOkEqaiI4LwEAIjQ7AQAgOiA6KAEmIjU2AhggOi8BJCEBIDggNDsBACA6IAE7ASQgOiA+NgIgIDogNTYBJiA6QQhqIDpBIGoQnAEgOigCCEEFRw0BCyA9QQU2AgAMAQsgPSA6KQMINwIAID1BCGogOkEQaikDADcCAAsgOkEwaiQADAELIDkgOSkCJDcCJCA5IAE2AiAgOUEIaiA5QSBqEJwBCyA5KAIIQQVHDQIgOUEgaiA3QZWLwABBCRAuAkAgOSgCICI4QQJGBEAgOUEgaiA3IERBLGooAgAiASBEQTBqKAIAIAEbIERBNGooAgAQLiA5KAIgIjhBAkYNAQsgOSA5KQIkNwIkIDkgODYCICA5QQhqIDlBIGoQnAEgOSgCCEEFRw0ECyA5QSBqIDdBnovAAEEHEC4CQCA5KAIgIjhBAkYEQCA5QSBqIDcgREE4aigCACBEQUBrKAIAEC4gOSgCICI4QQJGDQELIDkgOSkCJDcCJCA5IDg2AiAgOUEIaiA5QSBqEJwBIDkoAghBBUcNBQsgOUEIaiE7IERB0ABqITUjAEEgayI9JAAgPUEQaiA3QaWLwABBChAuAkAgPSgCECIBQQJGBEAgNS0AAEUEQCA9QQI7ARAgPUEQahBKIQEgNygCCCI1IDcoAgRGBH8gNyA1QQEQUiA3KAIIBSA1CyA3KAIAaiABOgAAIDcgNygCCEEBajYCCCA7QQU2AgAMAgsgPUEQaiA3QcAAEDMgPSgCECI+QQJGBEAgNygCBCA3KAIIIgFrQT9NBH8gNyABQcAAEFIgNygCCAUgAQsgNygCAGoiNCA1QQFqIgEpAAA3AAAgNEE4aiABQThqKQAANwAAIDRBMGogAUEwaikAADcAACA0QShqIAFBKGopAAA3AAAgNEEgaiABQSBqKQAANwAAIDRBGGogAUEYaikAADcAACA0QRBqIAFBEGopAAA3AAAgNEEIaiABQQhqKQAANwAAIDcgNygCCEFAazYCCCA7QQU2AgAMAgsgPUEMaiA9QRpqIjgvAQAiNDsBACA9ID0oARYiNTYCCCA9LwEUIQEgOCA0OwEAID0gATsBFCA9ID42AhAgPSA1NgEWIDsgPUEQahCcAQwBCyA9ID0pAhQ3AhQgPSABNgIQIDsgPUEQahCcAQsgPUEgaiQAIDkoAghBBUcNBSA5QQhqIDdBr4vAAEEHIERBxABqEEsgOSgCCEEFRw0GIDlBCGohOyBEQZEBaiE1IwBBIGsiPSQAID1BEGogN0G2i8AAQQUQLgJAID0oAhAiAUECRgRAID1BEGogN0EgEDMgPSgCECI+QQJGBEAgNygCBCA3KAIIIgFrQR9NBH8gNyABQSAQUiA3KAIIBSABCyA3KAIAaiIBIDUpAAA3AAAgAUEYaiA1QRhqKQAANwAAIAFBEGogNUEQaikAADcAACABQQhqIDVBCGopAAA3AAAgO0EFNgIAIDcgNygCCEEgajYCCAwCCyA9QQxqID1BGmoiOC8BACI0OwEAID0gPSgBFiI1NgIIID0vARQhASA4IDQ7AQAgPSABOwEUID0gPjYCECA9IDU2ARYgOyA9QRBqEJwBDAELID0gPSkCFDcCFCA9IAE2AhAgOyA9QRBqEJwBCyA9QSBqJAAgOSgCCEEFRw0HIDlBCGohOyMAQSBrIkckACBHQRBqIDdBu4vAAEEKEC4CQCBHKAIQIgFBAkYEQCBHQRBqIT0gRCkDACECIwBBMGsiOiQAAkAgAkJgWgRAIDogAqdBCHRBAXIiNDsBICA6QSBqEEohASA3KAIIIjUgNygCBEYEQCA3IDVBARBSIDcoAgghNQsgNyA1QQFqNgIIIDcoAgAgNWogAToAACA9QQI2AgAgPSA0OwEEDAELIAJCgAF8Qt8AWARAIDpBCTsBICA6QSBqEEohASA3KAIIIjggNygCBEYEQCA3IDhBARBSIDcoAgghOAsgNyA4QQFqIjU2AgggNygCACA4aiABOgAAIDUgNygCBEYEQCA3IDVBARBSIDcoAgghNQsgPUEJOgAEID1BAjYCACA3IDVBAWo2AgggNygCACA1aiACPAAADAELIAJCgIACfEL//gFYBEAgOkEKOwEgIDpBIGoQSiEBIDcoAggiOCA3KAIERgRAIDcgOEEBEFIgNygCCCE4CyA3IDhBAWoiNTYCCCA3KAIAIDhqIAE6AAAgNygCBCA1a0EBTQRAIDcgNUECEFIgNygCCCE1CyA9QQo6AAQgPUECNgIAIDcgNUECajYCCCA3KAIAIDVqIAKnIgFBCHQgAUGA/gNxQQh2cjsAAAwBCyACQoCAgIAIfEL///3/B1gEQCA6QQs7ASAgOkEgahBKIQEgNygCCCI1IDcoAgRGBEAgNyA1QQEQUiA3KAIIITULIDcgNUEBaiI4NgIIIDcoAgAgNWogAToAACA3KAIEIDhrQQNNBEAgNyA4QQQQUiA3KAIIITgLID1BCzoABCA9QQI2AgAgNyA4QQRqNgIIIDcoAgAgOGogAqciAUEIdEGAgPwHcSABQRh0ciABQQh2QYD+A3EgAUEYdnJyNgAADAELAkACQCACQoCAgIB4WQRAIAJCgAFaDQIjAEEQayI4JAAgOCACpyI0QQh0OwEIIDhBCGoQSiEBIDcoAggiNSA3KAIERgRAIDcgNUEBEFIgNygCCCE1CyA3IDVBAWo2AgggNygCACA1aiABOgAAIDpBEGoiAUEEOgAAIDhBEGokACA6IDQ6ACIgOkEEOwEgIDpBCGogOkEgaiI1IAEgAS0AACIBQQRGGykCADcCAAJAIAFBBEYNACA1LQAAQQNHDQAgNSgCBCI1KAIAIDUoAgQoAgARBAAgNSgCBCIBQQRqKAIABEAgAUEIaigCABogNSgCABAmCyA1ECYLIDotAAhBBEcNASA9IDovAAk7AQQgPUECNgIADAMLIDpBDDsBICA6QSBqEEohASA3KAIIIjggNygCBEYEQCA3IDhBARBSIDcoAgghOAsgNyA4QQFqIjU2AgggNygCACA4aiABOgAAIDcoAgQgNWtBB00EQCA3IDVBCBBSIDcoAgghNQsgPUEMOgAEID1BAjYCACA3IDVBCGo2AgggNygCACA1aiACQiiGQoCAgICAgMD/AIMgAkI4hoQgAkIYhkKAgICAgOA/gyACQgiGQoCAgIDwH4OEhCACQgiIQoCAgPgPgyACQhiIQoCA/AeDhCACQiiIQoD+A4MgAkI4iISEhDcAAAwCCyA9IDopAwg3AgQgPUEANgIADAELAkAgAkKAAloEQCACQoCABFQNASACQoCAgIAQWgRAIwBBEGsiNCQAIDRBCDsBCCA0QQhqEEohASA3KAIEIkIgNygCCCI1RgRAIDcgNUEBEFIgNygCBCFCIDcoAgghNQsgNyA1QQFqIjg2AgggNSA3KAIAIjVqIAE6AAAgQiA4a0EHTQRAIDcgOEEIEFIgNygCCCE4IDcoAgAhNQsgOkEQaiIBQQI2AgAgNyA4QQhqNgIIIDUgOGogAkIohkKAgICAgIDA/wCDIAJCOIaEIAJCGIZCgICAgIDgP4MgAkIIhkKAgICA8B+DhIQgAkIIiEKAgID4D4MgAkIYiEKAgPwHg4QgAkIoiEKA/gODIAJCOIiEhIQ3AAAgNEEQaiQAIDpBAjYCICA6QQg6ACQgPSABIDpBIGoQUQwDCyMAQRBrIjQkACA0QQc7AQggNEEIahBKIQEgNygCBCJCIDcoAggiNUYEQCA3IDVBARBSIDcoAgQhQiA3KAIIITULIDcgNUEBaiI4NgIIIDUgNygCACI1aiABOgAAIEIgOGtBA00EQCA3IDhBBBBSIDcoAgghOCA3KAIAITULIDpBEGoiAUECNgIAIDcgOEEEajYCCCA1IDhqIAKnIjVBCHRBgID8B3EgNUEYdHIgNUEIdkGA/gNxIDVBGHZycjYAACA0QRBqJAAgOkECNgIgIDpBBzoAJCA9IAEgOkEgahBRDAILIwBBEGsiNCQAIDRBBTsBCCA0QQhqEEohASA3KAIEIkIgNygCCCI1RgRAIDcgNUEBEFIgNygCBCFCIDcoAgghNQsgNyA1QQFqIjg2AgggNSA3KAIAIjVqIAE6AAAgOCBCRgRAIDcgQkEBEFIgNygCCCE4IDcoAgAhNQsgOkEQaiIBQQI2AgAgNyA4QQFqNgIIIDUgOGogAjwAACA0QRBqJAAgOkECNgIgIDpBBToAJCA9IAEgOkEgahBRDAELIwBBEGsiPiQAID5BBjsBCCA+QQhqEEohASA3KAIEIkIgNygCCCI1RgRAIDcgNUEBEFIgNygCBCFCIDcoAgghNQsgNyA1QQFqIjg2AgggNSA3KAIAIjVqIAE6AAAgQiA4a0EBTQRAIDcgOEECEFIgNygCCCE4IDcoAgAhNQsgOkEQaiI0QQI2AgAgNyA4QQJqNgIIIDUgOGogAqciAUEIdCABQYD+A3FBCHZyOwAAID5BEGokACA6QQI2AiAgOkEGOgAkID0gNCA6QSBqEFELIDpBMGokACBHKAIQIj5BAkYEQCA7QQU2AgAMAgsgR0EMaiBHQRpqIjgvAQAiNDsBACBHIEcoARYiNTYCCCBHLwEUIQEgOCA0OwEAIEcgATsBFCBHID42AhAgRyA1NgEWIDsgR0EQahCcAQwBCyBHIEcpAhQ3AhQgRyABNgIQIDsgR0EQahCcAQsgR0EgaiQAIDkoAghBBUYEQCBDQQU2AgAMCQsgQyA5KQMINwIAIENBCGogOUEQaikDADcCAAwICyA5KAIMIQEgQyA5KQMQNwIIIEMgATYCBCBDIDU2AgAMBwsgQyA5KQMINwIAIENBCGogOUEQaikDADcCAAwGCyBDIDkpAwg3AgAgQ0EIaiA5QRBqKQMANwIADAULIEMgOSkDCDcCACBDQQhqIDlBEGopAwA3AgAMBAsgQyA5KQMINwIAIENBCGogOUEQaikDADcCAAwDCyBDIDkpAwg3AgAgQ0EIaiA5QRBqKQMANwIADAILIEMgOSkDCDcCACBDQQhqIDlBEGopAwA3AgAMAQsgQyA5KQMINwIAIENBCGogOUEQaikDADcCAAsgOUEwaiQAIDwoAhhBBUYNAiA8QUBrIDxBIGopAwA3AwAgPCA8KQMYNwM4IDxBADYCUCA8QgE3A0ggPEHYAGoiNSA8QcgAakHIicAAEJIBIwBBMGsiNCQAAn8CQAJAAkACQAJAIDxBOGoiASgCAEEBaw4EAQIDBAALIDQgAUEEajYCCCA0QSRqQQE2AgAgNEIBNwIUIDRBoJ7AADYCECA0QdkANgIsIDQgNEEoajYCICA0IDRBCGo2AiggNSA0QRBqEGsMBAsgNUHIncAAQcAAEK0BDAMLIDQgASkCBDcDCCA0QSRqQQE2AgAgNEIBNwIUIDRBwJ3AADYCECA0QdoANgIsIDQgNEEoajYCICA0IDRBCGo2AiggNSA0QRBqEGsMAgsgNUGLncAAQRQQrQEMAQsgNSABQQRqKAIAIAFBDGooAgAQrQELIDRBMGokAA0BIDxBMGogPEHQAGooAgA2AgAgPCA8KQNINwMoAkACQAJAIDwoAjgOBAECAgIACyA8QUBrKAIARQ0BIDwoAjwQJgwBCyA8QUBrLQAAIQECQAJAIDwoAjxFBEAgAUEDRw0DIDxBxABqKAIAIgEoAgAgASgCBCgCABEEACABKAIEIjRBBGooAgANAQwCCyABQQNHDQIgPEHEAGooAgAiASgCACABKAIEKAIAEQQAIAEoAgQiNEEEaigCAEUNAQsgNEEIaigCABogASgCABAmCyA8KAJEECYLIEUgPCkDKDcCBCBFQQxqIDxBMGooAgA2AgAgRUEANgIAIDwoAgxFDQMgPCgCCBAmDAMLQYABQQEQ2wEAC0HgicAAQTcgPEEoakGYisAAQfSKwAAQZAALIEUgPCkDCDcCBCBFQQI2AgAgRUEMaiA8QRBqKAIANgIACyA8QYABaiQAIEQoAvACQQJHBEAgREHAAWogREH4AmopAwA3AwAgRCBEKQPwAjcDuAECfyMAQUBqIjQkACA0QQA2AgggNEIBNwMAIDRBEGoiASA0QfSFwAAQkgEjAEEwayI4JAAgOCBEQbgBaiI1NgIMIDhBJGpBATYCACA4QgE3AhQgOEHUnMAANgIQIDhB1gA2AiwgOCA4QShqNgIgIDggOEEMajYCKCABIDhBEGoQayA4QTBqJABFBEAgNCgCACA0KAIIEAMgNCgCBARAIDQoAgAQJgsgNUEIaigCAARAIDUoAgQQJgsgNEFAayQADAELQYyGwABBNyA0QThqQcSGwABBoIfAABBkAAshNAwCCyBEQfgCaigCACE0IEQoAvQCIkdFDQEgREH8AmooAgAhQyMAQSBrIkIkACMAQdACayI5JAAgOUHmAGpBAEGgARDeARogOUEAOgBlIDlBADYCYEEBITogOUEBOgCKAiA5QYECNgGGAiA5QgA3A1ggOUEgOgBkIDlC+cL4m5Gjs/DbADcDyAIgOULr+obav7X2wR83A8ACIDlCn9j52cKR2oKbfzcDuAIgOULRhZrv+s+Uh9EANwOwAiA5QvHt9Pilp/2npX83A6gCIDlCq/DT9K/uvLc8NwOgAiA5QrvOqqbY0Ouzu383A5gCIDlCqJL3lf/M+YTqADcDkAIjAEGAAWsiASQAIDlBkAJqIjwpAzghKiA8KQMwISsgPCkDKCEsIDwpAyAhLSA8KQMYIS8gPCkDECEwIDwpAwghMSA8KQMAITIgAUEAQYABEN4BIT0gR0EAIENBAWsiASABIENLG0GAf3EiRSBDIEMgRUsbIgFqITUCQCBDIAFrIjhB/wBLBEBBgAEhOAwBCyA9IDUgOBDgASE1CyBFQYABaiE7AkACQAJAA0BCfyEJIDghPiA1IQEgRSBTRwRAIFNBgH9GDQIgU0GAAWogQ0sNA0IAIQlBgAEhPiBHIFNqIQELIC0gASkAKCIaIAEpACAiGyArIDB8fCICfCACIAmFQuv6htq/tfbBH4VCIIkiBEKr8NP0r+68tzx8IgMgK4VCKIkiAnwiFiAEhUIwiSITIAN8Ig8gAoVCAYkiCyABKQBQIhwgASkAGCIdIAEpABAiHiAsIDF8fCICfCACIDMgLiAuID6tfCIuVq18IjOFQp/Y+dnCkdqCm3+FQiCJIgZCxbHV2aevlMzEAH0iCiAshUIoiSIHfCIFfHwiAyABKQBYIh98IAsgAyABKQAIIiAgASkAACIhIC0gMnx8IgJ8IC0gAiAuhULRhZrv+s+Uh9EAhUIgiSICQoiS853/zPmE6gB8Ig6FQiiJIhB8IgQgAoVCMIkiDIVCIIkiFyABKQA4IiIgASkAMCIjICogL3x8IgJ8IAJC+cL4m5Gjs/DbAIVCIIkiA0KPkouH2tiC2NoAfSICICqFQiiJIg18IgggA4VCMIkiAyACfCIJfCIYhUIoiSIUfCIRIBt8IAcgCiAFIAaFQjCJIgZ8IgqFQgGJIgUgASkAQCIkIAR8fCICIAEpAEgiJXwgBSAPIAIgA4VCIIkiBHwiA4VCKIkiAnwiEiAEhUIwiSIVIAN8IgsgAoVCAYkiB3wiBSAkfCAHIAUgCSANhUIBiSIEIBYgASkAYCImfHwiAiABKQBoIid8IAQgAiAGhUIgiSIDIAwgDnwiAnwiDoVCKIkiD3wiBiADhUIwiSIMhUIgiSIZIAEpAHAiKCAIIAIgEIVCAYkiBHx8IgIgASkAeCIpfCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiFoVCKIkiE3wiECAhfCARIBeFQjCJIgcgGHwiCiAUhUIBiSIFIAYgJXx8IgIgKXwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiESAEhUIwiSIUIAN8IgsgAoVCAYkiBnwiBSAefCAGIAUgCSANhUIBiSIEIBIgKHx8IgIgHHwgBCACIAeFQiCJIgMgDCAOfCICfCIOhUIoiSISfCIHIAOFQjCJIgyFQiCJIhcgAiAPhUIBiSIEIAggJ3x8IgIgI3wgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhiFQiiJIhV8Ig8gJnwgEyAWIBAgGYVCMIkiBnwiCoVCAYkiBSAHICB8fCICICZ8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhAgBIVCMIkiEyADfCILIAKFQgGJIgd8IgUgIXwgByAFIAkgDYVCAYkiBCARIB98fCICICJ8IAQgAiAGhUIgiSIDIAwgDnwiAnwiDoVCKIkiEXwiBiADhUIwiSIMhUIgiSIZIAIgEoVCAYkiBCAIIBp8fCICIB18IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIWhUIoiSIUfCISIB18IBUgGCAPIBeFQjCJIgd8IgqFQgGJIgUgBiAafHwiAiAefCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIPIASFQjCJIhUgA3wiCyAChUIBiSIGfCIFICN8IAYgBSAJIA2FQgGJIgQgECAffHwiAiAkfCAEIAIgB4VCIIkiAyAMIA58IgJ8Ig6FQiiJIhB8IgcgA4VCMIkiDIVCIIkiFyACIBGFQgGJIgQgCCApfHwiAiAnfCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiGIVCKIkiE3wiESAdfCAUIBYgEiAZhUIwiSIGfCIKhUIBiSIFIAcgHHx8IgIgKHwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiEiAEhUIwiSIUIAN8IgsgAoVCAYkiB3wiBSAgfCAHIAUgCSANhUIBiSIEIA8gInx8IgIgIHwgBCACIAaFQiCJIgMgDCAOfCICfCIOhUIoiSIPfCIGIAOFQjCJIgyFQiCJIhkgAiAQhUIBiSIEIAggJXx8IgIgG3wgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhaFQiiJIhV8IhAgGnwgEyAYIBEgF4VCMIkiB3wiCoVCAYkiBSAGICd8fCICICZ8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhEgBIVCMIkiEyADfCILIAKFQgGJIgZ8IgUgHHwgBiAFIAkgDYVCAYkiBCASICJ8fCICICV8IAQgAiAHhUIgiSIDIAwgDnwiAnwiDoVCKIkiEnwiByADhUIwiSIMhUIgiSIXIAIgD4VCAYkiBCAIIB98fCICICh8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIYhUIoiSIUfCIPIBp8IBUgFiAQIBmFQjCJIgZ8IgqFQgGJIgUgByAefHwiAiAjfCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIQIASFQjCJIhUgA3wiCyAChUIBiSIHfCIFICJ8IAcgBSAJIA2FQgGJIgQgESAbfHwiAiAhfCAEIAIgBoVCIIkiAyAMIA58IgJ8Ig6FQiiJIhF8IgYgA4VCMIkiDIVCIIkiGSACIBKFQgGJIgQgCCApfHwiAiAkfCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiFoVCKIkiE3wiEiAffCAUIBggDyAXhUIwiSIHfCIKhUIBiSIFIAYgHnx8IgIgG3wgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiDyAEhUIwiSIUIAN8IgsgAoVCAYkiBnwiBSAmfCAGIAUgCSANhUIBiSIEIBAgJXx8IgIgIXwgBCACIAeFQiCJIgMgDCAOfCICfCIOhUIoiSIQfCIHIAOFQjCJIgyFQiCJIhcgAiARhUIBiSIEIAggHHx8IgIgKXwgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhiFQiiJIhV8IhEgI3wgEyAWIBIgGYVCMIkiBnwiCoVCAYkiBSAHICh8fCICICB8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhIgBIVCMIkiEyADfCILIAKFQgGJIgd8IgUgHHwgByAFIAkgDYVCAYkiBCAPICN8fCICICR8IAQgAiAGhUIgiSIDIAwgDnwiAnwiDoVCKIkiD3wiBiADhUIwiSIMhUIgiSIZIAIgEIVCAYkiBCAIIB18fCICICd8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIWhUIoiSIUfCIQICJ8IBUgGCARIBeFQjCJIgd8IgqFQgGJIgUgBiAhfHwiAiAffCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIRIASFQjCJIhUgA3wiCyAChUIBiSIGfCIFIBp8IAYgBSAJIA2FQgGJIgQgEiAefHwiAiAmfCAEIAIgB4VCIIkiAyAMIA58IgJ8Ig6FQiiJIhJ8IgcgA4VCMIkiDIVCIIkiFyACIA+FQgGJIgQgCCAkfHwiAiAdfCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiGIVCKIkiE3wiDyAgfCAUIBYgECAZhUIwiSIGfCIKhUIBiSIFIAcgG3x8IgIgJ3wgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiECAEhUIwiSIUIAN8IgsgAoVCAYkiB3wiBSApfCAHIAUgCSANhUIBiSIEIBEgKXx8IgIgKHwgBCACIAaFQiCJIgMgDCAOfCICfCIOhUIoiSIRfCIGIAOFQjCJIgyFQiCJIhkgAiAShUIBiSIEIAggIHx8IgIgJXwgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhaFQiiJIhV8IhIgI3wgEyAPIBeFQjCJIgcgGHwiCoVCAYkiBSAGICh8fCICICd8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8Ig8gBIVCMIkiEyADfCILIAKFQgGJIgZ8IgUgHXwgBiAFIAkgDYVCAYkiBCAQICZ8fCICIBp8IAQgAiAHhUIgiSIDIAwgDnwiAnwiDoVCKIkiEHwiByADhUIwiSIMhUIgiSIXIAIgEYVCAYkiBCAIIBt8fCICIBx8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIYhUIoiSIUfCIRICJ8IBUgEiAZhUIwiSIGIBZ8IgqFQgGJIgUgByAhfHwiAiAifCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCISIASFQjCJIhUgA3wiCyAChUIBiSIHfCIFICh8IAcgBSAJIA2FQgGJIgQgDyAlfHwiAiAefCAEIAIgBoVCIIkiAyAMIA58IgJ8Ig6FQiiJIg98IgYgA4VCMIkiDIVCIIkiGSACIBCFQgGJIgQgCCAkfHwiAiAffCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiFoVCKIkiE3wiECApfCAUIBEgF4VCMIkiByAYfCIKhUIBiSIFIAYgJnx8IgIgIHwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiESAEhUIwiSIUIAN8IgsgAoVCAYkiBnwiBSAbfCAGIAUgCSANhUIBiSIEIBIgJ3x8IgIgH3wgBCACIAeFQiCJIgMgDCAOfCICfCIOhUIoiSISfCIHIAOFQjCJIgyFQiCJIhcgAiAPhUIBiSIEIAggHXx8IgIgJXwgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhiFQiiJIhV8Ig8gKHwgEyAQIBmFQjCJIgYgFnwiCoVCAYkiBSAHIBp8fCICICF8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhMgBIVCMIkiECADfCILIAKFQgGJIgd8IgUgJXwgByAFIAkgDYVCAYkiBCARICR8fCICICN8IAQgAiAGhUIgiSIDIAwgDnwiAnwiDoVCKIkiEXwiBiADhUIwiSIMhUIgiSIZIAIgEoVCAYkiBCAIIB58fCICIBx8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIWhUIoiSIUfCISICd8IBUgDyAXhUIwiSIHIBh8IgqFQgGJIgUgBiAffHwiAiAdfCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIPIASFQjCJIhUgA3wiCyAChUIBiSIGfCIFICJ8IAYgBSAJIA2FQgGJIgQgEyAjfHwiAiApfCAEIAIgB4VCIIkiAyAMIA58IgJ8Ig6FQiiJIhN8IgcgA4VCMIkiDIVCIIkiFyACIBGFQgGJIgQgCCAhfHwiAiAkfCAEIAIgEIVCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiGIVCKIkiEHwiESAkfCAUIBIgGYVCMIkiBiAWfCIKhUIBiSIFIAcgJnx8IgIgHnwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiEiAEhUIwiSIUIAN8IgsgAoVCAYkiB3wiBSAbfCAHIAUgCSANhUIBiSIEIA8gIHx8IgIgG3wgBCACIAaFQiCJIgMgDCAOfCICfCIOhUIoiSIPfCIGIAOFQjCJIgyFQiCJIhkgAiAThUIBiSIEIAggHHx8IgIgGnwgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhaFQiiJIhV8IhMgJXwgECARIBeFQjCJIgcgGHwiCoVCAYkiBSAGICJ8fCICICN8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhAgBIVCMIkiESADfCILIAKFQgGJIgZ8IgUgKHwgBiAFIAkgDYVCAYkiBCASIBx8fCICIB58IAQgAiAHhUIgiSIDIAwgDnwiAnwiDoVCKIkiEnwiByADhUIwiSIMhUIgiSIXIAIgD4VCAYkiBCAIICB8fCICIBp8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIYhUIoiSIUfCIPIB58IBUgEyAZhUIwiSIGIBZ8IgqFQgGJIgUgByApfHwiAiAffCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIVIASFQjCJIhMgA3wiCyAChUIBiSIHfCIFIB18IAcgBSAJIA2FQgGJIgQgECAdfHwiAiAmfCAEIAIgBoVCIIkiAyAMIA58IgJ8Ig6FQiiJIhB8IgYgA4VCMIkiDIVCIIkiGSACIBKFQgGJIgQgCCAnfHwiAiAhfCAEIAIgEYVCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiFoVCKIkiEXwiEiAcfCAUIA8gF4VCMIkiByAYfCIKhUIBiSIFIAYgG3x8IgIgGnwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiDyAEhUIwiSIXIAN8IgsgAoVCAYkiBnwiBSAffCAGIAUgCSANhUIBiSIEIBUgIXx8IgIgIHwgBCACIAeFQiCJIgMgDCAOfCICfCIOhUIoiSIYfCIHIAOFQjCJIgyFQiCJIhQgAiAQhUIBiSIEIAggI3x8IgIgInwgBCACIBOFQiCJIgMgCnwiAoVCKIkiDXwiFSADhUIwiSIDIAJ8Igh8IhOFQiiJIhB8IgkgG3wgESASIBmFQjCJIgogFnwiBoVCAYkiBSAHICR8fCICICV8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhEgBIVCMIkiEiADfCILIAKFQgGJIgd8IgUgJHwgByAFIAggDYVCAYkiBCAPICZ8fCICICd8IAQgAiAKhUIgiSIDIAwgDnwiAnwiD4VCKIkiDnwiDCADhUIwiSINhUIgiSIZIAIgGIVCAYkiBCAVICh8fCICICl8IAQgAiAXhUIgiSIDIAZ8IgKFQiiJIgp8IgggA4VCMIkiAyACfCIGfCIWhUIoiSIXfCIYICF8ICkgECAJIBSFQjCJIgcgE3wiCYVCAYkiBSAMICV8fCICfCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIUIASFQjCJIgsgA3wiFSAChUIBiSIMfCIFIB58IAwgBSAcIAYgCoVCAYkiBCARICh8fCICfCAEIAIgB4VCIIkiAyANIA98IgJ8IgqFQiiJIg18IhMgA4VCMIkiBoVCIIkiByAjIAIgDoVCAYkiBSAIICd8fCICfCAFIAIgEoVCIIkiBCAJfCIDhUIoiSIIfCICIASFQjCJIhAgA3wiCXwiEYVCKIkiEnwiDyAHhUIwiSIOhSAdIA0gBiAKfCIKhUIBiSIGIAIgGnx8IgJ8IAYgAiALhUIgiSIHIBggGYVCMIkiBSAWfCIEfCIDhUIoiSICfCILIAeFQjCJIgwgA3wiDSAChUIBiYUhLSAIIAmFQgGJIgMgFCAffHwiAiAifCADIAogAiAFhUIgiSICfCIIhUIoiSIJfCIKIAKFQjCJIgYgLIUgBCAXhUIBiSIFIBMgIHx8IgIgJnwgBSACIBCFQiCJIgQgFXwiA4VCKIkiAnwiByAEhUIwiSIFIAN8IgQgAoVCAYmFISwgDiARfCIDIC+FIAuFIS8gDyAxhSANhSExIAYgCHwiAiAHIDKFhSEyIAUgKoUgAiAJhUIBiYUhKiADIBKFQgGJICuFIAyFISsgCiAwhSAEhSEwIDsgU0GAAWoiU0cNAAsgPCAqNwM4IDwgKzcDMCA8ICw3AyggPCAtNwMgIDwgLzcDGCA8IDA3AxAgPCAxNwMIIDwgMjcDACA9QYABaiQADAILQYB/IFNBgAFqQdibwAAQywEACyBTQYABaiBDQdibwAAQygEACyA5IDktAGQ6AFAgOSA5KQPIAjcDSCA5IDkpA8ACNwNAIDkgOSkDuAI3AzggOSA5KQOwAjcDMCA5IDkpA6gCNwMoIDkgOSkDoAI3AyAgOSA5KQOYAjcDGCA5IDkpA5ACNwMQIDlBEGoiNS0AQCI4QcEATwRAIDhBwABBxJzAABDKAQALIDlBCGoiASA4NgIEIAEgNTYCACA5KAIIIQECQAJAAkAgOSgCDCI4BEAgOEEATiI1RQ0BIDggNRC4ASI6RQ0CCyA6IAEgOBDgASEBIEJBDGogODYCACBCQQhqIDg2AgAgQiABNgIEIEJBBjoAACA5QdACaiQADAILEIgBAAsgOCA1ENsBAAsCQCBCLQAAQQZGBEAgTyBCKQIENwIAIE9BCGogQkEMaigCADYCACBCQSBqJAAMAQsgQkEYaiBCQQhqKQMANwMAIEIgQikDADcDEEHHmcAAQSsgQkEQakH0mcAAQYSawAAQZAALIDRFDQIgRxAmDAILAn8jAEHQAGsiPiQAID4gNTYCDCA+QQA2AhggPkIBNwMQID5BIGoiASA+QRBqQfSFwAAQkgEjAEEQayI4JAAgOEEIaiA+QQxqKAIAEAggOCgCCCI0IDgoAgwiNSABENwBIDUEQCA0ECYLIDhBEGokAEUEQCA+KAIQID4oAhgQAyA+KAIUBEAgPigCEBAmCyA+KAIMIgFBJE8EQCABEAALID5B0ABqJAAMAQtBjIbAAEE3ID5ByABqQcSGwABBoIfAABBkAAshASBPQQA2AgAgTyABNgIEDAILIE9BADYCACBPIDQ2AgQLIERBDGooAgAEQCBEKAIIECYLIERBGGooAgAEQCBEKAIUECYLIERBJGooAgAEQCBEQSBqKAIAECYLAkAgRCgCLCIBRQ0AIERBMGooAgBFDQAgARAmCyBEQTxqKAIABEAgRCgCOBAmCyBEQcgAaigCAARAIEQoAkQQJgsLIERBgANqJAAgTygCCCE0IE8oAgQhAQJAIAACfyBPKAIAIjUEQAJAIAEgNE0EQCA1IVkMAQsgNEUEQEEBIVkgNRAmDAELIDUgAUEBIDQQsAEiWUUNAwtBACEBQQAMAQtBAQs2AgwgACABNgIIIAAgNDYCBCAAIFk2AgAgT0EQaiQADwsgNEEBENsBAAuTAQEBfyMAQRBrIgYkAAJAIAEEQCAGIAEgAyAEIAUgAigCEBEHACAGKAIAIQECQCAGKAIEIgMgBigCCCICTQRAIAEhBAwBCyACRQRAQQQhBCABECYMAQsgASADQQJ0QQQgAkECdCIBELABIgRFDQILIAAgAjYCBCAAIAQ2AgAgBkEQaiQADwsQ1AEACyABQQQQ2wEAC5gBAQF/IwBBIGsiAiQAAkACQCABEMIBRQRAIAEQwQENASAAQQA2AgAMAgsgAkEQaiABEF8gAEEIaiACQRhqKAIANgIAIAAgAikDEDcCAAwBCyACIAEQ6QE2AgwgAkEQaiACQQxqEF8gAEEIaiACQRhqKAIANgIAIAAgAikDEDcCACACKAIMIgBBJEkNACAAEAALIAJBIGokAAuXAQEBfyMAQUBqIgIkACAAKAIAIQAgAkIANwM4IAJBOGogABAhIAJBHGpBATYCACACIAIoAjwiADYCMCACIAA2AiwgAiACKAI4NgIoIAJBzwA2AiQgAkICNwIMIAJByJfAADYCCCACIAJBKGo2AiAgAiACQSBqNgIYIAEgAkEIahBrIAIoAiwEQCACKAIoECYLIAJBQGskAAuUAQEEfwJAAkACQCABKAIAIgQQHCIBRQRAQQEhAwwBCyABQQBOIgJFDQEgASACELgBIgNFDQILIAAgATYCBCAAIAM2AgAQIyICEBkiBRAaIQEgBUEkTwRAIAUQAAsgASAEIAMQGyABQSRPBEAgARAACyACQSRPBEAgAhAACyAAIAQQHDYCCA8LEIgBAAsgASACENsBAAvyAgEDfyMAQRBrIgIkAAJ/AkACQAJAAkACQAJAIAAtAABBAWsOBQECAwQFAAsgAUH0msAAQQMQrQEMBQsgAUHrmsAAQQkQrQEMBAsgAUHkmsAAQQcQrQEMAwsgAiAAQQRqNgIIIAIgAEEBajYCDCMAQRBrIgAkACAAIAEoAhhBuprAAEEJIAFBHGooAgAoAgwRAQA6AAggACABNgIAIABBADoACSAAQQA2AgQgACACQQhqQcSawAAQRCACQQxqQdSawAAQRCEBAn8gAC0ACCIDIAAoAgQiBEUNABpBASADDQAaIAEoAgAhAQJAIARBAUcNACAALQAJRQ0AIAEtAABBBHENAEEBIAEoAhhBgsvAAEEBIAFBHGooAgAoAgwRAQANARoLIAEoAhhB7MfAAEEBIAFBHGooAgAoAgwRAQALIABBEGokAEH/AXFBAEcMAgsgAUGvmsAAQQsQrQEMAQsgAUGkmsAAQQsQrQELIAJBEGokAAuMAQEEfyMAQRBrIgIkAAJAIAEtAAQEQEECIQQMAQsgASgCABANIQMgAkEIahCVASACKAIIRQRAAn8gAxAORQRAIAMQDyEFQQAMAQsgAUEBOgAEQQILIQQgA0EkSQ0BIAMQAAwBCyACKAIMIQVBASEEIAFBAToABAsgACAFNgIEIAAgBDYCACACQRBqJAALgAEBAX8jAEFAaiIBJAAgAUGsgMAANgIUIAFBpIDAADYCECABIAA2AgwgAUEsakECNgIAIAFBPGpBCzYCACABQgI3AhwgAUHAhcAANgIYIAFBDjYCNCABIAFBMGo2AiggASABQRBqNgI4IAEgAUEMajYCMCABQRhqEFogAUFAayQAC3kBAn8jAEFAaiIAJAAgAEEANgIIIABCATcDACAAQRBqIgEgAEGog8AAEJIBQdCIwABBOyABENwBRQRAIAAoAgAgACgCCBDoASAAKAIEBEAgACgCABAmCyAAQUBrJAAPC0HAg8AAQTcgAEE4akH4g8AAQdSEwAAQZAALgAEBAX8jAEFAaiIFJAAgBSABNgIMIAUgADYCCCAFIAM2AhQgBSACNgIQIAVBLGpBAjYCACAFQTxqQfsANgIAIAVCAjcCHCAFQbzKwAA2AhggBUH6ADYCNCAFIAVBMGo2AiggBSAFQRBqNgI4IAUgBUEIajYCMCAFQRhqIAQQiQEAC64BAQJ/IwBBEGsiAiQAIAAoAgAhACABKAIYQYTLwABBASABQRxqKAIAKAIMEQEAIQMgAkEAOgAFIAIgAzoABCACIAE2AgAgAiAANgIMIAIgAkEMaiIBEM0BIAIgAEEBajYCDCACIAEQzQEgAiAAQQJqNgIMIAIgARDNASACLQAEBH9BAQUgAigCACIAQRhqKAIAQYXLwABBASAAQRxqKAIAKAIMEQEACyACQRBqJAALbQEBfyMAQTBrIgMkACADIAI2AgQgAyABNgIAIANBHGpBAjYCACADQSxqQQs2AgAgA0ICNwIMIANBgIXAADYCCCADQQw2AiQgAyAANgIgIAMgA0EgajYCGCADIAM2AiggA0EIahBaIANBMGokAAtbAQJ/IwBBIGsiAiQAIAFBHGooAgAhAyABKAIYIAJBGGogACgCACIAQRBqKQIANwMAIAJBEGogAEEIaikCADcDACACIAApAgA3AwggAyACQQhqEDAgAkEgaiQAC2wBBH8jAEEgayICJABBASEDAkAgACABEEMNACABQRxqKAIAIQQgASgCGCACQQA2AhwgAkHIr8AANgIYIAJCATcCDCACQfDHwAA2AgggBCACQQhqEDANACAAQQRqIAEQQyEDCyACQSBqJAAgAwttAQF/IwBBMGsiAyQAIAMgATYCBCADIAA2AgAgA0EcakECNgIAIANBLGpBDjYCACADQgI3AgwgA0G4yMAANgIIIANBDjYCJCADIANBIGo2AhggAyADNgIoIAMgA0EEajYCICADQQhqIAIQiQEAC1YBAn8jAEEgayICJAAgAUEcaigCACEDIAEoAhggAkEYaiAAQRBqKQIANwMAIAJBEGogAEEIaikCADcDACACIAApAgA3AwggAyACQQhqEDAgAkEgaiQAC1YBAn8jAEEgayICJAAgAEEcaigCACEDIAAoAhggAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAyACQQhqEDAgAkEgaiQAC2YBAX8jAEEgayICJAAgAkH4ocAANgIEIAIgADYCACACQRhqIAFBEGopAgA3AwAgAkEQaiABQQhqKQIANwMAIAIgASkCADcDCCACQYyiwAAgAkEEakGMosAAIAJBCGpBpKnAABA8AAtjAQF/IwBBIGsiAyQAIANBqKrAADYCBCADIAA2AgAgA0EYaiABQRBqKQIANwMAIANBEGogAUEIaikCADcDACADIAEpAgA3AwggA0H8ocAAIANBBGpB/KHAACADQQhqIAIQPAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHAj8AAIAJBCGoQMCACQSBqJAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHYkMAAIAJBCGoQMCACQSBqJAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHglcAAIAJBCGoQMCACQSBqJAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHAocAAIAJBCGoQMCACQSBqJAALaAAjAEEwayIBJABBsObAAC0AAARAIAFBHGpBATYCACABQgI3AgwgAUHApcAANgIIIAFBDjYCJCABIAA2AiwgASABQSBqNgIYIAEgAUEsajYCICABQQhqQeilwAAQiQEACyABQTBqJAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakH8rcAAIAJBCGoQMCACQSBqJAALaAECfyABKAIAIQMCQAJAAkAgAUEIaigCACIBRQRAQQEhAgwBCyABQQBIDQEgAUEBELgBIgJFDQILIAIgAyABEOABIQIgACABNgIIIAAgATYCBCAAIAI2AgAPCxCIAQALIAFBARDbAQALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakGAzcAAIAJBCGoQMCACQSBqJAALVgEBfyMAQSBrIgIkACACIAA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHAj8AAIAJBCGoQMCACQSBqJAALVgEBfyMAQSBrIgIkACACIAA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHYkMAAIAJBCGoQMCACQSBqJAALVgEBfyMAQSBrIgIkACACIAA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHglcAAIAJBCGoQMCACQSBqJAALWwEBfyMAQRBrIgIkAAJ/IAAoAgAiACgCAEUEQCACIABBBGo2AgggAUH4nMAAQQkgAkEIahBVDAELIAIgAEEEajYCDCABQdycwABBCyACQQxqEFULIAJBEGokAAtWAQF/IwBBIGsiAiQAIAIgADYCBCACQRhqIAFBEGopAgA3AwAgAkEQaiABQQhqKQIANwMAIAIgASkCADcDCCACQQRqQYDNwAAgAkEIahAwIAJBIGokAAtfAQF/IwBBMGsiAiQAIAIgATYCDCACIAA2AgggAkEkakEBNgIAIAJCAjcCFCACQaCFwAA2AhAgAkENNgIsIAIgAkEoajYCICACIAJBCGo2AiggAkEQahBaIAJBMGokAAtfAQF/IwBBMGsiAiQAIAIgATYCDCACIAA2AgggAkEkakEBNgIAIAJCAjcCFCACQeSFwAA2AhAgAkENNgIsIAIgAkEoajYCICACIAJBCGo2AiggAkEQahBaIAJBMGokAAtRAQF/AkAgAEEQaigCACIBRQ0AIAFBADoAACAAQRRqKAIARQ0AIAAoAhAQJgsCQCAAQX9GDQAgACAAKAIEIgFBAWs2AgQgAUEBRw0AIAAQJgsLQAEBfyMAQSBrIgAkACAAQRxqQQA2AgAgAEH4rMAANgIYIABCATcCDCAAQZStwAA2AgggAEEIakHsrcAAEIkBAAtKAQF/IAIgACgCACIAQQRqKAIAIAAoAggiA2tLBEAgACADIAIQUyAAKAIIIQMLIAAoAgAgA2ogASACEOABGiAAIAIgA2o2AghBAAtKAQF/IAIgACgCACIAQQRqKAIAIAAoAggiA2tLBEAgACADIAIQUiAAKAIIIQMLIAAoAgAgA2ogASACEOABGiAAIAIgA2o2AghBAAtHAQF/IAIgACgCACIAKAIEIAAoAggiA2tLBEAgACADIAIQUiAAKAIIIQMLIAAoAgAgA2ogASACEOABGiAAIAIgA2o2AghBAAtCAQF/IAIgACgCBCAAKAIIIgNrSwRAIAAgAyACEFIgACgCCCEDCyAAKAIAIANqIAEgAhDgARogACACIANqNgIIQQALSAEBfyMAQSBrIgMkACADQRRqQQA2AgAgA0HIr8AANgIQIANCATcCBCADIAE2AhwgAyAANgIYIAMgA0EYajYCACADIAIQiQEAC0YBAn8gASgCBCECIAEoAgAhA0EIQQQQuAEiAUUEQEEIQQQQ2wEACyABIAI2AgQgASADNgIAIABBkKfAADYCBCAAIAE2AgALrHcDGH4rfwF8IAEoAgBBAXEhGiAAKwMAIUUCQAJAAkAgASgCEEEBRgRAAn8gASE8IAFBFGooAgAhNkEAIQEjAEHwCGsiIyQAIEW9IQYCQCBFIEViBEBBAiEADAELIAZC/////////weDIgNCgICAgICAgAiEIAZCAYZC/v///////w+DIAZCNIinQf8PcSIeGyIHQgGDIQVBAyEAAkACQAJAQQFBAkEEIAZCgICAgICAgPj/AIMiAlAiKBsgAkKAgICAgICA+P8AURtBA0EEICgbIANQG0ECaw4DAAECAwtBBCEADAILIB5BswhrIQEgBVAhAEIBIQQMAQtCgICAgICAgCAgB0IBhiAHQoCAgICAgIAIUSIBGyEHQgJCASABGyEEIAVQIQBBy3dBzHcgARsgHmohAQsgIyABOwHoCCAjIAQ3A+AIICNCATcD2AggIyAHNwPQCCAjIAA6AOoIAkACfyAAQQJrQf8BcSIAQQMgAEEDSRsiKARAQavHwABBrMfAAEHIr8AAIBobIAZCAFMbIT1BASEAIAZCP4inIBpyIUECQAJAAkAgKEECaw4CAQACC0F0QQUgAUEQdEEQdSIAQQBIGyAAbCIAQb/9AEsNBCAjQZAIaiEfICNBEGohKSAAQQR2QRVqIjEhK0EAIDZrQYCAfiA2QYCAAkkbITICQAJAAkACQAJAAkACQCAjQdAIaiIAKQMAIgJQRQRAIAJC//////////8fVg0BICtFDQNBoH8gAC8BGCIAQSBrIAAgAkKAgICAEFQiARsiAEEQayAAIAJCIIYgAiABGyICQoCAgICAgMAAVCIBGyIAQQhrIAAgAkIQhiACIAEbIgJCgICAgICAgIABVCIBGyIAQQRrIAAgAkIIhiACIAEbIgJCgICAgICAgIAQVCIBGyIAQQJrIAAgAkIEhiACIAEbIgJCgICAgICAgIDAAFQiABsgAkIChiACIAAbIgJCP4enQX9zaiIAa0EQdEEQdUHQAGxBsKcFakHOEG0iAUHRAE8NAiABQQR0IgFBwrfAAGovAQAhKAJ/AkACQCABQbi3wABqKQMAIgZC/////w+DIgcgAiACQn+FQj+IhiIDQiCIIgJ+IgVCIIggAiAGQiCIIgJ+fCACIANC/////w+DIgN+IgJCIIh8IAVC/////w+DIAMgB35CIIh8IAJC/////w+DfEKAgICACHxCIIh8IgJBQCAAIAFBwLfAAGovAQBqayIaQT9xrSIGiKciAEGQzgBPBEAgAEHAhD1JDQEgAEGAwtcvSQ0CQQhBCSAAQYCU69wDSSIBGyEeQYDC1y9BgJTr3AMgARsMAwsgAEHkAE8EQEECQQMgAEHoB0kiARshHkHkAEHoByABGwwDCyAAQQlLIR5BAUEKIABBCkkbDAILQQRBBSAAQaCNBkkiARshHkGQzgBBoI0GIAEbDAELQQZBByAAQYCt4gRJIgEbIR5BwIQ9QYCt4gQgARsLISBCASAGhiEHAkAgHiAoa0EQdEGAgARqQRB1IiQgMkEQdEEQdSIBSgRAIAIgB0IBfSIFgyECIBpB//8DcSEcICQgMmtBEHRBEHUgKyAkIAFrICtJGyIbQQFrIShBACEBA0AgACAgbiEaIAEgK0YNByAAIBogIGxrIQAgASApaiAaQTBqOgAAIAEgKEYNCCABIB5GDQIgAUEBaiEBICBBCkkgIEEKbiEgRQ0AC0HAw8AAQRlBrMXAABCDAQALIB8gKSArQQAgJCAyIAJCCoAgIK0gBoYgBxA5DAgLIAFBAWohASAcQQFrQT9xrSEDQgEhBANAIAQgA4hQRQRAIB9BADYCAAwJCyABICtPDQcgASApaiACQgp+IgIgBoinQTBqOgAAIARCCn4hBCACIAWDIQIgGyABQQFqIgFHDQALIB8gKSArIBsgJCAyIAIgByAEEDkMBwtB/7LAAEEcQdjEwAAQgwEAC0HoxMAAQSRBjMXAABCDAQALIAFB0QBB+MHAABBpAAtBjMTAAEEhQZzFwAAQgwEACyArICtBvMXAABBpAAsgHyApICsgGyAkIDIgAK0gBoYgAnwgIK0gBoYgBxA5DAELIAEgK0HMxcAAEGkACyAyQRB0QRB1IToCQCAjKAKQCEUEQCAjQcAIaiE7ICNBEGohOSMAQdAGayIhJAACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAjQdAIaiIAKQMAIgVQRQRAIAApAwgiA1ANASAAKQMQIgJQDQIgAiAFfCAFVA0DIAUgA30gBVYNBCAALwEYIRogISAFPgIMICFBEGpBACAFQiCIpyAFQoCAgIAQVCIAGzYCACAhQQFBAiAAGzYCCCAhQRRqQQBBmAEQ3gEaICFBuAFqQQBBnAEQ3gEaICFCgYCAgBA3A7ABIBqtQjCGQjCHIAVCAX15fULCmsHoBH5CgKHNoLQCfEIgiKciAUEQdEEQdSEzAkAgGkEQdEEQdSIAQQBOBEAgIUEIaiAaECUaDAELICFBsAFqQQAgAGtBEHRBEHUQJRoLICFBsAFqQQRyISwCQCAzQQBIBEAgIUEIakEAIDNrQRB0QRB1ECsMAQsgIUGwAWogAUH//wNxECsLICEoArABIRwgIUGoBWpBBHIgLEGgARDgASEqICEgHDYCqAUCQCAxIiJBCkkNAAJAIBxBKEsEQCAcIQAMAQsgIUGkBWohHiAcIQADQAJAIABFDQAgAEECdCEaIABBAWtB/////wNxIgFBAWoiAEEBcQJ/IAFFBEBCACEEIBogKmoMAQsgAEH+////B3EhASAaIB5qIQBCACEEA0AgAEEEaiIaIBo1AgAgBEIghoQiA0KAlOvcA4AiAj4CACAAIAA1AgAgAyACQoCU69wDfn1CIIaEIgNCgJTr3AOAIgI+AgAgAyACQoCU69wDfn0hBCAAQQhrIQAgAUECayIBDQALIABBCGoLIQBFDQAgAEEEayIAIAA1AgAgBEIghoRCgJTr3AOAPgIACyAiQQlrIiJBCU0NAiAhKAKoBSIAQSlJDQALCwwRCwJ/An8CQCAiQQJ0QdCwwABqKAIAIhoEQCAhKAKoBSIAQSlPDRRBACAARQ0DGiAAQQJ0IR4gAEEBa0H/////A3EiAUEBaiIAQQFxISggGq0hBSABDQFCACEEIB4gKmoMAgtB+97AAEEbQbTewAAQgwEACyAAQf7///8HcSEBIB4gIWpBpAVqIQBCACEEA0AgAEEEaiIaIBo1AgAgBEIghoQiAyAFgCICPgIAIAAgADUCACADIAIgBX59QiCGhCIDIAWAIgI+AgAgAyACIAV+fSEEIABBCGshACABQQJrIgENAAsgAEEIagshACAoBEAgAEEEayIAIAA1AgAgBEIghoQgBYA+AgALICEoAqgFCyIAICEoAggiHiAAIB5LGyIbQSlPDR0gIUEIakEEciEoIBtFBEBBACEbDAcLIBtBAXEhKSAbQQFGBEBBACEiDAYLIBtBfnEhJCAhQRBqIQEgIUGwBWohAEEAISIDQCAAQQRrIhogGigCACIfIAFBBGsoAgBqIisgIkEBcWoiGjYCACAAIAAoAgAiICABKAIAaiIyIBogK0kgHyArS3JqIho2AgAgGiAySSAgIDJLciEiIAFBCGohASAAQQhqIQAgJCAlQQJqIiVHDQALDAULQf+ywABBHEGYtsAAEIMBAAtBrLPAAEEdQai2wAAQgwEAC0Hcs8AAQRxBuLbAABCDAQALQYi0wABBNkHItsAAEIMBAAtB0LTAAEE3Qdi2wAAQgwEACyApBH8gKiAlQQJ0IhpqIgAgACgCACIBIBogKGooAgBqIhogImoiADYCACAAIBpJIAEgGktyBSAiC0EBcUUNACAbQSdLDRggG0ECdCAhakGsBWpBATYCACAbQQFqIRsLICEgGzYCqAUgGyAcIBsgHEsbIgBBKU8NCSAAQQJ0IQACQANAIAAEQCAhQagFaiAAaiEgICFBsAFqIABqIQEgAEEEayEAQX8gASgCACIaICAoAgAiAUcgASAaSRsiAUUNAQwCCwtBf0EAIAAbIQELIAFBAU0EQCAzQQFqITMMAwsgHkEpTw0KIB5FBEBBACEeDAILIB5BAWtB/////wNxIhpBAWoiAEEDcSEBIBpBA0kEQEIAIQQgKCEADAELIABB/P///wdxIRtCACEEICghAANAIAAgADUCAEIKfiAEfCICPgIAIABBBGoiGiAaNQIAQgp+IAJCIIh8IgI+AgAgAEEIaiIaIBo1AgBCCn4gAkIgiHwiAj4CACAAQQxqIhogGjUCAEIKfiACQiCIfCICPgIAIAJCIIghBCAAQRBqIQAgG0EEayIbDQALDAALIAEEQANAIAAgADUCAEIKfiAEfCICPgIAIABBBGohACACQiCIIQQgAUEBayIBDQALCyAEpyIARQ0AIB5BJ0sNAiAeQQJ0ICFqQQxqIAA2AgAgHkEBaiEeCyAhIB42AggLQQEhJQJAIDogM0EQdEEQdSIATARAIDMgOmtBEHRBEHUgMSAAIDprIDFJGyIiDQELQQAhIgwFCyAhQdgCaiIAQQRyICxBoAEQ4AEhQiAhIBw2AtgCIABBARAlICEoArABIQEgIUGABGoiAEEEciAsQaABEOABIUMgISABNgKABCAAQQIQJSEeICEoArABIQEgIUGoBWoiAEEEciAsQaABEOABIUQgISABNgKoBSAhQbgBaiEyICFB4AJqISkgIUGIBGohJCAhQbAFaiEfICFBEGohGiAAQQMQJSEAKAIAIT4gHigCACE/IAAoAgAhQCAhKAIIISAgISgCsAEhHEEAISsCQANAICshKiAgQSlPDQogKkEBaiErICBBAnQhHkEAIQACQAJAAkADQCAAIB5GDQEgIUEIaiAAaiAAQQRqIQBBBGooAgBFDQALICAgQCAgIEBLGyIeQSlPDQwgHkECdCEAAkADQCAABEAgIUEIaiAAaiElICFBqAVqIABqIQEgAEEEayEAQX8gASgCACIbICUoAgAiAUcgASAbSRsiAUUNAQwCCwtBf0EAIAAbIQELQQAhNCABQQJJBEAgHgRAQQEhJUEAISAgHkEBRwRAIB5BfnEhLyAfIQEgGiEAA0AgAEEEayIbIBsoAgAiMCABQQRrKAIAQX9zaiImICVBAXFqIhs2AgAgACAAKAIAIiUgASgCAEF/c2oiNSAmIDBJIBsgJklyaiIbNgIAIBsgNUkgJSA1S3IhJSABQQhqIQEgAEEIaiEAIC8gIEECaiIgRw0ACwsgHkEBcQR/ICggIEECdCIgaiIAIAAoAgAiASAgIERqKAIAQX9zaiIgICVqIgA2AgAgACAgSSABICBLcgUgJQtBAXFFDRALICEgHjYCCEEIITQgHiEgCyAgID8gICA/SxsiG0EpTw0YIBtBAnQhAANAIABFDQIgIUEIaiAAaiElICFBgARqIABqIQEgAEEEayEAQX8gASgCACIeICUoAgAiAUcgASAeSRsiAUUNAAsMAgsgIiAqSQ0FICIgMUsNBiAiICpGDQkgKiA5akEwICIgKmsQ3gEaDAkLQX9BACAAGyEBCwJAIAFBAUsEQCAgIRsMAQsgGwRAQQEhJUEAISAgG0EBRwRAIBtBfnEhLyAkIQEgGiEAA0AgAEEEayIeIB4oAgAiMCABQQRrKAIAQX9zaiImICVBAXFqIh42AgAgACAAKAIAIiUgASgCAEF/c2oiNSAmIDBJIB4gJklyaiIeNgIAIB4gNUkgJSA1S3IhJSABQQhqIQEgAEEIaiEAIC8gIEECaiIgRw0ACwsgG0EBcQR/ICggIEECdCIeaiIAIAAoAgAiASAeIENqKAIAQX9zaiIeICVqIgA2AgAgACAeSSABIB5LcgUgJQtBAXFFDQ0LICEgGzYCCCA0QQRyITQLIBsgPiAbID5LGyIeQSlPDQkgHkECdCEAAkADQCAABEAgIUEIaiAAaiElICFB2AJqIABqIQEgAEEEayEAQX8gASgCACIgICUoAgAiAUcgASAgSRsiAUUNAQwCCwtBf0EAIAAbIQELAkAgAUEBSwRAIBshHgwBCyAeBEBBASElQQAhICAeQQFHBEAgHkF+cSEvICkhASAaIQADQCAAQQRrIhsgGygCACIwIAFBBGsoAgBBf3NqIiYgJUEBcWoiGzYCACAAIAAoAgAiJSABKAIAQX9zaiI1ICYgMEkgGyAmSXJqIhs2AgAgGyA1SSAlIDVLciElIAFBCGohASAAQQhqIQAgLyAgQQJqIiBHDQALCyAeQQFxBH8gKCAgQQJ0IiBqIgAgACgCACIBICAgQmooAgBBf3NqIiAgJWoiADYCACAAICBJIAEgIEtyBSAlC0EBcUUNDQsgISAeNgIIIDRBAmohNAsgHiAcIBwgHkkbIiBBKU8NCiAgQQJ0IQACQANAIAAEQCAhQQhqIABqISUgIUGwAWogAGohASAAQQRrIQBBfyABKAIAIhsgJSgCACIBRyABIBtJGyIBRQ0BDAILC0F/QQAgABshAQsCQCABQQFLBEAgHiEgDAELICAEQEEBISVBACEeICBBAUcEQCAgQX5xIS8gMiEBIBohAANAIABBBGsiGyAbKAIAIjAgAUEEaygCAEF/c2oiJiAlQQFxaiIbNgIAIAAgACgCACIlIAEoAgBBf3NqIjUgJiAwSSAbICZJcmoiGzYCACAbIDVJICUgNUtyISUgAUEIaiEBIABBCGohACAvIB5BAmoiHkcNAAsLICBBAXEEfyAoIB5BAnQiHmoiACAAKAIAIgEgHiAsaigCAEF/c2oiHiAlaiIANgIAIAAgHkkgASAeS3IFICULQQFxRQ0NCyAhICA2AgggNEEBaiE0CyAqIDFGDQEgKiA5aiA0QTBqOgAAICBBKU8NCgJAICBFBEBBACEgDAELICBBAWtB/////wNxIhtBAWoiHkEDcSEBQgAhBCAoIQAgG0EDTwRAIB5B/P///wdxIRsDQCAAIAA1AgBCCn4gBHwiAj4CACAAQQRqIh4gHjUCAEIKfiACQiCIfCICPgIAIABBCGoiHiAeNQIAQgp+IAJCIIh8IgI+AgAgAEEMaiIeIB41AgBCCn4gAkIgiHwiAj4CACACQiCIIQQgAEEQaiEAIBtBBGsiGw0ACwsgAQRAA0AgACAANQIAQgp+IAR8IgI+AgAgAEEEaiEAIAJCIIghBCABQQFrIgENAAsLIASnIgBFDQAgIEEnSw0GICBBAnQgIWpBDGogADYCACAgQQFqISALICEgIDYCCCAiICtHDQALQQAhJQwFCyAxIDFB+LbAABBpAAsgHkEoQbTewAAQaQALICogIkHotsAAEMsBAAsgIiAxQei2wAAQygEACyAgQShBtN7AABBpAAsCQAJAAkACQAJAAkAgHEEpSQRAIBxFBEBBACEcDAMLIBxBAWtB/////wNxIhpBAWoiAUEDcSEAIBpBA0kEQEIAIQQMAgsgAUH8////B3EhAUIAIQQDQCAsICw1AgBCBX4gBHwiAj4CACAsQQRqIhogGjUCAEIFfiACQiCIfCICPgIAICxBCGoiGiAaNQIAQgV+IAJCIIh8IgI+AgAgLEEMaiIaIBo1AgBCBX4gAkIgiHwiAj4CACACQiCIIQQgLEEQaiEsIAFBBGsiAQ0ACwwBCwwWCyAABEADQCAsICw1AgBCBX4gBHwiAj4CACAsQQRqISwgAkIgiCEEIABBAWsiAA0ACwsgBKciAEUNACAcQSdLDQEgHEECdCAhakG0AWogADYCACAcQQFqIRwLICEgHDYCsAEgISgCCCIAIBwgACAcSxsiAEEpTw0FIABBAnQhAAJAA0AgAARAICFBCGogAGohKCAhQbABaiAAaiEBIABBBGshAEF/IAEoAgAiGiAoKAIAIgFHIAEgGkkbIgFFDQEMAgsLQX9BACAAGyEBCwJAAkAgAUH/AXEOAgABBQsgJQ0AICJBAWsiACAxTw0CIAAgOWotAABBAXFFDQQLICIgMUsNAkEAIQAgOSEBAkADQCAAICJGDQEgAEEBaiEAIAFBAWsiASAiaiIaLQAAQTlGDQALIBogGi0AAEEBajoAACAiIABrQQFqICJPDQQgGkEBakEwIABBAWsQ3gEaDAQLAn9BMSAlDQAaIDlBMToAAEEwICJBAUYNABogOUEBakEwICJBAWsQ3gEaQTALIQAgM0EQdEGAgARqQRB1IjMgOkwgIiAxT3INAyAiIDlqIAA6AAAgIkEBaiEiDAMLIBxBKEG03sAAEGkACyAAIDFBiLfAABBpAAsgIiAxQZi3wAAQygEACyAiIDFNDQAgIiAxQai3wAAQygEACyA7IDM7AQggOyAiNgIEIDsgOTYCACAhQdAGaiQADAULIABBKEG03sAAEMoBAAsgHkEoQbTewAAQygEACyAgQShBtN7AABDKAQALQcTewABBGkG03sAAEIMBAAsgI0HICGogI0GYCGooAgA2AgAgIyAjKQOQCDcDwAgLIDogIy4ByAgiAEgEQCAjQQhqICMoAsAIICMoAsQIIAAgNiAjQZAIahA6ICMoAgwhACAjKAIIDAQLQQIhACAjQQI7AZAIIDYEQCAjQaAIaiA2NgIAICNBADsBnAggI0ECNgKYCCAjQajHwAA2ApQIICNBkAhqDAQLQQEhACAjQQE2ApgIICNBrcfAADYClAggI0GQCGoMAwtBAiEAICNBAjsBkAggNgRAICNBoAhqIDY2AgAgI0EAOwGcCCAjQQI2ApgIICNBqMfAADYClAggI0GQCGoMAwtBASEAICNBATYCmAggI0Gtx8AANgKUCCAjQZAIagwCCyAjQQM2ApgIICNBrsfAADYClAggI0ECOwGQCCAjQZAIagwBCyAjQQM2ApgIICNBscfAADYClAggI0ECOwGQCEEBIQBByK/AACE9ICNBkAhqCyEBICNBzAhqIAA2AgAgIyABNgLICCAjIEE2AsQIICMgPTYCwAggPCAjQcAIahAxICNB8AhqJAAMAQtBtMfAAEElQdzHwAAQgwEACw8LIAEgGiEBIwBBgAFrIickACBFvSEEAkAgRSBFYgRAQQIhAAwBCyAEQv////////8HgyIFQoCAgICAgIAIhCAEQgGGQv7///////8PgyAEQjSIp0H/D3EiKBsiA0IBgyEHQQMhAAJAAkACQEEBQQJBBCAEQoCAgICAgID4/wCDIgJQIhobIAJCgICAgICAgPj/AFEbQQNBBCAaGyAFUBtBAmsOAwABAgMLQQQhAAwCCyAoQbMIayEsIAdQIQBCASEGDAELQoCAgICAgIAgIANCAYYgA0KAgICAgICACFEiGhshA0ICQgEgGhshBiAHUCEAQct3Qcx3IBobIChqISwLICcgLDsBeCAnIAY3A3AgJ0IBNwNoICcgAzcDYCAnIAA6AHoCfyAAQQJrQf8BcSIAQQMgAEEDSRsiGgRAQavHwABBrMfAAEHIr8AAIAEbIARCAFMbISxBASEAQQEgBEI/iKcgARshPQJAAkACQCAaQQJrDgIBAAILICdBIGohJCAnQQ9qIR8jAEEwayIpJAACQAJAAkACQAJAAkACQCAnQeAAaiIAKQMAIgVQRQRAIAApAwgiA1BFBEAgACkDECICUEUEQCAFIAIgBXwiAlgEQCAFIAUgA30iBloEQAJAAkAgAkL//////////x9YBEAgKSAALwEYIho7AQggKSAGNwMAIBogGkEgayAaIAJCgICAgBBUIgEbIgBBEGsgACACQiCGIAIgARsiAkKAgICAgIDAAFQiARsiAEEIayAAIAJCEIYgAiABGyICQoCAgICAgICAAVQiARsiAEEEayAAIAJCCIYgAiABGyICQoCAgICAgICAEFQiARsiAEECayAAIAJCBIYgAiABGyICQoCAgICAgICAwABUIgAbIAJCAoYgAiAAGyIEQj+Hp0F/c2oiAWtBEHRBEHUiAEEASA0CIClCfyAArSICiCIDIAaDNwMQIAMgBlQNDSApIBo7AQggKSAFNwMAICkgAyAFgzcDECADIAVUDQ1BoH8gAWtBEHRBEHVB0ABsQbCnBWpBzhBtIgBB0QBPDQEgAEEEdCIAQbi3wABqKQMAIgNC/////w+DIg0gBSACQj+DIgeGIgJCIIgiFX4iBUIgiCIJIANCIIgiDyAVfnwgDyACQv////8PgyIDfiICQiCIIhB8IAVC/////w+DIAMgDX5CIIh8IAJC/////w+DfEKAgICACHxCIIghFkIBQQAgASAAQcC3wABqLwEAamtBP3GtIgiGIgxCAX0hDiANIAYgB4YiAkIgiCIFfiIDQv////8PgyANIAJC/////w+DIgJ+QiCIfCACIA9+IgJC/////w+DfEKAgICACHxCIIghESAFIA9+IQsgAkIgiCEGIANCIIghByAAQcK3wABqLwEAIRoCfwJAAkAgDyAEIARCf4VCP4iGIgJCIIgiF34iBCANIBd+IgVCIIgiGHwgDyACQv////8PgyIDfiICQiCIIhl8IAVC/////w+DIAMgDX5CIIh8IAJC/////w+DfEKAgICACHxCIIgiDXxCAXwiEyAIiKciAUGQzgBPBEAgAUHAhD1JDQEgAUGAwtcvSQ0CQQhBCSABQYCU69wDSSIAGyEcQYDC1y9BgJTr3AMgABsMAwsgAUHkAE8EQEECQQMgAUHoB0kiABshHEHkAEHoByAAGwwDCyABQQlLIRxBAUEKIAFBCkkbDAILQQRBBSABQaCNBkkiABshHEGQzgBBoI0GIAAbDAELQQZBByABQYCt4gRJIgAbIRxBwIQ9QYCt4gQgABsLIRsgFnwhFCAOIBODIQMgHCAaa0EBaiEgIBMgByALfCAGfCARfCILfUIBfCIKIA6DIQZBACEAA0AgASAbbiEeAkACQCAAQRFHBEAgACAfaiIaIB5BMGoiKDoAACAKIAEgGyAebGsiAa0gCIYiEiADfCICVg0MIAAgHEcNAiAAQQFqIQBCASECA0AgAiEHIAYhBSAAQRFPDQIgACAfaiADQgp+IgMgCIinQTBqIhs6AAAgAEEBaiEAIAdCCn4hAiAFQgp+IgYgAyAOgyIDWA0ACyAGIAN9IgsgDFohASACIBMgFH1+IgQgAnwhECALIAxUIAQgAn0iCiADWHINDSAAIB9qQQFrIRogBUIKfiADIAx8fSERIAwgCn0hCyAKIAN9IQRCACEJA0AgAyAMfCICIApUIAQgCXwgAyALfFpyRQRAQQEhAQwPCyAaIBtBAWsiGzoAACAJIBF8IgUgDFohASACIApaDQ8gCSAMfSEJIAIhAyAFIAxaDQALDA4LQRFBEUHcw8AAEGkACyAAQRFB/MPAABBpAAsgAEEBaiEAIBtBCkkgG0EKbiEbRQ0AC0HAw8AAQRlBqMPAABCDAQALQejCwABBLUGYw8AAEIMBAAsgAEHRAEH4wcAAEGkAC0HIr8AAQR1BiLDAABCDAQALQdC0wABBN0HIwsAAEIMBAAtBiLTAAEE2QbjCwAAQgwEAC0Hcs8AAQRxBqMLAABCDAQALQayzwABBHUGYwsAAEIMBAAtB/7LAAEEcQYjCwAAQgwEACyAAQQFqIQECQCAAQRFJBEAgCiACfSIHIButIAiGIghaIQAgEyAUfSIFQgF8IQ4gByAIVCAFQgF9IhEgAlhyDQEgAyAIfCICIAl8IBB8IBZ8IA8gFSAXfX58IBh9IBl9IA19IQkgGCAZfCANfCAEfCEGQgAgFCADIBJ8fH0hBEICIAsgAiASfHx9IQcDQCACIBJ8IgUgEVQgBCAGfCAJIBJ8WnJFBEAgAyASfCECQQEhAAwDCyAaIChBAWsiKDoAACADIAh8IQMgBiAHfCELIAUgEVQEQCACIAh8IQIgCCAJfCEJIAYgCH0hBiAIIAtYDQELCyAIIAtYIQAgAyASfCECDAELIAFBEUHsw8AAEMoBAAsCQAJAIABFIAIgDlpyRQRAIAIgCHwiAyAOVCAOIAJ9IAMgDn1acg0BCyACIApCBH1YIAJCAlpxDQEgJEEANgIADAULICRBADYCAAwECyAkICA7AQggJCABNgIEDAILIAMhAgsCQAJAIAFFIAIgEFpyRQRAIAIgDHwiAyAQVCAQIAJ9IAMgEH1acg0BCyACIAdCWH4gBnxYIAIgB0IUflpxDQEgJEEANgIADAMLICRBADYCAAwCCyAkICA7AQggJCAANgIECyAkIB82AgALIClBMGokAAwBCyApQQA2AhgjAEEgayIBJAAgASApNgIEIAEgKUEQajYCACABQRhqIClBGGoiAEEQaikCADcDACABQRBqIABBCGopAgA3AwAgASAAKQIANwMIIAFBnMnAACABQQRqQZzJwAAgAUEIakGYsMAAEDwACwJAICcoAiBFBEAgJ0HQAGohOiAnQQ9qISEjAEHACmsiHSQAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgJ0HgAGoiACkDACIHUEUEQCAAKQMIIgVQDQEgACkDECIDUA0CIAMgB3wiAiAHVA0DIAcgBX0gB1YNBCAALAAaITMgAC8BGCEaIB0gBz4CBCAdQQhqQQAgB0IgiKcgB0KAgICAEFQiABs2AgAgHUEBQQIgABs2AgAgHUEMakEAQZgBEN4BGiAdIAU+AqwBIB1BsAFqQQAgBUIgiKcgBUKAgICAEFQiABs2AgAgHUEBQQIgABs2AqgBIB1BtAFqQQBBmAEQ3gEaIB0gAz4C1AIgHUHYAmpBACADQiCIpyADQoCAgIAQVCIAGzYCACAdQQFBAiAAGzYC0AIgHUHcAmpBAEGYARDeARogHUGABGpBAEGcARDeARogHUKBgICAEDcD+AMgGq1CMIZCMIcgAkIBfXl9QsKawegEfkKAoc2gtAJ8QiCIpyIBQRB0QRB1ISMCQCAaQRB0QRB1IgBBAE4EQCAdIBoQJRogHUGoAWogGhAlGiAdQdACaiAaECUaDAELIB1B+ANqQQAgAGtBEHRBEHUQJRoLIB1BBHIhIAJAICNBAEgEQCAdQQAgI2tBEHRBEHUiABArIB1BqAFqIAAQKyAdQdACaiAAECsMAQsgHUH4A2ogAUH//wNxECsLIB0oAgAhHCAdQZgJakEEciAgQaABEOABITIgHSAcNgKYCSAcIB0oAtACIiogHCAqSxsiH0EpTw0aIB1B0AJqQQRyIR4gH0UEQEEAIR8MBwsgH0EBcSEpIB9BAUYNBSAfQX5xISQgHUHYAmohASAdQaAJaiEAA0AgAEEEayIaIBooAgAiGyABQQRrKAIAaiIrICZqIho2AgAgACAAKAIAIiggASgCAGoiPCAaICtJIBsgK0tyaiIaNgIAIBogPEkgKCA8S3IhJiABQQhqIQEgAEEIaiEAICQgLUECaiItRw0ACwwFC0H/ssAAQRxBnLPAABCDAQALQayzwABBHUHMs8AAEIMBAAtB3LPAAEEcQfizwAAQgwEAC0GItMAAQTZBwLTAABCDAQALQdC0wABBN0GItcAAEIMBAAsgKQR/IDIgLUECdCIaaiIAIAAoAgAiASAaIB5qKAIAaiIaICZqIgA2AgAgACAaSSABIBpLcgUgJgtFDQAgH0EnSw0BIB9BAnQgHWpBnAlqQQE2AgAgH0EBaiEfCyAdIB82ApgJIB0oAvgDIiQgHyAfICRJGyIAQSlPDRQgHUH4A2pBBHIhNCAdQagBakEEciEoIABBAnQhAAJAA0AgAARAIB1B+ANqIABqIRsgHUGYCWogAGohASAAQQRrIQBBfyABKAIAIhogGygCACIBRyABIBpJGyIBRQ0BDAILC0F/QQAgABshAQsgASAzTgRAIBxBKU8NHyAcRQRAQQAhHAwECyAcQQFrQf////8DcSIaQQFqIgBBA3EhASAaQQNJBEBCACECICAhAAwDCyAAQfz///8HcSEfQgAhAiAgIQADQCAAIAA1AgBCCn4gAnwiAj4CACAAQQRqIhogGjUCAEIKfiACQiCIfCICPgIAIABBCGoiGiAaNQIAQgp+IAJCIIh8IgI+AgAgAEEMaiIaIBo1AgBCCn4gAkIgiHwiAj4CACACQiCIIQIgAEEQaiEAIB9BBGsiHw0ACwwCCyAjQQFqISMMCAsgH0EoQbTewAAQaQALIAEEQANAIAAgADUCAEIKfiACfCICPgIAIABBBGohACACQiCIIQIgAUEBayIBDQALCyACpyIARQ0AIBxBJ0sNASAdIBxBAnRqQQRqIAA2AgAgHEEBaiEcCyAdIBw2AgAgHSgCqAEiG0EpTw0ZIBtFBEBBACEbDAMLIBtBAWtB/////wNxIhpBAWoiAEEDcSEBIBpBA0kEQEIAIQIgKCEADAILIABB/P///wdxIR9CACECICghAANAIAAgADUCAEIKfiACfCICPgIAIABBBGoiGiAaNQIAQgp+IAJCIIh8IgI+AgAgAEEIaiIaIBo1AgBCCn4gAkIgiHwiAj4CACAAQQxqIhogGjUCAEIKfiACQiCIfCICPgIAIAJCIIghAiAAQRBqIQAgH0EEayIfDQALDAELIBxBKEG03sAAEGkACyABBEADQCAAIAA1AgBCCn4gAnwiAj4CACAAQQRqIQAgAkIgiCECIAFBAWsiAQ0ACwsgAqciAEUNACAbQSdLDRggG0ECdCAdakGsAWogADYCACAbQQFqIRsLIB0gGzYCqAEgKkEpTw0AICpFBEAgHUEANgLQAgwDCyAqQQFrQf////8DcSIaQQFqIgBBA3EhASAaQQNJBEBCACECIB4hAAwCCyAAQfz///8HcSEfQgAhAiAeIQADQCAAIAA1AgBCCn4gAnwiAj4CACAAQQRqIhogGjUCAEIKfiACQiCIfCICPgIAIABBCGoiGiAaNQIAQgp+IAJCIIh8IgI+AgAgAEEMaiIaIBo1AgBCCn4gAkIgiHwiAj4CACACQiCIIQIgAEEQaiEAIB9BBGsiHw0ACwwBCyAqQShBtN7AABDKAQALIAEEQANAIAAgADUCAEIKfiACfCICPgIAIABBBGohACACQiCIIQIgAUEBayIBDQALCyAdIAKnIgAEfyAqQSdLDQIgKkECdCAdakHUAmogADYCACAqQQFqBSAqCzYC0AILIB1BoAVqIgBBBHIgNEGgARDgASE1IB0gJDYCoAUgAEEBECUhJCAdKAL4AyEBIB1ByAZqIgBBBHIgNEGgARDgASFBIB0gATYCyAYgAEECECUhHCAdKAL4AyEBIB1B8AdqIgBBBHIgNEGgARDgASFCIB0gATYC8AcgAEEDECUhAAJAIB0oAgAiGyAAKAIAIjsgGyA7SxsiH0EoTQRAIB1B2AJqITkgHUGgCWohKiAdQYAEaiErIB1BqAVqITwgHUHQBmohMiAdQfgHaiEpIB1BCGohGiAdQZgJakEEciFDICQoAgAhPiAcKAIAIT8gHSgC+AMhNkEAIRwDQCAcISQgH0ECdCEAAkADQCAABEAgACAdaiEiIB1B8AdqIABqIQEgAEEEayEAQX8gASgCACIcICIoAgAiAUcgASAcSRsiAUUNAQwCCwtBf0EAIAAbIQELQQAhLiABQQFNBEAgHwRAQQEhJkEAIS0gH0EBRwRAIB9BfnEhJSApIQEgGiEAA0AgAEEEayIcICYgHCgCACIiIAFBBGsoAgBBf3NqIi9qIhw2AgAgACAAKAIAIhsgASgCAEF/c2oiMCAcIC9JICIgL0tyaiIcNgIAIBwgMEkgGyAwS3IhJiABQQhqIQEgAEEIaiEAICUgLUECaiItRw0ACwsgH0EBcQR/ICAgLUECdCIcaiIAIAAoAgAiASAcIEJqKAIAQX9zaiIcICZqIgA2AgAgACAcSSABIBxLcgUgJgtFDRELIB0gHzYCAEEIIS4gHyEbCyAbID8gGyA/SxsiH0EpTw0NIB9BAnQhAAJAA0AgAARAIAAgHWohIiAdQcgGaiAAaiEBIABBBGshAEF/IAEoAgAiHCAiKAIAIgFHIAEgHEkbIgFFDQEMAgsLQX9BACAAGyEBCwJAIAFBAUsEQCAbIR8MAQsgHwRAQQEhJkEAIS0gH0EBRwRAIB9BfnEhJSAyIQEgGiEAA0AgAEEEayIcICYgHCgCACIiIAFBBGsoAgBBf3NqIi9qIhw2AgAgACAAKAIAIhsgASgCAEF/c2oiMCAcIC9JICIgL0tyaiIcNgIAIBwgMEkgGyAwS3IhJiABQQhqIQEgAEEIaiEAICUgLUECaiItRw0ACwsgH0EBcQR/ICAgLUECdCIcaiIAIAAoAgAiASAcIEFqKAIAQX9zaiIcICZqIgA2AgAgACAcSSABIBxLcgUgJgtFDRELIB0gHzYCACAuQQRyIS4LIB8gPiAfID5LGyIcQSlPDRggHEECdCEAAkADQCAABEAgACAdaiEiIB1BoAVqIABqIQEgAEEEayEAQX8gASgCACIbICIoAgAiAUcgASAbSRsiAUUNAQwCCwtBf0EAIAAbIQELAkAgAUEBSwRAIB8hHAwBCyAcBEBBASEmQQAhLSAcQQFHBEAgHEF+cSElIDwhASAaIQADQCAAQQRrIhsgJiAbKAIAIiIgAUEEaygCAEF/c2oiL2oiGzYCACAAIAAoAgAiHyABKAIAQX9zaiIwIBsgL0kgIiAvS3JqIhs2AgAgGyAwSSAfIDBLciEmIAFBCGohASAAQQhqIQAgJSAtQQJqIi1HDQALCyAcQQFxBH8gICAtQQJ0IhtqIgAgACgCACIBIBsgNWooAgBBf3NqIhsgJmoiADYCACAAIBtJIAEgG0tyBSAmC0UNEQsgHSAcNgIAIC5BAmohLgsgHCA2IBwgNksbIhtBKU8NFiAbQQJ0IQACQANAIAAEQCAAIB1qISIgHUH4A2ogAGohASAAQQRrIQBBfyABKAIAIh8gIigCACIBRyABIB9JGyIBRQ0BDAILC0F/QQAgABshAQsCQCABQQFLBEAgHCEbDAELIBsEQEEBISZBACEtIBtBAUcEQCAbQX5xISUgKyEBIBohAANAIABBBGsiHCAmIBwoAgAiIiABQQRrKAIAQX9zaiIvaiIcNgIAIAAgACgCACIfIAEoAgBBf3NqIjAgHCAvSSAiIC9LcmoiHDYCACAcIDBJIB8gMEtyISYgAUEIaiEBIABBCGohACAlIC1BAmoiLUcNAAsLIBtBAXEEfyAgIC1BAnQiHGoiACAAKAIAIgEgHCA0aigCAEF/c2oiHCAmaiIANgIAIAAgHEkgASAcS3IFICYLRQ0RCyAdIBs2AgAgLkEBaiEuCyAkQRFGDQYgISAkaiAuQTBqOgAAIBsgHSgCqAEiNyAbIDdLGyIAQSlPDQ4gJEEBaiEcIABBAnQhAAJAA0AgAARAIAAgHWohIiAdQagBaiAAaiEBIABBBGshAEF/IAEoAgAiHyAiKAIAIgFHIAEgH0kbIh9FDQEMAgsLQX9BACAAGyEfCyBDICBBoAEQ4AEhRCAdIBs2ApgJIBsgHSgC0AIiOCAbIDhLGyIuQSlPDQQCQCAuRQRAQQAhLgwBC0EAISZBACEtIC5BAUcEQCAuQX5xIS8gOSEBICohAANAIABBBGsiIiAmICIoAgAiMCABQQRrKAIAaiJAaiIiNgIAIAAgACgCACIlIAEoAgBqIiYgIiBASSAwIEBLcmoiIjYCACAiICZJICUgJktyISYgAUEIaiEBIABBCGohACAvIC1BAmoiLUcNAAsLIC5BAXEEfyBEIC1BAnQiImoiACAAKAIAIgEgHiAiaigCAGoiIiAmaiIANgIAIAAgIkkgASAiS3IFICYLRQ0AIC5BJ0sNBiAuQQJ0IB1qQZwJakEBNgIAIC5BAWohLgsgHSAuNgKYCSA2IC4gLiA2SRsiAEEpTw0OIABBAnQhAAJAA0AgAARAIB1B+ANqIABqISUgHUGYCWogAGohASAAQQRrIQBBfyABKAIAIiIgJSgCACIBRyABICJJGyIBRQ0BDAILC0F/QQAgABshAQsgHyAzSCABIDNIcg0CIBtBKU8NFgJAIBtFBEBBACEbDAELIBtBAWtB/////wNxIiRBAWoiH0EDcSEBQgAhAiAgIQAgJEEDTwRAIB9B/P///wdxIR8DQCAAIAA1AgBCCn4gAnwiAj4CACAAQQRqIiQgJDUCAEIKfiACQiCIfCICPgIAIABBCGoiJCAkNQIAQgp+IAJCIIh8IgI+AgAgAEEMaiIkICQ1AgBCCn4gAkIgiHwiAj4CACACQiCIIQIgAEEQaiEAIB9BBGsiHw0ACwsgAQRAA0AgACAANQIAQgp+IAJ8IgI+AgAgAEEEaiEAIAJCIIghAiABQQFrIgENAAsLIAKnIgBFDQAgG0EnSw0YIB0gG0ECdGpBBGogADYCACAbQQFqIRsLIB0gGzYCACA3QSlPDQcCQCA3RQRAQQAhNwwBCyA3QQFrQf////8DcSIkQQFqIh9BA3EhAUIAIQIgKCEAICRBA08EQCAfQfz///8HcSEfA0AgACAANQIAQgp+IAJ8IgI+AgAgAEEEaiIkICQ1AgBCCn4gAkIgiHwiAj4CACAAQQhqIiQgJDUCAEIKfiACQiCIfCICPgIAIABBDGoiJCAkNQIAQgp+IAJCIIh8IgI+AgAgAkIgiCECIABBEGohACAfQQRrIh8NAAsLIAEEQANAIAAgADUCAEIKfiACfCICPgIAIABBBGohACACQiCIIQIgAUEBayIBDQALCyACpyIARQ0AIDdBJ0sNCSA3QQJ0IB1qQawBaiAANgIAIDdBAWohNwsgHSA3NgKoASA4QSlPDQkCQCA4RQRAQQAhOAwBCyA4QQFrQf////8DcSIkQQFqIh9BA3EhAUIAIQIgHiEAICRBA08EQCAfQfz///8HcSEfA0AgACAANQIAQgp+IAJ8IgI+AgAgAEEEaiIkICQ1AgBCCn4gAkIgiHwiAj4CACAAQQhqIiQgJDUCAEIKfiACQiCIfCICPgIAIABBDGoiJCAkNQIAQgp+IAJCIIh8IgI+AgAgAkIgiCECIABBEGohACAfQQRrIh8NAAsLIAEEQANAIAAgADUCAEIKfiACfCICPgIAIABBBGohACACQiCIIQIgAUEBayIBDQALCyACpyIARQ0AIDhBJ0sNCyA4QQJ0IB1qQdQCaiAANgIAIDhBAWohOAsgHSA4NgLQAiAbIDsgGyA7SxsiH0EoTQ0ACwsMCwsgASAzTg0JIB8gM0gEQCAdQQEQJSgCACIBIB0oAvgDIgAgACABSRsiAEEpTw0MIABBAnQhAAJAA0AgAARAIAAgHWohKCAdQfgDaiAAaiEBIABBBGshAEF/IAEoAgAiGiAoKAIAIgFHIAEgGkkbIgFFDQEMAgsLQX9BACAAGyEBCyABQQJPDQoLICRBEU8NCCAkIQBBfyEBAkADQCAAQX9GDQEgAUEBaiEBIAAgIWogAEEBayEALQAAQTlGDQALIAAgIWoiKEEBaiIaIBotAABBAWo6AAAgAEECaiAkSw0KIChBAmpBMCABEN4BGgwKCyAhQTE6AAAgJARAICFBAWpBMCAkEN4BGgsgHCAhaiEAIBxBEUkEQCAAQTA6AAAgI0EBaiEjICRBAmohHAwKCyAcQRFB+LXAABBpAAsgKkEoQbTewAAQaQALIC5BKEG03sAAEMoBAAsgLkEoQbTewAAQaQALQRFBEUHYtcAAEGkACyA3QShBtN7AABDKAQALIDdBKEG03sAAEGkACyA4QShBtN7AABDKAQALIDhBKEG03sAAEGkACyAcQRFB6LXAABDKAQALIBxBEU0EQCA6ICM7AQggOiAcNgIEIDogITYCACAdQcAKaiQADAULIBxBEUGItsAAEMoBAAsgH0EoQbTewAAQygEACyAAQShBtN7AABDKAQALQcTewABBGkG03sAAEIMBAAsgJ0HYAGogJ0EoaigCADYCACAnICcpAyA3A1ALICcgJygCUCAnKAJUICcvAVhBACAnQSBqEDogJygCBCEAICcoAgAMAwsgJ0ECOwEgICdBATYCKCAnQa3HwAA2AiQgJ0EgagwCCyAnQQM2AiggJ0Gux8AANgIkICdBAjsBICAnQSBqDAELICdBAzYCKCAnQbHHwAA2AiQgJ0ECOwEgQQEhAEHIr8AAISwgJ0EgagshASAnQdwAaiAANgIAICcgATYCWCAnID02AlQgJyAsNgJQICdB0ABqEDEgJ0GAAWokAA8LIBtBKEG03sAAEMoBAAsgG0EoQbTewAAQaQALIBxBKEG03sAAEMoBAAs5AAJAAn8gAkGAgMQARwRAQQEgACACIAEoAhARAAANARoLIAMNAUEACw8LIAAgAyAEIAEoAgwRAQALQAEBfyMAQSBrIgAkACAAQRxqQQA2AgAgAEHYocAANgIYIABCATcCDCAAQcCkwAA2AgggAEEIakHIpMAAEIkBAAtAAQF/IwBBIGsiACQAIABBHGpBADYCACAAQZSuwAA2AhggAEIBNwIMIABBxK7AADYCCCAAQQhqQcyuwAAQiQEAC98CAQJ/IwBBIGsiAiQAIAJBAToAGCACIAE2AhQgAiAANgIQIAJBhMnAADYCDCACQcivwAA2AggjAEEQayIBJAACQCACQQhqIgAoAgwiAgRAIAAoAggiA0UNASABIAI2AgggASAANgIEIAEgAzYCACMAQRBrIgAkACAAQQhqIAFBCGooAgA2AgAgACABKQIANwMAIwBBEGsiASQAIAAoAgAiAkEUaigCACEDAkACfwJAAkAgAigCBA4CAAEDCyADDQJBACECQdihwAAMAQsgAw0BIAIoAgAiAygCBCECIAMoAgALIQMgASACNgIEIAEgAzYCACABQbSnwAAgACgCBCIBKAIIIAAoAgggAS0AEBBWAAsgAUEANgIEIAEgAjYCACABQaCnwAAgACgCBCIBKAIIIAAoAgggAS0AEBBWAAtBnKLAAEErQfCmwAAQgwEAC0GcosAAQStB4KbAABCDAQALMwACQCAAQfz///8HSw0AIABFBEBBBA8LIAAgAEH9////B0lBAnQQuAEiAEUNACAADwsACz0BAX8gACgCACEBAkAgAEEEai0AAA0AQYTnwAAoAgBB/////wdxRQ0AEOoBDQAgAUEBOgABCyABQQA6AAALjB0CFH8EfiMAQRBrIhMkACATIAE2AgwgEyAANgIIAn8jAEEgayIJJAAgE0EIaiIAQQRqKAIAIQ0gACgCACELAkBBAEHYksAAKAIAEQIAIhEEQCARKAIADQEgEUF/NgIAIBFBBGoiCEEEaigCACICQQxrIQMgDQR+IA1BB3EhAQJAIA1BAWtBB0kEQEKlxoihyJyn+UshFiALIQAMAQsgDUF4cSEEQqXGiKHInKf5SyEWIAshAANAIAAxAAcgADEABiAAMQAFIAAxAAQgADEAAyAAMQACIAAxAAEgFiAAMQAAhUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+IRYgAEEIaiEAIARBCGsiBA0ACwsgAQRAA0AgFiAAMQAAhUKzg4CAgCB+IRYgAEEBaiEAIAFBAWsiAQ0ACwsgFkL/AYVCs4OAgIAgfgVC7taLsMjJnLKvfwsiGEIZiEL/AINCgYKEiJCgwIABfiEZIBinIQAgCCgCACEBAkADQAJAIAIgACABcSIAaikAACIXIBmFIhZCf4UgFkKBgoSIkKDAgAF9g0KAgYKEiJCgwIB/gyIWUA0AA0ACQCANIANBACAWeqdBA3YgAGogAXFrIgRBDGxqIgdBBGooAgBGBEAgBygCACALIA0Q3wFFDQELIBZCAX0gFoMiFlBFDQEMAgsLIAkgCzYCBCAJQRBqIAg2AgAgCUEIaiANNgIAIAlBDGogAiAEQQxsajYCACAJQQA2AgAMAgsgFyAXQgGGg0KAgYKEiJCgwIB/g1AEQCAAIAVBCGoiBWohAAwBCwsgCCgCCEUEQEEAIQAjAEEwayIPJAACQCAIQQxqKAIAIhBBAWoiASAQSQRAEH4gDygCDBoMAQsCQAJAAn8CQCAIKAIAIgwgDEEBaiIHQQN2QQdsIAxBCEkbIhVBAXYgAUkEQCABIBVBAWoiACAAIAFJGyIAQQhJDQFBfyAAQQN0QQduQQFrZ3ZBAWogACAAQf////8BcUYNAhoQfiAPKAIsQYGAgIB4Rw0FIA8oAigMAgsgCEEEaigCACEEQQAhAQNAAkACfyAAQQFxBEAgAUEHaiIAIAFJIAAgB09yDQIgAUEIagwBCyABIAdJIgJFDQEgAiABIgBqCyEBIAAgBGoiACAAKQMAIhZCf4VCB4hCgYKEiJCgwIABgyAWQv/+/fv379+//wCEfDcDAEEBIQAMAQsLAkACQCAHQQhPBEAgBCAHaiAEKQAANwAADAELAkACQAJ/AkAgByIDIARBCGoiAiAEIgBrSwRAIAAgA2ohBSACIANqIQEgA0EPSw0BIAIMAgsgA0EPTQRAIAIhAQwDCyACQQAgAmtBA3EiBWohBiAFBEAgAiEBIAAhAgNAIAEgAi0AADoAACACQQFqIQIgAUEBaiIBIAZJDQALCyAGIAMgBWsiA0F8cSIKaiEBAkAgACAFaiIFQQNxIgIEQCAKQQBMDQEgBUF8cSIOQQRqIQBBACACQQN0IhJrQRhxIRQgDigCACECA0AgBiACIBJ2IAAoAgAiAiAUdHI2AgAgAEEEaiEAIAZBBGoiBiABSQ0ACwwBCyAKQQBMDQAgBSEAA0AgBiAAKAIANgIAIABBBGohACAGQQRqIgYgAUkNAAsLIANBA3EhAyAFIApqIQAMAgsgAUF8cSECQQAgAUEDcSIKayEOIAoEQCAAIANqQQFrIQYDQCABQQFrIgEgBi0AADoAACAGQQFrIQYgASACSw0ACwsgAiADIAprIgpBfHEiA2shAUEAIANrIQMCQCAFIA5qIgVBA3EiBgRAIANBAE4NASAFQXxxIg5BBGshAEEAIAZBA3QiEmtBGHEhFCAOKAIAIQYDQCACQQRrIgIgBiAUdCAAKAIAIgYgEnZyNgIAIABBBGshACABIAJJDQALDAELIANBAE4NACAAIApqQQRrIQADQCACQQRrIgIgACgCADYCACAAQQRrIQAgASACSQ0ACwsgCkEDcSIARQ0CIAMgBWohBSABIABrCyECIAVBAWshAANAIAFBAWsiASAALQAAOgAAIABBAWshACABIAJLDQALDAELIANFDQAgASADaiECA0AgASAALQAAOgAAIABBAWohACABQQFqIgEgAkkNAAsLIAdFDQELIARBDGshDkEAIQEDQAJAIAQgASICaiIFLQAAQYABRw0AIA4gAkF0bGohBiAEIAJBf3NBDGxqIQcCQANAIAwgBkEEaigCACIABH4gBigCACEBIABBB3EhA0KlxoihyJyn+UshFgJAIABBAWtBB0kEQCABIQAMAQsgAEF4cSEKA0AgATEAByABMQAGIAExAAUgATEABCABMQADIAExAAIgATEAASAWIAExAACFQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH4hFiABQQhqIgAhASAKQQhrIgoNAAsLIAMEQANAIBYgADEAAIVCs4OAgIAgfiEWIABBAWohACADQQFrIgMNAAsLIBZC/wGFQrODgICAIH4FQu7Wi7DIyZyyr38LpyIKcSIDIQAgAyAEaikAAEKAgYKEiJCgwIB/gyIWUARAQQghASADIQADQCAAIAFqIQAgAUEIaiEBIAQgACAMcSIAaikAAEKAgYKEiJCgwIB/gyIWUA0ACwsgBCAWeqdBA3YgAGogDHEiAGosAABBAE4EQCAEKQMAQoCBgoSIkKDAgH+DeqdBA3YhAAsgACADayACIANrcyAMcUEITwRAIAQgAEF/c0EMbGohASAAIARqIgMtAAAgAyAKQRl2IgM6AAAgAEEIayAMcSAEakEIaiADOgAAQf8BRg0CIAcoAAAhACAHIAEoAAA2AAAgASAANgAAIAEoAAQhACABIAcoAAQ2AAQgByAANgAEIActAAohACAHIAEtAAo6AAogASAAOgAKIActAAshACAHIAEtAAs6AAsgASAAOgALIAcvAAghACAHIAEvAAg7AAggASAAOwAIDAELCyAFIApBGXYiADoAACACQQhrIAxxIARqQQhqIAA6AAAMAQsgBUH/AToAACACQQhrIAxxIARqQQhqQf8BOgAAIAFBCGogB0EIaigAADYAACABIAcpAAA3AAALIAJBAWohASACIAxHDQALCyAIIBUgEGs2AggMBAtBBEEIIABBBEkbCyIBrUIMfiIWQiCIpw0AIBanIgBBB2oiAiAASQ0AIAJBeHEiAiABQQhqIgRqIgAgAk8NAQsQfiAPKAIUGgwBCwJAAkAgAEEATgRAQQghAwJAIABFDQAgAEEIELgBIgMNACAAQQgQ2wEACyACIANqQf8BIAQQ3gEhBCABQQFrIgUgAUEDdkEHbCAFQQhJGyAQa60gEK1CIIaEIRcgB0UEQCAIIBc3AgggCCAFNgIAIAgoAgQhAiAIIAQ2AgQMAwsgCEEEaigCACICQQxrIRADQCACIAZqLAAAQQBOBEAgBCAFIBAgBkF0bGoiAUEEaigCACIABH4gASgCACEBIABBB3EhCkKlxoihyJyn+UshFgJAIABBAWtBB0kEQCABIQAMAQsgAEF4cSEDA0AgATEAByABMQAGIAExAAUgATEABCABMQADIAExAAIgATEAASAWIAExAACFQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH4hFiABQQhqIgAhASADQQhrIgMNAAsLIAoEQANAIBYgADEAAIVCs4OAgIAgfiEWIABBAWohACAKQQFrIgoNAAsLIBZC/wGFQrODgICAIH4FQu7Wi7DIyZyyr38LpyIDcSIAaikAAEKAgYKEiJCgwIB/gyIWUARAQQghAQNAIAAgAWohACABQQhqIQEgBCAAIAVxIgBqKQAAQoCBgoSIkKDAgH+DIhZQDQALCyAEIBZ6p0EDdiAAaiAFcSIBaiwAAEEATgRAIAQpAwBCgIGChIiQoMCAf4N6p0EDdiEBCyABIARqIANBGXYiADoAACABQQhrIAVxIARqQQhqIAA6AAAgBCABQX9zQQxsaiIAQQhqIAIgBkF/c0EMbGoiAUEIaigAADYAACAAIAEpAAA3AAALIAYgDEYgBkEBaiEGRQ0ACwwBCxB+IA8oAhwaDAILIAggFzcCCCAIIAU2AgAgCEEEaiAENgIAIAwNAAwBCyAMIAetQgx+p0EHakF4cSIAakF3Rg0AIAIgAGsQJgsgD0EwaiQACyAJIBg3AwggCUEYaiAINgIAIAlBFGogDTYCACAJQRBqIAs2AgAgCUEBNgIACwJAIAkoAgBFBEAgCUEMaigCACEADAELIAlBFGooAgAhAyAJQRBqKAIAIQcgCUEYaigCACECIAkoAgghCCALIA0QEyEFIAJBBGooAgAiASAIIAIoAgAiBHEiC2opAABCgIGChIiQoMCAf4MiFlAEQEEIIQADQCAAIAtqIQsgAEEIaiEAIAEgBCALcSILaikAAEKAgYKEiJCgwIB/gyIWUA0ACwsgASAWeqdBA3YgC2ogBHEiAGosAAAiC0EATgRAIAEgASkDAEKAgYKEiJCgwIB/g3qnQQN2IgBqLQAAIQsLIAAgAWogCEEZdiIIOgAAIABBCGsgBHEgAWpBCGogCDoAACACIAIoAgggC0EBcWs2AgggAiACKAIMQQFqNgIMIAEgAEF0bGoiAEEMayIBIAU2AgggASADNgIEIAEgBzYCAAsgAEEEaygCABAKIBEgESgCAEEBajYCACAJQSBqJAAMAgtB6JLAAEHGACAJQbCTwABBkJTAABBkAAtBoJTAAEEQIAlBsJTAAEGglcAAEGQACyATQRBqJAALvQIBA38gACgCACEAIAEQvwFFBEAgARDAAUUEQCAAMQAAQQEgARBCDwsjAEGAAWsiAyQAIAAtAAAhAANAIAIgA2pB/wBqQTBBNyAAQQ9xIgRBCkkbIARqOgAAIAJBAWshAiAAIgRBBHYhACAEQQ9LDQALIAJBgAFqIgBBgQFPBEAgAEGAAUGky8AAEMkBAAsgAUEBQbTLwABBAiACIANqQYABakEAIAJrEC0gA0GAAWokAA8LIwBBgAFrIgMkACAALQAAIQADQCACIANqQf8AakEwQdcAIABBD3EiBEEKSRsgBGo6AAAgAkEBayECIAAiBEEEdiEAIARBD0sNAAsgAkGAAWoiAEGBAU8EQCAAQYABQaTLwAAQyQEACyABQQFBtMvAAEECIAIgA2pBgAFqQQAgAmsQLSADQYABaiQAC70CAQN/IAAoAgAhAiABEL8BRQRAIAEQwAFFBEAgAiABEMwBDwtBACEAIwBBgAFrIgMkACACKAIAIQIDQCAAIANqQf8AakEwQTcgAkEPcSIEQQpJGyAEajoAACAAQQFrIQAgAkEPSyACQQR2IQINAAsgAEGAAWoiAkGBAU8EQCACQYABQaTLwAAQyQEACyABQQFBtMvAAEECIAAgA2pBgAFqQQAgAGsQLSADQYABaiQADwtBACEAIwBBgAFrIgMkACACKAIAIQIDQCAAIANqQf8AakEwQdcAIAJBD3EiBEEKSRsgBGo6AAAgAEEBayEAIAJBD0sgAkEEdiECDQALIABBgAFqIgJBgQFPBEAgAkGAAUGky8AAEMkBAAsgAUEBQbTLwABBAiAAIANqQYABakEAIABrEC0gA0GAAWokAAuZAQEBfyMAQRBrIgAkACAAQQhqIgIgAUHyosAAEJMBIAItAAQhASACLQAFBEAgAgJ/QQEgAUH/AXENABogAigCACIBLQAAQQRxRQRAIAEoAhhB/crAAEECIAFBHGooAgAoAgwRAQAMAQsgASgCGEHvysAAQQEgAUEcaigCACgCDBEBAAsiAToABAsgAUH/AXFBAEcgAEEQaiQAC+QBAQJ/IwBBEGsiACQAIABBCGoiAyABQdikwAAQkwEjAEEQayICJAAgAwJ/QQEgAy0ABA0AGiADKAIAIQEgA0EFai0AAEUEQCABKAIYQfbKwABBByABQRxqKAIAKAIMEQEADAELIAEtAABBBHFFBEAgASgCGEHwysAAQQYgAUEcaigCACgCDBEBAAwBCyACQQE6AA8gAiABKQIYNwMAIAIgAkEPajYCCEEBIAJB7MrAAEEDEDcNABogASgCGEHvysAAQQEgASgCHCgCDBEBAAsiAToABCACQRBqJAAgAEEQaiQAIAEL8wIBAn8gACgCACIALQAAIABBADoAAEEBcUUEQEG4jsAAQStBsI/AABCDAQALIwBBIGsiACQAAkACQAJAQYTnwAAoAgBB/////wdxBEAQ6gFFDQELQfTmwAAoAgBB9ObAAEF/NgIADQECQAJAQYTnwAAoAgBB/////wdxRQRAQYDnwAAoAgAhAUGA58AAQYyOwAA2AgBB/ObAACgCACECQfzmwABBATYCAAwBCxDqAUGA58AAKAIAIQFBgOfAAEGMjsAANgIAQfzmwAAoAgAhAkH85sAAQQE2AgBFDQELQYTnwAAoAgBB/////wdxRQ0AEOoBDQBB+ObAAEEBOgAAC0H05sAAQQA2AgACQCACRQ0AIAIgASgCABEEACABQQRqKAIARQ0AIAFBCGooAgAaIAIQJgsgAEEgaiQADAILIABBHGpBADYCACAAQdihwAA2AhggAEIBNwIMIABBrKbAADYCCCAAQQhqQdCmwAAQiQEACwALCzQAIABBAzoAICAAQoCAgICABDcCACAAIAE2AhggAEEANgIQIABBADYCCCAAQRxqIAI2AgALMAAgASgCGCACQQsgAUEcaigCACgCDBEBACECIABBADoABSAAIAI6AAQgACABNgIACycAIAAgACgCBEEBcSABckECcjYCBCAAIAFqIgAgACgCBEEBcjYCBAs6AQJ/QdDmwAAtAAAhAUHQ5sAAQQA6AABB1ObAACgCACECQdTmwABBADYCACAAIAI2AgQgACABNgIACyEAAkAgAC0AAEEDRw0AIABBCGooAgBFDQAgACgCBBAmCwsgAQF/AkAgACgCBCIBRQ0AIABBCGooAgBFDQAgARAmCwsjAAJAIAFB/P///wdNBEAgACABQQQgAhCwASIADQELAAsgAAsjACACIAIoAgRBfnE2AgQgACABQQFyNgIEIAAgAWogATYCAAseACAAKAIAIgCtQgAgAKx9IABBAE4iABsgACABEEILHgAgAEUEQBDUAQALIAAgAiADIAQgBSABKAIQEQ0ACyMAIABBADYCACAAIAEpAgA3AgQgAEEMaiABQQhqKAIANgIACx8BAn4gACkDACICIAJCP4ciA4UgA30gAkIAWSABEEILHAAgAEUEQBDUAQALIAAgAiADIAQgASgCEBETAAscACAARQRAENQBAAsgACACIAMgBCABKAIQERUACxwAIABFBEAQ1AEACyAAIAIgAyAEIAEoAhARCAALHAAgAEUEQBDUAQALIAAgAiADIAQgASgCEBEXAAscACAARQRAENQBAAsgACACIAMgBCABKAIQEQwACx4AIAAgAUEDcjYCBCAAIAFqIgAgACgCBEEBcjYCBAsUACAAQQRqKAIABEAgACgCABAmCwsaACAARQRAENQBAAsgACACIAMgASgCEBEFAAsiACAALQAARQRAIAFBmM7AAEEFECcPCyABQZTOwABBBBAnCxgAIABFBEAQ1AEACyAAIAIgASgCEBEAAAsZAQF/IAAoAhAiAQR/IAEFIABBFGooAgALCxgAIAAoAgAiACgCACAAQQhqKAIAIAEQKgsSAEEAQRkgAEEBdmsgAEEfRhsLFgAgACABQQFyNgIEIAAgAWogATYCAAscACABKAIYQfjHwABBDiABQRxqKAIAKAIMEQEACxkAIAAoAhggASACIABBHGooAgAoAgwRAQALHAAgASgCGEG538AAQQUgAUEcaigCACgCDBEBAAsQACAAIAFqQQFrQQAgAWtxC48GAQZ/An8gACEFAkACQAJAIAJBCU8EQCADIAIQOCIHDQFBAAwEC0EIQQgQrwEhAEEUQQgQrwEhAUEQQQgQrwEhAkEAQRBBCBCvAUECdGsiBEGAgHwgAiAAIAFqamtBd3FBA2siACAAIARLGyADTQ0BQRAgA0EEakEQQQgQrwFBBWsgA0sbQQgQrwEhAiAFEO4BIgAgABDXASIEEOsBIQECQAJAAkACQAJAAkACQCAAEMQBRQRAIAIgBE0NASABQazqwAAoAgBGDQIgAUGo6sAAKAIARg0DIAEQvQENByABENcBIgYgBGoiCCACSQ0HIAggAmshBCAGQYACSQ0EIAEQRgwFCyAAENcBIQEgAkGAAkkNBiABIAJrQYGACEkgAkEEaiABTXENBSABIAAoAgAiAWpBEGohBCACQR9qQYCABBCvASECDAYLQRBBCBCvASAEIAJrIgFLDQQgACACEOsBIQQgACACEJQBIAQgARCUASAEIAEQMgwEC0Gk6sAAKAIAIARqIgQgAk0NBCAAIAIQ6wEhASAAIAIQlAEgASAEIAJrIgJBAXI2AgRBpOrAACACNgIAQazqwAAgATYCAAwDC0Gg6sAAKAIAIARqIgQgAkkNAwJAQRBBCBCvASAEIAJrIgFLBEAgACAEEJQBQQAhAUEAIQQMAQsgACACEOsBIgQgARDrASEGIAAgAhCUASAEIAEQqwEgBiAGKAIEQX5xNgIEC0Go6sAAIAQ2AgBBoOrAACABNgIADAILIAFBDGooAgAiCSABQQhqKAIAIgFHBEAgASAJNgIMIAkgATYCCAwBC0GQ58AAQZDnwAAoAgBBfiAGQQN2d3E2AgALQRBBCBCvASAETQRAIAAgAhDrASEBIAAgAhCUASABIAQQlAEgASAEEDIMAQsgACAIEJQBCyAADQMLIAMQJCIBRQ0BIAEgBSAAENcBQXhBfCAAEMQBG2oiACADIAAgA0kbEOABIAUQJgwDCyAHIAUgASADIAEgA0kbEOABGiAFECYLIAcMAQsgABDEARogABDtAQsLFAAgACgCACAAQQhqKAIAIAEQ3AELCwAgAQRAIAAQJgsLDwAgAEEBdCIAQQAgAGtyCxUAIAEgACgCACIAKAIAIAAoAgQQJwsUACAAKAIAIAEgACgCBCgCDBEAAAuuCAEDfyMAQfAAayIFJAAgBSADNgIMIAUgAjYCCAJAAkACQAJAIAUCfwJAAkAgAUGBAk8EQANAIAAgBmogBkEBayEGQYACaiwAAEG/f0wNAAsgBkGBAmoiByABSQ0CIAFBgQJrIAZHDQQgBSAHNgIUDAELIAUgATYCFAsgBSAANgIQQcivwAAhBkEADAELIAAgBmpBgQJqLAAAQb9/TA0BIAUgBzYCFCAFIAA2AhBBjNDAACEGQQULNgIcIAUgBjYCGAJAIAEgAkkiBiABIANJckUEQAJ/AkACQCACIANNBEACQAJAIAJFDQAgASACTQRAIAEgAkYNAQwCCyAAIAJqLAAAQUBIDQELIAMhAgsgBSACNgIgIAIgASIGSQRAIAJBAWoiBkEAIAJBA2siAyACIANJGyIDSQ0GIAAgBmogACADamshBgNAIAZBAWshBiAAIAJqIAJBAWshAiwAAEFASA0ACyACQQFqIQYLAkAgBkUNACABIAZNBEAgASAGRg0BDAoLIAAgBmosAABBv39MDQkLIAEgBkYNBwJAIAAgBmoiAiwAACIDQQBIBEAgAi0AAUE/cSEAIANBH3EhASADQV9LDQEgAUEGdCAAciEADAQLIAUgA0H/AXE2AiRBAQwECyACLQACQT9xIABBBnRyIQAgA0FwTw0BIAAgAUEMdHIhAAwCCyAFQeQAakH6ADYCACAFQdwAakH6ADYCACAFQdQAakEONgIAIAVBxABqQQQ2AgAgBUIENwI0IAVB8NDAADYCMCAFQQ42AkwgBSAFQcgAajYCQCAFIAVBGGo2AmAgBSAFQRBqNgJYIAUgBUEMajYCUCAFIAVBCGo2AkgMCAsgAUESdEGAgPAAcSACLQADQT9xIABBBnRyciIAQYCAxABGDQULIAUgADYCJEEBIABBgAFJDQAaQQIgAEGAEEkNABpBA0EEIABBgIAESRsLIQAgBSAGNgIoIAUgACAGajYCLCAFQcQAakEFNgIAIAVB7ABqQfoANgIAIAVB5ABqQfoANgIAIAVB3ABqQf0ANgIAIAVB1ABqQf4ANgIAIAVCBTcCNCAFQcTRwAA2AjAgBUEONgJMIAUgBUHIAGo2AkAgBSAFQRhqNgJoIAUgBUEQajYCYCAFIAVBKGo2AlggBSAFQSRqNgJQIAUgBUEgajYCSAwFCyAFIAIgAyAGGzYCKCAFQcQAakEDNgIAIAVB3ABqQfoANgIAIAVB1ABqQfoANgIAIAVCAzcCNCAFQbTQwAA2AjAgBUEONgJMIAUgBUHIAGo2AkAgBSAFQRhqNgJYIAUgBUEQajYCUCAFIAVBKGo2AkgMBAsgAyAGQYjSwAAQywEACyAAIAFBACAHIAQQtgEAC0GtxMAAQSsgBBCDAQALIAAgASAGIAEgBBC2AQALIAVBMGogBBCJAQALEQAgACgCACAAKAIEIAEQ3AELCAAgACABEDgLFgBB1ObAACAANgIAQdDmwABBAToAAAsRACABIAAoAgAgACgCBBCtAQsQACAAKAIAIAAoAgQgARAqCxMAIABBkKfAADYCBCAAIAE2AgALDQAgAC0ABEECcUEBdgsQACABIAAoAgAgACgCBBAnCw0AIAAtAABBEHFBBHYLDQAgAC0AAEEgcUEFdgsMACAAKAIAEBVBAEcLDAAgACgCABAdQQBHCwoAQQAgAGsgAHELCwAgAC0ABEEDcUULDAAgACABQQNyNgIECw0AIAAoAgAgACgCBGoL1gIBAn8gACgCACEAIwBBEGsiAiQAAkACfwJAIAFBgAFPBEAgAkEANgIMIAFBgBBPDQEgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAgsgACgCCCIDIAAoAgRGBEAgACADEFQgACgCCCEDCyAAIANBAWo2AgggACgCACADaiABOgAADAILIAFBgIAETwRAIAIgAUE/cUGAAXI6AA8gAiABQQZ2QT9xQYABcjoADiACIAFBDHZBP3FBgAFyOgANIAIgAUESdkEHcUHwAXI6AAxBBAwBCyACIAFBP3FBgAFyOgAOIAIgAUEMdkHgAXI6AAwgAiABQQZ2QT9xQYABcjoADUEDCyEBIAEgAEEEaigCACAAKAIIIgNrSwRAIAAgAyABEFIgACgCCCEDCyAAKAIAIANqIAJBDGogARDgARogACABIANqNgIICyACQRBqJABBAAsOACAAKAIAGgNADAALAAttAQF/IwBBMGsiAyQAIAMgATYCBCADIAA2AgAgA0EcakECNgIAIANBLGpBDjYCACADQgI3AgwgA0Goz8AANgIIIANBDjYCJCADIANBIGo2AhggAyADQQRqNgIoIAMgAzYCICADQQhqIAIQiQEAC20BAX8jAEEwayIDJAAgAyABNgIEIAMgADYCACADQRxqQQI2AgAgA0EsakEONgIAIANCAjcCDCADQcjPwAA2AgggA0EONgIkIAMgA0EgajYCGCADIANBBGo2AiggAyADNgIgIANBCGogAhCJAQALbQEBfyMAQTBrIgMkACADIAE2AgQgAyAANgIAIANBHGpBAjYCACADQSxqQQ42AgAgA0ICNwIMIANB/M/AADYCCCADQQ42AiQgAyADQSBqNgIYIAMgA0EEajYCKCADIAM2AiAgA0EIaiACEIkBAAsNACAANQIAQQEgARBCC9gCAgR/An4jAEFAaiICJABBASEEAkAgAC0ABA0AIAAtAAUhBAJAAkACQCAAKAIAIgMoAgAiBUEEcUUEQCAEDQEMAwsgBA0BQQEhBCADKAIYQYPLwABBASADQRxqKAIAKAIMEQEADQMgAygCACEFDAELQQEhBCADKAIYQerKwABBAiADQRxqKAIAKAIMEQEARQ0BDAILQQEhBCACQQE6ABcgAkE0akHMysAANgIAIAIgBTYCGCACIAMpAhg3AwggAiACQRdqNgIQIAMpAgghBiADKQIQIQcgAiADLQAgOgA4IAIgAygCBDYCHCACIAc3AyggAiAGNwMgIAIgAkEIajYCMCABIAJBGGpBoJrAACgCABEAAA0BIAIoAjBB6MrAAEECIAIoAjQoAgwRAQAhBAwBCyABIANBoJrAACgCABEAACEECyAAQQE6AAUgACAEOgAEIAJBQGskAAsNACAAKAIAIAEgAhA3Cw0AIAApAwBBASABEEILxwMCAX4EfyAAKAIAKQMAIQIjAEGAAWsiBSQAAkACQAJAAkAgASgCACIAQRBxRQRAIABBIHENASACQQEgARBCIQAMBAtBgAEhACAFQYABaiEEAkACQANAIABFBEBBACEADAMLIARBAWtBMEHXACACpyIDQQ9xIgZBCkkbIAZqOgAAIAJCEFoEQCAEQQJrIgRBMEHXACADQf8BcSIDQaABSRsgA0EEdmo6AAAgAEECayEAIAJCgAJUIAJCCIghAkUNAQwCCwsgAEEBayEACyAAQYEBTw0CCyABQQFBtMvAAEECIAAgBWpBgAEgAGsQLSEADAMLQYABIQAgBUGAAWohBAJAAkADQCAARQRAQQAhAAwDCyAEQQFrQTBBNyACpyIDQQ9xIgZBCkkbIAZqOgAAIAJCEFoEQCAEQQJrIgRBMEE3IANB/wFxIgNBoAFJGyADQQR2ajoAACAAQQJrIQAgAkKAAlQgAkIIiCECRQ0BDAILCyAAQQFrIQALIABBgQFPDQILIAFBAUG0y8AAQQIgACAFakGAASAAaxAtIQAMAgsgAEGAAUGky8AAEMkBAAsgAEGAAUGky8AAEMkBAAsgBUGAAWokACAACwsAIAAjAGokACMACw4AIAFBpInAAEEhEK0BCwsAIAAoAgAgARAJCwwAQbCVwABBMBAiAAsOACABQaiewABBMBCtAQsMACAAKAIAIAEQpgELCgAgACgCBEF4cQsKACAAKAIEQQFxCwoAIAAoAgxBAXELCgAgACgCDEEBdgsaACAAIAFB8ObAACgCACIAQeEAIAAbEQMAAAsKACACIAAgARAnCw0AIAFBwM7AAEECECcLrwEBA38gASEFAkAgAkEPTQRAIAAhAQwBCyAAQQAgAGtBA3EiA2ohBCADBEAgACEBA0AgASAFOgAAIAFBAWoiASAESQ0ACwsgBCACIANrIgJBfHEiA2ohASADQQBKBEAgBUH/AXFBgYKECGwhAwNAIAQgAzYCACAEQQRqIgQgAUkNAAsLIAJBA3EhAgsgAgRAIAEgAmohAgNAIAEgBToAACABQQFqIgEgAkkNAAsLIAALQwEDfwJAIAJFDQADQCAALQAAIgQgAS0AACIFRgRAIABBAWohACABQQFqIQEgAkEBayICDQEMAgsLIAQgBWshAwsgAwuzAgEHfwJAIAIiBEEPTQRAIAAhAgwBCyAAQQAgAGtBA3EiA2ohBSADBEAgACECIAEhBgNAIAIgBi0AADoAACAGQQFqIQYgAkEBaiICIAVJDQALCyAFIAQgA2siCEF8cSIHaiECAkAgASADaiIDQQNxIgQEQCAHQQBMDQEgA0F8cSIGQQRqIQFBACAEQQN0IglrQRhxIQQgBigCACEGA0AgBSAGIAl2IAEoAgAiBiAEdHI2AgAgAUEEaiEBIAVBBGoiBSACSQ0ACwwBCyAHQQBMDQAgAyEBA0AgBSABKAIANgIAIAFBBGohASAFQQRqIgUgAkkNAAsLIAhBA3EhBCADIAdqIQELIAQEQCACIARqIQMDQCACIAEtAAA6AAAgAUEBaiEBIAJBAWoiAiADSQ0ACwsgAAsOACABQYGdwABBChCtAQsOACABQbShwABBCBCtAQsOACABQbyhwABBAxCtAQttAQF/IwBBMGsiACQAIABBHzYCFCAAQfiXwAA2AhAgAEEBNgIsIABCATcCHCAAQfCXwAA2AhggACAAQRBqNgIoIAAgAEEYahA1IAEgACgCACIBIAAoAggQrQEgACgCBARAIAEQJgsgAEEwaiQACw4AIAFB/JfAAEEXEK0BC20BAX8jAEEwayIAJAAgAEEONgIUIABByJjAADYCECAAQQE2AiwgAEIBNwIcIABBwJjAADYCGCAAIABBEGo2AiggACAAQRhqEDUgASAAKAIAIgEgACgCCBCtASAAKAIEBEAgARAmCyAAQTBqJAALDgAgAUGTmMAAQRMQrQELCAAgACABEBcLCQAgACgCABAaCwsAQdzqwAAoAgBFCwcAIAAgAWoLBwAgACABawsHACAAQQhqCwcAIABBCGsLlQYBBX8CQCMAQdAAayICJAAgAkEANgIYIAJCATcDECACQSBqIgQgAkEQakH4lcAAEJIBIwBBQGoiACQAQQEhAwJAIAQoAhgiBUHkyMAAQQwgBEEcaigCACIEKAIMEQEADQACQCABKAIIIgMEQCAAIAM2AgwgAEH4ADYCFCAAIABBDGo2AhBBASEDIABBATYCPCAAQgI3AiwgAEH0yMAANgIoIAAgAEEQajYCOCAFIAQgAEEoahAwRQ0BDAILIAEoAgAiAyABKAIEQQxqKAIAEQoAQuuRk7X22LOi9ABSDQAgACADNgIMIABB+QA2AhQgACAAQQxqNgIQQQEhAyAAQQE2AjwgAEICNwIsIABB9MjAADYCKCAAIABBEGo2AjggBSAEIABBKGoQMA0BCyABKAIMIQEgAEEkakEONgIAIABBHGpBDjYCACAAIAFBDGo2AiAgACABQQhqNgIYIABB+gA2AhQgACABNgIQIABBAzYCPCAAQgM3AiwgAEHMyMAANgIoIAAgAEEQajYCOCAFIAQgAEEoahAwIQMLIABBQGskAAJAIANFBEAgAigCFCACKAIYIgBrQQlNBEAgAkEQaiAAQQoQUiACKAIYIQALIAIoAhAgAGoiAUG0l8AAKQAANwAAIAFBCGpBvJfAAC8AADsAACACIABBCmo2AhggAkEIahAeIgQQHyACKAIIIQYgAigCDCIFIAIoAhQgAigCGCIAa0sEQCACQRBqIAAgBRBSIAIoAhghAAsgAigCECAAaiAGIAUQ4AEaIAIgACAFaiIANgIYIAIoAhQgAGtBAU0EQCACQRBqIABBAhBSIAIoAhghAAsgAigCECAAakGKFDsAACACIABBAmoiAzYCGCACKAIQIQACQCADIAIoAhQiAU8EQCAAIQEMAQsgA0UEQEEBIQEgABAmDAELIAAgAUEBIAMQsAEiAUUNAgsgASADECAgBQRAIAYQJgsgBEEkTwRAIAQQAAsgAkHQAGokAAwCC0GQlsAAQTcgAkHIAGpByJbAAEGkl8AAEGQACyADQQEQ2wEACwsNAELrkZO19tizovQACw0AQo/oo8y3gau8un8LDABCsqH/yeyFlYdWCwMAAQsLi2YHAEGAgMAAC44xdHVwbGUgc3RydWN0IENlbGxJZCB3aXRoIDIgZWxlbWVudHMAAAAQACMAAAABAAAACAAAAAQAAAACAAAAAQAAAAAAAAABAAAAAwAAAAEAAAAAAAAAAQAAAAQAAAABAAAAAAAAAAEAAAAFAAAAAQAAAAAAAAABAAAABgAAAAEAAAAAAAAAAQAAAAcAAAABAAAAAAAAAAEAAAAIAAAAAQAAAAAAAAABAAAABAAAAAEAAAAAAAAAAQAAAAkAAAABAAAAAAAAAAEAAAAKAAAAcHJvdmVuYW5jZWNlbGxfaWR6b21lX25hbWVmbl9uYW1lY2FwX3NlY3JldHBheWxvYWRub25jZWV4cGlyZXNfYXRjYWxsZWQgYE9wdGlvbjo6dW53cmFwKClgIG9uIGEgYE5vbmVgIHZhbHVlL1VzZXJzL2pvc3QvLmNhcmdvL3JlZ2lzdHJ5L3NyYy9naXRodWIuY29tLTFlY2M2Mjk5ZGI5ZWM4MjMvc2VyZGUtd2FzbS1iaW5kZ2VuLTAuMy4xL3NyYy9kZS5ycwAAOAEQAF4AAABZAAAAHwAAAA8AAAAMAAAABAAAABAAAAARAAAAEgAAAGEgRGlzcGxheSBpbXBsZW1lbnRhdGlvbiByZXR1cm5lZCBhbiBlcnJvciB1bmV4cGVjdGVkbHkAEwAAAAAAAAABAAAAFAAAAC9ydXN0Yy82OWY5YzMzZDcxYzg3MWZjMTZhYzQ0NTIxMTI4MWM2ZTdhMzQwOTQzL2xpYnJhcnkvYWxsb2Mvc3JjL3N0cmluZy5ycwAIAhAASwAAAOgJAAAJAAAAaW52YWxpZCB2YWx1ZTogLCBleHBlY3RlZCAAAGQCEAAPAAAAcwIQAAsAAABtaXNzaW5nIGZpZWxkIGBgkAIQAA8AAACfAhAAAQAAAGludmFsaWQgbGVuZ3RoIACwAhAADwAAAHMCEAALAAAAZHVwbGljYXRlIGZpZWxkIGAAAADQAhAAEQAAAJ8CEAABAAAAFQAAAAwAAAAEAAAAFgAAABcAAAASAAAAYSBEaXNwbGF5IGltcGxlbWVudGF0aW9uIHJldHVybmVkIGFuIGVycm9yIHVuZXhwZWN0ZWRseQAYAAAAAAAAAAEAAAAUAAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9hbGxvYy9zcmMvc3RyaW5nLnJzAFQDEABLAAAA6AkAAAkAAAAzIGJ5dGUgcHJlZml4AAAAGAAAAAAAAAABAAAAGQAAAC9Vc2Vycy9qb3N0Ly5jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2hvbG9faGFzaC0wLjEuMC1iZXRhLXJjLjAvc3JjL2hhc2hfdHlwZS9wcmltaXRpdmUucnPQAxAAcAAAAE0AAAARAAAASG9sb0hhc2ggc2VyaWFsaXplZCByZXByZXNlbnRhdGlvbiBtdXN0IGJlIGV4YWN0bHkgMzkgYnl0ZXNIb2xvSGFzaCBlcnJvcjogAIsEEAAQAAAAYSBIb2xvSGFzaCBvZiBwcmltaXRpdmUgaGFzaF90eXBlAAAAGwAAAAwAAAAEAAAAHAAAAB0AAAASAAAAYSBEaXNwbGF5IGltcGxlbWVudGF0aW9uIHJldHVybmVkIGFuIGVycm9yIHVuZXhwZWN0ZWRseQAeAAAAAAAAAAEAAAAUAAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9hbGxvYy9zcmMvc3RyaW5nLnJzACgFEABLAAAA6AkAAAkAAABwcm92ZW5hbmNlY2VsbF9pZHpvbWVfbmFtZWZuX25hbWVjYXBfc2VjcmV0cGF5bG9hZG5vbmNlZXhwaXJlc19hdFpvbWVDYWxsVW5zaWduZWQAAACEBRAACgAAAI4FEAAHAAAAlQUQAAkAAACeBRAABwAAAKUFEAAKAAAArwUQAAcAAAC2BRAABQAAALsFEAAKAAAAIGJ5dGVzLCBnb3QgIGJ5dGVzAAAYBhAAAAAAABgGEAAMAAAAJAYQAAYAAAAgAAAAIAAAAAgAAAAEAAAAAgAAAC9Vc2Vycy9qb3N0Ly5jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2hvbG9faGFzaC0wLjEuMC1iZXRhLXJjLjAvc3JjL2hhc2gucnMAAABYBhAAYQAAAF8AAAAtAAAAIGJ5dGVzLCBnb3QgIGJ5dGVzAADMBhAAAAAAAMwGEAAMAAAA2AYQAAYAAABAAAAAIQAAAAgAAAAEAAAAAgAAACIAAAAAAAAAAQAAACMAAAAkAAAAJQAAACIAAAAEAAAABAAAACYAAAAnAAAAY2FsbGVkIGBPcHRpb246OnVud3JhcCgpYCBvbiBhIGBOb25lYCB2YWx1ZS9ydXN0Yy82OWY5YzMzZDcxYzg3MWZjMTZhYzQ0NTIxMTI4MWM2ZTdhMzQwOTQzL2xpYnJhcnkvc3RkL3NyYy9zeW5jL29uY2UucnMAYwcQAEwAAACPAAAAKQAAACIAAAAEAAAABAAAACgAAAApAAAAKgAAAC9Vc2Vycy9qb3N0Ly5jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2NvbnNvbGVfZXJyb3JfcGFuaWNfaG9vay0wLjEuNy9zcmMvbGliLnJzAAAA2AcQAGUAAACVAAAADgAAAFAIEAAAAAAALAAAAAQAAAAEAAAALQAAAC4AAAAvAAAAMQAAAAwAAAAEAAAAMgAAADMAAAA0AAAAYSBEaXNwbGF5IGltcGxlbWVudGF0aW9uIHJldHVybmVkIGFuIGVycm9yIHVuZXhwZWN0ZWRseQA1AAAAAAAAAAEAAAAUAAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9hbGxvYy9zcmMvc3RyaW5nLnJzANAIEABLAAAA6AkAAAkAAABpbnZhbGlkIHR5cGU6ICwgZXhwZWN0ZWQgAAAALAkQAA4AAAA6CRAACwAAADYAAAAAAAAA//////////9jYW5ub3QgYWNjZXNzIGEgVGhyZWFkIExvY2FsIFN0b3JhZ2UgdmFsdWUgZHVyaW5nIG9yIGFmdGVyIGRlc3RydWN0aW9uAAA3AAAAAAAAAAEAAAA4AAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9zdGQvc3JjL3RocmVhZC9sb2NhbC5ycwDACRAATwAAAKYBAAAJAAAAYWxyZWFkeSBib3Jyb3dlZDcAAAAAAAAAAQAAADkAAAAvVXNlcnMvam9zdC8uY2FyZ28vcmVnaXN0cnkvc3JjL2dpdGh1Yi5jb20tMWVjYzYyOTlkYjllYzgyMy9zZXJkZS13YXNtLWJpbmRnZW4tMC4zLjEvc3JjL2xpYi5ycwBAChAAXwAAABgAAAAOAAAAY2xvc3VyZSBpbnZva2VkIHJlY3Vyc2l2ZWx5IG9yIGRlc3Ryb3llZCBhbHJlYWR5RgAAAAQAAAAEAAAARwAAAEgAAABJAAAASgAAAAwAAAAEAAAASwAAAEwAAABNAAAAYSBEaXNwbGF5IGltcGxlbWVudGF0aW9uIHJldHVybmVkIGFuIGVycm9yIHVuZXhwZWN0ZWRseQBOAAAAAAAAAAEAAAAUAAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9hbGxvYy9zcmMvc3RyaW5nLnJzAFgLEABLAAAA6AkAAAkAAAAKClN0YWNrOgoKSnNWYWx1ZSgpAL4LEAAIAAAAxgsQAAEAAABhIGJ5dGUgYXJyYXkgb2YgbGVuZ3RoIADYCxAAFwAAACAAAABzdHJ1Y3QgWm9tZUNhbGxVbnNpZ25lZHR1cGxlIHN0cnVjdCBDZWxsSWRhIGJ5dGUgYXJyYXkgb2YgbGVuZ3RoIAAAACYMEAAXAAAAQAAAAIQgJEFnZW50UHViS2V5hC0kRG5hSGFzaC9Vc2Vycy9qb3N0Ly5jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2hvbG9faGFzaC0wLjEuMC1iZXRhLXJjLjAvc3JjL2VuY29kZS5yc2NhbGxlZCBgUmVzdWx0Ojp1bndyYXAoKWAgb24gYW4gYEVycmAgdmFsdWUAAFAAAAAQAAAABAAAABoAAABkDBAAYwAAAIMAAAAFAAAAUQAAAAQAAAAEAAAAUgAAAEJhZEhhc2hTaXplQmFkQ2hlY2tzdW1CYWRQcmVmaXgAUwAAAAQAAAAEAAAAVAAAAFMAAAAEAAAABAAAAFUAAABCYWRTaXplQmFkQmFzZTY0Tm9VL1VzZXJzL2pvc3QvLmNhcmdvL3JlZ2lzdHJ5L3NyYy9naXRodWIuY29tLTFlY2M2Mjk5ZGI5ZWM4MjMvYmxha2UyYl9zaW1kLTAuNS4xMS9zcmMvcG9ydGFibGUucnMAAHcNEABfAAAAlgAAABUAAAAvVXNlcnMvam9zdC8uY2FyZ28vcmVnaXN0cnkvc3JjL2dpdGh1Yi5jb20tMWVjYzYyOTlkYjllYzgyMy9ibGFrZTJiX3NpbWQtMC41LjExL3NyYy9saWIucnMAAOgNEABaAAAATgIAAAoAAABUDhAAAAAAAERlc2VyaWFsaXplAFcAAAAEAAAABAAAAFgAAABTZXJpYWxpemVieXRlIGFycmF5ZGVwdGggbGltaXQgZXhjZWVkZWRzZXJpYWxpemUgZGF0YSBtb2RlbCBpcyBpbnZhbGlkOiCfDhAAIQAAAGF0dGVtcHQgdG8gc2VyaWFsaXplIHN0cnVjdCwgc2VxdWVuY2Ugb3IgbWFwIHdpdGggdW5rbm93biBsZW5ndGhpbnZhbGlkIHZhbHVlIHdyaXRlOiAAAAAIDxAAFQAAAGVycm9yIHdoaWxlIHdyaXRpbmcgbXVsdGktYnl0ZSBNZXNzYWdlUGFjayB2YWx1ZXN0cnVjdCB2YXJpYW50AABYDxAADgAAAHR1cGxlIHZhcmlhbnQAAABwDxAADQAAAG5ld3R5cGUgdmFyaWFudACIDxAADwAAAHVuaXQgdmFyaWFudKAPEAAMAAAAZW51bbQPEAAEAAAAbWFwAMAPEAADAAAAc2VxdWVuY2XMDxAACAAAAG5ld3R5cGUgc3RydWN0AADcDxAADgAAAE9wdGlvbiB2YWx1ZfQPEAAMAAAAdW5pdCB2YWx1ZQAACBAQAAoAAABieXRlIGFycmF5AAAcEBAACgAAAHN0cmluZyAAMBAQAAcAAABjaGFyYWN0ZXIgYGBAEBAACwAAAEsQEAABAAAAZmxvYXRpbmcgcG9pbnQgYFwQEAAQAAAASxAQAAEAAABpbnRlZ2VyIGAAAAB8EBAACQAAAEsQEAABAAAAYm9vbGVhbiBgAAAAmBAQAAkAAABLEBAAAQAAAGEgc3RyaW5naTY0AGIAAAAEAAAABAAAAGMAAABkAAAAZQAAAGFscmVhZHkgYm9ycm93ZWRiAAAAAAAAAAEAAAA5AAAAAAAAAGIAAAAEAAAABAAAAGYAAABiAAAABAAAAAQAAABnAAAAY2FsbGVkIGBPcHRpb246OnVud3JhcCgpYCBvbiBhIGBOb25lYCB2YWx1ZWNhbGxlZCBgUmVzdWx0Ojp1bndyYXAoKWAgb24gYW4gYEVycmAgdmFsdWVBY2Nlc3NFcnJvcnVzZSBvZiBzdGQ6OnRocmVhZDo6Y3VycmVudCgpIGlzIG5vdCBwb3NzaWJsZSBhZnRlciB0aGUgdGhyZWFkJ3MgbG9jYWwgZGF0YSBoYXMgYmVlbiBkZXN0cm95ZWRsaWJyYXJ5L3N0ZC9zcmMvdGhyZWFkL21vZC5yc9sREAAdAAAA3QIAAAUAAABmYWlsZWQgdG8gZ2VuZXJhdGUgdW5pcXVlIHRocmVhZCBJRDogYml0c3BhY2UgZXhoYXVzdGVkAAgSEAA3AAAA2xEQAB0AAABWBAAADQAAAFBvaXNvbkVycm9ybGlicmFyeS9zdGQvc3JjL3N5c19jb21tb24vdGhyZWFkX2luZm8ucnNjEhAAKQAAABYAAAAzAAAAbWVtb3J5IGFsbG9jYXRpb24gb2YgIGJ5dGVzIGZhaWxlZAoAnBIQABUAAACxEhAADgAAAGxpYnJhcnkvc3RkL3NyYy9hbGxvYy5yc9ASEAAYAAAAVQEAAAkAAABjYW5ub3QgbW9kaWZ5IHRoZSBwYW5pYyBob29rIGZyb20gYSBwYW5pY2tpbmcgdGhyZWFk+BIQADQAAABsaWJyYXJ5L3N0ZC9zcmMvcGFuaWNraW5nLnJzNBMQABwAAACGAAAACQAAADQTEAAcAAAAPgIAAA8AAAA0ExAAHAAAAD0CAAAPAAAAaAAAAAwAAAAEAAAAaQAAAGIAAAAIAAAABAAAAGoAAABrAAAAEAAAAAQAAABsAAAAbQAAAGIAAAAIAAAABAAAAG4AAABvAAAAYgAAAAAAAAABAAAAcAAAAGNvbmR2YXIgd2FpdCBub3Qgc3VwcG9ydGVkAADYExAAGgAAAGxpYnJhcnkvc3RkL3NyYy9zeXMvd2FzbS8uLi91bnN1cHBvcnRlZC9sb2Nrcy9jb25kdmFyLnJz/BMQADgAAAAWAAAACQAAAGNhbm5vdCByZWN1cnNpdmVseSBhY3F1aXJlIG11dGV4RBQQACAAAABsaWJyYXJ5L3N0ZC9zcmMvc3lzL3dhc20vLi4vdW5zdXBwb3J0ZWQvbG9ja3MvbXV0ZXgucnMAAGwUEAA2AAAAFgAAAAkAAABhc3NlcnRpb24gZmFpbGVkOiBzdGF0ZV9hbmRfcXVldWUuYWRkcigpICYgU1RBVEVfTUFTSyA9PSBSVU5OSU5HT25jZSBpbnN0YW5jZSBoYXMgcHJldmlvdXNseSBiZWVuIHBvaXNvbmVkAAD0FBAAKgAAAAIAAABsaWJyYXJ5L3N0ZC9zcmMvc3lzX2NvbW1vbi9vbmNlL2dlbmVyaWMucnMAACwVEAAqAAAA+AAAAAkAAAAsFRAAKgAAAAUBAAAeAAAAcQAAAAgAAAAEAAAAcgAAAGxpYnJhcnkvc3RkL3NyYy9zeXNfY29tbW9uL3RocmVhZF9wYXJrZXIvZ2VuZXJpYy5ycwCIFRAAMwAAACcAAAAVAAAAaW5jb25zaXN0ZW50IHBhcmsgc3RhdGUAzBUQABcAAACIFRAAMwAAADUAAAAXAAAAcGFyayBzdGF0ZSBjaGFuZ2VkIHVuZXhwZWN0ZWRseQD8FRAAHwAAAIgVEAAzAAAAMgAAABEAAABpbmNvbnNpc3RlbnQgc3RhdGUgaW4gdW5wYXJrNBYQABwAAACIFRAAMwAAAGwAAAASAAAAiBUQADMAAAB6AAAADgAAAEhhc2ggdGFibGUgY2FwYWNpdHkgb3ZlcmZsb3d4FhAAHAAAAC9jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2hhc2hicm93bi0wLjEyLjMvc3JjL3Jhdy9tb2QucnMAnBYQAE8AAABaAAAAKAAAAHMAAAAEAAAABAAAAHQAAAB1AAAAdgAAAGxpYnJhcnkvYWxsb2Mvc3JjL3Jhd192ZWMucnNjYXBhY2l0eSBvdmVyZmxvdwAAADAXEAARAAAAFBcQABwAAAAGAgAABQAAAGEgZm9ybWF0dGluZyB0cmFpdCBpbXBsZW1lbnRhdGlvbiByZXR1cm5lZCBhbiBlcnJvcgBzAAAAAAAAAAEAAAAUAAAAbGlicmFyeS9hbGxvYy9zcmMvZm10LnJzoBcQABgAAABkAgAACQAAAGFzc2VydGlvbiBmYWlsZWQ6IGVkZWx0YSA+PSAwbGlicmFyeS9jb3JlL3NyYy9udW0vZGl5X2Zsb2F0LnJzAADlFxAAIQAAAEwAAAAJAAAA5RcQACEAAABOAAAACQAAAAEAAAAKAAAAZAAAAOgDAAAQJwAAoIYBAEBCDwCAlpgAAOH1BQDKmjsCAAAAFAAAAMgAAADQBwAAIE4AAEANAwCAhB4AAC0xAQDC6wsAlDV3AADBb/KGIwAAAAAAge+shVtBbS3uBABBmLHAAAsTAR9qv2TtOG7tl6fa9Pk/6QNPGABBvLHAAAsmAT6VLgmZ3wP9OBUPL+R0I+z1z9MI3ATE2rDNvBl/M6YDJh/pTgIAQYSywAALoAoBfC6YW4fTvnKf2diHLxUSxlDea3BuSs8P2JXVbnGyJrBmxq0kNhUdWtNCPA5U/2PAc1XMF+/5ZfIovFX3x9yA3O1u9M7v3F/3UwUAbGlicmFyeS9jb3JlL3NyYy9udW0vZmx0MmRlYy9zdHJhdGVneS9kcmFnb24ucnNhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQgPiAwAFAZEAAvAAAAdQAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1pbnVzID4gMAAAAFAZEAAvAAAAdgAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLnBsdXMgPiAwUBkQAC8AAAB3AAAABQAAAGFzc2VydGlvbiBmYWlsZWQ6IGQubWFudC5jaGVja2VkX2FkZChkLnBsdXMpLmlzX3NvbWUoKQAAUBkQAC8AAAB4AAAABQAAAGFzc2VydGlvbiBmYWlsZWQ6IGQubWFudC5jaGVja2VkX3N1YihkLm1pbnVzKS5pc19zb21lKCkAUBkQAC8AAAB5AAAABQAAAGFzc2VydGlvbiBmYWlsZWQ6IGJ1Zi5sZW4oKSA+PSBNQVhfU0lHX0RJR0lUUwAAAFAZEAAvAAAAegAAAAUAAABQGRAALwAAAMEAAAAJAAAAUBkQAC8AAAD5AAAAVAAAAFAZEAAvAAAA+gAAAA0AAABQGRAALwAAAAEBAAAzAAAAUBkQAC8AAAAKAQAABQAAAFAZEAAvAAAACwEAAAUAAABQGRAALwAAAAwBAAAFAAAAUBkQAC8AAAANAQAABQAAAFAZEAAvAAAADgEAAAUAAABQGRAALwAAAEsBAAAfAAAAUBkQAC8AAABlAQAADQAAAFAZEAAvAAAAcQEAACYAAABQGRAALwAAAHYBAABUAAAAUBkQAC8AAACDAQAAMwAAAN9FGj0DzxrmwfvM/gAAAADKxprHF/5wq9z71P4AAAAAT9y8vvyxd//2+9z+AAAAAAzWa0HvkVa+Efzk/gAAAAA8/H+QrR/QjSz87P4AAAAAg5pVMShcUdNG/PT+AAAAALXJpq2PrHGdYfz8/gAAAADLi+4jdyKc6nv8BP8AAAAAbVN4QJFJzK6W/Az/AAAAAFfOtl15EjyCsfwU/wAAAAA3VvtNNpQQwsv8HP8AAAAAT5hIOG/qlpDm/CT/AAAAAMc6giXLhXTXAP0s/wAAAAD0l7+Xzc+GoBv9NP8AAAAA5awqF5gKNO81/Tz/AAAAAI6yNSr7ZziyUP1E/wAAAAA7P8bS39TIhGv9TP8AAAAAus3TGidE3cWF/VT/AAAAAJbJJbvOn2uToP1c/wAAAACEpWJ9JGys27r9ZP8AAAAA9tpfDVhmq6PV/Wz/AAAAACbxw96T+OLz7/10/wAAAAC4gP+qqK21tQr+fP8AAAAAi0p8bAVfYocl/oT/AAAAAFMwwTRg/7zJP/6M/wAAAABVJrqRjIVOllr+lP8AAAAAvX4pcCR3+d90/pz/AAAAAI+45bifvd+mj/6k/wAAAACUfXSIz1+p+Kn+rP8AAAAAz5uoj5NwRLnE/rT/AAAAAGsVD7/48AiK3/68/wAAAAC2MTFlVSWwzfn+xP8AAAAArH970MbiP5kU/8z/AAAAAAY7KyrEEFzkLv/U/wAAAADTknNpmSQkqkn/3P8AAAAADsoAg/K1h/1j/+T/AAAAAOsaEZJkCOW8fv/s/wAAAADMiFBvCcy8jJn/9P8AAAAALGUZ4lgXt9Gz//z/AEGuvMAACwVAnM7/BABBvLzAAAv5BhCl1Ojo/wwAAAAAAAAAYqzF63itAwAUAAAAAACECZT4eDk/gR4AHAAAAAAAsxUHyXvOl8A4ACQAAAAAAHBc6nvOMn6PUwAsAAAAAABogOmrpDjS1W0ANAAAAAAARSKaFyYnT5+IADwAAAAAACf7xNQxomPtogBEAAAAAACorciMOGXesL0ATAAAAAAA22WrGo4Ix4PYAFQAAAAAAJodcUL5HV3E8gBcAAAAAABY5xumLGlNkg0BZAAAAAAA6o1wGmTuAdonAWwAAAAAAEp375qZo22iQgF0AAAAAACFa320e3gJ8lwBfAAAAAAAdxjdeaHkVLR3AYQAAAAAAMLFm1uShluGkgGMAAAAAAA9XZbIxVM1yKwBlAAAAAAAs6CX+ly0KpXHAZwAAAAAAONfoJm9n0be4QGkAAAAAAAljDnbNMKbpfwBrAAAAAAAXJ+Yo3KaxvYWArQAAAAAAM6+6VRTv9y3MQK8AAAAAADiQSLyF/P8iEwCxAAAAAAApXhc05vOIMxmAswAAAAAAN9TIXvzWhaYgQLUAAAAAAA6MB+X3LWg4psC3AAAAAAAlrPjXFPR2ai2AuQAAAAAADxEp6TZfJv70ALsAAAAAAAQRKSnTEx2u+sC9AAAAAAAGpxAtu+Oq4sGA/wAAAAAACyEV6YQ7x/QIAMEAQAAAAApMZHp5aQQmzsDDAEAAAAAnQycofubEOdVAxQBAAAAACn0O2LZICiscAMcAQAAAACFz6d6XktEgIsDJAEAAAAALd2sA0DkIb+lAywBAAAAAI//RF4vnGeOwAM0AQAAAABBuIycnRcz1NoDPAEAAAAAqRvjtJLbGZ71A0QBAAAAANl337puv5brDwRMAQAAAABsaWJyYXJ5L2NvcmUvc3JjL251bS9mbHQyZGVjL3N0cmF0ZWd5L2dyaXN1LnJzAADIIBAALgAAAH0AAAAVAAAAyCAQAC4AAACpAAAABQAAAMggEAAuAAAAqgAAAAUAAADIIBAALgAAAKsAAAAFAAAAyCAQAC4AAACsAAAABQAAAMggEAAuAAAArQAAAAUAAADIIBAALgAAAK4AAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5tYW50ICsgZC5wbHVzIDwgKDEgPDwgNjEpAAAAyCAQAC4AAACvAAAABQAAAMggEAAuAAAACgEAABEAQcDDwAAL6SJhdHRlbXB0IHRvIGRpdmlkZSBieSB6ZXJvAAAAyCAQAC4AAAANAQAACQAAAMggEAAuAAAAFgEAAEIAAADIIBAALgAAAEABAAAJAAAAYXNzZXJ0aW9uIGZhaWxlZDogIWJ1Zi5pc19lbXB0eSgpY2FsbGVkIGBPcHRpb246OnVud3JhcCgpYCBvbiBhIGBOb25lYCB2YWx1ZcggEAAuAAAA3AEAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQgPCAoMSA8PCA2MSnIIBAALgAAAN0BAAAFAAAAyCAQAC4AAADeAQAABQAAAMggEAAuAAAAIwIAABEAAADIIBAALgAAACYCAAAJAAAAyCAQAC4AAABcAgAACQAAAMggEAAuAAAAvAIAAEcAAADIIBAALgAAANMCAABLAAAAyCAQAC4AAADfAgAARwAAAGxpYnJhcnkvY29yZS9zcmMvbnVtL2ZsdDJkZWMvbW9kLnJzAAwjEAAjAAAAvAAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBidWZbMF0gPiBiXCcwXCcAAAAMIxAAIwAAAL0AAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogcGFydHMubGVuKCkgPj0gNAAADCMQACMAAAC+AAAABQAAADAuLi0rMGluZk5hTmFzc2VydGlvbiBmYWlsZWQ6IGJ1Zi5sZW4oKSA+PSBtYXhsZW4AAAAMIxAAIwAAAH8CAAANAAAAKS4uAO0jEAACAAAAQm9ycm93TXV0RXJyb3JpbmRleCBvdXQgb2YgYm91bmRzOiB0aGUgbGVuIGlzICBidXQgdGhlIGluZGV4IGlzIAYkEAAgAAAAJiQQABIAAAA6AAAAyBcQAAAAAABIJBAAAQAAAEgkEAABAAAAcGFuaWNrZWQgYXQgJycsIHAkEAABAAAAcSQQAAMAAAB/AAAAAAAAAAEAAACAAAAAyBcQAAAAAAB/AAAABAAAAAQAAACBAAAAbWF0Y2hlcyE9PT1hc3NlcnRpb24gZmFpbGVkOiBgKGxlZnQgIHJpZ2h0KWAKICBsZWZ0OiBgYCwKIHJpZ2h0OiBgYDogAAAAtyQQABkAAADQJBAAEgAAAOIkEAAMAAAA7iQQAAMAAABgAAAAtyQQABkAAADQJBAAEgAAAOIkEAAMAAAAFCUQAAEAAAA6IAAAyBcQAAAAAAA4JRAAAgAAAH8AAAAMAAAABAAAAIIAAACDAAAAhAAAACAgICAsCiwgLi4KfSwgLi4gfSB7IC4uIH0gfSgKKCwKW11saWJyYXJ5L2NvcmUvc3JjL2ZtdC9udW0ucnMAAACGJRAAGwAAAGUAAAAUAAAAMHgwMDAxMDIwMzA0MDUwNjA3MDgwOTEwMTExMjEzMTQxNTE2MTcxODE5MjAyMTIyMjMyNDI1MjYyNzI4MjkzMDMxMzIzMzM0MzUzNjM3MzgzOTQwNDE0MjQzNDQ0NTQ2NDc0ODQ5NTA1MTUyNTM1NDU1NTY1NzU4NTk2MDYxNjI2MzY0NjU2NjY3Njg2OTcwNzE3MjczNzQ3NTc2Nzc3ODc5ODA4MTgyODM4NDg1ODY4Nzg4ODk5MDkxOTI5Mzk0OTU5Njk3OTg5OQAAfwAAAAQAAAAEAAAAhQAAAIYAAACHAAAAbGlicmFyeS9jb3JlL3NyYy9mbXQvbW9kLnJzAJgmEAAbAAAAQwYAAB4AAAAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwmCYQABsAAAA9BgAALQAAAHRydWVmYWxzZQAAAJgmEAAbAAAAewkAAB4AAACYJhAAGwAAAIIJAAAWAAAAKClsaWJyYXJ5L2NvcmUvc3JjL3NsaWNlL21lbWNoci5ycwAAQicQACAAAABoAAAAJwAAAHJhbmdlIHN0YXJ0IGluZGV4ICBvdXQgb2YgcmFuZ2UgZm9yIHNsaWNlIG9mIGxlbmd0aCB0JxAAEgAAAIYnEAAiAAAAcmFuZ2UgZW5kIGluZGV4ILgnEAAQAAAAhicQACIAAABzbGljZSBpbmRleCBzdGFydHMgYXQgIGJ1dCBlbmRzIGF0IADYJxAAFgAAAO4nEAANAAAAWy4uLl1ieXRlIGluZGV4ICBpcyBvdXQgb2YgYm91bmRzIG9mIGAAABEoEAALAAAAHCgQABYAAAAUJRAAAQAAAGJlZ2luIDw9IGVuZCAoIDw9ICkgd2hlbiBzbGljaW5nIGAAAEwoEAAOAAAAWigQAAQAAABeKBAAEAAAABQlEAABAAAAIGlzIG5vdCBhIGNoYXIgYm91bmRhcnk7IGl0IGlzIGluc2lkZSAgKGJ5dGVzICkgb2YgYBEoEAALAAAAkCgQACYAAAC2KBAACAAAAL4oEAAGAAAAFCUQAAEAAABsaWJyYXJ5L2NvcmUvc3JjL3N0ci9tb2QucnMA7CgQABsAAAAHAQAAHQAAAGxpYnJhcnkvY29yZS9zcmMvdW5pY29kZS9wcmludGFibGUucnMAAAAYKRAAJQAAAAoAAAAcAAAAGCkQACUAAAAaAAAAKAAAAAABAwUFBgYCBwYIBwkRChwLGQwaDRAODA8EEAMSEhMJFgEXBBgBGQMaBxsBHAIfFiADKwMtCy4BMAMxAjIBpwKpAqoEqwj6AvsF/QL+A/8JrXh5i42iMFdYi4yQHN0OD0tM+/wuLz9cXV/ihI2OkZKpsbq7xcbJyt7k5f8ABBESKTE0Nzo7PUlKXYSOkqmxtLq7xsrOz+TlAAQNDhESKTE0OjtFRklKXmRlhJGbncnOzw0RKTo7RUlXW1xeX2RljZGptLq7xcnf5OXwDRFFSWRlgISyvL6/1dfw8YOFi6Smvr/Fx8/a20iYvc3Gzs9JTk9XWV5fiY6Psba3v8HGx9cRFhdbXPb3/v+AbXHe3w4fbm8cHV99fq6vf7u8FhceH0ZHTk9YWlxefn+1xdTV3PDx9XJzj3R1liYuL6evt7/Hz9ffmkCXmDCPH9LUzv9OT1pbBwgPECcv7u9ubzc9P0JFkJFTZ3XIydDR2Nnn/v8AIF8igt8EgkQIGwQGEYGsDoCrBR8JgRsDGQgBBC8ENAQHAwEHBgcRClAPEgdVBwMEHAoJAwgDBwMCAwMDDAQFAwsGAQ4VBU4HGwdXBwIGFwxQBEMDLQMBBBEGDww6BB0lXyBtBGolgMgFgrADGgaC/QNZBxYJGAkUDBQMagYKBhoGWQcrBUYKLAQMBAEDMQssBBoGCwOArAYKBi8xTQOApAg8Aw8DPAc4CCsFgv8RGAgvES0DIQ8hD4CMBIKXGQsViJQFLwU7BwIOGAmAviJ0DIDWGgwFgP8FgN8M8p0DNwmBXBSAuAiAywUKGDsDCgY4CEYIDAZ0Cx4DWgRZCYCDGBwKFglMBICKBqukDBcEMaEEgdomBwwFBYCmEIH1BwEgKgZMBICNBIC+AxsDDw0ABgEBAwEEAgUHBwIICAkCCgULAg4EEAERAhIFExEUARUCFwIZDRwFHQgfASQBagRrAq8DsQK8As8C0QLUDNUJ1gLXAtoB4AXhAucE6ALuIPAE+AL6A/sBDCc7Pk5Pj56en3uLk5aisrqGsQYHCTY9Plbz0NEEFBg2N1ZXf6qur7014BKHiY6eBA0OERIpMTQ6RUZJSk5PZGVctrcbHAcICgsUFzY5Oqip2NkJN5CRqAcKOz5maY+SEW9fv+7vWmL0/P9TVJqbLi8nKFWdoKGjpKeorbq8xAYLDBUdOj9FUaanzM2gBxkaIiU+P+fs7//FxgQgIyUmKDM4OkhKTFBTVVZYWlxeYGNlZmtzeH1/iqSqr7DA0K6vbm++k14iewUDBC0DZgMBLy6Agh0DMQ8cBCQJHgUrBUQEDiqAqgYkBCQEKAg0C05DgTcJFgoIGDtFOQNjCAkwFgUhAxsFAUA4BEsFLwQKBwkHQCAnBAwJNgM6BRoHBAwHUEk3Mw0zBy4ICoEmUksrCCoWGiYcFBcJTgQkCUQNGQcKBkgIJwl1C0I+KgY7BQoGUQYBBRADBYCLYh5ICAqApl4iRQsKBg0TOgYKNiwEF4C5PGRTDEgJCkZFG0gIUw1JBwqA9kYKHQNHSTcDDggKBjkHCoE2GQc7AxxWAQ8yDYObZnULgMSKTGMNhDAQFo+qgkehuYI5ByoEXAYmCkYKKAUTgrBbZUsEOQcRQAULAg6X+AiE1ioJoueBMw8BHQYOBAiBjIkEawUNAwkHEJJgRwl0PID2CnMIcBVGehQMFAxXCRmAh4FHA4VCDxWEUB8GBoDVKwU+IQFwLQMaBAKBQB8ROgUBgdAqguaA9ylMBAoEAoMRREw9gMI8BgEEVQUbNAKBDiwEZAxWCoCuOB0NLAQJBwIOBoCag9gEEQMNA3cEXwYMBAEPDAQ4CAoGKAgiToFUDB0DCQc2CA4ECQcJB4DLJQqEBmxpYnJhcnkvY29yZS9zcmMvdW5pY29kZS91bmljb2RlX2RhdGEucnPcLhAAKAAAAFcAAAA+AAAAbGlicmFyeS9jb3JlL3NyYy9udW0vYmlnbnVtLnJzAAAULxAAHgAAAKwBAAABAAAAYXNzZXJ0aW9uIGZhaWxlZDogbm9ib3Jyb3dhc3NlcnRpb24gZmFpbGVkOiBkaWdpdHMgPCA0MGFzc2VydGlvbiBmYWlsZWQ6IG90aGVyID4gMAAAfwAAAAQAAAAEAAAAiAAAAFRyeUZyb21TbGljZUVycm9yRXJyb3IAAAADAACDBCAAkQVgAF0ToAASFyAfDCBgH+8soCsqMCAsb6bgLAKoYC0e+2AuAP4gNp7/YDb9AeE2AQohNyQN4TerDmE5LxihOTAcYUjzHqFMQDRhUPBqoVFPbyFSnbyhUgDPYVNl0aFTANohVADg4VWu4mFX7OQhWdDooVkgAO5Z8AF/WgBwAAcALQEBAQIBAgEBSAswFRABZQcCBgICAQQjAR4bWws6CQkBGAQBCQEDAQUrAzwIKhgBIDcBAQEECAQBAwcKAh0BOgEBAQIECAEJAQoCGgECAjkBBAIEAgIDAwEeAgMBCwI5AQQFAQIEARQCFgYBAToBAQIBBAgBBwMKAh4BOwEBAQwBCQEoAQMBNwEBAwUDAQQHAgsCHQE6AQIBAgEDAQUCBwILAhwCOQIBAQIECAEJAQoCHQFIAQQBAgMBAQgBUQECBwwIYgECCQsHSQIbAQEBAQE3DgEFAQIFCwEkCQFmBAEGAQICAhkCBAMQBA0BAgIGAQ8BAAMAAx0CHgIeAkACAQcIAQILCQEtAwEBdQIiAXYDBAIJAQYD2wICAToBAQcBAQEBAggGCgIBMB8xBDAHAQEFASgJDAIgBAICAQM4AQECAwEBAzoIAgKYAwENAQcEAQYBAwLGQAABwyEAA40BYCAABmkCAAQBCiACUAIAAQMBBAEZAgUBlwIaEg0BJggZCy4DMAECBAICJwFDBgICAgIMAQgBLwEzAQEDAgIFAgEBKgIIAe4BAgEEAQABABAQEAACAAHiAZUFAAMBAgUEKAMEAaUCAAQAAlADRgsxBHsBNg8pAQICCgMxBAICBwE9AyQFAQg+AQwCNAkKBAIBXwMCAQECBgECAZ0BAwgVAjkCAQEBARYBDgcDBcMIAgMBARcBUQECBgEBAgEBAgEC6wECBAYCAQIbAlUIAgEBAmoBAQECBgEBZQMCBAEFAAkBAvUBCgIBAQQBkAQCAgQBIAooBgIECAEJBgIDLg0BAgAHAQYBAVIWAgcBAgECegYDAQECAQcBAUgCAwEBAQACCwI0BQUBAQEAAQYPAAU7BwABPwRRAQACAC4CFwABAQMEBQgIAgceBJQDADcEMggBDgEWBQEPAAcBEQIHAQIBBWQBoAcAAT0EAAQAB20HAGCA8AAA3C4QACgAAAA/AQAACQB7CXByb2R1Y2VycwIIbGFuZ3VhZ2UBBFJ1c3QADHByb2Nlc3NlZC1ieQMFcnVzdGMdMS42Ni4wICg2OWY5YzMzZDcgMjAyMi0xMi0xMikGd2FscnVzBjAuMTkuMAx3YXNtLWJpbmRnZW4SMC4yLjgzIChlYmE2OTFmMzgp");
var tA;
(function(t) {
  t.Provisioned = "provisioned", t.Cloned = "cloned", t.Stem = "stem";
})(tA || (tA = {}));
var wr;
(function(t) {
  t.Create = "create", t.UseExisting = "use_existing", t.CreateIfNoExists = "create_if_no_exists";
})(wr || (wr = {}));
var mr;
(function(t) {
  t.Enabled = "enabled", t.Disabled = "disabled", t.Running = "running", t.Stopped = "stopped", t.Paused = "paused";
})(mr || (mr = {}));
var nt = 4294967295;
function Xc(t, A, e) {
  var i = Math.floor(e / 4294967296), o = e;
  t.setUint32(A, i), t.setUint32(A + 4, o);
}
function ta(t, A) {
  var e = t.getInt32(A), i = t.getUint32(A + 4);
  return e * 4294967296 + i;
}
function Ah(t, A) {
  var e = t.getUint32(A), i = t.getUint32(A + 4);
  return e * 4294967296 + i;
}
var Co, Bo, Qo, Ki = (typeof process > "u" || ((Co = process == null ? void 0 : process.env) === null || Co === void 0 ? void 0 : Co.TEXT_ENCODING) !== "never") && typeof TextEncoder < "u" && typeof TextDecoder < "u", Ee = Ki ? new TextEncoder() : void 0;
Ki && typeof process < "u" && ((Bo = process == null ? void 0 : process.env) === null || Bo === void 0 || Bo.TEXT_ENCODING);
function th(t, A, e) {
  A.set(Ee.encode(t), e);
}
function eh(t, A, e) {
  Ee.encodeInto(t, A.subarray(e));
}
Ee?.encodeInto;
var ih = 4096;
function ea(t, A, e) {
  for (var i = A, o = i + e, s = [], r = ""; i < o; ) {
    var n = t[i++];
    if (!(n & 128))
      s.push(n);
    else if ((n & 224) === 192) {
      var l = t[i++] & 63;
      s.push((n & 31) << 6 | l);
    } else if ((n & 240) === 224) {
      var l = t[i++] & 63, a = t[i++] & 63;
      s.push((n & 31) << 12 | l << 6 | a);
    } else if ((n & 248) === 240) {
      var l = t[i++] & 63, a = t[i++] & 63, h = t[i++] & 63, g = (n & 7) << 18 | l << 12 | a << 6 | h;
      g > 65535 && (g -= 65536, s.push(g >>> 10 & 1023 | 55296), g = 56320 | g & 1023), s.push(g);
    } else
      s.push(n);
    s.length >= ih && (r += String.fromCharCode.apply(String, s), s.length = 0);
  }
  return s.length > 0 && (r += String.fromCharCode.apply(String, s)), r;
}
var oh = Ki ? new TextDecoder() : null, sh = Ki ? typeof process < "u" && ((Qo = process == null ? void 0 : process.env) === null || Qo === void 0 ? void 0 : Qo.TEXT_DECODER) !== "force" ? 200 : 0 : nt;
function rh(t, A, e) {
  var i = t.subarray(A, A + e);
  return oh.decode(i);
}
var $e = (
  /** @class */
  function() {
    function t(A, e) {
      this.type = A, this.data = e;
    }
    return t;
  }()
), nh = globalThis && globalThis.__extends || function() {
  var t = function(A, e) {
    return t = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, o) {
      i.__proto__ = o;
    } || function(i, o) {
      for (var s in o)
        Object.prototype.hasOwnProperty.call(o, s) && (i[s] = o[s]);
    }, t(A, e);
  };
  return function(A, e) {
    if (typeof e != "function" && e !== null)
      throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    t(A, e);
    function i() {
      this.constructor = A;
    }
    A.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
}(), SA = (
  /** @class */
  function(t) {
    nh(A, t);
    function A(e) {
      var i = t.call(this, e) || this, o = Object.create(A.prototype);
      return Object.setPrototypeOf(i, o), Object.defineProperty(i, "name", {
        configurable: !0,
        enumerable: !1,
        value: A.name
      }), i;
    }
    return A;
  }(Error)
), ah = -1, lh = 4294967296 - 1, gh = 17179869184 - 1;
function Ih(t) {
  var A = t.sec, e = t.nsec;
  if (A >= 0 && e >= 0 && A <= gh)
    if (e === 0 && A <= lh) {
      var i = new Uint8Array(4), o = new DataView(i.buffer);
      return o.setUint32(0, A), i;
    } else {
      var s = A / 4294967296, r = A & 4294967295, i = new Uint8Array(8), o = new DataView(i.buffer);
      return o.setUint32(0, e << 2 | s & 3), o.setUint32(4, r), i;
    }
  else {
    var i = new Uint8Array(12), o = new DataView(i.buffer);
    return o.setUint32(0, e), Xc(o, 4, A), i;
  }
}
function ch(t) {
  var A = t.getTime(), e = Math.floor(A / 1e3), i = (A - e * 1e3) * 1e6, o = Math.floor(i / 1e9);
  return {
    sec: e + o,
    nsec: i - o * 1e9
  };
}
function hh(t) {
  if (t instanceof Date) {
    var A = ch(t);
    return Ih(A);
  } else
    return null;
}
function Ch(t) {
  var A = new DataView(t.buffer, t.byteOffset, t.byteLength);
  switch (t.byteLength) {
    case 4: {
      var e = A.getUint32(0), i = 0;
      return { sec: e, nsec: i };
    }
    case 8: {
      var o = A.getUint32(0), s = A.getUint32(4), e = (o & 3) * 4294967296 + s, i = o >>> 2;
      return { sec: e, nsec: i };
    }
    case 12: {
      var e = ta(A, 4), i = A.getUint32(0);
      return { sec: e, nsec: i };
    }
    default:
      throw new SA("Unrecognized data size for timestamp (expected 4, 8, or 12): ".concat(t.length));
  }
}
function dh(t) {
  var A = Ch(t);
  return new Date(A.sec * 1e3 + A.nsec / 1e6);
}
var Bh = {
  type: ah,
  encode: hh,
  decode: dh
}, Qh = (
  /** @class */
  function() {
    function t() {
      this.builtInEncoders = [], this.builtInDecoders = [], this.encoders = [], this.decoders = [], this.register(Bh);
    }
    return t.prototype.register = function(A) {
      var e = A.type, i = A.encode, o = A.decode;
      if (e >= 0)
        this.encoders[e] = i, this.decoders[e] = o;
      else {
        var s = 1 + e;
        this.builtInEncoders[s] = i, this.builtInDecoders[s] = o;
      }
    }, t.prototype.tryToEncode = function(A, e) {
      for (var i = 0; i < this.builtInEncoders.length; i++) {
        var o = this.builtInEncoders[i];
        if (o != null) {
          var s = o(A, e);
          if (s != null) {
            var r = -1 - i;
            return new $e(r, s);
          }
        }
      }
      for (var i = 0; i < this.encoders.length; i++) {
        var o = this.encoders[i];
        if (o != null) {
          var s = o(A, e);
          if (s != null) {
            var r = i;
            return new $e(r, s);
          }
        }
      }
      return A instanceof $e ? A : null;
    }, t.prototype.decode = function(A, e, i) {
      var o = e < 0 ? this.builtInDecoders[-1 - e] : this.decoders[e];
      return o ? o(A, e, i) : new $e(e, A);
    }, t.defaultCodec = new t(), t;
  }()
);
function Oo(t) {
  return t instanceof Uint8Array ? t : ArrayBuffer.isView(t) ? new Uint8Array(t.buffer, t.byteOffset, t.byteLength) : t instanceof ArrayBuffer ? new Uint8Array(t) : Uint8Array.from(t);
}
function Eh(t) {
  if (t instanceof ArrayBuffer)
    return new DataView(t);
  var A = Oo(t);
  return new DataView(A.buffer, A.byteOffset, A.byteLength);
}
function Eo(t) {
  return "".concat(t < 0 ? "-" : "", "0x").concat(Math.abs(t).toString(16).padStart(2, "0"));
}
var uh = 16, ph = 16, fh = (
  /** @class */
  function() {
    function t(A, e) {
      A === void 0 && (A = uh), e === void 0 && (e = ph), this.maxKeyLength = A, this.maxLengthPerKey = e, this.hit = 0, this.miss = 0, this.caches = [];
      for (var i = 0; i < this.maxKeyLength; i++)
        this.caches.push([]);
    }
    return t.prototype.canBeCached = function(A) {
      return A > 0 && A <= this.maxKeyLength;
    }, t.prototype.find = function(A, e, i) {
      var o = this.caches[i - 1];
      A:
        for (var s = 0, r = o; s < r.length; s++) {
          for (var n = r[s], l = n.bytes, a = 0; a < i; a++)
            if (l[a] !== A[e + a])
              continue A;
          return n.str;
        }
      return null;
    }, t.prototype.store = function(A, e) {
      var i = this.caches[A.length - 1], o = { bytes: A, str: e };
      i.length >= this.maxLengthPerKey ? i[Math.random() * i.length | 0] = o : i.push(o);
    }, t.prototype.decode = function(A, e, i) {
      var o = this.find(A, e, i);
      if (o != null)
        return this.hit++, o;
      this.miss++;
      var s = ea(A, e, i), r = Uint8Array.prototype.slice.call(A, e, e + i);
      return this.store(r, s), s;
    }, t;
  }()
), yh = globalThis && globalThis.__awaiter || function(t, A, e, i) {
  function o(s) {
    return s instanceof e ? s : new e(function(r) {
      r(s);
    });
  }
  return new (e || (e = Promise))(function(s, r) {
    function n(h) {
      try {
        a(i.next(h));
      } catch (g) {
        r(g);
      }
    }
    function l(h) {
      try {
        a(i.throw(h));
      } catch (g) {
        r(g);
      }
    }
    function a(h) {
      h.done ? s(h.value) : o(h.value).then(n, l);
    }
    a((i = i.apply(t, A || [])).next());
  });
}, uo = globalThis && globalThis.__generator || function(t, A) {
  var e = { label: 0, sent: function() {
    if (s[0] & 1)
      throw s[1];
    return s[1];
  }, trys: [], ops: [] }, i, o, s, r;
  return r = { next: n(0), throw: n(1), return: n(2) }, typeof Symbol == "function" && (r[Symbol.iterator] = function() {
    return this;
  }), r;
  function n(a) {
    return function(h) {
      return l([a, h]);
    };
  }
  function l(a) {
    if (i)
      throw new TypeError("Generator is already executing.");
    for (; e; )
      try {
        if (i = 1, o && (s = a[0] & 2 ? o.return : a[0] ? o.throw || ((s = o.return) && s.call(o), 0) : o.next) && !(s = s.call(o, a[1])).done)
          return s;
        switch (o = 0, s && (a = [a[0] & 2, s.value]), a[0]) {
          case 0:
          case 1:
            s = a;
            break;
          case 4:
            return e.label++, { value: a[1], done: !1 };
          case 5:
            e.label++, o = a[1], a = [0];
            continue;
          case 7:
            a = e.ops.pop(), e.trys.pop();
            continue;
          default:
            if (s = e.trys, !(s = s.length > 0 && s[s.length - 1]) && (a[0] === 6 || a[0] === 2)) {
              e = 0;
              continue;
            }
            if (a[0] === 3 && (!s || a[1] > s[0] && a[1] < s[3])) {
              e.label = a[1];
              break;
            }
            if (a[0] === 6 && e.label < s[1]) {
              e.label = s[1], s = a;
              break;
            }
            if (s && e.label < s[2]) {
              e.label = s[2], e.ops.push(a);
              break;
            }
            s[2] && e.ops.pop(), e.trys.pop();
            continue;
        }
        a = A.call(t, e);
      } catch (h) {
        a = [6, h], o = 0;
      } finally {
        i = s = 0;
      }
    if (a[0] & 5)
      throw a[1];
    return { value: a[0] ? a[1] : void 0, done: !0 };
  }
}, vr = globalThis && globalThis.__asyncValues || function(t) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var A = t[Symbol.asyncIterator], e;
  return A ? A.call(t) : (t = typeof __values == "function" ? __values(t) : t[Symbol.iterator](), e = {}, i("next"), i("throw"), i("return"), e[Symbol.asyncIterator] = function() {
    return this;
  }, e);
  function i(s) {
    e[s] = t[s] && function(r) {
      return new Promise(function(n, l) {
        r = t[s](r), o(n, l, r.done, r.value);
      });
    };
  }
  function o(s, r, n, l) {
    Promise.resolve(l).then(function(a) {
      s({ value: a, done: n });
    }, r);
  }
}, Nt = globalThis && globalThis.__await || function(t) {
  return this instanceof Nt ? (this.v = t, this) : new Nt(t);
}, wh = globalThis && globalThis.__asyncGenerator || function(t, A, e) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var i = e.apply(t, A || []), o, s = [];
  return o = {}, r("next"), r("throw"), r("return"), o[Symbol.asyncIterator] = function() {
    return this;
  }, o;
  function r(c) {
    i[c] && (o[c] = function(C) {
      return new Promise(function(B, Q) {
        s.push([c, C, B, Q]) > 1 || n(c, C);
      });
    });
  }
  function n(c, C) {
    try {
      l(i[c](C));
    } catch (B) {
      g(s[0][3], B);
    }
  }
  function l(c) {
    c.value instanceof Nt ? Promise.resolve(c.value.v).then(a, h) : g(s[0][2], c);
  }
  function a(c) {
    n("next", c);
  }
  function h(c) {
    n("throw", c);
  }
  function g(c, C) {
    c(C), s.shift(), s.length && n(s[0][0], s[0][1]);
  }
}, mh = function(t) {
  var A = typeof t;
  return A === "string" || A === "number";
}, re = -1, ws = new DataView(new ArrayBuffer(0)), vh = new Uint8Array(ws.buffer), Ko = function() {
  try {
    ws.getInt8(0);
  } catch (t) {
    return t.constructor;
  }
  throw new Error("never reached");
}(), br = new Ko("Insufficient data"), bh = new fh(), Dh = (
  /** @class */
  function() {
    function t(A, e, i, o, s, r, n, l) {
      A === void 0 && (A = Qh.defaultCodec), e === void 0 && (e = void 0), i === void 0 && (i = nt), o === void 0 && (o = nt), s === void 0 && (s = nt), r === void 0 && (r = nt), n === void 0 && (n = nt), l === void 0 && (l = bh), this.extensionCodec = A, this.context = e, this.maxStrLength = i, this.maxBinLength = o, this.maxArrayLength = s, this.maxMapLength = r, this.maxExtLength = n, this.keyDecoder = l, this.totalPos = 0, this.pos = 0, this.view = ws, this.bytes = vh, this.headByte = re, this.stack = [];
    }
    return t.prototype.reinitializeState = function() {
      this.totalPos = 0, this.headByte = re, this.stack.length = 0;
    }, t.prototype.setBuffer = function(A) {
      this.bytes = Oo(A), this.view = Eh(this.bytes), this.pos = 0;
    }, t.prototype.appendBuffer = function(A) {
      if (this.headByte === re && !this.hasRemaining(1))
        this.setBuffer(A);
      else {
        var e = this.bytes.subarray(this.pos), i = Oo(A), o = new Uint8Array(e.length + i.length);
        o.set(e), o.set(i, e.length), this.setBuffer(o);
      }
    }, t.prototype.hasRemaining = function(A) {
      return this.view.byteLength - this.pos >= A;
    }, t.prototype.createExtraByteError = function(A) {
      var e = this, i = e.view, o = e.pos;
      return new RangeError("Extra ".concat(i.byteLength - o, " of ").concat(i.byteLength, " byte(s) found at buffer[").concat(A, "]"));
    }, t.prototype.decode = function(A) {
      this.reinitializeState(), this.setBuffer(A);
      var e = this.doDecodeSync();
      if (this.hasRemaining(1))
        throw this.createExtraByteError(this.pos);
      return e;
    }, t.prototype.decodeMulti = function(A) {
      return uo(this, function(e) {
        switch (e.label) {
          case 0:
            this.reinitializeState(), this.setBuffer(A), e.label = 1;
          case 1:
            return this.hasRemaining(1) ? [4, this.doDecodeSync()] : [3, 3];
          case 2:
            return e.sent(), [3, 1];
          case 3:
            return [
              2
              /*return*/
            ];
        }
      });
    }, t.prototype.decodeAsync = function(A) {
      var e, i, o, s;
      return yh(this, void 0, void 0, function() {
        var r, n, l, a, h, g, c, C;
        return uo(this, function(B) {
          switch (B.label) {
            case 0:
              r = !1, B.label = 1;
            case 1:
              B.trys.push([1, 6, 7, 12]), e = vr(A), B.label = 2;
            case 2:
              return [4, e.next()];
            case 3:
              if (i = B.sent(), !!i.done)
                return [3, 5];
              if (l = i.value, r)
                throw this.createExtraByteError(this.totalPos);
              this.appendBuffer(l);
              try {
                n = this.doDecodeSync(), r = !0;
              } catch (Q) {
                if (!(Q instanceof Ko))
                  throw Q;
              }
              this.totalPos += this.pos, B.label = 4;
            case 4:
              return [3, 2];
            case 5:
              return [3, 12];
            case 6:
              return a = B.sent(), o = { error: a }, [3, 12];
            case 7:
              return B.trys.push([7, , 10, 11]), i && !i.done && (s = e.return) ? [4, s.call(e)] : [3, 9];
            case 8:
              B.sent(), B.label = 9;
            case 9:
              return [3, 11];
            case 10:
              if (o)
                throw o.error;
              return [
                7
                /*endfinally*/
              ];
            case 11:
              return [
                7
                /*endfinally*/
              ];
            case 12:
              if (r) {
                if (this.hasRemaining(1))
                  throw this.createExtraByteError(this.totalPos);
                return [2, n];
              }
              throw h = this, g = h.headByte, c = h.pos, C = h.totalPos, new RangeError("Insufficient data in parsing ".concat(Eo(g), " at ").concat(C, " (").concat(c, " in the current buffer)"));
          }
        });
      });
    }, t.prototype.decodeArrayStream = function(A) {
      return this.decodeMultiAsync(A, !0);
    }, t.prototype.decodeStream = function(A) {
      return this.decodeMultiAsync(A, !1);
    }, t.prototype.decodeMultiAsync = function(A, e) {
      return wh(this, arguments, function() {
        var o, s, r, n, l, a, h, g, c;
        return uo(this, function(C) {
          switch (C.label) {
            case 0:
              o = e, s = -1, C.label = 1;
            case 1:
              C.trys.push([1, 13, 14, 19]), r = vr(A), C.label = 2;
            case 2:
              return [4, Nt(r.next())];
            case 3:
              if (n = C.sent(), !!n.done)
                return [3, 12];
              if (l = n.value, e && s === 0)
                throw this.createExtraByteError(this.totalPos);
              this.appendBuffer(l), o && (s = this.readArraySize(), o = !1, this.complete()), C.label = 4;
            case 4:
              C.trys.push([4, 9, , 10]), C.label = 5;
            case 5:
              return [4, Nt(this.doDecodeSync())];
            case 6:
              return [4, C.sent()];
            case 7:
              return C.sent(), --s === 0 ? [3, 8] : [3, 5];
            case 8:
              return [3, 10];
            case 9:
              if (a = C.sent(), !(a instanceof Ko))
                throw a;
              return [3, 10];
            case 10:
              this.totalPos += this.pos, C.label = 11;
            case 11:
              return [3, 2];
            case 12:
              return [3, 19];
            case 13:
              return h = C.sent(), g = { error: h }, [3, 19];
            case 14:
              return C.trys.push([14, , 17, 18]), n && !n.done && (c = r.return) ? [4, Nt(c.call(r))] : [3, 16];
            case 15:
              C.sent(), C.label = 16;
            case 16:
              return [3, 18];
            case 17:
              if (g)
                throw g.error;
              return [
                7
                /*endfinally*/
              ];
            case 18:
              return [
                7
                /*endfinally*/
              ];
            case 19:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    }, t.prototype.doDecodeSync = function() {
      A:
        for (; ; ) {
          var A = this.readHeadByte(), e = void 0;
          if (A >= 224)
            e = A - 256;
          else if (A < 192)
            if (A < 128)
              e = A;
            else if (A < 144) {
              var i = A - 128;
              if (i !== 0) {
                this.pushMapState(i), this.complete();
                continue A;
              } else
                e = {};
            } else if (A < 160) {
              var i = A - 144;
              if (i !== 0) {
                this.pushArrayState(i), this.complete();
                continue A;
              } else
                e = [];
            } else {
              var o = A - 160;
              e = this.decodeUtf8String(o, 0);
            }
          else if (A === 192)
            e = null;
          else if (A === 194)
            e = !1;
          else if (A === 195)
            e = !0;
          else if (A === 202)
            e = this.readF32();
          else if (A === 203)
            e = this.readF64();
          else if (A === 204)
            e = this.readU8();
          else if (A === 205)
            e = this.readU16();
          else if (A === 206)
            e = this.readU32();
          else if (A === 207)
            e = this.readU64();
          else if (A === 208)
            e = this.readI8();
          else if (A === 209)
            e = this.readI16();
          else if (A === 210)
            e = this.readI32();
          else if (A === 211)
            e = this.readI64();
          else if (A === 217) {
            var o = this.lookU8();
            e = this.decodeUtf8String(o, 1);
          } else if (A === 218) {
            var o = this.lookU16();
            e = this.decodeUtf8String(o, 2);
          } else if (A === 219) {
            var o = this.lookU32();
            e = this.decodeUtf8String(o, 4);
          } else if (A === 220) {
            var i = this.readU16();
            if (i !== 0) {
              this.pushArrayState(i), this.complete();
              continue A;
            } else
              e = [];
          } else if (A === 221) {
            var i = this.readU32();
            if (i !== 0) {
              this.pushArrayState(i), this.complete();
              continue A;
            } else
              e = [];
          } else if (A === 222) {
            var i = this.readU16();
            if (i !== 0) {
              this.pushMapState(i), this.complete();
              continue A;
            } else
              e = {};
          } else if (A === 223) {
            var i = this.readU32();
            if (i !== 0) {
              this.pushMapState(i), this.complete();
              continue A;
            } else
              e = {};
          } else if (A === 196) {
            var i = this.lookU8();
            e = this.decodeBinary(i, 1);
          } else if (A === 197) {
            var i = this.lookU16();
            e = this.decodeBinary(i, 2);
          } else if (A === 198) {
            var i = this.lookU32();
            e = this.decodeBinary(i, 4);
          } else if (A === 212)
            e = this.decodeExtension(1, 0);
          else if (A === 213)
            e = this.decodeExtension(2, 0);
          else if (A === 214)
            e = this.decodeExtension(4, 0);
          else if (A === 215)
            e = this.decodeExtension(8, 0);
          else if (A === 216)
            e = this.decodeExtension(16, 0);
          else if (A === 199) {
            var i = this.lookU8();
            e = this.decodeExtension(i, 1);
          } else if (A === 200) {
            var i = this.lookU16();
            e = this.decodeExtension(i, 2);
          } else if (A === 201) {
            var i = this.lookU32();
            e = this.decodeExtension(i, 4);
          } else
            throw new SA("Unrecognized type byte: ".concat(Eo(A)));
          this.complete();
          for (var s = this.stack; s.length > 0; ) {
            var r = s[s.length - 1];
            if (r.type === 0)
              if (r.array[r.position] = e, r.position++, r.position === r.size)
                s.pop(), e = r.array;
              else
                continue A;
            else if (r.type === 1) {
              if (!mh(e))
                throw new SA("The type of key must be string or number but " + typeof e);
              if (e === "__proto__")
                throw new SA("The key __proto__ is not allowed");
              r.key = e, r.type = 2;
              continue A;
            } else if (r.map[r.key] = e, r.readCount++, r.readCount === r.size)
              s.pop(), e = r.map;
            else {
              r.key = null, r.type = 1;
              continue A;
            }
          }
          return e;
        }
    }, t.prototype.readHeadByte = function() {
      return this.headByte === re && (this.headByte = this.readU8()), this.headByte;
    }, t.prototype.complete = function() {
      this.headByte = re;
    }, t.prototype.readArraySize = function() {
      var A = this.readHeadByte();
      switch (A) {
        case 220:
          return this.readU16();
        case 221:
          return this.readU32();
        default: {
          if (A < 160)
            return A - 144;
          throw new SA("Unrecognized array type byte: ".concat(Eo(A)));
        }
      }
    }, t.prototype.pushMapState = function(A) {
      if (A > this.maxMapLength)
        throw new SA("Max length exceeded: map length (".concat(A, ") > maxMapLengthLength (").concat(this.maxMapLength, ")"));
      this.stack.push({
        type: 1,
        size: A,
        key: null,
        readCount: 0,
        map: {}
      });
    }, t.prototype.pushArrayState = function(A) {
      if (A > this.maxArrayLength)
        throw new SA("Max length exceeded: array length (".concat(A, ") > maxArrayLength (").concat(this.maxArrayLength, ")"));
      this.stack.push({
        type: 0,
        size: A,
        array: new Array(A),
        position: 0
      });
    }, t.prototype.decodeUtf8String = function(A, e) {
      var i;
      if (A > this.maxStrLength)
        throw new SA("Max length exceeded: UTF-8 byte length (".concat(A, ") > maxStrLength (").concat(this.maxStrLength, ")"));
      if (this.bytes.byteLength < this.pos + e + A)
        throw br;
      var o = this.pos + e, s;
      return this.stateIsMapKey() && (!((i = this.keyDecoder) === null || i === void 0) && i.canBeCached(A)) ? s = this.keyDecoder.decode(this.bytes, o, A) : A > sh ? s = rh(this.bytes, o, A) : s = ea(this.bytes, o, A), this.pos += e + A, s;
    }, t.prototype.stateIsMapKey = function() {
      if (this.stack.length > 0) {
        var A = this.stack[this.stack.length - 1];
        return A.type === 1;
      }
      return !1;
    }, t.prototype.decodeBinary = function(A, e) {
      if (A > this.maxBinLength)
        throw new SA("Max length exceeded: bin length (".concat(A, ") > maxBinLength (").concat(this.maxBinLength, ")"));
      if (!this.hasRemaining(A + e))
        throw br;
      var i = this.pos + e, o = this.bytes.subarray(i, i + A);
      return this.pos += e + A, o;
    }, t.prototype.decodeExtension = function(A, e) {
      if (A > this.maxExtLength)
        throw new SA("Max length exceeded: ext length (".concat(A, ") > maxExtLength (").concat(this.maxExtLength, ")"));
      var i = this.view.getInt8(this.pos + e), o = this.decodeBinary(
        A,
        e + 1
        /* extType */
      );
      return this.extensionCodec.decode(o, i, this.context);
    }, t.prototype.lookU8 = function() {
      return this.view.getUint8(this.pos);
    }, t.prototype.lookU16 = function() {
      return this.view.getUint16(this.pos);
    }, t.prototype.lookU32 = function() {
      return this.view.getUint32(this.pos);
    }, t.prototype.readU8 = function() {
      var A = this.view.getUint8(this.pos);
      return this.pos++, A;
    }, t.prototype.readI8 = function() {
      var A = this.view.getInt8(this.pos);
      return this.pos++, A;
    }, t.prototype.readU16 = function() {
      var A = this.view.getUint16(this.pos);
      return this.pos += 2, A;
    }, t.prototype.readI16 = function() {
      var A = this.view.getInt16(this.pos);
      return this.pos += 2, A;
    }, t.prototype.readU32 = function() {
      var A = this.view.getUint32(this.pos);
      return this.pos += 4, A;
    }, t.prototype.readI32 = function() {
      var A = this.view.getInt32(this.pos);
      return this.pos += 4, A;
    }, t.prototype.readU64 = function() {
      var A = Ah(this.view, this.pos);
      return this.pos += 8, A;
    }, t.prototype.readI64 = function() {
      var A = ta(this.view, this.pos);
      return this.pos += 8, A;
    }, t.prototype.readF32 = function() {
      var A = this.view.getFloat32(this.pos);
      return this.pos += 4, A;
    }, t.prototype.readF64 = function() {
      var A = this.view.getFloat64(this.pos);
      return this.pos += 8, A;
    }, t;
  }()
), kh = {};
function Sh(t, A) {
  A === void 0 && (A = kh);
  var e = new Dh(A.extensionCodec, A.context, A.maxStrLength, A.maxBinLength, A.maxArrayLength, A.maxMapLength, A.maxExtLength);
  return e.decode(t);
}
var xh = Object.defineProperty, Nh = (t, A) => {
  for (var e in A)
    xh(t, e, { get: A[e], enumerable: !0 });
}, Uh = {};
Nh(Uh, { convertFileSrc: () => Rh, invoke: () => Gh, transformCallback: () => $o });
function Fh() {
  return window.crypto.getRandomValues(new Uint32Array(1))[0];
}
function $o(t, A = !1) {
  let e = Fh(), i = `_${e}`;
  return Object.defineProperty(window, i, { value: (o) => (A && Reflect.deleteProperty(window, i), t?.(o)), writable: !1, configurable: !0 }), e;
}
async function Gh(t, A = {}) {
  return new Promise((e, i) => {
    let o = $o((r) => {
      e(r), Reflect.deleteProperty(window, `_${s}`);
    }, !0), s = $o((r) => {
      i(r), Reflect.deleteProperty(window, `_${o}`);
    }, !0);
    window.__TAURI_IPC__({ cmd: t, callback: o, error: s, ...A });
  });
}
function Rh(t, A = "asset") {
  let e = encodeURIComponent(t);
  return navigator.userAgent.includes("Windows") ? `https://${A}.localhost/${e}` : `${A}://localhost/${e}`;
}
/*! noble-ed25519 - MIT License (c) 2019 Paul Miller (paulmillr.com) */
const X = 2n ** 255n - 19n, si = 2n ** 252n + 27742317777372353535851937790883648493n, qo = 0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51an, Po = 0x6666666666666666666666666666666666666666666666666666666666666658n, qe = {
  a: -1n,
  d: 37095705934669439343138083508754565189542113879843219016388785533085940283555n,
  p: X,
  n: si,
  h: 8,
  Gx: qo,
  Gy: Po
  // field prime, curve (group) order, cofactor
}, CA = (t = "") => {
  throw new Error(t);
}, ia = (t) => typeof t == "string", oa = (t, A) => (
  // is Uint8Array (of specific length)
  !(t instanceof Uint8Array) || typeof A == "number" && A > 0 && t.length !== A ? CA("Uint8Array expected") : t
), ms = (t) => new Uint8Array(t), Mh = (t, A) => oa(ia(t) ? na(t) : ms(t), A), m = (t, A = X) => {
  let e = t % A;
  return e >= 0n ? e : A + e;
}, Dr = (t) => t instanceof dA ? t : CA("Point expected");
let kr;
class dA {
  constructor(A, e, i, o) {
    this.ex = A, this.ey = e, this.ez = i, this.et = o;
  }
  static fromAffine(A) {
    return new dA(A.x, A.y, 1n, m(A.x * A.y));
  }
  static fromHex(A, e = !0) {
    const { d: i } = qe;
    A = Mh(A, 32);
    const o = A.slice();
    o[31] = A[31] & -129;
    const s = Lh(o);
    s === 0n || (e && !(0n < s && s < X) && CA("bad y coord 1"), !e && !(0n < s && s < 2n ** 256n) && CA("bad y coord 2"));
    const r = m(s * s), n = m(r - 1n), l = m(i * r + 1n);
    let { isValid: a, value: h } = Hh(n, l);
    a || CA("bad y coordinate 3");
    const g = (h & 1n) === 1n;
    return (A[31] & 128) !== 0 !== g && (h = m(-h)), new dA(h, s, 1n, m(h * s));
  }
  get x() {
    return this.toAffine().x;
  }
  // .x, .y will call expensive toAffine.
  get y() {
    return this.toAffine().y;
  }
  // Should be used with care.
  equals(A) {
    const { ex: e, ey: i, ez: o } = this, { ex: s, ey: r, ez: n } = Dr(A), l = m(e * n), a = m(s * o), h = m(i * n), g = m(r * o);
    return l === a && h === g;
  }
  is0() {
    return this.equals(ri);
  }
  negate() {
    return new dA(m(-this.ex), this.ey, this.ez, m(-this.et));
  }
  double() {
    const { ex: A, ey: e, ez: i } = this, { a: o } = qe, s = m(A * A), r = m(e * e), n = m(2n * m(i * i)), l = m(o * s), a = A + e, h = m(m(a * a) - s - r), g = l + r, c = g - n, C = l - r, B = m(h * c), Q = m(g * C), E = m(h * C), f = m(c * g);
    return new dA(B, Q, f, E);
  }
  add(A) {
    const { ex: e, ey: i, ez: o, et: s } = this, { ex: r, ey: n, ez: l, et: a } = Dr(A), { a: h, d: g } = qe, c = m(e * r), C = m(i * n), B = m(s * g * a), Q = m(o * l), E = m((e + i) * (r + n) - c - C), f = m(Q - B), w = m(Q + B), v = m(C - h * c), x = m(E * f), N = m(w * v), R = m(E * v), M = m(f * w);
    return new dA(x, N, M, R);
  }
  mul(A, e = !0) {
    if (A === 0n)
      return e === !0 ? CA("cannot multiply by 0") : ri;
    if (typeof A == "bigint" && 0n < A && A < si || CA("invalid scalar, must be < L"), !e && this.is0() || A === 1n)
      return this;
    if (this.equals(Qi))
      return Oh(A).p;
    let i = ri, o = Qi;
    for (let s = this; A > 0n; s = s.double(), A >>= 1n)
      A & 1n ? i = i.add(s) : e && (o = o.add(s));
    return i;
  }
  multiply(A) {
    return this.mul(A);
  }
  // Aliases for compatibilty
  clearCofactor() {
    return this.mul(BigInt(qe.h), !1);
  }
  // multiply by cofactor
  isSmallOrder() {
    return this.clearCofactor().is0();
  }
  // check if P is small order
  isTorsionFree() {
    let A = this.mul(si / 2n, !1).double();
    return si % 2n && (A = A.add(this)), A.is0();
  }
  toAffine() {
    const { ex: A, ey: e, ez: i } = this;
    if (this.is0())
      return { x: 0n, y: 0n };
    const o = Jh(i);
    return m(i * o) !== 1n && CA("invalid inverse"), { x: m(A * o), y: m(e * o) };
  }
  toRawBytes() {
    const { x: A, y: e } = this.toAffine(), i = _h(e);
    return i[31] |= A & 1n ? 128 : 0, i;
  }
  toHex() {
    return ra(this.toRawBytes());
  }
  // encode to hex string
}
dA.BASE = new dA(qo, Po, 1n, m(qo * Po));
dA.ZERO = new dA(0n, 1n, 1n, 0n);
const { BASE: Qi, ZERO: ri } = dA, sa = (t, A) => t.toString(16).padStart(A, "0"), ra = (t) => Array.from(t).map((A) => sa(A, 2)).join(""), na = (t) => {
  const A = t.length;
  (!ia(t) || A % 2) && CA("hex invalid 1");
  const e = ms(A / 2);
  for (let i = 0; i < e.length; i++) {
    const o = i * 2, s = t.slice(o, o + 2), r = Number.parseInt(s, 16);
    (Number.isNaN(r) || r < 0) && CA("hex invalid 2"), e[i] = r;
  }
  return e;
}, _h = (t) => na(sa(t, 32 * 2)).reverse(), Lh = (t) => BigInt("0x" + ra(ms(oa(t)).reverse())), Jh = (t, A = X) => {
  (t === 0n || A <= 0n) && CA("no inverse n=" + t + " mod=" + A);
  let e = m(t, A), i = A, o = 0n, s = 1n;
  for (; e !== 0n; ) {
    const r = i / e, n = i % e, l = o - s * r;
    i = e, e = n, o = s, s = l;
  }
  return i === 1n ? m(o, A) : CA("no inverse");
}, DA = (t, A) => {
  let e = t;
  for (; A-- > 0n; )
    e *= e, e %= X;
  return e;
}, Yh = (t) => {
  const e = t * t % X * t % X, i = DA(e, 2n) * e % X, o = DA(i, 1n) * t % X, s = DA(o, 5n) * o % X, r = DA(s, 10n) * s % X, n = DA(r, 20n) * r % X, l = DA(n, 40n) * n % X, a = DA(l, 80n) * l % X, h = DA(a, 80n) * l % X, g = DA(h, 10n) * s % X;
  return { pow_p_5_8: DA(g, 2n) * t % X, b2: e };
}, Sr = 19681161376707505956807079304988542015446066515923890162744021073123829784752n, Hh = (t, A) => {
  const e = m(A * A * A), i = m(e * e * A), o = Yh(t * i).pow_p_5_8;
  let s = m(t * e * o);
  const r = m(A * s * s), n = s, l = m(s * Sr), a = r === t, h = r === m(-t), g = r === m(-t * Sr);
  return a && (s = n), (h || g) && (s = l), (m(s) & 1n) === 1n && (s = m(-s)), { isValid: a || h, value: s };
}, at = 8, Th = () => {
  const t = [], A = 256 / at + 1;
  let e = Qi, i = e;
  for (let o = 0; o < A; o++) {
    i = e, t.push(i);
    for (let s = 1; s < 2 ** (at - 1); s++)
      i = i.add(e), t.push(i);
    e = i.double();
  }
  return t;
}, Oh = (t) => {
  const A = kr || (kr = Th()), e = (h, g) => {
    let c = g.negate();
    return h ? c : g;
  };
  let i = ri, o = Qi;
  const s = 1 + 256 / at, r = 2 ** (at - 1), n = BigInt(2 ** at - 1), l = 2 ** at, a = BigInt(at);
  for (let h = 0; h < s; h++) {
    const g = h * r;
    let c = Number(t & n);
    t >>= a, c > r && (c -= l, t += 1n);
    const C = g, B = g + Math.abs(c) - 1, Q = h % 2 !== 0, E = c < 0;
    c === 0 ? o = o.add(e(Q, A[C])) : i = i.add(e(E, A[B]));
  }
  return { p: i, f: o };
}, aa = "3.7.5", Kh = aa, $h = typeof atob == "function", qh = typeof btoa == "function", jt = typeof Buffer == "function", xr = typeof TextDecoder == "function" ? new TextDecoder() : void 0, Nr = typeof TextEncoder == "function" ? new TextEncoder() : void 0, Ph = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", Ce = Array.prototype.slice.call(Ph), Pe = ((t) => {
  let A = {};
  return t.forEach((e, i) => A[e] = i), A;
})(Ce), zh = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/, AA = String.fromCharCode.bind(String), Ur = typeof Uint8Array.from == "function" ? Uint8Array.from.bind(Uint8Array) : (t) => new Uint8Array(Array.prototype.slice.call(t, 0)), la = (t) => t.replace(/=/g, "").replace(/[+\/]/g, (A) => A == "+" ? "-" : "_"), ga = (t) => t.replace(/[^A-Za-z0-9\+\/]/g, ""), Ia = (t) => {
  let A, e, i, o, s = "";
  const r = t.length % 3;
  for (let n = 0; n < t.length; ) {
    if ((e = t.charCodeAt(n++)) > 255 || (i = t.charCodeAt(n++)) > 255 || (o = t.charCodeAt(n++)) > 255)
      throw new TypeError("invalid character found");
    A = e << 16 | i << 8 | o, s += Ce[A >> 18 & 63] + Ce[A >> 12 & 63] + Ce[A >> 6 & 63] + Ce[A & 63];
  }
  return r ? s.slice(0, r - 3) + "===".substring(r) : s;
}, vs = qh ? (t) => btoa(t) : jt ? (t) => Buffer.from(t, "binary").toString("base64") : Ia, zo = jt ? (t) => Buffer.from(t).toString("base64") : (t) => {
  let e = [];
  for (let i = 0, o = t.length; i < o; i += 4096)
    e.push(AA.apply(null, t.subarray(i, i + 4096)));
  return vs(e.join(""));
}, ni = (t, A = !1) => A ? la(zo(t)) : zo(t), Vh = (t) => {
  if (t.length < 2) {
    var A = t.charCodeAt(0);
    return A < 128 ? t : A < 2048 ? AA(192 | A >>> 6) + AA(128 | A & 63) : AA(224 | A >>> 12 & 15) + AA(128 | A >>> 6 & 63) + AA(128 | A & 63);
  } else {
    var A = 65536 + (t.charCodeAt(0) - 55296) * 1024 + (t.charCodeAt(1) - 56320);
    return AA(240 | A >>> 18 & 7) + AA(128 | A >>> 12 & 63) + AA(128 | A >>> 6 & 63) + AA(128 | A & 63);
  }
}, jh = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, ca = (t) => t.replace(jh, Vh), Fr = jt ? (t) => Buffer.from(t, "utf8").toString("base64") : Nr ? (t) => zo(Nr.encode(t)) : (t) => vs(ca(t)), Ut = (t, A = !1) => A ? la(Fr(t)) : Fr(t), Gr = (t) => Ut(t, !0), Zh = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g, Wh = (t) => {
  switch (t.length) {
    case 4:
      var A = (7 & t.charCodeAt(0)) << 18 | (63 & t.charCodeAt(1)) << 12 | (63 & t.charCodeAt(2)) << 6 | 63 & t.charCodeAt(3), e = A - 65536;
      return AA((e >>> 10) + 55296) + AA((e & 1023) + 56320);
    case 3:
      return AA((15 & t.charCodeAt(0)) << 12 | (63 & t.charCodeAt(1)) << 6 | 63 & t.charCodeAt(2));
    default:
      return AA((31 & t.charCodeAt(0)) << 6 | 63 & t.charCodeAt(1));
  }
}, ha = (t) => t.replace(Zh, Wh), Ca = (t) => {
  if (t = t.replace(/\s+/g, ""), !zh.test(t))
    throw new TypeError("malformed base64.");
  t += "==".slice(2 - (t.length & 3));
  let A, e = "", i, o;
  for (let s = 0; s < t.length; )
    A = Pe[t.charAt(s++)] << 18 | Pe[t.charAt(s++)] << 12 | (i = Pe[t.charAt(s++)]) << 6 | (o = Pe[t.charAt(s++)]), e += i === 64 ? AA(A >> 16 & 255) : o === 64 ? AA(A >> 16 & 255, A >> 8 & 255) : AA(A >> 16 & 255, A >> 8 & 255, A & 255);
  return e;
}, bs = $h ? (t) => atob(ga(t)) : jt ? (t) => Buffer.from(t, "base64").toString("binary") : Ca, da = jt ? (t) => Ur(Buffer.from(t, "base64")) : (t) => Ur(bs(t).split("").map((A) => A.charCodeAt(0))), Ba = (t) => da(Qa(t)), Xh = jt ? (t) => Buffer.from(t, "base64").toString("utf8") : xr ? (t) => xr.decode(da(t)) : (t) => ha(bs(t)), Qa = (t) => ga(t.replace(/[-_]/g, (A) => A == "-" ? "+" : "/")), Vo = (t) => Xh(Qa(t)), AC = (t) => {
  if (typeof t != "string")
    return !1;
  const A = t.replace(/\s+/g, "").replace(/={0,2}$/, "");
  return !/[^\s0-9a-zA-Z\+/]/.test(A) || !/[^\s0-9a-zA-Z\-_]/.test(A);
}, Ea = (t) => ({
  value: t,
  enumerable: !1,
  writable: !0,
  configurable: !0
}), ua = function() {
  const t = (A, e) => Object.defineProperty(String.prototype, A, Ea(e));
  t("fromBase64", function() {
    return Vo(this);
  }), t("toBase64", function(A) {
    return Ut(this, A);
  }), t("toBase64URI", function() {
    return Ut(this, !0);
  }), t("toBase64URL", function() {
    return Ut(this, !0);
  }), t("toUint8Array", function() {
    return Ba(this);
  });
}, pa = function() {
  const t = (A, e) => Object.defineProperty(Uint8Array.prototype, A, Ea(e));
  t("toBase64", function(A) {
    return ni(this, A);
  }), t("toBase64URI", function() {
    return ni(this, !0);
  }), t("toBase64URL", function() {
    return ni(this, !0);
  });
}, tC = () => {
  ua(), pa();
}, fa = {
  version: aa,
  VERSION: Kh,
  atob: bs,
  atobPolyfill: Ca,
  btoa: vs,
  btoaPolyfill: Ia,
  fromBase64: Vo,
  toBase64: Ut,
  encode: Ut,
  encodeURI: Gr,
  encodeURL: Gr,
  utob: ca,
  btou: ha,
  decode: Vo,
  isValid: AC,
  fromUint8Array: ni,
  toUint8Array: Ba,
  extendString: ua,
  extendUint8Array: pa,
  extendBuiltins: tC
};
function ai(t) {
  return fa.toUint8Array(t.slice(1));
}
function kt(t) {
  return `u${fa.fromUint8Array(t, !0)}`;
}
globalThis.crypto || import("./__vite-browser-external-2447137e.js").then((t) => globalThis.crypto = t);
var Rr;
(function(t) {
  t.All = "All", t.Listed = "Listed";
})(Rr || (Rr = {}));
const KA = /* @__PURE__ */ new WeakMap(), ot = /* @__PURE__ */ new WeakMap(), YA = /* @__PURE__ */ new WeakMap(), Ei = Symbol("anyProducer"), Mr = Promise.resolve(), ui = Symbol("listenerAdded"), pi = Symbol("listenerRemoved");
let fi = !1, po = !1;
function yt(t) {
  if (typeof t != "string" && typeof t != "symbol" && typeof t != "number")
    throw new TypeError("`eventName` must be a string, symbol, or number");
}
function ze(t) {
  if (typeof t != "function")
    throw new TypeError("listener must be a function");
}
function wt(t, A) {
  const e = ot.get(t);
  if (e.has(A))
    return e.get(A);
}
function ue(t, A) {
  const e = typeof A == "string" || typeof A == "symbol" || typeof A == "number" ? A : Ei, i = YA.get(t);
  if (i.has(e))
    return i.get(e);
}
function eC(t, A, e) {
  const i = YA.get(t);
  if (i.has(A))
    for (const o of i.get(A))
      o.enqueue(e);
  if (i.has(Ei)) {
    const o = Promise.all([A, e]);
    for (const s of i.get(Ei))
      s.enqueue(o);
  }
}
function _r(t, A) {
  A = Array.isArray(A) ? A : [A];
  let e = !1, i = () => {
  }, o = [];
  const s = {
    enqueue(r) {
      o.push(r), i();
    },
    finish() {
      e = !0, i();
    }
  };
  for (const r of A) {
    let n = ue(t, r);
    n || (n = /* @__PURE__ */ new Set(), YA.get(t).set(r, n)), n.add(s);
  }
  return {
    async next() {
      return o ? o.length === 0 ? e ? (o = void 0, this.next()) : (await new Promise((r) => {
        i = r;
      }), this.next()) : {
        done: !1,
        value: await o.shift()
      } : { done: !0 };
    },
    async return(r) {
      o = void 0;
      for (const n of A) {
        const l = ue(t, n);
        l && (l.delete(s), l.size === 0 && YA.get(t).delete(n));
      }
      return i(), arguments.length > 0 ? { done: !0, value: await r } : { done: !0 };
    },
    [Symbol.asyncIterator]() {
      return this;
    }
  };
}
function Lr(t) {
  if (t === void 0)
    return Jr;
  if (!Array.isArray(t))
    throw new TypeError("`methodNames` must be an array of strings");
  for (const A of t)
    if (!Jr.includes(A))
      throw typeof A != "string" ? new TypeError("`methodNames` element must be a string") : new Error(`${A} is not Emittery method`);
  return t;
}
const bt = (t) => t === ui || t === pi;
function Ve(t, A, e) {
  if (bt(A))
    try {
      fi = !0, t.emit(A, e);
    } finally {
      fi = !1;
    }
}
class Yt {
  static mixin(A, e) {
    return e = Lr(e), (i) => {
      if (typeof i != "function")
        throw new TypeError("`target` must be function");
      for (const r of e)
        if (i.prototype[r] !== void 0)
          throw new Error(`The property \`${r}\` already exists on \`target\``);
      function o() {
        return Object.defineProperty(this, A, {
          enumerable: !1,
          value: new Yt()
        }), this[A];
      }
      Object.defineProperty(i.prototype, A, {
        enumerable: !1,
        get: o
      });
      const s = (r) => function(...n) {
        return this[A][r](...n);
      };
      for (const r of e)
        Object.defineProperty(i.prototype, r, {
          enumerable: !1,
          value: s(r)
        });
      return i;
    };
  }
  static get isDebugEnabled() {
    if (typeof globalThis.process?.env != "object")
      return po;
    const { env: A } = globalThis.process ?? { env: {} };
    return A.DEBUG === "emittery" || A.DEBUG === "*" || po;
  }
  static set isDebugEnabled(A) {
    po = A;
  }
  constructor(A = {}) {
    KA.set(this, /* @__PURE__ */ new Set()), ot.set(this, /* @__PURE__ */ new Map()), YA.set(this, /* @__PURE__ */ new Map()), YA.get(this).set(Ei, /* @__PURE__ */ new Set()), this.debug = A.debug ?? {}, this.debug.enabled === void 0 && (this.debug.enabled = !1), this.debug.logger || (this.debug.logger = (e, i, o, s) => {
      try {
        s = JSON.stringify(s);
      } catch {
        s = `Object with the following keys failed to stringify: ${Object.keys(s).join(",")}`;
      }
      (typeof o == "symbol" || typeof o == "number") && (o = o.toString());
      const r = /* @__PURE__ */ new Date(), n = `${r.getHours()}:${r.getMinutes()}:${r.getSeconds()}.${r.getMilliseconds()}`;
      console.log(`[${n}][emittery:${e}][${i}] Event Name: ${o}
	data: ${s}`);
    });
  }
  logIfDebugEnabled(A, e, i) {
    (Yt.isDebugEnabled || this.debug.enabled) && this.debug.logger(A, this.debug.name, e, i);
  }
  on(A, e) {
    ze(e), A = Array.isArray(A) ? A : [A];
    for (const i of A) {
      yt(i);
      let o = wt(this, i);
      o || (o = /* @__PURE__ */ new Set(), ot.get(this).set(i, o)), o.add(e), this.logIfDebugEnabled("subscribe", i, void 0), bt(i) || Ve(this, ui, { eventName: i, listener: e });
    }
    return this.off.bind(this, A, e);
  }
  off(A, e) {
    ze(e), A = Array.isArray(A) ? A : [A];
    for (const i of A) {
      yt(i);
      const o = wt(this, i);
      o && (o.delete(e), o.size === 0 && ot.get(this).delete(i)), this.logIfDebugEnabled("unsubscribe", i, void 0), bt(i) || Ve(this, pi, { eventName: i, listener: e });
    }
  }
  once(A) {
    let e;
    const i = new Promise((o) => {
      e = this.on(A, (s) => {
        e(), o(s);
      });
    });
    return i.off = e, i;
  }
  events(A) {
    A = Array.isArray(A) ? A : [A];
    for (const e of A)
      yt(e);
    return _r(this, A);
  }
  async emit(A, e) {
    if (yt(A), bt(A) && !fi)
      throw new TypeError("`eventName` cannot be meta event `listenerAdded` or `listenerRemoved`");
    this.logIfDebugEnabled("emit", A, e), eC(this, A, e);
    const i = wt(this, A) ?? /* @__PURE__ */ new Set(), o = KA.get(this), s = [...i], r = bt(A) ? [] : [...o];
    await Mr, await Promise.all([
      ...s.map(async (n) => {
        if (i.has(n))
          return n(e);
      }),
      ...r.map(async (n) => {
        if (o.has(n))
          return n(A, e);
      })
    ]);
  }
  async emitSerial(A, e) {
    if (yt(A), bt(A) && !fi)
      throw new TypeError("`eventName` cannot be meta event `listenerAdded` or `listenerRemoved`");
    this.logIfDebugEnabled("emitSerial", A, e);
    const i = wt(this, A) ?? /* @__PURE__ */ new Set(), o = KA.get(this), s = [...i], r = [...o];
    await Mr;
    for (const n of s)
      i.has(n) && await n(e);
    for (const n of r)
      o.has(n) && await n(A, e);
  }
  onAny(A) {
    return ze(A), this.logIfDebugEnabled("subscribeAny", void 0, void 0), KA.get(this).add(A), Ve(this, ui, { listener: A }), this.offAny.bind(this, A);
  }
  anyEvent() {
    return _r(this);
  }
  offAny(A) {
    ze(A), this.logIfDebugEnabled("unsubscribeAny", void 0, void 0), Ve(this, pi, { listener: A }), KA.get(this).delete(A);
  }
  clearListeners(A) {
    A = Array.isArray(A) ? A : [A];
    for (const e of A)
      if (this.logIfDebugEnabled("clear", e, void 0), typeof e == "string" || typeof e == "symbol" || typeof e == "number") {
        const i = wt(this, e);
        i && i.clear();
        const o = ue(this, e);
        if (o) {
          for (const s of o)
            s.finish();
          o.clear();
        }
      } else {
        KA.get(this).clear();
        for (const [i, o] of ot.get(this).entries())
          o.clear(), ot.get(this).delete(i);
        for (const [i, o] of YA.get(this).entries()) {
          for (const s of o)
            s.finish();
          o.clear(), YA.get(this).delete(i);
        }
      }
  }
  listenerCount(A) {
    A = Array.isArray(A) ? A : [A];
    let e = 0;
    for (const i of A) {
      if (typeof i == "string") {
        e += KA.get(this).size + (wt(this, i)?.size ?? 0) + (ue(this, i)?.size ?? 0) + (ue(this)?.size ?? 0);
        continue;
      }
      typeof i < "u" && yt(i), e += KA.get(this).size;
      for (const o of ot.get(this).values())
        e += o.size;
      for (const o of YA.get(this).values())
        e += o.size;
    }
    return e;
  }
  bindMethods(A, e) {
    if (typeof A != "object" || A === null)
      throw new TypeError("`target` must be an object");
    e = Lr(e);
    for (const i of e) {
      if (A[i] !== void 0)
        throw new Error(`The property \`${i}\` already exists on \`target\``);
      Object.defineProperty(A, i, {
        enumerable: !1,
        value: this[i].bind(this)
      });
    }
  }
}
const Jr = Object.getOwnPropertyNames(Yt.prototype).filter((t) => t !== "constructor");
Object.defineProperty(Yt, "listenerAdded", {
  value: ui,
  writable: !1,
  enumerable: !0,
  configurable: !1
});
Object.defineProperty(Yt, "listenerRemoved", {
  value: pi,
  writable: !1,
  enumerable: !0,
  configurable: !1
});
var Yr;
(function(t) {
  t.Dna = "Dna", t.AgentValidationPkg = "AgentValidationPkg", t.InitZomesComplete = "InitZomesComplete", t.CreateLink = "CreateLink", t.DeleteLink = "DeleteLink", t.OpenChain = "OpenChain", t.CloseChain = "CloseChain", t.Create = "Create", t.Update = "Update", t.Delete = "Delete";
})(Yr || (Yr = {}));
var Hr;
(function(t) {
  t.StoreRecord = "StoreRecord", t.StoreEntry = "StoreEntry", t.RegisterAgentActivity = "RegisterAgentActivity", t.RegisterUpdatedContent = "RegisterUpdatedContent", t.RegisterUpdatedRecord = "RegisterUpdatedRecord", t.RegisterDeletedBy = "RegisterDeletedBy", t.RegisterDeletedEntryAction = "RegisterDeletedEntryAction", t.RegisterAddLink = "RegisterAddLink", t.RegisterRemoveLink = "RegisterRemoveLink";
})(Hr || (Hr = {}));
var Tr;
(function(t) {
  t[t.AGENT = 0] = "AGENT", t[t.ENTRY = 1] = "ENTRY", t[t.DHTOP = 2] = "DHTOP", t[t.ACTION = 3] = "ACTION", t[t.DNA = 4] = "DNA";
})(Tr || (Tr = {}));
function iC(t, A) {
  for (const [e, i] of Object.entries(t.cell_info))
    for (const o of i)
      if (tA.Provisioned in o) {
        if (o[tA.Provisioned].cell_id.toString() === A.toString())
          return e;
      } else if (tA.Cloned in o)
        return o[tA.Cloned].clone_id ? o[tA.Cloned].clone_id : e;
}
async function oC(t, A, e) {
  const i = await t.appInfo(), o = iC(i, e.cell_id);
  return A === o;
}
class ya {
  constructor(A, e, i) {
    this.client = A, this.roleName = e, this.zomeName = i;
  }
  onSignal(A) {
    return this.client.on("signal", async (e) => {
      await oC(this.client, this.roleName, e) && this.zomeName === e.zome_name && A(e.payload);
    });
  }
  callZome(A, e) {
    const i = {
      role_name: this.roleName,
      zome_name: this.zomeName,
      fn_name: A,
      payload: e
    };
    return this.client.callZome(i);
  }
}
globalThis && globalThis.__classPrivateFieldGet;
class yi {
  constructor(A) {
    if (this._map = /* @__PURE__ */ new Map(), A)
      for (const [e, i] of A)
        this.set(e, i);
  }
  has(A) {
    return this._map.has(kt(A));
  }
  get(A) {
    return this._map.get(kt(A));
  }
  set(A, e) {
    return this._map.set(kt(A), e), this;
  }
  delete(A) {
    return this._map.delete(kt(A));
  }
  keys() {
    return Array.from(this._map.keys()).map((A) => ai(A))[Symbol.iterator]();
  }
  values() {
    return this._map.values();
  }
  entries() {
    return Array.from(this._map.entries()).map(([A, e]) => [ai(A), e])[Symbol.iterator]();
  }
  clear() {
    return this._map.clear();
  }
  forEach(A, e) {
    return this._map.forEach((i, o) => {
      A(i, ai(o), this);
    }, e);
  }
  get size() {
    return this._map.size;
  }
  [Symbol.iterator]() {
    return this.entries();
  }
  get [Symbol.toStringTag]() {
    return this._map[Symbol.toStringTag];
  }
}
class wa {
  constructor(A) {
    this.newValue = A, this.map = new yi();
  }
  get(A) {
    return this.map.has(A) || this.map.set(A, this.newValue(A)), this.map.get(A);
  }
}
function sC(t) {
  return Math.floor(t / 1e3);
}
function rC(t) {
  const A = t.entry?.Present?.entry;
  return Sh(A);
}
class je {
  constructor(A) {
    this.record = A;
  }
  get actionHash() {
    return this.record.signed_action.hashed.hash;
  }
  get action() {
    const A = this.record.signed_action.hashed.content;
    return {
      ...A,
      timestamp: sC(A.timestamp)
    };
  }
  get entry() {
    return rC(this.record);
  }
  get entryHash() {
    return this.record.signed_action.hashed.content.entry_hash;
  }
}
const ma = ".", va = (t) => t.includes(ma), nC = (t) => {
  if (!va(t))
    throw new Error("invalid clone id: no clone id delimiter found in role name");
  return t.split(ma)[0];
};
function aC(t, A) {
  if (va(t)) {
    const i = nC(t);
    if (!(i in A.cell_info))
      throw new Error(`No cell found with role_name ${t}`);
    const o = A.cell_info[i].find((s) => tA.Cloned in s && s[tA.Cloned].clone_id === t);
    if (!o || !(tA.Cloned in o))
      throw new Error(`No clone cell found with clone id ${t}`);
    return o[tA.Cloned].cell_id;
  }
  if (!(t in A.cell_info))
    throw new Error(`No cell found with role_name ${t}`);
  const e = A.cell_info[t].find((i) => tA.Provisioned in i);
  if (!e || !(tA.Provisioned in e))
    throw new Error(`No provisioned cell found with role_name ${t}`);
  return e[tA.Provisioned].cell_id;
}
function Ds(t) {
  return Yn({ status: "pending" }, (A) => (t().then((e) => {
    A({ status: "complete", value: e });
  }).catch((e) => A({ status: "error", error: e })), () => {
  }));
}
function jo(t, A) {
  return Yn({ status: "pending" }, (e) => {
    let i, o, s = !0;
    async function r() {
      const n = await t();
      (s || !Xn(n, o)) && (o = n, s = !1, e({ status: "complete", value: n }));
    }
    return r().then(() => {
      i = setInterval(() => r().catch(() => {
      }), A);
    }).catch((n) => {
      e({ status: "error", error: n });
    }), () => {
      i && clearInterval(i);
    };
  });
}
const QA = [
  z`
    .row {
      display: flex;
      flex-direction: row;
    }
    .column {
      display: flex;
      flex-direction: column;
    }
    .small-margin {
      margin-top: 6px;
    }
    .big-margin {
      margin-top: 23px;
    }

    .fill {
      flex: 1;
      height: 100%;
    }

    .title {
      font-size: 20px;
    }

    .center-content {
      align-items: center;
      justify-content: center;
    }

    .placeholder {
      color: var(--sl-color-gray-700);
    }

    .flex-scrollable-parent {
      position: relative;
      display: flex;
      flex: 1;
    }

    .flex-scrollable-container {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
    }

    .flex-scrollable-x {
      max-width: 100%;
      overflow-x: auto;
    }
    .flex-scrollable-y {
      max-height: 100%;
      overflow-y: auto;
    }
    :host {
      color: var(--sl-color-neutral-1000);
    }

    sl-card {
      display: flex;
    }
    sl-card::part(base) {
      flex: 1;
    }
    sl-card::part(body) {
      display: flex;
      flex: 1;
    }
    sl-drawer::part(body) {
      display: flex;
    }
  `
];
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ks = { ATTRIBUTE: 1, CHILD: 2, PROPERTY: 3, BOOLEAN_ATTRIBUTE: 4, EVENT: 5, ELEMENT: 6 }, $i = (t) => (...A) => ({ _$litDirective$: t, values: A });
let qi = class {
  constructor(A) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(A, e, i) {
    this._$Ct = A, this._$AM = e, this._$Ci = i;
  }
  _$AS(A, e) {
    return this.update(A, e);
  }
  update(A, e) {
    return this.render(...e);
  }
};
function fo(t) {
  return typeof t == "string" && t.split(",").length === 39 ? new Uint8Array(t.split(",").map((A) => parseInt(A, 10))) : t;
}
function Or(t) {
  const A = new FormData(t), e = {};
  return A.forEach((i, o) => {
    if (Reflect.has(e, o)) {
      const s = e[o];
      Array.isArray(s) ? s.push(fo(i)) : e[o] = [e[o], fo(i)];
    } else
      e[o] = fo(i);
  }), e;
}
class lC extends qi {
  constructor() {
    super(...arguments), this.initialized = !1;
  }
  update(A, e) {
    this.initialized || (this.initialized = !0, A.element.addEventListener("update-form", (o) => {
      this.listener && A.element.removeEventListener("submit", this.listener), this.listener = (s) => {
        s.preventDefault();
        const r = Or(A.element);
        e[0](r);
      }, A.element.addEventListener("submit", this.listener);
    })), setTimeout(() => {
      this.listener && A.element.removeEventListener("submit", this.listener), this.listener = (i) => {
        i.preventDefault();
        const o = Or(A.element);
        e[0](o);
      }, A.element.addEventListener("submit", this.listener);
    }, 100);
  }
  render(A) {
    return "";
  }
}
const ba = $i(lC);
function Zt(t) {
  return {
    attribute: t,
    type: Object,
    hasChanged: (A, e) => A?.toString() !== e?.toString(),
    converter: (A) => A && A.length > 0 && ai(A)
  };
}
function HA(t) {
  return `data:image/svg+xml;utf8,${gC(t)}`;
}
function gC(t) {
  return `<svg style='fill: currentColor' viewBox='0 0 24 24'><path d='${t}'></path></svg>`;
}
var Da = "M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z", IC = "M7.5 16.5H13.55C13.34 16.97 13.18 17.47 13.09 18H7.5C4.46 18 2 15.54 2 12.5S4.46 7 7.5 7H18C20.21 7 22 8.79 22 11C22 11.91 21.69 12.74 21.17 13.41C20.63 13.2 20.05 13.07 19.45 13.03C20.08 12.58 20.5 11.84 20.5 11C20.5 9.62 19.38 8.5 18 8.5H7.5C5.29 8.5 3.5 10.29 3.5 12.5S5.29 16.5 7.5 16.5M9.5 13.5C8.95 13.5 8.5 13.05 8.5 12.5S8.95 11.5 9.5 11.5H17V10H9.5C8.12 10 7 11.12 7 12.5S8.12 15 9.5 15H14.54C15.11 14.36 15.81 13.85 16.61 13.5H9.5M20 18V15H18V18H15V20H18V23H20V20H23V18H20Z", cC = "M16.61 13.5C15.81 13.85 15.11 14.36 14.54 15H9.5C8.12 15 7 13.88 7 12.5S8.12 10 9.5 10H17V11.5H9.5C8.95 11.5 8.5 11.95 8.5 12.5S8.95 13.5 9.5 13.5H16.61M3.5 12.5C3.5 10.29 5.29 8.5 7.5 8.5H18C19.38 8.5 20.5 9.62 20.5 11C20.5 11.84 20.08 12.58 19.45 13.03C20.05 13.07 20.63 13.2 21.17 13.41C21.69 12.74 22 11.91 22 11C22 8.79 20.21 7 18 7H7.5C4.46 7 2 9.46 2 12.5S4.46 18 7.5 18H13.09C13.18 17.47 13.34 16.97 13.55 16.5H7.5C5.29 16.5 3.5 14.71 3.5 12.5M22.54 16.88L21.12 15.47L19 17.59L16.88 15.47L15.47 16.88L17.59 19L15.47 21.12L16.88 22.54L19 20.41L21.12 22.54L22.54 21.12L20.41 19L22.54 16.88Z", hC = "M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z", ka = "M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z", CC = "M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z", Sa = "M3 3V21H21V3H3M18 18H6V17H18V18M18 16H6V15H18V16M18 12H6V6H18V12Z";
function dC(t) {
  const A = document.createElement("div");
  return A.textContent = t, A.innerHTML;
}
function BC(t, A = "primary", e = ka, i = 3e3) {
  const o = Object.assign(document.createElement("sl-alert"), {
    variant: A,
    closable: !0,
    duration: i,
    innerHTML: `
        <sl-icon src="${HA(e)}" slot="icon"></sl-icon>
        ${dC(t)}
      `
  });
  return document.body.append(o), o.toast();
}
function _e(t) {
  return BC(t, "danger", Da);
}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let QC = class extends Event {
  constructor(A, e, i) {
    super("context-request", { bubbles: !0, composed: !0 }), this.context = A, this.callback = e, this.subscribe = i;
  }
};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let EC = class {
  constructor(A, e, i, o = !1) {
    this.host = A, this.context = e, this.callback = i, this.subscribe = o, this.provided = !1, this.value = void 0, this.host.addController(this);
  }
  hostConnected() {
    this.dispatchRequest();
  }
  hostDisconnected() {
    this.unsubscribe && (this.unsubscribe(), this.unsubscribe = void 0);
  }
  dispatchRequest() {
    this.host.dispatchEvent(new QC(this.context, (A, e) => {
      this.unsubscribe && (this.unsubscribe !== e && (this.provided = !1, this.unsubscribe()), this.subscribe || this.unsubscribe()), this.value = A, this.host.requestUpdate(), this.provided && !this.subscribe || (this.provided = !0, this.callback && this.callback(A, e)), this.unsubscribe = e;
    }, this.subscribe));
  }
};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let uC = class {
  constructor(A) {
    this.callbacks = /* @__PURE__ */ new Map(), this.updateObservers = () => {
      for (const [e, i] of this.callbacks)
        e(this.t, i);
    }, A !== void 0 && (this.value = A);
  }
  get value() {
    return this.t;
  }
  set value(A) {
    this.setValue(A);
  }
  setValue(A, e = !1) {
    const i = e || !Object.is(A, this.t);
    this.t = A, i && this.updateObservers();
  }
  addCallback(A, e) {
    e && (this.callbacks.has(A) || this.callbacks.set(A, () => {
      this.callbacks.delete(A);
    })), A(this.value);
  }
  clearCallbacks() {
    this.callbacks.clear();
  }
};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let pC = class extends Event {
  constructor(A) {
    super("context-provider", { bubbles: !0, composed: !0 }), this.context = A;
  }
}, fC = class extends uC {
  constructor(A, e, i) {
    super(i), this.host = A, this.context = e, this.onContextRequest = (o) => {
      o.context === this.context && o.composedPath()[0] !== this.host && (o.stopPropagation(), this.addCallback(o.callback, o.subscribe));
    }, this.attachListeners(), this.host.addController(this);
  }
  attachListeners() {
    this.host.addEventListener("context-request", this.onContextRequest);
  }
  hostConnected() {
    this.host.dispatchEvent(new pC(this.context));
  }
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function Pi({ context: t }) {
  return zt({ finisher: (A, e) => {
    const i = /* @__PURE__ */ new WeakMap();
    A.addInitializer((n) => {
      i.set(n, new fC(n, t));
    });
    const o = Object.getOwnPropertyDescriptor(A.prototype, e), s = o?.set, r = { ...o, set: function(n) {
      var l;
      (l = i.get(this)) === null || l === void 0 || l.setValue(n), s && s.call(this, n);
    } };
    Object.defineProperty(A.prototype, e, r);
  } });
}
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function vA({ context: t, subscribe: A }) {
  return zt({ finisher: (e, i) => {
    e.addInitializer((o) => {
      new EC(o, t, (s) => {
        o[i] = s;
      }, A);
    });
  } });
}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const yC = (t) => typeof t != "string" && "strTag" in t, wC = (t, A, e) => {
  let i = t[0];
  for (let o = 1; o < t.length; o++)
    i += A[e ? e[o - 1] : o - 1], i += t[o];
  return i;
};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const mC = (t) => yC(t) ? wC(t.strings, t.values) : t;
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Kr = "lit-localize-status";
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let vC = class {
  constructor(A) {
    this.__litLocalizeEventHandler = (e) => {
      e.detail.status === "ready" && this.host.requestUpdate();
    }, this.host = A;
  }
  hostConnected() {
    window.addEventListener(Kr, this.__litLocalizeEventHandler);
  }
  hostDisconnected() {
    window.removeEventListener(Kr, this.__litLocalizeEventHandler);
  }
};
const bC = (t) => t.addController(new vC(t)), xa = bC;
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const DC = () => (t) => typeof t == "function" ? SC(t) : kC(t), LA = DC, kC = ({ kind: t, elements: A }) => ({
  kind: t,
  elements: A,
  finisher(e) {
    e.addInitializer(xa);
  }
}), SC = (t) => (t.addInitializer(xa), t);
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
class xC {
  constructor() {
    this.settled = !1, this.promise = new Promise((A, e) => {
      this._resolve = A, this._reject = e;
    });
  }
  resolve(A) {
    this.settled = !0, this._resolve(A);
  }
  reject(A) {
    this.settled = !0, this._reject(A);
  }
}
/**
 * @license
 * Copyright 2014 Travis Webb
 * SPDX-License-Identifier: MIT
 */
for (let t = 0; t < 256; t++)
  (t >> 4 & 15).toString(16) + (t & 15).toString(16);
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let NC = new xC();
NC.resolve();
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let k = mC;
var li = window, Ss = li.ShadowRoot && (li.ShadyCSS === void 0 || li.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, xs = Symbol(), $r = /* @__PURE__ */ new WeakMap(), Na = class {
  constructor(A, e, i) {
    if (this._$cssResult$ = !0, i !== xs)
      throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = A, this.t = e;
  }
  get styleSheet() {
    let A = this.o;
    const e = this.t;
    if (Ss && A === void 0) {
      const i = e !== void 0 && e.length === 1;
      i && (A = $r.get(e)), A === void 0 && ((this.o = A = new CSSStyleSheet()).replaceSync(this.cssText), i && $r.set(e, A));
    }
    return A;
  }
  toString() {
    return this.cssText;
  }
}, UC = (t) => new Na(typeof t == "string" ? t : t + "", void 0, xs), $ = (t, ...A) => {
  const e = t.length === 1 ? t[0] : A.reduce((i, o, s) => i + ((r) => {
    if (r._$cssResult$ === !0)
      return r.cssText;
    if (typeof r == "number")
      return r;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + r + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(o) + t[s + 1], t[0]);
  return new Na(e, t, xs);
}, FC = (t, A) => {
  Ss ? t.adoptedStyleSheets = A.map((e) => e instanceof CSSStyleSheet ? e : e.styleSheet) : A.forEach((e) => {
    const i = document.createElement("style"), o = li.litNonce;
    o !== void 0 && i.setAttribute("nonce", o), i.textContent = e.cssText, t.appendChild(i);
  });
}, qr = Ss ? (t) => t : (t) => t instanceof CSSStyleSheet ? ((A) => {
  let e = "";
  for (const i of A.cssRules)
    e += i.cssText;
  return UC(e);
})(t) : t, yo, wi = window, Pr = wi.trustedTypes, GC = Pr ? Pr.emptyScript : "", zr = wi.reactiveElementPolyfillSupport, Se = { toAttribute(t, A) {
  switch (A) {
    case Boolean:
      t = t ? GC : null;
      break;
    case Object:
    case Array:
      t = t == null ? t : JSON.stringify(t);
  }
  return t;
}, fromAttribute(t, A) {
  let e = t;
  switch (A) {
    case Boolean:
      e = t !== null;
      break;
    case Number:
      e = t === null ? null : Number(t);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(t);
      } catch {
        e = null;
      }
  }
  return e;
} }, Ua = (t, A) => A !== t && (A == A || t == t), wo = { attribute: !0, type: String, converter: Se, reflect: !1, hasChanged: Ua }, Dt = class extends HTMLElement {
  constructor() {
    super(), this._$Ei = /* @__PURE__ */ new Map(), this.isUpdatePending = !1, this.hasUpdated = !1, this._$El = null, this.u();
  }
  static addInitializer(t) {
    var A;
    this.finalize(), ((A = this.h) !== null && A !== void 0 ? A : this.h = []).push(t);
  }
  static get observedAttributes() {
    this.finalize();
    const t = [];
    return this.elementProperties.forEach((A, e) => {
      const i = this._$Ep(e, A);
      i !== void 0 && (this._$Ev.set(i, e), t.push(i));
    }), t;
  }
  static createProperty(t, A = wo) {
    if (A.state && (A.attribute = !1), this.finalize(), this.elementProperties.set(t, A), !A.noAccessor && !this.prototype.hasOwnProperty(t)) {
      const e = typeof t == "symbol" ? Symbol() : "__" + t, i = this.getPropertyDescriptor(t, e, A);
      i !== void 0 && Object.defineProperty(this.prototype, t, i);
    }
  }
  static getPropertyDescriptor(t, A, e) {
    return { get() {
      return this[A];
    }, set(i) {
      const o = this[t];
      this[A] = i, this.requestUpdate(t, o, e);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) || wo;
  }
  static finalize() {
    if (this.hasOwnProperty("finalized"))
      return !1;
    this.finalized = !0;
    const t = Object.getPrototypeOf(this);
    if (t.finalize(), t.h !== void 0 && (this.h = [...t.h]), this.elementProperties = new Map(t.elementProperties), this._$Ev = /* @__PURE__ */ new Map(), this.hasOwnProperty("properties")) {
      const A = this.properties, e = [...Object.getOwnPropertyNames(A), ...Object.getOwnPropertySymbols(A)];
      for (const i of e)
        this.createProperty(i, A[i]);
    }
    return this.elementStyles = this.finalizeStyles(this.styles), !0;
  }
  static finalizeStyles(t) {
    const A = [];
    if (Array.isArray(t)) {
      const e = new Set(t.flat(1 / 0).reverse());
      for (const i of e)
        A.unshift(qr(i));
    } else
      t !== void 0 && A.push(qr(t));
    return A;
  }
  static _$Ep(t, A) {
    const e = A.attribute;
    return e === !1 ? void 0 : typeof e == "string" ? e : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  u() {
    var t;
    this._$E_ = new Promise((A) => this.enableUpdating = A), this._$AL = /* @__PURE__ */ new Map(), this._$Eg(), this.requestUpdate(), (t = this.constructor.h) === null || t === void 0 || t.forEach((A) => A(this));
  }
  addController(t) {
    var A, e;
    ((A = this._$ES) !== null && A !== void 0 ? A : this._$ES = []).push(t), this.renderRoot !== void 0 && this.isConnected && ((e = t.hostConnected) === null || e === void 0 || e.call(t));
  }
  removeController(t) {
    var A;
    (A = this._$ES) === null || A === void 0 || A.splice(this._$ES.indexOf(t) >>> 0, 1);
  }
  _$Eg() {
    this.constructor.elementProperties.forEach((t, A) => {
      this.hasOwnProperty(A) && (this._$Ei.set(A, this[A]), delete this[A]);
    });
  }
  createRenderRoot() {
    var t;
    const A = (t = this.shadowRoot) !== null && t !== void 0 ? t : this.attachShadow(this.constructor.shadowRootOptions);
    return FC(A, this.constructor.elementStyles), A;
  }
  connectedCallback() {
    var t;
    this.renderRoot === void 0 && (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (t = this._$ES) === null || t === void 0 || t.forEach((A) => {
      var e;
      return (e = A.hostConnected) === null || e === void 0 ? void 0 : e.call(A);
    });
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    var t;
    (t = this._$ES) === null || t === void 0 || t.forEach((A) => {
      var e;
      return (e = A.hostDisconnected) === null || e === void 0 ? void 0 : e.call(A);
    });
  }
  attributeChangedCallback(t, A, e) {
    this._$AK(t, e);
  }
  _$EO(t, A, e = wo) {
    var i;
    const o = this.constructor._$Ep(t, e);
    if (o !== void 0 && e.reflect === !0) {
      const s = (((i = e.converter) === null || i === void 0 ? void 0 : i.toAttribute) !== void 0 ? e.converter : Se).toAttribute(A, e.type);
      this._$El = t, s == null ? this.removeAttribute(o) : this.setAttribute(o, s), this._$El = null;
    }
  }
  _$AK(t, A) {
    var e;
    const i = this.constructor, o = i._$Ev.get(t);
    if (o !== void 0 && this._$El !== o) {
      const s = i.getPropertyOptions(o), r = typeof s.converter == "function" ? { fromAttribute: s.converter } : ((e = s.converter) === null || e === void 0 ? void 0 : e.fromAttribute) !== void 0 ? s.converter : Se;
      this._$El = o, this[o] = r.fromAttribute(A, s.type), this._$El = null;
    }
  }
  requestUpdate(t, A, e) {
    let i = !0;
    t !== void 0 && (((e = e || this.constructor.getPropertyOptions(t)).hasChanged || Ua)(this[t], A) ? (this._$AL.has(t) || this._$AL.set(t, A), e.reflect === !0 && this._$El !== t && (this._$EC === void 0 && (this._$EC = /* @__PURE__ */ new Map()), this._$EC.set(t, e))) : i = !1), !this.isUpdatePending && i && (this._$E_ = this._$Ej());
  }
  async _$Ej() {
    this.isUpdatePending = !0;
    try {
      await this._$E_;
    } catch (A) {
      Promise.reject(A);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var t;
    if (!this.isUpdatePending)
      return;
    this.hasUpdated, this._$Ei && (this._$Ei.forEach((i, o) => this[o] = i), this._$Ei = void 0);
    let A = !1;
    const e = this._$AL;
    try {
      A = this.shouldUpdate(e), A ? (this.willUpdate(e), (t = this._$ES) === null || t === void 0 || t.forEach((i) => {
        var o;
        return (o = i.hostUpdate) === null || o === void 0 ? void 0 : o.call(i);
      }), this.update(e)) : this._$Ek();
    } catch (i) {
      throw A = !1, this._$Ek(), i;
    }
    A && this._$AE(e);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    var A;
    (A = this._$ES) === null || A === void 0 || A.forEach((e) => {
      var i;
      return (i = e.hostUpdated) === null || i === void 0 ? void 0 : i.call(e);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$Ek() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$E_;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$EC !== void 0 && (this._$EC.forEach((A, e) => this._$EO(e, this[e], A)), this._$EC = void 0), this._$Ek();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
Dt.finalized = !0, Dt.elementProperties = /* @__PURE__ */ new Map(), Dt.elementStyles = [], Dt.shadowRootOptions = { mode: "open" }, zr?.({ ReactiveElement: Dt }), ((yo = wi.reactiveElementVersions) !== null && yo !== void 0 ? yo : wi.reactiveElementVersions = []).push("1.6.1");
var mo, mi = window, Ht = mi.trustedTypes, Vr = Ht ? Ht.createPolicy("lit-html", { createHTML: (t) => t }) : void 0, qA = `lit$${(Math.random() + "").slice(9)}$`, Fa = "?" + qA, RC = `<${Fa}>`, Tt = document, xe = (t = "") => Tt.createComment(t), Ne = (t) => t === null || typeof t != "object" && typeof t != "function", Ga = Array.isArray, MC = (t) => Ga(t) || typeof t?.[Symbol.iterator] == "function", ne = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, jr = /-->/g, Zr = />/g, et = RegExp(`>|[ 	
\f\r](?:([^\\s"'>=/]+)([ 	
\f\r]*=[ 	
\f\r]*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Wr = /'/g, Xr = /"/g, Ra = /^(?:script|style|textarea|title)$/i, _C = (t) => (A, ...e) => ({ _$litType$: t, strings: A, values: e }), Y = _C(1), yA = Symbol.for("lit-noChange"), K = Symbol.for("lit-nothing"), An = /* @__PURE__ */ new WeakMap(), Ft = Tt.createTreeWalker(Tt, 129, null, !1), LC = (t, A) => {
  const e = t.length - 1, i = [];
  let o, s = A === 2 ? "<svg>" : "", r = ne;
  for (let l = 0; l < e; l++) {
    const a = t[l];
    let h, g, c = -1, C = 0;
    for (; C < a.length && (r.lastIndex = C, g = r.exec(a), g !== null); )
      C = r.lastIndex, r === ne ? g[1] === "!--" ? r = jr : g[1] !== void 0 ? r = Zr : g[2] !== void 0 ? (Ra.test(g[2]) && (o = RegExp("</" + g[2], "g")), r = et) : g[3] !== void 0 && (r = et) : r === et ? g[0] === ">" ? (r = o ?? ne, c = -1) : g[1] === void 0 ? c = -2 : (c = r.lastIndex - g[2].length, h = g[1], r = g[3] === void 0 ? et : g[3] === '"' ? Xr : Wr) : r === Xr || r === Wr ? r = et : r === jr || r === Zr ? r = ne : (r = et, o = void 0);
    const B = r === et && t[l + 1].startsWith("/>") ? " " : "";
    s += r === ne ? a + RC : c >= 0 ? (i.push(h), a.slice(0, c) + "$lit$" + a.slice(c) + qA + B) : a + qA + (c === -2 ? (i.push(void 0), l) : B);
  }
  const n = s + (t[e] || "<?>") + (A === 2 ? "</svg>" : "");
  if (!Array.isArray(t) || !t.hasOwnProperty("raw"))
    throw Error("invalid template strings array");
  return [Vr !== void 0 ? Vr.createHTML(n) : n, i];
}, vi = class {
  constructor({ strings: A, _$litType$: e }, i) {
    let o;
    this.parts = [];
    let s = 0, r = 0;
    const n = A.length - 1, l = this.parts, [a, h] = LC(A, e);
    if (this.el = vi.createElement(a, i), Ft.currentNode = this.el.content, e === 2) {
      const g = this.el.content, c = g.firstChild;
      c.remove(), g.append(...c.childNodes);
    }
    for (; (o = Ft.nextNode()) !== null && l.length < n; ) {
      if (o.nodeType === 1) {
        if (o.hasAttributes()) {
          const g = [];
          for (const c of o.getAttributeNames())
            if (c.endsWith("$lit$") || c.startsWith(qA)) {
              const C = h[r++];
              if (g.push(c), C !== void 0) {
                const B = o.getAttribute(C.toLowerCase() + "$lit$").split(qA), Q = /([.?@])?(.*)/.exec(C);
                l.push({ type: 1, index: s, name: Q[2], strings: B, ctor: Q[1] === "." ? YC : Q[1] === "?" ? TC : Q[1] === "@" ? OC : Vi });
              } else
                l.push({ type: 6, index: s });
            }
          for (const c of g)
            o.removeAttribute(c);
        }
        if (Ra.test(o.tagName)) {
          const g = o.textContent.split(qA), c = g.length - 1;
          if (c > 0) {
            o.textContent = Ht ? Ht.emptyScript : "";
            for (let C = 0; C < c; C++)
              o.append(g[C], xe()), Ft.nextNode(), l.push({ type: 2, index: ++s });
            o.append(g[c], xe());
          }
        }
      } else if (o.nodeType === 8)
        if (o.data === Fa)
          l.push({ type: 2, index: s });
        else {
          let g = -1;
          for (; (g = o.data.indexOf(qA, g + 1)) !== -1; )
            l.push({ type: 7, index: s }), g += qA.length - 1;
        }
      s++;
    }
  }
  static createElement(A, e) {
    const i = Tt.createElement("template");
    return i.innerHTML = A, i;
  }
};
function Ot(t, A, e = t, i) {
  var o, s, r, n;
  if (A === yA)
    return A;
  let l = i !== void 0 ? (o = e._$Co) === null || o === void 0 ? void 0 : o[i] : e._$Cl;
  const a = Ne(A) ? void 0 : A._$litDirective$;
  return l?.constructor !== a && ((s = l?._$AO) === null || s === void 0 || s.call(l, !1), a === void 0 ? l = void 0 : (l = new a(t), l._$AT(t, e, i)), i !== void 0 ? ((r = (n = e)._$Co) !== null && r !== void 0 ? r : n._$Co = [])[i] = l : e._$Cl = l), l !== void 0 && (A = Ot(t, l._$AS(t, A.values), l, i)), A;
}
var JC = class {
  constructor(A, e) {
    this.u = [], this._$AN = void 0, this._$AD = A, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  v(A) {
    var e;
    const { el: { content: i }, parts: o } = this._$AD, s = ((e = A?.creationScope) !== null && e !== void 0 ? e : Tt).importNode(i, !0);
    Ft.currentNode = s;
    let r = Ft.nextNode(), n = 0, l = 0, a = o[0];
    for (; a !== void 0; ) {
      if (n === a.index) {
        let h;
        a.type === 2 ? h = new zi(r, r.nextSibling, this, A) : a.type === 1 ? h = new a.ctor(r, a.name, a.strings, this, A) : a.type === 6 && (h = new KC(r, this, A)), this.u.push(h), a = o[++l];
      }
      n !== a?.index && (r = Ft.nextNode(), n++);
    }
    return s;
  }
  p(A) {
    let e = 0;
    for (const i of this.u)
      i !== void 0 && (i.strings !== void 0 ? (i._$AI(A, i, e), e += i.strings.length - 2) : i._$AI(A[e])), e++;
  }
}, zi = class {
  constructor(t, A, e, i) {
    var o;
    this.type = 2, this._$AH = K, this._$AN = void 0, this._$AA = t, this._$AB = A, this._$AM = e, this.options = i, this._$Cm = (o = i?.isConnected) === null || o === void 0 || o;
  }
  get _$AU() {
    var t, A;
    return (A = (t = this._$AM) === null || t === void 0 ? void 0 : t._$AU) !== null && A !== void 0 ? A : this._$Cm;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const A = this._$AM;
    return A !== void 0 && t.nodeType === 11 && (t = A.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, A = this) {
    t = Ot(this, t, A), Ne(t) ? t === K || t == null || t === "" ? (this._$AH !== K && this._$AR(), this._$AH = K) : t !== this._$AH && t !== yA && this.g(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : MC(t) ? this.k(t) : this.g(t);
  }
  O(t, A = this._$AB) {
    return this._$AA.parentNode.insertBefore(t, A);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  g(t) {
    this._$AH !== K && Ne(this._$AH) ? this._$AA.nextSibling.data = t : this.T(Tt.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    var A;
    const { values: e, _$litType$: i } = t, o = typeof i == "number" ? this._$AC(t) : (i.el === void 0 && (i.el = vi.createElement(i.h, this.options)), i);
    if (((A = this._$AH) === null || A === void 0 ? void 0 : A._$AD) === o)
      this._$AH.p(e);
    else {
      const s = new JC(o, this), r = s.v(this.options);
      s.p(e), this.T(r), this._$AH = s;
    }
  }
  _$AC(t) {
    let A = An.get(t.strings);
    return A === void 0 && An.set(t.strings, A = new vi(t)), A;
  }
  k(t) {
    Ga(this._$AH) || (this._$AH = [], this._$AR());
    const A = this._$AH;
    let e, i = 0;
    for (const o of t)
      i === A.length ? A.push(e = new zi(this.O(xe()), this.O(xe()), this, this.options)) : e = A[i], e._$AI(o), i++;
    i < A.length && (this._$AR(e && e._$AB.nextSibling, i), A.length = i);
  }
  _$AR(t = this._$AA.nextSibling, A) {
    var e;
    for ((e = this._$AP) === null || e === void 0 || e.call(this, !1, !0, A); t && t !== this._$AB; ) {
      const i = t.nextSibling;
      t.remove(), t = i;
    }
  }
  setConnected(t) {
    var A;
    this._$AM === void 0 && (this._$Cm = t, (A = this._$AP) === null || A === void 0 || A.call(this, t));
  }
}, Vi = class {
  constructor(t, A, e, i, o) {
    this.type = 1, this._$AH = K, this._$AN = void 0, this.element = t, this.name = A, this._$AM = i, this.options = o, e.length > 2 || e[0] !== "" || e[1] !== "" ? (this._$AH = Array(e.length - 1).fill(new String()), this.strings = e) : this._$AH = K;
  }
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t, A = this, e, i) {
    const o = this.strings;
    let s = !1;
    if (o === void 0)
      t = Ot(this, t, A, 0), s = !Ne(t) || t !== this._$AH && t !== yA, s && (this._$AH = t);
    else {
      const r = t;
      let n, l;
      for (t = o[0], n = 0; n < o.length - 1; n++)
        l = Ot(this, r[e + n], A, n), l === yA && (l = this._$AH[n]), s || (s = !Ne(l) || l !== this._$AH[n]), l === K ? t = K : t !== K && (t += (l ?? "") + o[n + 1]), this._$AH[n] = l;
    }
    s && !i && this.j(t);
  }
  j(t) {
    t === K ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}, YC = class extends Vi {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === K ? void 0 : t;
  }
}, HC = Ht ? Ht.emptyScript : "", TC = class extends Vi {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(A) {
    A && A !== K ? this.element.setAttribute(this.name, HC) : this.element.removeAttribute(this.name);
  }
}, OC = class extends Vi {
  constructor(A, e, i, o, s) {
    super(A, e, i, o, s), this.type = 5;
  }
  _$AI(A, e = this) {
    var i;
    if ((A = (i = Ot(this, A, e, 0)) !== null && i !== void 0 ? i : K) === yA)
      return;
    const o = this._$AH, s = A === K && o !== K || A.capture !== o.capture || A.once !== o.once || A.passive !== o.passive, r = A !== K && (o === K || s);
    s && this.element.removeEventListener(this.name, this, o), r && this.element.addEventListener(this.name, this, A), this._$AH = A;
  }
  handleEvent(A) {
    var e, i;
    typeof this._$AH == "function" ? this._$AH.call((i = (e = this.options) === null || e === void 0 ? void 0 : e.host) !== null && i !== void 0 ? i : this.element, A) : this._$AH.handleEvent(A);
  }
}, KC = class {
  constructor(t, A, e) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = A, this.options = e;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    Ot(this, t);
  }
}, tn = mi.litHtmlPolyfillSupport;
tn?.(vi, zi), ((mo = mi.litHtmlVersions) !== null && mo !== void 0 ? mo : mi.litHtmlVersions = []).push("2.6.1");
var $C = (t, A, e) => {
  var i, o;
  const s = (i = e?.renderBefore) !== null && i !== void 0 ? i : A;
  let r = s._$litPart$;
  if (r === void 0) {
    const n = (o = e?.renderBefore) !== null && o !== void 0 ? o : null;
    s._$litPart$ = r = new zi(A.insertBefore(xe(), n), n, void 0, e ?? {});
  }
  return r._$AI(t), r;
}, vo, bo, pe = class extends Dt {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Dt = void 0;
  }
  createRenderRoot() {
    var t, A;
    const e = super.createRenderRoot();
    return (t = (A = this.renderOptions).renderBefore) !== null && t !== void 0 || (A.renderBefore = e.firstChild), e;
  }
  update(t) {
    const A = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Dt = $C(A, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Dt) === null || t === void 0 || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Dt) === null || t === void 0 || t.setConnected(!1);
  }
  render() {
    return yA;
  }
};
pe.finalized = !0, pe._$litElement$ = !0, (vo = globalThis.litElementHydrateSupport) === null || vo === void 0 || vo.call(globalThis, { LitElement: pe });
var en = globalThis.litElementPolyfillSupport;
en?.({ LitElement: pe });
((bo = globalThis.litElementVersions) !== null && bo !== void 0 ? bo : globalThis.litElementVersions = []).push("3.2.0");
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/lit-html.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-element/lit-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var Z = $`
  :host {
    box-sizing: border-box;
  }

  :host *,
  :host *::before,
  :host *::after {
    box-sizing: inherit;
  }

  [hidden] {
    display: none !important;
  }
`, qC = $`
  ${Z}

  :host {
    --max-width: 20rem;
    --hide-delay: 0ms;
    --show-delay: 150ms;

    display: contents;
  }

  .tooltip {
    --arrow-size: var(--sl-tooltip-arrow-size);
    --arrow-color: var(--sl-tooltip-background-color);
  }

  .tooltip::part(popup) {
    pointer-events: none;
    z-index: var(--sl-z-index-tooltip);
  }

  .tooltip[placement^='top']::part(popup) {
    transform-origin: bottom;
  }

  .tooltip[placement^='bottom']::part(popup) {
    transform-origin: top;
  }

  .tooltip[placement^='left']::part(popup) {
    transform-origin: right;
  }

  .tooltip[placement^='right']::part(popup) {
    transform-origin: left;
  }

  .tooltip__body {
    display: block;
    width: max-content;
    max-width: var(--max-width);
    border-radius: var(--sl-tooltip-border-radius);
    background-color: var(--sl-tooltip-background-color);
    font-family: var(--sl-tooltip-font-family);
    font-size: var(--sl-tooltip-font-size);
    font-weight: var(--sl-tooltip-font-weight);
    line-height: var(--sl-tooltip-line-height);
    color: var(--sl-tooltip-color);
    padding: var(--sl-tooltip-padding);
    pointer-events: none;
  }
`, Ma = Object.defineProperty, PC = Object.defineProperties, zC = Object.getOwnPropertyDescriptor, VC = Object.getOwnPropertyDescriptors, bi = Object.getOwnPropertySymbols, _a = Object.prototype.hasOwnProperty, La = Object.prototype.propertyIsEnumerable, on = (t, A, e) => A in t ? Ma(t, A, { enumerable: !0, configurable: !0, writable: !0, value: e }) : t[A] = e, L = (t, A) => {
  for (var e in A || (A = {}))
    _a.call(A, e) && on(t, e, A[e]);
  if (bi)
    for (var e of bi(A))
      La.call(A, e) && on(t, e, A[e]);
  return t;
}, sA = (t, A) => PC(t, VC(A)), Ns = (t, A) => {
  var e = {};
  for (var i in t)
    _a.call(t, i) && A.indexOf(i) < 0 && (e[i] = t[i]);
  if (t != null && bi)
    for (var i of bi(t))
      A.indexOf(i) < 0 && La.call(t, i) && (e[i] = t[i]);
  return e;
}, I = (t, A, e, i) => {
  for (var o = i > 1 ? void 0 : i ? zC(A, e) : A, s = t.length - 1, r; s >= 0; s--)
    (r = t[s]) && (o = (i ? r(A, e, o) : r(o)) || o);
  return i && o && Ma(A, e, o), o;
}, Ja = /* @__PURE__ */ new Map(), jC = /* @__PURE__ */ new WeakMap();
function ZC(t) {
  return t ?? { keyframes: [], options: { duration: 0 } };
}
function sn(t, A) {
  return A.toLowerCase() === "rtl" ? {
    keyframes: t.rtlKeyframes || t.keyframes,
    options: t.options
  } : t;
}
function bA(t, A) {
  Ja.set(t, ZC(A));
}
function pA(t, A, e) {
  const i = jC.get(t);
  if (i?.[A])
    return sn(i[A], e.dir);
  const o = Ja.get(A);
  return o ? sn(o, e.dir) : {
    keyframes: [],
    options: { duration: 0 }
  };
}
function jA(t, A) {
  return new Promise((e) => {
    function i(o) {
      o.target === t && (t.removeEventListener(A, i), e());
    }
    t.addEventListener(A, i);
  });
}
function fA(t, A, e) {
  return new Promise((i) => {
    if (e?.duration === 1 / 0)
      throw new Error("Promise-based animations must be finite.");
    const o = t.animate(A, sA(L({}, e), {
      duration: WC() ? 0 : e.duration
    }));
    o.addEventListener("cancel", i, { once: !0 }), o.addEventListener("finish", i, { once: !0 });
  });
}
function rn(t) {
  return t = t.toString().toLowerCase(), t.indexOf("ms") > -1 ? parseFloat(t) : t.indexOf("s") > -1 ? parseFloat(t) * 1e3 : parseFloat(t);
}
function WC() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function NA(t) {
  return Promise.all(
    t.getAnimations().map((A) => new Promise((e) => {
      const i = requestAnimationFrame(e);
      A.addEventListener("cancel", () => i, { once: !0 }), A.addEventListener("finish", () => i, { once: !0 }), A.cancel();
    }))
  );
}
var Zo = /* @__PURE__ */ new Set(), XC = new MutationObserver(Ta), St = /* @__PURE__ */ new Map(), Ya = document.documentElement.dir || "ltr", Ha = document.documentElement.lang || navigator.language, lt;
XC.observe(document.documentElement, {
  attributes: !0,
  attributeFilter: ["dir", "lang"]
});
function Ad(...t) {
  t.map((A) => {
    const e = A.$code.toLowerCase();
    St.has(e) ? St.set(e, Object.assign(Object.assign({}, St.get(e)), A)) : St.set(e, A), lt || (lt = A);
  }), Ta();
}
function Ta() {
  Ya = document.documentElement.dir || "ltr", Ha = document.documentElement.lang || navigator.language, [...Zo.keys()].map((t) => {
    typeof t.requestUpdate == "function" && t.requestUpdate();
  });
}
var td = class {
  constructor(t) {
    this.host = t, this.host.addController(this);
  }
  hostConnected() {
    Zo.add(this.host);
  }
  hostDisconnected() {
    Zo.delete(this.host);
  }
  dir() {
    return `${this.host.dir || Ya}`.toLowerCase();
  }
  lang() {
    return `${this.host.lang || Ha}`.toLowerCase();
  }
  getTranslationData(t) {
    var A, e;
    const i = new Intl.Locale(t), o = i?.language.toLowerCase(), s = (e = (A = i?.region) === null || A === void 0 ? void 0 : A.toLowerCase()) !== null && e !== void 0 ? e : "", r = St.get(`${o}-${s}`), n = St.get(o);
    return { locale: i, language: o, region: s, primary: r, secondary: n };
  }
  exists(t, A) {
    var e;
    const { primary: i, secondary: o } = this.getTranslationData((e = A.lang) !== null && e !== void 0 ? e : this.lang());
    return A = Object.assign({ includeFallback: !1 }, A), !!(i && i[t] || o && o[t] || A.includeFallback && lt && lt[t]);
  }
  term(t, ...A) {
    const { primary: e, secondary: i } = this.getTranslationData(this.lang());
    let o;
    if (e && e[t])
      o = e[t];
    else if (i && i[t])
      o = i[t];
    else if (lt && lt[t])
      o = lt[t];
    else
      return console.error(`No translation found for: ${String(t)}`), String(t);
    return typeof o == "function" ? o(...A) : o;
  }
  date(t, A) {
    return t = new Date(t), new Intl.DateTimeFormat(this.lang(), A).format(t);
  }
  number(t, A) {
    return t = Number(t), isNaN(t) ? "" : new Intl.NumberFormat(this.lang(), A).format(t);
  }
  relativeTime(t, A, e) {
    return new Intl.RelativeTimeFormat(this.lang(), e).format(t, A);
  }
}, XA = class extends td {
}, ed = {
  $code: "en",
  $name: "English",
  $dir: "ltr",
  carousel: "Carousel",
  clearEntry: "Clear entry",
  close: "Close",
  copy: "Copy",
  currentValue: "Current value",
  goToSlide: (t, A) => `Go to slide ${t} of ${A}`,
  hidePassword: "Hide password",
  loading: "Loading",
  nextSlide: "Next slide",
  numOptionsSelected: (t) => t === 0 ? "No options selected" : t === 1 ? "1 option selected" : `${t} options selected`,
  previousSlide: "Previous slide",
  progress: "Progress",
  remove: "Remove",
  resize: "Resize",
  scrollToEnd: "Scroll to end",
  scrollToStart: "Scroll to start",
  selectAColorFromTheScreen: "Select a color from the screen",
  showPassword: "Show password",
  slideNum: (t) => `Slide ${t}`,
  toggleColorFormat: "Toggle color format"
};
Ad(ed);
function q(t, A) {
  const e = L({
    waitUntilFirstUpdate: !1
  }, A);
  return (i, o) => {
    const { update: s } = i, r = Array.isArray(t) ? t : [t];
    i.update = function(n) {
      r.forEach((l) => {
        const a = l;
        if (n.has(a)) {
          const h = n.get(a), g = this[a];
          h !== g && (!e.waitUntilFirstUpdate || this.hasUpdated) && this[o](h, g);
        }
      }), s.call(this, n);
    };
  };
}
var st = { ATTRIBUTE: 1, CHILD: 2, PROPERTY: 3, BOOLEAN_ATTRIBUTE: 4, EVENT: 5, ELEMENT: 6 }, Oa = (t) => (...A) => ({ _$litDirective$: t, values: A }), Ka = class {
  constructor(A) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(A, e, i) {
    this._$Ct = A, this._$AM = e, this._$Ci = i;
  }
  _$AS(A, e) {
    return this.update(A, e);
  }
  update(A, e) {
    return this.render(...e);
  }
};
/*! Bundled license information:

lit-html/directive.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var rA = Oa(class extends Ka {
  constructor(t) {
    var A;
    if (super(t), t.type !== st.ATTRIBUTE || t.name !== "class" || ((A = t.strings) === null || A === void 0 ? void 0 : A.length) > 2)
      throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.");
  }
  render(t) {
    return " " + Object.keys(t).filter((A) => t[A]).join(" ") + " ";
  }
  update(t, [A]) {
    var e, i;
    if (this.nt === void 0) {
      this.nt = /* @__PURE__ */ new Set(), t.strings !== void 0 && (this.st = new Set(t.strings.join(" ").split(/\s/).filter((s) => s !== "")));
      for (const s in A)
        A[s] && !(!((e = this.st) === null || e === void 0) && e.has(s)) && this.nt.add(s);
      return this.render(A);
    }
    const o = t.element.classList;
    this.nt.forEach((s) => {
      s in A || (o.remove(s), this.nt.delete(s));
    });
    for (const s in A) {
      const r = !!A[s];
      r === this.nt.has(s) || !((i = this.st) === null || i === void 0) && i.has(s) || (r ? (o.add(s), this.nt.add(s)) : (o.remove(s), this.nt.delete(s)));
    }
    return yA;
  }
});
/*! Bundled license information:

lit-html/directives/class-map.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var W = (t) => (A) => typeof A == "function" ? ((e, i) => (customElements.define(e, i), i))(t, A) : ((e, i) => {
  const { kind: o, elements: s } = i;
  return { kind: o, elements: s, finisher(r) {
    customElements.define(e, r);
  } };
})(t, A), id = (t, A) => A.kind === "method" && A.descriptor && !("value" in A.descriptor) ? sA(L({}, A), { finisher(e) {
  e.createProperty(A.key, t);
} }) : { kind: "field", key: Symbol(), placement: "own", descriptor: {}, originalKey: A.key, initializer() {
  typeof A.initializer == "function" && (this[A.key] = A.initializer.call(this));
}, finisher(e) {
  e.createProperty(A.key, t);
} };
function d(t) {
  return (A, e) => e !== void 0 ? ((i, o, s) => {
    o.constructor.createProperty(s, i);
  })(t, A, e) : id(t, A);
}
function Wt(t) {
  return d(sA(L({}, t), { state: !0 }));
}
var od = ({ finisher: t, descriptor: A }) => (e, i) => {
  var o;
  if (i === void 0) {
    const s = (o = e.originalKey) !== null && o !== void 0 ? o : e.key, r = A != null ? { kind: "method", placement: "prototype", key: s, descriptor: A(e.key) } : sA(L({}, e), { key: s });
    return t != null && (r.finisher = function(n) {
      t(n, s);
    }), r;
  }
  {
    const s = e.constructor;
    A !== void 0 && Object.defineProperty(e, i, A(i)), t?.(s, i);
  }
};
function V(t, A) {
  return od({ descriptor: (e) => {
    const i = { get() {
      var o, s;
      return (s = (o = this.renderRoot) === null || o === void 0 ? void 0 : o.querySelector(t)) !== null && s !== void 0 ? s : null;
    }, enumerable: !0, configurable: !0 };
    if (A) {
      const o = typeof e == "symbol" ? Symbol() : "__" + e;
      i.get = function() {
        var s, r;
        return this[o] === void 0 && (this[o] = (r = (s = this.renderRoot) === null || s === void 0 ? void 0 : s.querySelector(t)) !== null && r !== void 0 ? r : null), this[o];
      };
    }
    return i;
  } });
}
var Do;
((Do = window.HTMLSlotElement) === null || Do === void 0 ? void 0 : Do.prototype.assignedElements) != null;
var P = class extends pe {
  emit(t, A) {
    const e = new CustomEvent(t, L({
      bubbles: !0,
      cancelable: !1,
      composed: !0,
      detail: {}
    }, A));
    return this.dispatchEvent(e), e;
  }
};
I([
  d()
], P.prototype, "dir", 2);
I([
  d()
], P.prototype, "lang", 2);
/*! Bundled license information:

@lit/reactive-element/decorators/custom-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/property.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/state.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/base.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/event-options.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-async.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-all.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-assigned-elements.js:
  (**
   * @license
   * Copyright 2021 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-assigned-nodes.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var eA = class extends P {
  constructor() {
    super(...arguments), this.localize = new XA(this), this.content = "", this.placement = "top", this.disabled = !1, this.distance = 8, this.open = !1, this.skidding = 0, this.trigger = "hover focus", this.hoist = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.handleBlur = this.handleBlur.bind(this), this.handleClick = this.handleClick.bind(this), this.handleFocus = this.handleFocus.bind(this), this.handleKeyDown = this.handleKeyDown.bind(this), this.handleMouseOver = this.handleMouseOver.bind(this), this.handleMouseOut = this.handleMouseOut.bind(this), this.updateComplete.then(() => {
      this.addEventListener("blur", this.handleBlur, !0), this.addEventListener("focus", this.handleFocus, !0), this.addEventListener("click", this.handleClick), this.addEventListener("keydown", this.handleKeyDown), this.addEventListener("mouseover", this.handleMouseOver), this.addEventListener("mouseout", this.handleMouseOut);
    });
  }
  firstUpdated() {
    this.body.hidden = !this.open, this.open && (this.popup.active = !0, this.popup.reposition());
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("blur", this.handleBlur, !0), this.removeEventListener("focus", this.handleFocus, !0), this.removeEventListener("click", this.handleClick), this.removeEventListener("keydown", this.handleKeyDown), this.removeEventListener("mouseover", this.handleMouseOver), this.removeEventListener("mouseout", this.handleMouseOut);
  }
  handleBlur() {
    this.hasTrigger("focus") && this.hide();
  }
  handleClick() {
    this.hasTrigger("click") && (this.open ? this.hide() : this.show());
  }
  handleFocus() {
    this.hasTrigger("focus") && this.show();
  }
  handleKeyDown(t) {
    this.open && t.key === "Escape" && (t.stopPropagation(), this.hide());
  }
  handleMouseOver() {
    if (this.hasTrigger("hover")) {
      const t = rn(getComputedStyle(this).getPropertyValue("--show-delay"));
      clearTimeout(this.hoverTimeout), this.hoverTimeout = window.setTimeout(() => this.show(), t);
    }
  }
  handleMouseOut() {
    if (this.hasTrigger("hover")) {
      const t = rn(getComputedStyle(this).getPropertyValue("--hide-delay"));
      clearTimeout(this.hoverTimeout), this.hoverTimeout = window.setTimeout(() => this.hide(), t);
    }
  }
  hasTrigger(t) {
    return this.trigger.split(" ").includes(t);
  }
  async handleOpenChange() {
    if (this.open) {
      if (this.disabled)
        return;
      this.emit("sl-show"), await NA(this.body), this.body.hidden = !1, this.popup.active = !0;
      const { keyframes: t, options: A } = pA(this, "tooltip.show", { dir: this.localize.dir() });
      await fA(this.popup.popup, t, A), this.emit("sl-after-show");
    } else {
      this.emit("sl-hide"), await NA(this.body);
      const { keyframes: t, options: A } = pA(this, "tooltip.hide", { dir: this.localize.dir() });
      await fA(this.popup.popup, t, A), this.popup.active = !1, this.body.hidden = !0, this.emit("sl-after-hide");
    }
  }
  async handleOptionsChange() {
    this.hasUpdated && (await this.updateComplete, this.popup.reposition());
  }
  handleDisabledChange() {
    this.disabled && this.open && this.hide();
  }
  /** Shows the tooltip. */
  async show() {
    if (!this.open)
      return this.open = !0, jA(this, "sl-after-show");
  }
  /** Hides the tooltip */
  async hide() {
    if (this.open)
      return this.open = !1, jA(this, "sl-after-hide");
  }
  render() {
    return Y`
      <sl-popup
        part="base"
        exportparts="
          popup:base__popup,
          arrow:base__arrow
        "
        class=${rA({
      tooltip: !0,
      "tooltip--open": this.open
    })}
        placement=${this.placement}
        distance=${this.distance}
        skidding=${this.skidding}
        strategy=${this.hoist ? "fixed" : "absolute"}
        flip
        shift
        arrow
      >
        <slot slot="anchor" aria-describedby="tooltip"></slot>

        <slot
          name="content"
          part="body"
          id="tooltip"
          class="tooltip__body"
          role="tooltip"
          aria-live=${this.open ? "polite" : "off"}
        >
          ${this.content}
        </slot>
      </sl-popup>
    `;
  }
};
eA.styles = qC;
I([
  V("slot:not([name])")
], eA.prototype, "defaultSlot", 2);
I([
  V(".tooltip__body")
], eA.prototype, "body", 2);
I([
  V("sl-popup")
], eA.prototype, "popup", 2);
I([
  d()
], eA.prototype, "content", 2);
I([
  d()
], eA.prototype, "placement", 2);
I([
  d({ type: Boolean, reflect: !0 })
], eA.prototype, "disabled", 2);
I([
  d({ type: Number })
], eA.prototype, "distance", 2);
I([
  d({ type: Boolean, reflect: !0 })
], eA.prototype, "open", 2);
I([
  d({ type: Number })
], eA.prototype, "skidding", 2);
I([
  d()
], eA.prototype, "trigger", 2);
I([
  d({ type: Boolean })
], eA.prototype, "hoist", 2);
I([
  q("open", { waitUntilFirstUpdate: !0 })
], eA.prototype, "handleOpenChange", 1);
I([
  q(["content", "distance", "hoist", "placement", "skidding"])
], eA.prototype, "handleOptionsChange", 1);
I([
  q("disabled")
], eA.prototype, "handleDisabledChange", 1);
eA = I([
  W("sl-tooltip")
], eA);
bA("tooltip.show", {
  keyframes: [
    { opacity: 0, scale: 0.8 },
    { opacity: 1, scale: 1 }
  ],
  options: { duration: 150, easing: "ease" }
});
bA("tooltip.hide", {
  keyframes: [
    { opacity: 1, scale: 1 },
    { opacity: 0, scale: 0.8 }
  ],
  options: { duration: 150, easing: "ease" }
});
var sd = $`
  ${Z}

  :host {
    --arrow-color: var(--sl-color-neutral-1000);
    --arrow-size: 6px;

    /*
     * These properties are computed to account for the arrow's dimensions after being rotated 45º. The constant
     * 0.7071 is derived from sin(45), which is the diagonal size of the arrow's container after rotating.
     */
    --arrow-size-diagonal: calc(var(--arrow-size) * 0.7071);
    --arrow-padding-offset: calc(var(--arrow-size-diagonal) - var(--arrow-size));

    display: contents;
  }

  .popup {
    position: absolute;
    isolation: isolate;
    max-width: var(--auto-size-available-width, none);
    max-height: var(--auto-size-available-height, none);
  }

  .popup--fixed {
    position: fixed;
  }

  .popup:not(.popup--active) {
    display: none;
  }

  .popup__arrow {
    position: absolute;
    width: calc(var(--arrow-size-diagonal) * 2);
    height: calc(var(--arrow-size-diagonal) * 2);
    rotate: 45deg;
    background: var(--arrow-color);
    z-index: -1;
  }
`;
function Xt(t) {
  return t.split("-")[1];
}
function Us(t) {
  return t === "y" ? "height" : "width";
}
function zA(t) {
  return t.split("-")[0];
}
function Ae(t) {
  return ["top", "bottom"].includes(zA(t)) ? "x" : "y";
}
function nn(t, A, e) {
  let { reference: i, floating: o } = t;
  const s = i.x + i.width / 2 - o.width / 2, r = i.y + i.height / 2 - o.height / 2, n = Ae(A), l = Us(n), a = i[l] / 2 - o[l] / 2, h = n === "x";
  let g;
  switch (zA(A)) {
    case "top":
      g = { x: s, y: i.y - o.height };
      break;
    case "bottom":
      g = { x: s, y: i.y + i.height };
      break;
    case "right":
      g = { x: i.x + i.width, y: r };
      break;
    case "left":
      g = { x: i.x - o.width, y: r };
      break;
    default:
      g = { x: i.x, y: i.y };
  }
  switch (Xt(A)) {
    case "start":
      g[n] -= a * (e && h ? -1 : 1);
      break;
    case "end":
      g[n] += a * (e && h ? -1 : 1);
  }
  return g;
}
var rd = async (t, A, e) => {
  const { placement: i = "bottom", strategy: o = "absolute", middleware: s = [], platform: r } = e, n = s.filter(Boolean), l = await (r.isRTL == null ? void 0 : r.isRTL(A));
  let a = await r.getElementRects({ reference: t, floating: A, strategy: o }), { x: h, y: g } = nn(a, i, l), c = i, C = {}, B = 0;
  for (let Q = 0; Q < n.length; Q++) {
    const { name: E, fn: f } = n[Q], { x: w, y: v, data: x, reset: N } = await f({ x: h, y: g, initialPlacement: i, placement: c, strategy: o, middlewareData: C, rects: a, platform: r, elements: { reference: t, floating: A } });
    h = w ?? h, g = v ?? g, C = sA(L({}, C), { [E]: L(L({}, C[E]), x) }), N && B <= 50 && (B++, typeof N == "object" && (N.placement && (c = N.placement), N.rects && (a = N.rects === !0 ? await r.getElementRects({ reference: t, floating: A, strategy: o }) : N.rects), { x: h, y: g } = nn(a, c, l)), Q = -1);
  }
  return { x: h, y: g, placement: c, strategy: o, middlewareData: C };
};
function $a(t) {
  return typeof t != "number" ? function(A) {
    return L({ top: 0, right: 0, bottom: 0, left: 0 }, A);
  }(t) : { top: t, right: t, bottom: t, left: t };
}
function Wo(t) {
  return sA(L({}, t), { top: t.y, left: t.x, right: t.x + t.width, bottom: t.y + t.height });
}
async function Fs(t, A) {
  var e;
  A === void 0 && (A = {});
  const { x: i, y: o, platform: s, rects: r, elements: n, strategy: l } = t, { boundary: a = "clippingAncestors", rootBoundary: h = "viewport", elementContext: g = "floating", altBoundary: c = !1, padding: C = 0 } = A, B = $a(C), Q = n[c ? g === "floating" ? "reference" : "floating" : g], E = Wo(await s.getClippingRect({ element: (e = await (s.isElement == null ? void 0 : s.isElement(Q))) == null || e ? Q : Q.contextElement || await (s.getDocumentElement == null ? void 0 : s.getDocumentElement(n.floating)), boundary: a, rootBoundary: h, strategy: l })), f = g === "floating" ? sA(L({}, r.floating), { x: i, y: o }) : r.reference, w = await (s.getOffsetParent == null ? void 0 : s.getOffsetParent(n.floating)), v = await (s.isElement == null ? void 0 : s.isElement(w)) && await (s.getScale == null ? void 0 : s.getScale(w)) || { x: 1, y: 1 }, x = Wo(s.convertOffsetParentRelativeRectToViewportRelativeRect ? await s.convertOffsetParentRelativeRectToViewportRelativeRect({ rect: f, offsetParent: w, strategy: l }) : f);
  return { top: (E.top - x.top + B.top) / v.y, bottom: (x.bottom - E.bottom + B.bottom) / v.y, left: (E.left - x.left + B.left) / v.x, right: (x.right - E.right + B.right) / v.x };
}
var Xo = Math.min, rt = Math.max;
function As(t, A, e) {
  return rt(t, Xo(A, e));
}
var nd = (t) => ({ name: "arrow", options: t, async fn(A) {
  const { element: e, padding: i = 0 } = t || {}, { x: o, y: s, placement: r, rects: n, platform: l } = A;
  if (e == null)
    return {};
  const a = $a(i), h = { x: o, y: s }, g = Ae(r), c = Us(g), C = await l.getDimensions(e), B = g === "y" ? "top" : "left", Q = g === "y" ? "bottom" : "right", E = n.reference[c] + n.reference[g] - h[g] - n.floating[c], f = h[g] - n.reference[g], w = await (l.getOffsetParent == null ? void 0 : l.getOffsetParent(e));
  let v = w ? g === "y" ? w.clientHeight || 0 : w.clientWidth || 0 : 0;
  v === 0 && (v = n.floating[c]);
  const x = E / 2 - f / 2, N = a[B], R = v - C[c] - a[Q], M = v / 2 - C[c] / 2 + x, j = As(N, M, R), lA = Xt(r) != null && M != j && n.reference[c] / 2 - (M < N ? a[B] : a[Q]) - C[c] / 2 < 0;
  return { [g]: h[g] - (lA ? M < N ? N - M : R - M : 0), data: { [g]: j, centerOffset: M - j } };
} }), ad = ["top", "right", "bottom", "left"];
ad.reduce((t, A) => t.concat(A, A + "-start", A + "-end"), []);
var ld = { left: "right", right: "left", bottom: "top", top: "bottom" };
function Di(t) {
  return t.replace(/left|right|bottom|top/g, (A) => ld[A]);
}
function gd(t, A, e) {
  e === void 0 && (e = !1);
  const i = Xt(t), o = Ae(t), s = Us(o);
  let r = o === "x" ? i === (e ? "end" : "start") ? "right" : "left" : i === "start" ? "bottom" : "top";
  return A.reference[s] > A.floating[s] && (r = Di(r)), { main: r, cross: Di(r) };
}
var Id = { start: "end", end: "start" };
function ko(t) {
  return t.replace(/start|end/g, (A) => Id[A]);
}
var cd = function(t) {
  return t === void 0 && (t = {}), { name: "flip", options: t, async fn(A) {
    var e;
    const { placement: i, middlewareData: o, rects: s, initialPlacement: r, platform: n, elements: l } = A, a = t, { mainAxis: h = !0, crossAxis: g = !0, fallbackPlacements: c, fallbackStrategy: C = "bestFit", fallbackAxisSideDirection: B = "none", flipAlignment: Q = !0 } = a, E = Ns(a, ["mainAxis", "crossAxis", "fallbackPlacements", "fallbackStrategy", "fallbackAxisSideDirection", "flipAlignment"]), f = zA(i), w = zA(r) === r, v = await (n.isRTL == null ? void 0 : n.isRTL(l.floating)), x = c || (w || !Q ? [Di(r)] : function(iA) {
      const EA = Di(iA);
      return [ko(iA), EA, ko(EA)];
    }(r));
    c || B === "none" || x.push(...function(iA, EA, JA, uA) {
      const hA = Xt(iA);
      let aA = function(At, ie, eo) {
        const Os = ["left", "right"], Ks = ["right", "left"], fl = ["top", "bottom"], yl = ["bottom", "top"];
        switch (At) {
          case "top":
          case "bottom":
            return eo ? ie ? Ks : Os : ie ? Os : Ks;
          case "left":
          case "right":
            return ie ? fl : yl;
          default:
            return [];
        }
      }(zA(iA), JA === "start", uA);
      return hA && (aA = aA.map((At) => At + "-" + hA), EA && (aA = aA.concat(aA.map(ko)))), aA;
    }(r, Q, B, v));
    const N = [r, ...x], R = await Fs(A, E), M = [];
    let j = ((e = o.flip) == null ? void 0 : e.overflows) || [];
    if (h && M.push(R[f]), g) {
      const { main: iA, cross: EA } = gd(i, s, v);
      M.push(R[iA], R[EA]);
    }
    if (j = [...j, { placement: i, overflows: M }], !M.every((iA) => iA <= 0)) {
      var lA, He;
      const iA = (((lA = o.flip) == null ? void 0 : lA.index) || 0) + 1, EA = N[iA];
      if (EA)
        return { data: { index: iA, overflows: j }, reset: { placement: EA } };
      let JA = (He = j.filter((uA) => uA.overflows[0] <= 0).sort((uA, hA) => uA.overflows[1] - hA.overflows[1])[0]) == null ? void 0 : He.placement;
      if (!JA)
        switch (C) {
          case "bestFit": {
            var Te;
            const uA = (Te = j.map((hA) => [hA.placement, hA.overflows.filter((aA) => aA > 0).reduce((aA, At) => aA + At, 0)]).sort((hA, aA) => hA[1] - aA[1])[0]) == null ? void 0 : Te[0];
            uA && (JA = uA);
            break;
          }
          case "initialPlacement":
            JA = r;
        }
      if (i !== JA)
        return { reset: { placement: JA } };
    }
    return {};
  } };
}, hd = function(t) {
  return t === void 0 && (t = 0), { name: "offset", options: t, async fn(A) {
    const { x: e, y: i } = A, o = await async function(s, r) {
      const { placement: n, platform: l, elements: a } = s, h = await (l.isRTL == null ? void 0 : l.isRTL(a.floating)), g = zA(n), c = Xt(n), C = Ae(n) === "x", B = ["left", "top"].includes(g) ? -1 : 1, Q = h && C ? -1 : 1, E = typeof r == "function" ? r(s) : r;
      let { mainAxis: f, crossAxis: w, alignmentAxis: v } = typeof E == "number" ? { mainAxis: E, crossAxis: 0, alignmentAxis: null } : L({ mainAxis: 0, crossAxis: 0, alignmentAxis: null }, E);
      return c && typeof v == "number" && (w = c === "end" ? -1 * v : v), C ? { x: w * Q, y: f * B } : { x: f * B, y: w * Q };
    }(A, t);
    return { x: e + o.x, y: i + o.y, data: o };
  } };
};
function Cd(t) {
  return t === "x" ? "y" : "x";
}
var dd = function(t) {
  return t === void 0 && (t = {}), { name: "shift", options: t, async fn(A) {
    const { x: e, y: i, placement: o } = A, s = t, { mainAxis: r = !0, crossAxis: n = !1, limiter: l = { fn: (f) => {
      let { x: w, y: v } = f;
      return { x: w, y: v };
    } } } = s, a = Ns(s, ["mainAxis", "crossAxis", "limiter"]), h = { x: e, y: i }, g = await Fs(A, a), c = Ae(zA(o)), C = Cd(c);
    let B = h[c], Q = h[C];
    if (r) {
      const f = c === "y" ? "bottom" : "right";
      B = As(B + g[c === "y" ? "top" : "left"], B, B - g[f]);
    }
    if (n) {
      const f = C === "y" ? "bottom" : "right";
      Q = As(Q + g[C === "y" ? "top" : "left"], Q, Q - g[f]);
    }
    const E = l.fn(sA(L({}, A), { [c]: B, [C]: Q }));
    return sA(L({}, E), { data: { x: E.x - e, y: E.y - i } });
  } };
}, an = function(t) {
  return t === void 0 && (t = {}), { name: "size", options: t, async fn(A) {
    const { placement: e, rects: i, platform: o, elements: s } = A, r = t, { apply: n = () => {
    } } = r, l = Ns(r, ["apply"]), a = await Fs(A, l), h = zA(e), g = Xt(e), c = Ae(e) === "x", { width: C, height: B } = i.floating;
    let Q, E;
    h === "top" || h === "bottom" ? (Q = h, E = g === (await (o.isRTL == null ? void 0 : o.isRTL(s.floating)) ? "start" : "end") ? "left" : "right") : (E = h, Q = g === "end" ? "top" : "bottom");
    const f = B - a[Q], w = C - a[E];
    let v = f, x = w;
    if (c ? x = Xo(C - a.right - a.left, w) : v = Xo(B - a.bottom - a.top, f), !A.middlewareData.shift && !g) {
      const R = rt(a.left, 0), M = rt(a.right, 0), j = rt(a.top, 0), lA = rt(a.bottom, 0);
      c ? x = C - 2 * (R !== 0 || M !== 0 ? R + M : rt(a.left, a.right)) : v = B - 2 * (j !== 0 || lA !== 0 ? j + lA : rt(a.top, a.bottom));
    }
    await n(sA(L({}, A), { availableWidth: x, availableHeight: v }));
    const N = await o.getDimensions(s.floating);
    return C !== N.width || B !== N.height ? { reset: { rects: !0 } } : {};
  } };
};
function gA(t) {
  var A;
  return ((A = t.ownerDocument) == null ? void 0 : A.defaultView) || window;
}
function UA(t) {
  return gA(t).getComputedStyle(t);
}
var ln = Math.min, fe = Math.max, ki = Math.round;
function qa(t) {
  const A = UA(t);
  let e = parseFloat(A.width), i = parseFloat(A.height);
  const o = t.offsetWidth, s = t.offsetHeight, r = ki(e) !== o || ki(i) !== s;
  return r && (e = o, i = s), { width: e, height: i, fallback: r };
}
function ZA(t) {
  return za(t) ? (t.nodeName || "").toLowerCase() : "";
}
var Ze;
function Pa() {
  if (Ze)
    return Ze;
  const t = navigator.userAgentData;
  return t && Array.isArray(t.brands) ? (Ze = t.brands.map((A) => A.brand + "/" + A.version).join(" "), Ze) : navigator.userAgent;
}
function FA(t) {
  return t instanceof gA(t).HTMLElement;
}
function wA(t) {
  return t instanceof gA(t).Element;
}
function za(t) {
  return t instanceof gA(t).Node;
}
function gn(t) {
  return typeof ShadowRoot > "u" ? !1 : t instanceof gA(t).ShadowRoot || t instanceof ShadowRoot;
}
function ji(t) {
  const { overflow: A, overflowX: e, overflowY: i, display: o } = UA(t);
  return /auto|scroll|overlay|hidden|clip/.test(A + i + e) && !["inline", "contents"].includes(o);
}
function Bd(t) {
  return ["table", "td", "th"].includes(ZA(t));
}
function ts(t) {
  const A = /firefox/i.test(Pa()), e = UA(t), i = e.backdropFilter || e.WebkitBackdropFilter;
  return e.transform !== "none" || e.perspective !== "none" || !!i && i !== "none" || A && e.willChange === "filter" || A && !!e.filter && e.filter !== "none" || ["transform", "perspective"].some((o) => e.willChange.includes(o)) || ["paint", "layout", "strict", "content"].some((o) => {
    const s = e.contain;
    return s != null && s.includes(o);
  });
}
function es() {
  return /^((?!chrome|android).)*safari/i.test(Pa());
}
function Gs(t) {
  return ["html", "body", "#document"].includes(ZA(t));
}
function Va(t) {
  return wA(t) ? t : t.contextElement;
}
var ja = { x: 1, y: 1 };
function Gt(t) {
  const A = Va(t);
  if (!FA(A))
    return ja;
  const e = A.getBoundingClientRect(), { width: i, height: o, fallback: s } = qa(A);
  let r = (s ? ki(e.width) : e.width) / i, n = (s ? ki(e.height) : e.height) / o;
  return r && Number.isFinite(r) || (r = 1), n && Number.isFinite(n) || (n = 1), { x: r, y: n };
}
function It(t, A, e, i) {
  var o, s;
  A === void 0 && (A = !1), e === void 0 && (e = !1);
  const r = t.getBoundingClientRect(), n = Va(t);
  let l = ja;
  A && (i ? wA(i) && (l = Gt(i)) : l = Gt(t));
  const a = n ? gA(n) : window, h = es() && e;
  let g = (r.left + (h && ((o = a.visualViewport) == null ? void 0 : o.offsetLeft) || 0)) / l.x, c = (r.top + (h && ((s = a.visualViewport) == null ? void 0 : s.offsetTop) || 0)) / l.y, C = r.width / l.x, B = r.height / l.y;
  if (n) {
    const Q = gA(n), E = i && wA(i) ? gA(i) : i;
    let f = Q.frameElement;
    for (; f && i && E !== Q; ) {
      const w = Gt(f), v = f.getBoundingClientRect(), x = getComputedStyle(f);
      v.x += (f.clientLeft + parseFloat(x.paddingLeft)) * w.x, v.y += (f.clientTop + parseFloat(x.paddingTop)) * w.y, g *= w.x, c *= w.y, C *= w.x, B *= w.y, g += v.x, c += v.y, f = gA(f).frameElement;
    }
  }
  return { width: C, height: B, top: c, right: g + C, bottom: c + B, left: g, x: g, y: c };
}
function VA(t) {
  return ((za(t) ? t.ownerDocument : t.document) || window.document).documentElement;
}
function Zi(t) {
  return wA(t) ? { scrollLeft: t.scrollLeft, scrollTop: t.scrollTop } : { scrollLeft: t.pageXOffset, scrollTop: t.pageYOffset };
}
function Za(t) {
  return It(VA(t)).left + Zi(t).scrollLeft;
}
function Ue(t) {
  if (ZA(t) === "html")
    return t;
  const A = t.assignedSlot || t.parentNode || gn(t) && t.host || VA(t);
  return gn(A) ? A.host : A;
}
function Wa(t) {
  const A = Ue(t);
  return Gs(A) ? A.ownerDocument.body : FA(A) && ji(A) ? A : Wa(A);
}
function ye(t, A) {
  var e;
  A === void 0 && (A = []);
  const i = Wa(t), o = i === ((e = t.ownerDocument) == null ? void 0 : e.body), s = gA(i);
  return o ? A.concat(s, s.visualViewport || [], ji(i) ? i : []) : A.concat(i, ye(i));
}
function In(t, A, e) {
  let i;
  if (A === "viewport")
    i = function(r, n) {
      const l = gA(r), a = VA(r), h = l.visualViewport;
      let g = a.clientWidth, c = a.clientHeight, C = 0, B = 0;
      if (h) {
        g = h.width, c = h.height;
        const Q = es();
        (!Q || Q && n === "fixed") && (C = h.offsetLeft, B = h.offsetTop);
      }
      return { width: g, height: c, x: C, y: B };
    }(t, e);
  else if (A === "document")
    i = function(r) {
      const n = VA(r), l = Zi(r), a = r.ownerDocument.body, h = fe(n.scrollWidth, n.clientWidth, a.scrollWidth, a.clientWidth), g = fe(n.scrollHeight, n.clientHeight, a.scrollHeight, a.clientHeight);
      let c = -l.scrollLeft + Za(r);
      const C = -l.scrollTop;
      return UA(a).direction === "rtl" && (c += fe(n.clientWidth, a.clientWidth) - h), { width: h, height: g, x: c, y: C };
    }(VA(t));
  else if (wA(A))
    i = function(r, n) {
      const l = It(r, !0, n === "fixed"), a = l.top + r.clientTop, h = l.left + r.clientLeft, g = FA(r) ? Gt(r) : { x: 1, y: 1 };
      return { width: r.clientWidth * g.x, height: r.clientHeight * g.y, x: h * g.x, y: a * g.y };
    }(A, e);
  else {
    const r = L({}, A);
    if (es()) {
      var o, s;
      const n = gA(t);
      r.x -= ((o = n.visualViewport) == null ? void 0 : o.offsetLeft) || 0, r.y -= ((s = n.visualViewport) == null ? void 0 : s.offsetTop) || 0;
    }
    i = r;
  }
  return Wo(i);
}
function cn(t, A) {
  return FA(t) && UA(t).position !== "fixed" ? A ? A(t) : t.offsetParent : null;
}
function hn(t, A) {
  const e = gA(t);
  let i = cn(t, A);
  for (; i && Bd(i) && UA(i).position === "static"; )
    i = cn(i, A);
  return i && (ZA(i) === "html" || ZA(i) === "body" && UA(i).position === "static" && !ts(i)) ? e : i || function(o) {
    let s = Ue(o);
    for (; FA(s) && !Gs(s); ) {
      if (ts(s))
        return s;
      s = Ue(s);
    }
    return null;
  }(t) || e;
}
function Qd(t, A, e) {
  const i = FA(A), o = VA(A), s = It(t, !0, e === "fixed", A);
  let r = { scrollLeft: 0, scrollTop: 0 };
  const n = { x: 0, y: 0 };
  if (i || !i && e !== "fixed")
    if ((ZA(A) !== "body" || ji(o)) && (r = Zi(A)), FA(A)) {
      const l = It(A, !0);
      n.x = l.x + A.clientLeft, n.y = l.y + A.clientTop;
    } else
      o && (n.x = Za(o));
  return { x: s.left + r.scrollLeft - n.x, y: s.top + r.scrollTop - n.y, width: s.width, height: s.height };
}
var gi = { getClippingRect: function(t) {
  let { element: A, boundary: e, rootBoundary: i, strategy: o } = t;
  const s = e === "clippingAncestors" ? function(a, h) {
    const g = h.get(a);
    if (g)
      return g;
    let c = ye(a).filter((E) => wA(E) && ZA(E) !== "body"), C = null;
    const B = UA(a).position === "fixed";
    let Q = B ? Ue(a) : a;
    for (; wA(Q) && !Gs(Q); ) {
      const E = UA(Q), f = ts(Q);
      E.position === "fixed" ? C = null : (B ? f || C : f || E.position !== "static" || !C || !["absolute", "fixed"].includes(C.position)) ? C = E : c = c.filter((w) => w !== Q), Q = Ue(Q);
    }
    return h.set(a, c), c;
  }(A, this._c) : [].concat(e), r = [...s, i], n = r[0], l = r.reduce((a, h) => {
    const g = In(A, h, o);
    return a.top = fe(g.top, a.top), a.right = ln(g.right, a.right), a.bottom = ln(g.bottom, a.bottom), a.left = fe(g.left, a.left), a;
  }, In(A, n, o));
  return { width: l.right - l.left, height: l.bottom - l.top, x: l.left, y: l.top };
}, convertOffsetParentRelativeRectToViewportRelativeRect: function(t) {
  let { rect: A, offsetParent: e, strategy: i } = t;
  const o = FA(e), s = VA(e);
  if (e === s)
    return A;
  let r = { scrollLeft: 0, scrollTop: 0 }, n = { x: 1, y: 1 };
  const l = { x: 0, y: 0 };
  if ((o || !o && i !== "fixed") && ((ZA(e) !== "body" || ji(s)) && (r = Zi(e)), FA(e))) {
    const a = It(e);
    n = Gt(e), l.x = a.x + e.clientLeft, l.y = a.y + e.clientTop;
  }
  return { width: A.width * n.x, height: A.height * n.y, x: A.x * n.x - r.scrollLeft * n.x + l.x, y: A.y * n.y - r.scrollTop * n.y + l.y };
}, isElement: wA, getDimensions: function(t) {
  return FA(t) ? qa(t) : t.getBoundingClientRect();
}, getOffsetParent: hn, getDocumentElement: VA, getScale: Gt, async getElementRects(t) {
  let { reference: A, floating: e, strategy: i } = t;
  const o = this.getOffsetParent || hn, s = this.getDimensions;
  return { reference: Qd(A, await o(e), i), floating: L({ x: 0, y: 0 }, await s(e)) };
}, getClientRects: (t) => Array.from(t.getClientRects()), isRTL: (t) => UA(t).direction === "rtl" };
function Ed(t, A, e, i) {
  i === void 0 && (i = {});
  const { ancestorScroll: o = !0, ancestorResize: s = !0, elementResize: r = !0, animationFrame: n = !1 } = i, l = o && !n, a = l || s ? [...wA(t) ? ye(t) : t.contextElement ? ye(t.contextElement) : [], ...ye(A)] : [];
  a.forEach((C) => {
    l && C.addEventListener("scroll", e, { passive: !0 }), s && C.addEventListener("resize", e);
  });
  let h, g = null;
  if (r) {
    let C = !0;
    g = new ResizeObserver(() => {
      C || e(), C = !1;
    }), wA(t) && !n && g.observe(t), wA(t) || !t.contextElement || n || g.observe(t.contextElement), g.observe(A);
  }
  let c = n ? It(t) : null;
  return n && function C() {
    const B = It(t);
    !c || B.x === c.x && B.y === c.y && B.width === c.width && B.height === c.height || e(), c = B, h = requestAnimationFrame(C);
  }(), e(), () => {
    var C;
    a.forEach((B) => {
      l && B.removeEventListener("scroll", e), s && B.removeEventListener("resize", e);
    }), (C = g) == null || C.disconnect(), g = null, n && cancelAnimationFrame(h);
  };
}
var ud = (t, A, e) => {
  const i = /* @__PURE__ */ new Map(), o = L({ platform: gi }, e), s = sA(L({}, o.platform), { _c: i });
  return rd(t, A, sA(L({}, o), { platform: s }));
};
function pd(t) {
  return fd(t);
}
function So(t) {
  return t.assignedSlot ? t.assignedSlot : t.parentNode instanceof ShadowRoot ? t.parentNode.host : t.parentNode;
}
function fd(t) {
  for (let A = t; A; A = So(A))
    if (A instanceof Element && getComputedStyle(A).display === "none")
      return null;
  for (let A = So(t); A; A = So(A)) {
    if (!(A instanceof Element))
      continue;
    const e = getComputedStyle(A);
    if (e.display !== "contents" && (e.position !== "static" || e.filter !== "none" || A.tagName === "BODY"))
      return A;
  }
  return null;
}
var G = class extends P {
  constructor() {
    super(...arguments), this.active = !1, this.placement = "top", this.strategy = "absolute", this.distance = 0, this.skidding = 0, this.arrow = !1, this.arrowPlacement = "anchor", this.arrowPadding = 10, this.flip = !1, this.flipFallbackPlacements = "", this.flipFallbackStrategy = "best-fit", this.flipPadding = 0, this.shift = !1, this.shiftPadding = 0, this.autoSizePadding = 0;
  }
  async connectedCallback() {
    super.connectedCallback(), await this.updateComplete, this.start();
  }
  disconnectedCallback() {
    this.stop();
  }
  async updated(t) {
    super.updated(t), t.has("active") && (this.active ? this.start() : this.stop()), t.has("anchor") && this.handleAnchorChange(), this.active && (await this.updateComplete, this.reposition());
  }
  async handleAnchorChange() {
    if (await this.stop(), this.anchor && typeof this.anchor == "string") {
      const t = this.getRootNode();
      this.anchorEl = t.getElementById(this.anchor);
    } else
      this.anchor instanceof Element ? this.anchorEl = this.anchor : this.anchorEl = this.querySelector('[slot="anchor"]');
    if (this.anchorEl instanceof HTMLSlotElement && (this.anchorEl = this.anchorEl.assignedElements({ flatten: !0 })[0]), !this.anchorEl)
      throw new Error(
        "Invalid anchor element: no anchor could be found using the anchor slot or the anchor attribute."
      );
    this.start();
  }
  start() {
    this.anchorEl && (this.cleanup = Ed(this.anchorEl, this.popup, () => {
      this.reposition();
    }));
  }
  async stop() {
    return new Promise((t) => {
      this.cleanup ? (this.cleanup(), this.cleanup = void 0, this.removeAttribute("data-current-placement"), this.style.removeProperty("--auto-size-available-width"), this.style.removeProperty("--auto-size-available-height"), requestAnimationFrame(() => t())) : t();
    });
  }
  /** Forces the popup to recalculate and reposition itself. */
  reposition() {
    if (!this.active || !this.anchorEl)
      return;
    const t = [
      // The offset middleware goes first
      hd({ mainAxis: this.distance, crossAxis: this.skidding })
    ];
    this.sync ? t.push(
      an({
        apply: ({ rects: e }) => {
          const i = this.sync === "width" || this.sync === "both", o = this.sync === "height" || this.sync === "both";
          this.popup.style.width = i ? `${e.reference.width}px` : "", this.popup.style.height = o ? `${e.reference.height}px` : "";
        }
      })
    ) : (this.popup.style.width = "", this.popup.style.height = ""), this.flip && t.push(
      cd({
        boundary: this.flipBoundary,
        // @ts-expect-error - We're converting a string attribute to an array here
        fallbackPlacements: this.flipFallbackPlacements,
        fallbackStrategy: this.flipFallbackStrategy === "best-fit" ? "bestFit" : "initialPlacement",
        padding: this.flipPadding
      })
    ), this.shift && t.push(
      dd({
        boundary: this.shiftBoundary,
        padding: this.shiftPadding
      })
    ), this.autoSize ? t.push(
      an({
        boundary: this.autoSizeBoundary,
        padding: this.autoSizePadding,
        apply: ({ availableWidth: e, availableHeight: i }) => {
          this.autoSize === "vertical" || this.autoSize === "both" ? this.style.setProperty("--auto-size-available-height", `${i}px`) : this.style.removeProperty("--auto-size-available-height"), this.autoSize === "horizontal" || this.autoSize === "both" ? this.style.setProperty("--auto-size-available-width", `${e}px`) : this.style.removeProperty("--auto-size-available-width");
        }
      })
    ) : (this.style.removeProperty("--auto-size-available-width"), this.style.removeProperty("--auto-size-available-height")), this.arrow && t.push(
      nd({
        element: this.arrowEl,
        padding: this.arrowPadding
      })
    );
    const A = this.strategy === "absolute" ? (e) => gi.getOffsetParent(e, pd) : gi.getOffsetParent;
    ud(this.anchorEl, this.popup, {
      placement: this.placement,
      middleware: t,
      strategy: this.strategy,
      platform: sA(L({}, gi), {
        getOffsetParent: A
      })
    }).then(({ x: e, y: i, middlewareData: o, placement: s }) => {
      const r = getComputedStyle(this).direction === "rtl", n = { top: "bottom", right: "left", bottom: "top", left: "right" }[s.split("-")[0]];
      if (this.setAttribute("data-current-placement", s), Object.assign(this.popup.style, {
        left: `${e}px`,
        top: `${i}px`
      }), this.arrow) {
        const l = o.arrow.x, a = o.arrow.y;
        let h = "", g = "", c = "", C = "";
        if (this.arrowPlacement === "start") {
          const B = typeof l == "number" ? `calc(${this.arrowPadding}px - var(--arrow-padding-offset))` : "";
          h = typeof a == "number" ? `calc(${this.arrowPadding}px - var(--arrow-padding-offset))` : "", g = r ? B : "", C = r ? "" : B;
        } else if (this.arrowPlacement === "end") {
          const B = typeof l == "number" ? `calc(${this.arrowPadding}px - var(--arrow-padding-offset))` : "";
          g = r ? "" : B, C = r ? B : "", c = typeof a == "number" ? `calc(${this.arrowPadding}px - var(--arrow-padding-offset))` : "";
        } else
          this.arrowPlacement === "center" ? (C = typeof l == "number" ? "calc(50% - var(--arrow-size-diagonal))" : "", h = typeof a == "number" ? "calc(50% - var(--arrow-size-diagonal))" : "") : (C = typeof l == "number" ? `${l}px` : "", h = typeof a == "number" ? `${a}px` : "");
        Object.assign(this.arrowEl.style, {
          top: h,
          right: g,
          bottom: c,
          left: C,
          [n]: "calc(var(--arrow-size-diagonal) * -1)"
        });
      }
    }), this.emit("sl-reposition");
  }
  render() {
    return Y`
      <slot name="anchor" @slotchange=${this.handleAnchorChange}></slot>

      <div
        part="popup"
        class=${rA({
      popup: !0,
      "popup--active": this.active,
      "popup--fixed": this.strategy === "fixed",
      "popup--has-arrow": this.arrow
    })}
      >
        <slot></slot>
        ${this.arrow ? Y`<div part="arrow" class="popup__arrow" role="presentation"></div>` : ""}
      </div>
    `;
  }
};
G.styles = sd;
I([
  V(".popup")
], G.prototype, "popup", 2);
I([
  V(".popup__arrow")
], G.prototype, "arrowEl", 2);
I([
  d()
], G.prototype, "anchor", 2);
I([
  d({ type: Boolean, reflect: !0 })
], G.prototype, "active", 2);
I([
  d({ reflect: !0 })
], G.prototype, "placement", 2);
I([
  d({ reflect: !0 })
], G.prototype, "strategy", 2);
I([
  d({ type: Number })
], G.prototype, "distance", 2);
I([
  d({ type: Number })
], G.prototype, "skidding", 2);
I([
  d({ type: Boolean })
], G.prototype, "arrow", 2);
I([
  d({ attribute: "arrow-placement" })
], G.prototype, "arrowPlacement", 2);
I([
  d({ attribute: "arrow-padding", type: Number })
], G.prototype, "arrowPadding", 2);
I([
  d({ type: Boolean })
], G.prototype, "flip", 2);
I([
  d({
    attribute: "flip-fallback-placements",
    converter: {
      fromAttribute: (t) => t.split(" ").map((A) => A.trim()).filter((A) => A !== ""),
      toAttribute: (t) => t.join(" ")
    }
  })
], G.prototype, "flipFallbackPlacements", 2);
I([
  d({ attribute: "flip-fallback-strategy" })
], G.prototype, "flipFallbackStrategy", 2);
I([
  d({ type: Object })
], G.prototype, "flipBoundary", 2);
I([
  d({ attribute: "flip-padding", type: Number })
], G.prototype, "flipPadding", 2);
I([
  d({ type: Boolean })
], G.prototype, "shift", 2);
I([
  d({ type: Object })
], G.prototype, "shiftBoundary", 2);
I([
  d({ attribute: "shift-padding", type: Number })
], G.prototype, "shiftPadding", 2);
I([
  d({ attribute: "auto-size" })
], G.prototype, "autoSize", 2);
I([
  d()
], G.prototype, "sync", 2);
I([
  d({ type: Object })
], G.prototype, "autoSizeBoundary", 2);
I([
  d({ attribute: "auto-size-padding", type: Number })
], G.prototype, "autoSizePadding", 2);
G = I([
  W("sl-popup")
], G);
var is = "";
function Cn(t) {
  is = t;
}
function yd(t = "") {
  if (!is) {
    const A = [...document.getElementsByTagName("script")], e = A.find((i) => i.hasAttribute("data-shoelace"));
    if (e)
      Cn(e.getAttribute("data-shoelace"));
    else {
      const i = A.find((s) => /shoelace(\.min)?\.js($|\?)/.test(s.src) || /shoelace-autoloader(\.min)?\.js($|\?)/.test(s.src));
      let o = "";
      i && (o = i.getAttribute("src")), Cn(o.split("/").slice(0, -1).join("/"));
    }
  }
  return is.replace(/\/$/, "") + (t ? `/${t.replace(/^\//, "")}` : "");
}
var wd = {
  name: "default",
  resolver: (t) => yd(`assets/icons/${t}.svg`)
}, md = wd, dn = {
  caret: `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="6 9 12 15 18 9"></polyline>
    </svg>
  `,
  check: `
    <svg part="checked-icon" class="checkbox__icon" viewBox="0 0 16 16">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">
        <g stroke="currentColor" stroke-width="2">
          <g transform="translate(3.428571, 3.428571)">
            <path d="M0,5.71428571 L3.42857143,9.14285714"></path>
            <path d="M9.14285714,0 L3.42857143,9.14285714"></path>
          </g>
        </g>
      </g>
    </svg>
  `,
  "chevron-down": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-down" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
    </svg>
  `,
  "chevron-left": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-left" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
    </svg>
  `,
  "chevron-right": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
    </svg>
  `,
  eye: `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
      <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
      <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
    </svg>
  `,
  "eye-slash": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-slash" viewBox="0 0 16 16">
      <path d="M13.359 11.238C15.06 9.72 16 8 16 8s-3-5.5-8-5.5a7.028 7.028 0 0 0-2.79.588l.77.771A5.944 5.944 0 0 1 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.134 13.134 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755-.165.165-.337.328-.517.486l.708.709z"/>
      <path d="M11.297 9.176a3.5 3.5 0 0 0-4.474-4.474l.823.823a2.5 2.5 0 0 1 2.829 2.829l.822.822zm-2.943 1.299.822.822a3.5 3.5 0 0 1-4.474-4.474l.823.823a2.5 2.5 0 0 0 2.829 2.829z"/>
      <path d="M3.35 5.47c-.18.16-.353.322-.518.487A13.134 13.134 0 0 0 1.172 8l.195.288c.335.48.83 1.12 1.465 1.755C4.121 11.332 5.881 12.5 8 12.5c.716 0 1.39-.133 2.02-.36l.77.772A7.029 7.029 0 0 1 8 13.5C3 13.5 0 8 0 8s.939-1.721 2.641-3.238l.708.709zm10.296 8.884-12-12 .708-.708 12 12-.708.708z"/>
    </svg>
  `,
  eyedropper: `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eyedropper" viewBox="0 0 16 16">
      <path d="M13.354.646a1.207 1.207 0 0 0-1.708 0L8.5 3.793l-.646-.647a.5.5 0 1 0-.708.708L8.293 5l-7.147 7.146A.5.5 0 0 0 1 12.5v1.793l-.854.853a.5.5 0 1 0 .708.707L1.707 15H3.5a.5.5 0 0 0 .354-.146L11 7.707l1.146 1.147a.5.5 0 0 0 .708-.708l-.647-.646 3.147-3.146a1.207 1.207 0 0 0 0-1.708l-2-2zM2 12.707l7-7L10.293 7l-7 7H2v-1.293z"></path>
    </svg>
  `,
  "grip-vertical": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
      <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"></path>
    </svg>
  `,
  indeterminate: `
    <svg part="indeterminate-icon" class="checkbox__icon" viewBox="0 0 16 16">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">
        <g stroke="currentColor" stroke-width="2">
          <g transform="translate(2.285714, 6.857143)">
            <path d="M10.2857143,1.14285714 L1.14285714,1.14285714"></path>
          </g>
        </g>
      </g>
    </svg>
  `,
  "person-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
      <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
    </svg>
  `,
  "play-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16">
      <path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"></path>
    </svg>
  `,
  "pause-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pause-fill" viewBox="0 0 16 16">
      <path d="M5.5 3.5A1.5 1.5 0 0 1 7 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5zm5 0A1.5 1.5 0 0 1 12 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5z"></path>
    </svg>
  `,
  radio: `
    <svg part="checked-icon" class="radio__icon" viewBox="0 0 16 16">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g fill="currentColor">
          <circle cx="8" cy="8" r="3.42857143"></circle>
        </g>
      </g>
    </svg>
  `,
  "star-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
      <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
    </svg>
  `,
  "x-lg": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
      <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
    </svg>
  `,
  "x-circle-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"></path>
    </svg>
  `
}, vd = {
  name: "system",
  resolver: (t) => t in dn ? `data:image/svg+xml,${encodeURIComponent(dn[t])}` : ""
}, bd = vd, Dd = [md, bd], os = [];
function kd(t) {
  os.push(t);
}
function Sd(t) {
  os = os.filter((A) => A !== t);
}
function Bn(t) {
  return Dd.find((A) => A.name === t);
}
var xd = $`
  ${Z}

  :host {
    display: inline-block;
    width: 1em;
    height: 1em;
    box-sizing: content-box !important;
  }

  svg {
    display: block;
    height: 100%;
    width: 100%;
  }
`, ae = Symbol(), We = Symbol(), xo, No = /* @__PURE__ */ new Map(), mA = class extends P {
  constructor() {
    super(...arguments), this.svg = null, this.label = "", this.library = "default";
  }
  /** Given a URL, this function returns the resulting SVG element or an appropriate error symbol. */
  static async resolveIcon(t) {
    var A;
    let e;
    try {
      if (e = await fetch(t, { mode: "cors" }), !e.ok)
        return e.status === 410 ? ae : We;
    } catch {
      return We;
    }
    try {
      const i = document.createElement("div");
      i.innerHTML = await e.text();
      const o = i.firstElementChild;
      if (((A = o?.tagName) == null ? void 0 : A.toLowerCase()) !== "svg")
        return ae;
      xo || (xo = new DOMParser());
      const r = xo.parseFromString(o.outerHTML, "text/html").body.querySelector("svg");
      return r ? (r.part.add("svg"), document.adoptNode(r)) : ae;
    } catch {
      return ae;
    }
  }
  connectedCallback() {
    super.connectedCallback(), kd(this);
  }
  firstUpdated() {
    this.setIcon();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), Sd(this);
  }
  getUrl() {
    const t = Bn(this.library);
    return this.name && t ? t.resolver(this.name) : this.src;
  }
  handleLabelChange() {
    typeof this.label == "string" && this.label.length > 0 ? (this.setAttribute("role", "img"), this.setAttribute("aria-label", this.label), this.removeAttribute("aria-hidden")) : (this.removeAttribute("role"), this.removeAttribute("aria-label"), this.setAttribute("aria-hidden", "true"));
  }
  async setIcon() {
    var t;
    const A = Bn(this.library), e = this.getUrl();
    if (!e) {
      this.svg = null;
      return;
    }
    let i = No.get(e);
    i || (i = mA.resolveIcon(e), No.set(e, i));
    const o = await i;
    if (o === We && No.delete(e), e === this.getUrl())
      switch (o) {
        case We:
        case ae:
          this.svg = null, this.emit("sl-error");
          break;
        default:
          this.svg = o.cloneNode(!0), (t = A?.mutator) == null || t.call(A, this.svg), this.emit("sl-load");
      }
  }
  render() {
    return this.svg;
  }
};
mA.styles = xd;
I([
  Wt()
], mA.prototype, "svg", 2);
I([
  d({ reflect: !0 })
], mA.prototype, "name", 2);
I([
  d()
], mA.prototype, "src", 2);
I([
  d()
], mA.prototype, "label", 2);
I([
  d({ reflect: !0 })
], mA.prototype, "library", 2);
I([
  q("label")
], mA.prototype, "handleLabelChange", 1);
I([
  q(["name", "src", "library"])
], mA.prototype, "setIcon", 1);
mA = I([
  W("sl-icon")
], mA);
var Le = globalThis && globalThis.__decorate || function(t, A, e, i) {
  var o = arguments.length, s = o < 3 ? A : i === null ? i = Object.getOwnPropertyDescriptor(A, e) : i, r;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function")
    s = Reflect.decorate(t, A, e, i);
  else
    for (var n = t.length - 1; n >= 0; n--)
      (r = t[n]) && (s = (o < 3 ? r(s) : o > 3 ? r(A, e, s) : r(A, e)) || s);
  return o > 3 && s && Object.defineProperty(A, e, s), s;
};
let ct = class extends F {
  constructor() {
    super(...arguments), this.tooltip = !1;
  }
  get _iconSize() {
    return this.iconSize ? this.iconSize : this.tooltip !== !1 ? "32px" : "64px";
  }
  renderIcon() {
    return p`
      <sl-icon
        style="color: red; height: ${this._iconSize}; width: ${this._iconSize}; margin-bottom: 8px;"
        src="${HA(Da)}"
      ></sl-icon>
    `;
  }
  renderFull() {
    return p` <div class="column center-content" style="flex: 1">
      ${this.renderIcon()}
      <div style="width: 500px; text-align: center" class="column">
        ${this.headline ? p` <span style="margin-bottom: 8px">${this.headline} </span>` : p``}
        <span class="placeholder">${this.error} </span>
      </div>
    </div>`;
  }
  renderTooltip() {
    return p`
      <sl-tooltip hoist .content=${this.headline ? this.headline : this.error}>
        ${this.renderIcon()}</sl-tooltip
      >
    `;
  }
  render() {
    return this.tooltip !== !1 ? this.renderTooltip() : this.renderFull();
  }
};
ct.styles = [
  QA,
  z`
      :host {
        display: flex;
        flex: 1;
      }
    `
];
Le([
  y({ attribute: "tooltip" })
], ct.prototype, "tooltip", void 0);
Le([
  y()
], ct.prototype, "headline", void 0);
Le([
  y()
], ct.prototype, "error", void 0);
Le([
  y({ attribute: "icon-size" })
], ct.prototype, "iconSize", void 0);
ct = Le([
  H("display-error")
], ct);
var Nd = $`
  ${Z}

  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.01em, 2.75em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.01em, 2.75em;
    }
  }
`, ss = class extends P {
  constructor() {
    super(...arguments), this.localize = new XA(this);
  }
  render() {
    return Y`
      <svg part="base" class="spinner" role="progressbar" aria-valuetext=${this.localize.term("loading")}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `;
  }
};
ss.styles = Nd;
ss = I([
  W("sl-spinner")
], ss);
var le = /* @__PURE__ */ new WeakMap(), ge = /* @__PURE__ */ new WeakMap(), Uo = /* @__PURE__ */ new WeakSet(), Xe = /* @__PURE__ */ new WeakMap(), Rs = class {
  constructor(t, A) {
    (this.host = t).addController(this), this.options = L({
      form: (e) => {
        if (e.hasAttribute("form") && e.getAttribute("form") !== "") {
          const i = e.getRootNode(), o = e.getAttribute("form");
          if (o)
            return i.getElementById(o);
        }
        return e.closest("form");
      },
      name: (e) => e.name,
      value: (e) => e.value,
      defaultValue: (e) => e.defaultValue,
      disabled: (e) => {
        var i;
        return (i = e.disabled) != null ? i : !1;
      },
      reportValidity: (e) => typeof e.reportValidity == "function" ? e.reportValidity() : !0,
      setValue: (e, i) => e.value = i,
      assumeInteractionOn: ["sl-input"]
    }, A), this.handleFormData = this.handleFormData.bind(this), this.handleFormSubmit = this.handleFormSubmit.bind(this), this.handleFormReset = this.handleFormReset.bind(this), this.reportFormValidity = this.reportFormValidity.bind(this), this.handleInteraction = this.handleInteraction.bind(this);
  }
  hostConnected() {
    const t = this.options.form(this.host);
    t && this.attachForm(t), Xe.set(this.host, []), this.options.assumeInteractionOn.forEach((A) => {
      this.host.addEventListener(A, this.handleInteraction);
    });
  }
  hostDisconnected() {
    this.detachForm(), Xe.delete(this.host), this.options.assumeInteractionOn.forEach((t) => {
      this.host.removeEventListener(t, this.handleInteraction);
    });
  }
  hostUpdated() {
    const t = this.options.form(this.host);
    t || this.detachForm(), t && this.form !== t && (this.detachForm(), this.attachForm(t)), this.host.hasUpdated && this.setValidity(this.host.validity.valid);
  }
  attachForm(t) {
    t ? (this.form = t, le.has(this.form) ? le.get(this.form).add(this.host) : le.set(this.form, /* @__PURE__ */ new Set([this.host])), this.form.addEventListener("formdata", this.handleFormData), this.form.addEventListener("submit", this.handleFormSubmit), this.form.addEventListener("reset", this.handleFormReset), ge.has(this.form) || (ge.set(this.form, this.form.reportValidity), this.form.reportValidity = () => this.reportFormValidity())) : this.form = void 0;
  }
  detachForm() {
    var t;
    this.form && ((t = le.get(this.form)) == null || t.delete(this.host), this.form.removeEventListener("formdata", this.handleFormData), this.form.removeEventListener("submit", this.handleFormSubmit), this.form.removeEventListener("reset", this.handleFormReset), ge.has(this.form) && (this.form.reportValidity = ge.get(this.form), ge.delete(this.form))), this.form = void 0;
  }
  handleFormData(t) {
    const A = this.options.disabled(this.host), e = this.options.name(this.host), i = this.options.value(this.host), o = this.host.tagName.toLowerCase() === "sl-button";
    !A && !o && typeof e == "string" && e.length > 0 && typeof i < "u" && (Array.isArray(i) ? i.forEach((s) => {
      t.formData.append(e, s.toString());
    }) : t.formData.append(e, i.toString()));
  }
  handleFormSubmit(t) {
    var A;
    const e = this.options.disabled(this.host), i = this.options.reportValidity;
    this.form && !this.form.noValidate && ((A = le.get(this.form)) == null || A.forEach((o) => {
      this.setUserInteracted(o, !0);
    })), this.form && !this.form.noValidate && !e && !i(this.host) && (t.preventDefault(), t.stopImmediatePropagation());
  }
  handleFormReset() {
    this.options.setValue(this.host, this.options.defaultValue(this.host)), this.setUserInteracted(this.host, !1), Xe.set(this.host, []);
  }
  handleInteraction(t) {
    const A = Xe.get(this.host);
    A.includes(t.type) || A.push(t.type), A.length === this.options.assumeInteractionOn.length && this.setUserInteracted(this.host, !0);
  }
  reportFormValidity() {
    if (this.form && !this.form.noValidate) {
      const t = this.form.querySelectorAll("*");
      for (const A of t)
        if (typeof A.reportValidity == "function" && !A.reportValidity())
          return !1;
    }
    return !0;
  }
  setUserInteracted(t, A) {
    A ? Uo.add(t) : Uo.delete(t), t.requestUpdate();
  }
  doAction(t, A) {
    if (this.form) {
      const e = document.createElement("button");
      e.type = t, e.style.position = "absolute", e.style.width = "0", e.style.height = "0", e.style.clipPath = "inset(50%)", e.style.overflow = "hidden", e.style.whiteSpace = "nowrap", A && (e.name = A.name, e.value = A.value, ["formaction", "formenctype", "formmethod", "formnovalidate", "formtarget"].forEach((i) => {
        A.hasAttribute(i) && e.setAttribute(i, A.getAttribute(i));
      })), this.form.append(e), e.click(), e.remove();
    }
  }
  /** Returns the associated `<form>` element, if one exists. */
  getForm() {
    var t;
    return (t = this.form) != null ? t : null;
  }
  /** Resets the form, restoring all the control to their default value */
  reset(t) {
    this.doAction("reset", t);
  }
  /** Submits the form, triggering validation and form data injection. */
  submit(t) {
    this.doAction("submit", t);
  }
  /**
   * Synchronously sets the form control's validity. Call this when you know the future validity but need to update
   * the host element immediately, i.e. before Lit updates the component in the next update.
   */
  setValidity(t) {
    const A = this.host, e = !!Uo.has(A), i = !!A.required;
    A.toggleAttribute("data-required", i), A.toggleAttribute("data-optional", !i), A.toggleAttribute("data-invalid", !t), A.toggleAttribute("data-valid", t), A.toggleAttribute("data-user-invalid", !t && e), A.toggleAttribute("data-user-valid", t && e);
  }
  /**
   * Updates the form control's validity based on the current value of `host.validity.valid`. Call this when anything
   * that affects constraint validation changes so the component receives the correct validity states.
   */
  updateValidity() {
    const t = this.host;
    this.setValidity(t.validity.valid);
  }
  /**
   * Dispatches a non-bubbling, cancelable custom event of type `sl-invalid`.
   * If the `sl-invalid` event will be cancelled then the original `invalid`
   * event (which may have been passed as argument) will also be cancelled.
   * If no original `invalid` event has been passed then the `sl-invalid`
   * event will be cancelled before being dispatched.
   */
  emitInvalidEvent(t) {
    const A = new CustomEvent("sl-invalid", {
      bubbles: !1,
      composed: !1,
      cancelable: !0,
      detail: {}
    });
    t || A.preventDefault(), this.host.dispatchEvent(A) || t?.preventDefault();
  }
}, Ms = Object.freeze({
  badInput: !1,
  customError: !1,
  patternMismatch: !1,
  rangeOverflow: !1,
  rangeUnderflow: !1,
  stepMismatch: !1,
  tooLong: !1,
  tooShort: !1,
  typeMismatch: !1,
  valid: !0,
  valueMissing: !1
});
Object.freeze(sA(L({}, Ms), {
  valid: !1,
  valueMissing: !0
}));
Object.freeze(sA(L({}, Ms), {
  valid: !1,
  customError: !0
}));
var Ud = $`
  ${Z}

  :host {
    display: inline-block;
    position: relative;
    width: auto;
    cursor: pointer;
  }

  .button {
    display: inline-flex;
    align-items: stretch;
    justify-content: center;
    width: 100%;
    border-style: solid;
    border-width: var(--sl-input-border-width);
    font-family: var(--sl-input-font-family);
    font-weight: var(--sl-font-weight-semibold);
    text-decoration: none;
    user-select: none;
    white-space: nowrap;
    vertical-align: middle;
    padding: 0;
    transition: var(--sl-transition-x-fast) background-color, var(--sl-transition-x-fast) color,
      var(--sl-transition-x-fast) border, var(--sl-transition-x-fast) box-shadow;
    cursor: inherit;
  }

  .button::-moz-focus-inner {
    border: 0;
  }

  .button:focus {
    outline: none;
  }

  .button:focus-visible {
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .button--disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* When disabled, prevent mouse events from bubbling up from children */
  .button--disabled * {
    pointer-events: none;
  }

  .button__prefix,
  .button__suffix {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    pointer-events: none;
  }

  .button__label {
    display: inline-block;
  }

  .button__label::slotted(sl-icon) {
    vertical-align: -2px;
  }

  /*
   * Standard buttons
   */

  /* Default */
  .button--standard.button--default {
    background-color: var(--sl-color-neutral-0);
    border-color: var(--sl-color-neutral-300);
    color: var(--sl-color-neutral-700);
  }

  .button--standard.button--default:hover:not(.button--disabled) {
    background-color: var(--sl-color-primary-50);
    border-color: var(--sl-color-primary-300);
    color: var(--sl-color-primary-700);
  }

  .button--standard.button--default:active:not(.button--disabled) {
    background-color: var(--sl-color-primary-100);
    border-color: var(--sl-color-primary-400);
    color: var(--sl-color-primary-700);
  }

  /* Primary */
  .button--standard.button--primary {
    background-color: var(--sl-color-primary-600);
    border-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--primary:hover:not(.button--disabled) {
    background-color: var(--sl-color-primary-500);
    border-color: var(--sl-color-primary-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--primary:active:not(.button--disabled) {
    background-color: var(--sl-color-primary-600);
    border-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  /* Success */
  .button--standard.button--success {
    background-color: var(--sl-color-success-600);
    border-color: var(--sl-color-success-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--success:hover:not(.button--disabled) {
    background-color: var(--sl-color-success-500);
    border-color: var(--sl-color-success-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--success:active:not(.button--disabled) {
    background-color: var(--sl-color-success-600);
    border-color: var(--sl-color-success-600);
    color: var(--sl-color-neutral-0);
  }

  /* Neutral */
  .button--standard.button--neutral {
    background-color: var(--sl-color-neutral-600);
    border-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--neutral:hover:not(.button--disabled) {
    background-color: var(--sl-color-neutral-500);
    border-color: var(--sl-color-neutral-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--neutral:active:not(.button--disabled) {
    background-color: var(--sl-color-neutral-600);
    border-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-0);
  }

  /* Warning */
  .button--standard.button--warning {
    background-color: var(--sl-color-warning-600);
    border-color: var(--sl-color-warning-600);
    color: var(--sl-color-neutral-0);
  }
  .button--standard.button--warning:hover:not(.button--disabled) {
    background-color: var(--sl-color-warning-500);
    border-color: var(--sl-color-warning-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--warning:active:not(.button--disabled) {
    background-color: var(--sl-color-warning-600);
    border-color: var(--sl-color-warning-600);
    color: var(--sl-color-neutral-0);
  }

  /* Danger */
  .button--standard.button--danger {
    background-color: var(--sl-color-danger-600);
    border-color: var(--sl-color-danger-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--danger:hover:not(.button--disabled) {
    background-color: var(--sl-color-danger-500);
    border-color: var(--sl-color-danger-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--danger:active:not(.button--disabled) {
    background-color: var(--sl-color-danger-600);
    border-color: var(--sl-color-danger-600);
    color: var(--sl-color-neutral-0);
  }

  /*
   * Outline buttons
   */

  .button--outline {
    background: none;
    border: solid 1px;
  }

  /* Default */
  .button--outline.button--default {
    border-color: var(--sl-color-neutral-300);
    color: var(--sl-color-neutral-700);
  }

  .button--outline.button--default:hover:not(.button--disabled),
  .button--outline.button--default.button--checked:not(.button--disabled) {
    border-color: var(--sl-color-primary-600);
    background-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--default:active:not(.button--disabled) {
    border-color: var(--sl-color-primary-700);
    background-color: var(--sl-color-primary-700);
    color: var(--sl-color-neutral-0);
  }

  /* Primary */
  .button--outline.button--primary {
    border-color: var(--sl-color-primary-600);
    color: var(--sl-color-primary-600);
  }

  .button--outline.button--primary:hover:not(.button--disabled),
  .button--outline.button--primary.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--primary:active:not(.button--disabled) {
    border-color: var(--sl-color-primary-700);
    background-color: var(--sl-color-primary-700);
    color: var(--sl-color-neutral-0);
  }

  /* Success */
  .button--outline.button--success {
    border-color: var(--sl-color-success-600);
    color: var(--sl-color-success-600);
  }

  .button--outline.button--success:hover:not(.button--disabled),
  .button--outline.button--success.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-success-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--success:active:not(.button--disabled) {
    border-color: var(--sl-color-success-700);
    background-color: var(--sl-color-success-700);
    color: var(--sl-color-neutral-0);
  }

  /* Neutral */
  .button--outline.button--neutral {
    border-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-600);
  }

  .button--outline.button--neutral:hover:not(.button--disabled),
  .button--outline.button--neutral.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--neutral:active:not(.button--disabled) {
    border-color: var(--sl-color-neutral-700);
    background-color: var(--sl-color-neutral-700);
    color: var(--sl-color-neutral-0);
  }

  /* Warning */
  .button--outline.button--warning {
    border-color: var(--sl-color-warning-600);
    color: var(--sl-color-warning-600);
  }

  .button--outline.button--warning:hover:not(.button--disabled),
  .button--outline.button--warning.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-warning-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--warning:active:not(.button--disabled) {
    border-color: var(--sl-color-warning-700);
    background-color: var(--sl-color-warning-700);
    color: var(--sl-color-neutral-0);
  }

  /* Danger */
  .button--outline.button--danger {
    border-color: var(--sl-color-danger-600);
    color: var(--sl-color-danger-600);
  }

  .button--outline.button--danger:hover:not(.button--disabled),
  .button--outline.button--danger.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-danger-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--danger:active:not(.button--disabled) {
    border-color: var(--sl-color-danger-700);
    background-color: var(--sl-color-danger-700);
    color: var(--sl-color-neutral-0);
  }

  @media (forced-colors: active) {
    .button.button--outline.button--checked:not(.button--disabled) {
      outline: solid 2px transparent;
    }
  }

  /*
   * Text buttons
   */

  .button--text {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-600);
  }

  .button--text:hover:not(.button--disabled) {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-500);
  }

  .button--text:focus-visible:not(.button--disabled) {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-500);
  }

  .button--text:active:not(.button--disabled) {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-700);
  }

  /*
   * Size modifiers
   */

  .button--small {
    font-size: var(--sl-button-font-size-small);
    height: var(--sl-input-height-small);
    line-height: calc(var(--sl-input-height-small) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-small);
  }

  .button--medium {
    font-size: var(--sl-button-font-size-medium);
    height: var(--sl-input-height-medium);
    line-height: calc(var(--sl-input-height-medium) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-medium);
  }

  .button--large {
    font-size: var(--sl-button-font-size-large);
    height: var(--sl-input-height-large);
    line-height: calc(var(--sl-input-height-large) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-large);
  }

  /*
   * Pill modifier
   */

  .button--pill.button--small {
    border-radius: var(--sl-input-height-small);
  }

  .button--pill.button--medium {
    border-radius: var(--sl-input-height-medium);
  }

  .button--pill.button--large {
    border-radius: var(--sl-input-height-large);
  }

  /*
   * Circle modifier
   */

  .button--circle {
    padding-left: 0;
    padding-right: 0;
  }

  .button--circle.button--small {
    width: var(--sl-input-height-small);
    border-radius: 50%;
  }

  .button--circle.button--medium {
    width: var(--sl-input-height-medium);
    border-radius: 50%;
  }

  .button--circle.button--large {
    width: var(--sl-input-height-large);
    border-radius: 50%;
  }

  .button--circle .button__prefix,
  .button--circle .button__suffix,
  .button--circle .button__caret {
    display: none;
  }

  /*
   * Caret modifier
   */

  .button--caret .button__suffix {
    display: none;
  }

  .button--caret .button__caret {
    height: auto;
  }

  /*
   * Loading modifier
   */

  .button--loading {
    position: relative;
    cursor: wait;
  }

  .button--loading .button__prefix,
  .button--loading .button__label,
  .button--loading .button__suffix,
  .button--loading .button__caret {
    visibility: hidden;
  }

  .button--loading sl-spinner {
    --indicator-color: currentColor;
    position: absolute;
    font-size: 1em;
    height: 1em;
    width: 1em;
    top: calc(50% - 0.5em);
    left: calc(50% - 0.5em);
  }

  /*
   * Badges
   */

  .button ::slotted(sl-badge) {
    position: absolute;
    top: 0;
    right: 0;
    translate: 50% -50%;
    pointer-events: none;
  }

  .button--rtl ::slotted(sl-badge) {
    right: auto;
    left: 0;
    translate: -50% -50%;
  }

  /*
   * Button spacing
   */

  .button--has-label.button--small .button__label {
    padding: 0 var(--sl-spacing-small);
  }

  .button--has-label.button--medium .button__label {
    padding: 0 var(--sl-spacing-medium);
  }

  .button--has-label.button--large .button__label {
    padding: 0 var(--sl-spacing-large);
  }

  .button--has-prefix.button--small {
    padding-inline-start: var(--sl-spacing-x-small);
  }

  .button--has-prefix.button--small .button__label {
    padding-inline-start: var(--sl-spacing-x-small);
  }

  .button--has-prefix.button--medium {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-prefix.button--medium .button__label {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-prefix.button--large {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-prefix.button--large .button__label {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-suffix.button--small,
  .button--caret.button--small {
    padding-inline-end: var(--sl-spacing-x-small);
  }

  .button--has-suffix.button--small .button__label,
  .button--caret.button--small .button__label {
    padding-inline-end: var(--sl-spacing-x-small);
  }

  .button--has-suffix.button--medium,
  .button--caret.button--medium {
    padding-inline-end: var(--sl-spacing-small);
  }

  .button--has-suffix.button--medium .button__label,
  .button--caret.button--medium .button__label {
    padding-inline-end: var(--sl-spacing-small);
  }

  .button--has-suffix.button--large,
  .button--caret.button--large {
    padding-inline-end: var(--sl-spacing-small);
  }

  .button--has-suffix.button--large .button__label,
  .button--caret.button--large .button__label {
    padding-inline-end: var(--sl-spacing-small);
  }

  /*
   * Button groups support a variety of button types (e.g. buttons with tooltips, buttons as dropdown triggers, etc.).
   * This means buttons aren't always direct descendants of the button group, thus we can't target them with the
   * ::slotted selector. To work around this, the button group component does some magic to add these special classes to
   * buttons and we style them here instead.
   */

  :host(.sl-button-group__button--first:not(.sl-button-group__button--last)) .button {
    border-start-end-radius: 0;
    border-end-end-radius: 0;
  }

  :host(.sl-button-group__button--inner) .button {
    border-radius: 0;
  }

  :host(.sl-button-group__button--last:not(.sl-button-group__button--first)) .button {
    border-start-start-radius: 0;
    border-end-start-radius: 0;
  }

  /* All except the first */
  :host(.sl-button-group__button:not(.sl-button-group__button--first)) {
    margin-inline-start: calc(-1 * var(--sl-input-border-width));
  }

  /* Add a visual separator between solid buttons */
  :host(
      .sl-button-group__button:not(
          .sl-button-group__button--first,
          .sl-button-group__button--radio,
          [variant='default']
        ):not(:hover)
    )
    .button:after {
    content: '';
    position: absolute;
    top: 0;
    inset-inline-start: 0;
    bottom: 0;
    border-left: solid 1px rgb(128 128 128 / 33%);
    mix-blend-mode: multiply;
  }

  /* Bump hovered, focused, and checked buttons up so their focus ring isn't clipped */
  :host(.sl-button-group__button--hover) {
    z-index: 1;
  }

  /* Focus and checked are always on top */
  :host(.sl-button-group__button--focus),
  :host(.sl-button-group__button[checked]) {
    z-index: 2;
  }
`, Xa = Symbol.for(""), Fd = (t) => {
  if (t?.r === Xa)
    return t?._$litStatic$;
}, Si = (t, ...A) => ({ _$litStatic$: A.reduce((e, i, o) => e + ((s) => {
  if (s._$litStatic$ !== void 0)
    return s._$litStatic$;
  throw Error(`Value passed to 'literal' function must be a 'literal' result: ${s}. Use 'unsafeStatic' to pass non-literal values, but
            take care to ensure page security.`);
})(i) + t[o + 1], t[0]), r: Xa }), Qn = /* @__PURE__ */ new Map(), Gd = (t) => (A, ...e) => {
  const i = e.length;
  let o, s;
  const r = [], n = [];
  let l, a = 0, h = !1;
  for (; a < i; ) {
    for (l = A[a]; a < i && (s = e[a], (o = Fd(s)) !== void 0); )
      l += o + A[++a], h = !0;
    n.push(s), r.push(l), a++;
  }
  if (a === i && r.push(A[i]), h) {
    const g = r.join("$$lit$$");
    (A = Qn.get(g)) === void 0 && (r.raw = r, Qn.set(g, A = r)), e = n;
  }
  return t(A, ...e);
}, Ii = Gd(Y);
/*! Bundled license information:

lit-html/static.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var b = (t) => t ?? K;
/*! Bundled license information:

lit-html/directives/if-defined.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var te = class {
  constructor(t, ...A) {
    this.slotNames = [], (this.host = t).addController(this), this.slotNames = A, this.handleSlotChange = this.handleSlotChange.bind(this);
  }
  hasDefaultSlot() {
    return [...this.host.childNodes].some((t) => {
      if (t.nodeType === t.TEXT_NODE && t.textContent.trim() !== "")
        return !0;
      if (t.nodeType === t.ELEMENT_NODE) {
        const A = t;
        if (A.tagName.toLowerCase() === "sl-visually-hidden")
          return !1;
        if (!A.hasAttribute("slot"))
          return !0;
      }
      return !1;
    });
  }
  hasNamedSlot(t) {
    return this.host.querySelector(`:scope > [slot="${t}"]`) !== null;
  }
  test(t) {
    return t === "[default]" ? this.hasDefaultSlot() : this.hasNamedSlot(t);
  }
  hostConnected() {
    this.host.shadowRoot.addEventListener("slotchange", this.handleSlotChange);
  }
  hostDisconnected() {
    this.host.shadowRoot.removeEventListener("slotchange", this.handleSlotChange);
  }
  handleSlotChange(t) {
    const A = t.target;
    (this.slotNames.includes("[default]") && !A.name || A.name && this.slotNames.includes(A.name)) && this.host.requestUpdate();
  }
};
function Rd(t) {
  if (!t)
    return "";
  const A = t.assignedNodes({ flatten: !0 });
  let e = "";
  return [...A].forEach((i) => {
    i.nodeType === Node.TEXT_NODE && (e += i.textContent);
  }), e;
}
var U = class extends P {
  constructor() {
    super(...arguments), this.formControlController = new Rs(this, {
      form: (t) => {
        if (t.hasAttribute("form")) {
          const A = t.getRootNode(), e = t.getAttribute("form");
          return A.getElementById(e);
        }
        return t.closest("form");
      },
      assumeInteractionOn: ["click"]
    }), this.hasSlotController = new te(this, "[default]", "prefix", "suffix"), this.localize = new XA(this), this.hasFocus = !1, this.invalid = !1, this.title = "", this.variant = "default", this.size = "medium", this.caret = !1, this.disabled = !1, this.loading = !1, this.outline = !1, this.pill = !1, this.circle = !1, this.type = "button", this.name = "", this.value = "", this.href = "", this.rel = "noreferrer noopener";
  }
  /** Gets the validity state object */
  get validity() {
    return this.isButton() ? this.button.validity : Ms;
  }
  /** Gets the validation message */
  get validationMessage() {
    return this.isButton() ? this.button.validationMessage : "";
  }
  connectedCallback() {
    super.connectedCallback(), this.handleHostClick = this.handleHostClick.bind(this), this.addEventListener("click", this.handleHostClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("click", this.handleHostClick);
  }
  firstUpdated() {
    this.isButton() && this.formControlController.updateValidity();
  }
  handleBlur() {
    this.hasFocus = !1, this.emit("sl-blur");
  }
  handleFocus() {
    this.hasFocus = !0, this.emit("sl-focus");
  }
  handleClick() {
    this.type === "submit" && this.formControlController.submit(this), this.type === "reset" && this.formControlController.reset(this);
  }
  handleHostClick(t) {
    (this.disabled || this.loading) && (t.preventDefault(), t.stopImmediatePropagation());
  }
  handleInvalid(t) {
    this.formControlController.setValidity(!1), this.formControlController.emitInvalidEvent(t);
  }
  isButton() {
    return !this.href;
  }
  isLink() {
    return !!this.href;
  }
  handleDisabledChange() {
    this.isButton() && this.formControlController.setValidity(this.disabled);
  }
  /** Simulates a click on the button. */
  click() {
    this.button.click();
  }
  /** Sets focus on the button. */
  focus(t) {
    this.button.focus(t);
  }
  /** Removes focus from the button. */
  blur() {
    this.button.blur();
  }
  /** Checks for validity but does not show a validation message. Returns `true` when valid and `false` when invalid. */
  checkValidity() {
    return this.isButton() ? this.button.checkValidity() : !0;
  }
  /** Gets the associated form, if one exists. */
  getForm() {
    return this.formControlController.getForm();
  }
  /** Checks for validity and shows the browser's validation message if the control is invalid. */
  reportValidity() {
    return this.isButton() ? this.button.reportValidity() : !0;
  }
  /** Sets a custom validation message. Pass an empty string to restore validity. */
  setCustomValidity(t) {
    this.isButton() && (this.button.setCustomValidity(t), this.formControlController.updateValidity());
  }
  render() {
    const t = this.isLink(), A = t ? Si`a` : Si`button`;
    return Ii`
      <${A}
        part="base"
        class=${rA({
      button: !0,
      "button--default": this.variant === "default",
      "button--primary": this.variant === "primary",
      "button--success": this.variant === "success",
      "button--neutral": this.variant === "neutral",
      "button--warning": this.variant === "warning",
      "button--danger": this.variant === "danger",
      "button--text": this.variant === "text",
      "button--small": this.size === "small",
      "button--medium": this.size === "medium",
      "button--large": this.size === "large",
      "button--caret": this.caret,
      "button--circle": this.circle,
      "button--disabled": this.disabled,
      "button--focused": this.hasFocus,
      "button--loading": this.loading,
      "button--standard": !this.outline,
      "button--outline": this.outline,
      "button--pill": this.pill,
      "button--rtl": this.localize.dir() === "rtl",
      "button--has-label": this.hasSlotController.test("[default]"),
      "button--has-prefix": this.hasSlotController.test("prefix"),
      "button--has-suffix": this.hasSlotController.test("suffix")
    })}
        ?disabled=${b(t ? void 0 : this.disabled)}
        type=${b(t ? void 0 : this.type)}
        title=${this.title}
        name=${b(t ? void 0 : this.name)}
        value=${b(t ? void 0 : this.value)}
        href=${b(t ? this.href : void 0)}
        target=${b(t ? this.target : void 0)}
        download=${b(t ? this.download : void 0)}
        rel=${b(t ? this.rel : void 0)}
        role=${b(t ? void 0 : "button")}
        aria-disabled=${this.disabled ? "true" : "false"}
        tabindex=${this.disabled ? "-1" : "0"}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
        @invalid=${this.isButton() ? this.handleInvalid : null}
        @click=${this.handleClick}
      >
        <slot name="prefix" part="prefix" class="button__prefix"></slot>
        <slot part="label" class="button__label"></slot>
        <slot name="suffix" part="suffix" class="button__suffix"></slot>
        ${this.caret ? Ii` <sl-icon part="caret" class="button__caret" library="system" name="caret"></sl-icon> ` : ""}
        ${this.loading ? Ii`<sl-spinner></sl-spinner>` : ""}
      </${A}>
    `;
  }
};
U.styles = Ud;
I([
  V(".button")
], U.prototype, "button", 2);
I([
  Wt()
], U.prototype, "hasFocus", 2);
I([
  Wt()
], U.prototype, "invalid", 2);
I([
  d()
], U.prototype, "title", 2);
I([
  d({ reflect: !0 })
], U.prototype, "variant", 2);
I([
  d({ reflect: !0 })
], U.prototype, "size", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "caret", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "disabled", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "loading", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "outline", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "pill", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "circle", 2);
I([
  d()
], U.prototype, "type", 2);
I([
  d()
], U.prototype, "name", 2);
I([
  d()
], U.prototype, "value", 2);
I([
  d()
], U.prototype, "href", 2);
I([
  d()
], U.prototype, "target", 2);
I([
  d()
], U.prototype, "rel", 2);
I([
  d()
], U.prototype, "download", 2);
I([
  d()
], U.prototype, "form", 2);
I([
  d({ attribute: "formaction" })
], U.prototype, "formAction", 2);
I([
  d({ attribute: "formenctype" })
], U.prototype, "formEnctype", 2);
I([
  d({ attribute: "formmethod" })
], U.prototype, "formMethod", 2);
I([
  d({ attribute: "formnovalidate", type: Boolean })
], U.prototype, "formNoValidate", 2);
I([
  d({ attribute: "formtarget" })
], U.prototype, "formTarget", 2);
I([
  q("disabled", { waitUntilFirstUpdate: !0 })
], U.prototype, "handleDisabledChange", 1);
U = I([
  W("sl-button")
], U);
var Md = $`
  ${Z}

  :host {
    display: contents;

    /* For better DX, we'll reset the margin here so the base part can inherit it */
    margin: 0;
  }

  .alert {
    position: relative;
    display: flex;
    align-items: stretch;
    background-color: var(--sl-panel-background-color);
    border: solid var(--sl-panel-border-width) var(--sl-panel-border-color);
    border-top-width: calc(var(--sl-panel-border-width) * 3);
    border-radius: var(--sl-border-radius-medium);
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-small);
    font-weight: var(--sl-font-weight-normal);
    line-height: 1.6;
    color: var(--sl-color-neutral-700);
    margin: inherit;
  }

  .alert:not(.alert--has-icon) .alert__icon,
  .alert:not(.alert--closable) .alert__close-button {
    display: none;
  }

  .alert__icon {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    font-size: var(--sl-font-size-large);
    padding-inline-start: var(--sl-spacing-large);
  }

  .alert--primary {
    border-top-color: var(--sl-color-primary-600);
  }

  .alert--primary .alert__icon {
    color: var(--sl-color-primary-600);
  }

  .alert--success {
    border-top-color: var(--sl-color-success-600);
  }

  .alert--success .alert__icon {
    color: var(--sl-color-success-600);
  }

  .alert--neutral {
    border-top-color: var(--sl-color-neutral-600);
  }

  .alert--neutral .alert__icon {
    color: var(--sl-color-neutral-600);
  }

  .alert--warning {
    border-top-color: var(--sl-color-warning-600);
  }

  .alert--warning .alert__icon {
    color: var(--sl-color-warning-600);
  }

  .alert--danger {
    border-top-color: var(--sl-color-danger-600);
  }

  .alert--danger .alert__icon {
    color: var(--sl-color-danger-600);
  }

  .alert__message {
    flex: 1 1 auto;
    display: block;
    padding: var(--sl-spacing-large);
    overflow: hidden;
  }

  .alert__close-button {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    font-size: var(--sl-font-size-medium);
    padding-inline-end: var(--sl-spacing-medium);
  }
`, mt = Object.assign(document.createElement("div"), { className: "sl-toast-stack" }), RA = class extends P {
  constructor() {
    super(...arguments), this.hasSlotController = new te(this, "icon", "suffix"), this.localize = new XA(this), this.open = !1, this.closable = !1, this.variant = "primary", this.duration = 1 / 0;
  }
  firstUpdated() {
    this.base.hidden = !this.open;
  }
  restartAutoHide() {
    clearTimeout(this.autoHideTimeout), this.open && this.duration < 1 / 0 && (this.autoHideTimeout = window.setTimeout(() => this.hide(), this.duration));
  }
  handleCloseClick() {
    this.hide();
  }
  handleMouseMove() {
    this.restartAutoHide();
  }
  async handleOpenChange() {
    if (this.open) {
      this.emit("sl-show"), this.duration < 1 / 0 && this.restartAutoHide(), await NA(this.base), this.base.hidden = !1;
      const { keyframes: t, options: A } = pA(this, "alert.show", { dir: this.localize.dir() });
      await fA(this.base, t, A), this.emit("sl-after-show");
    } else {
      this.emit("sl-hide"), clearTimeout(this.autoHideTimeout), await NA(this.base);
      const { keyframes: t, options: A } = pA(this, "alert.hide", { dir: this.localize.dir() });
      await fA(this.base, t, A), this.base.hidden = !0, this.emit("sl-after-hide");
    }
  }
  handleDurationChange() {
    this.restartAutoHide();
  }
  /** Shows the alert. */
  async show() {
    if (!this.open)
      return this.open = !0, jA(this, "sl-after-show");
  }
  /** Hides the alert */
  async hide() {
    if (this.open)
      return this.open = !1, jA(this, "sl-after-hide");
  }
  /**
   * Displays the alert as a toast notification. This will move the alert out of its position in the DOM and, when
   * dismissed, it will be removed from the DOM completely. By storing a reference to the alert, you can reuse it by
   * calling this method again. The returned promise will resolve after the alert is hidden.
   */
  async toast() {
    return new Promise((t) => {
      mt.parentElement === null && document.body.append(mt), mt.appendChild(this), requestAnimationFrame(() => {
        this.clientWidth, this.show();
      }), this.addEventListener(
        "sl-after-hide",
        () => {
          mt.removeChild(this), t(), mt.querySelector("sl-alert") === null && mt.remove();
        },
        { once: !0 }
      );
    });
  }
  render() {
    return Y`
      <div
        part="base"
        class=${rA({
      alert: !0,
      "alert--open": this.open,
      "alert--closable": this.closable,
      "alert--has-icon": this.hasSlotController.test("icon"),
      "alert--primary": this.variant === "primary",
      "alert--success": this.variant === "success",
      "alert--neutral": this.variant === "neutral",
      "alert--warning": this.variant === "warning",
      "alert--danger": this.variant === "danger"
    })}
        role="alert"
        aria-hidden=${this.open ? "false" : "true"}
        @mousemove=${this.handleMouseMove}
      >
        <slot name="icon" part="icon" class="alert__icon"></slot>

        <slot part="message" class="alert__message" aria-live="polite"></slot>

        ${this.closable ? Y`
              <sl-icon-button
                part="close-button"
                exportparts="base:close-button__base"
                class="alert__close-button"
                name="x-lg"
                library="system"
                label=${this.localize.term("close")}
                @click=${this.handleCloseClick}
              ></sl-icon-button>
            ` : ""}
      </div>
    `;
  }
};
RA.styles = Md;
I([
  V('[part~="base"]')
], RA.prototype, "base", 2);
I([
  d({ type: Boolean, reflect: !0 })
], RA.prototype, "open", 2);
I([
  d({ type: Boolean, reflect: !0 })
], RA.prototype, "closable", 2);
I([
  d({ reflect: !0 })
], RA.prototype, "variant", 2);
I([
  d({ type: Number })
], RA.prototype, "duration", 2);
I([
  q("open", { waitUntilFirstUpdate: !0 })
], RA.prototype, "handleOpenChange", 1);
I([
  q("duration")
], RA.prototype, "handleDurationChange", 1);
RA = I([
  W("sl-alert")
], RA);
bA("alert.show", {
  keyframes: [
    { opacity: 0, scale: 0.8 },
    { opacity: 1, scale: 1 }
  ],
  options: { duration: 250, easing: "ease" }
});
bA("alert.hide", {
  keyframes: [
    { opacity: 1, scale: 1 },
    { opacity: 0, scale: 0.8 }
  ],
  options: { duration: 250, easing: "ease" }
});
var _d = $`
  ${Z}

  :host {
    display: inline-block;
    color: var(--sl-color-neutral-600);
  }

  .icon-button {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    background: none;
    border: none;
    border-radius: var(--sl-border-radius-medium);
    font-size: inherit;
    color: inherit;
    padding: var(--sl-spacing-x-small);
    cursor: pointer;
    transition: var(--sl-transition-x-fast) color;
    -webkit-appearance: none;
  }

  .icon-button:hover:not(.icon-button--disabled),
  .icon-button:focus-visible:not(.icon-button--disabled) {
    color: var(--sl-color-primary-600);
  }

  .icon-button:active:not(.icon-button--disabled) {
    color: var(--sl-color-primary-700);
  }

  .icon-button:focus {
    outline: none;
  }

  .icon-button--disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .icon-button:focus-visible {
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .icon-button__icon {
    pointer-events: none;
  }
`, IA = class extends P {
  constructor() {
    super(...arguments), this.hasFocus = !1, this.label = "", this.disabled = !1;
  }
  handleBlur() {
    this.hasFocus = !1, this.emit("sl-blur");
  }
  handleFocus() {
    this.hasFocus = !0, this.emit("sl-focus");
  }
  handleClick(t) {
    this.disabled && (t.preventDefault(), t.stopPropagation());
  }
  /** Simulates a click on the icon button. */
  click() {
    this.button.click();
  }
  /** Sets focus on the icon button. */
  focus(t) {
    this.button.focus(t);
  }
  /** Removes focus from the icon button. */
  blur() {
    this.button.blur();
  }
  render() {
    const t = !!this.href, A = t ? Si`a` : Si`button`;
    return Ii`
      <${A}
        part="base"
        class=${rA({
      "icon-button": !0,
      "icon-button--disabled": !t && this.disabled,
      "icon-button--focused": this.hasFocus
    })}
        ?disabled=${b(t ? void 0 : this.disabled)}
        type=${b(t ? void 0 : "button")}
        href=${b(t ? this.href : void 0)}
        target=${b(t ? this.target : void 0)}
        download=${b(t ? this.download : void 0)}
        rel=${b(t && this.target ? "noreferrer noopener" : void 0)}
        role=${b(t ? void 0 : "button")}
        aria-disabled=${this.disabled ? "true" : "false"}
        aria-label="${this.label}"
        tabindex=${this.disabled ? "-1" : "0"}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
        @click=${this.handleClick}
      >
        <sl-icon
          class="icon-button__icon"
          name=${b(this.name)}
          library=${b(this.library)}
          src=${b(this.src)}
          aria-hidden="true"
        ></sl-icon>
      </${A}>
    `;
  }
};
IA.styles = _d;
I([
  V(".icon-button")
], IA.prototype, "button", 2);
I([
  Wt()
], IA.prototype, "hasFocus", 2);
I([
  d()
], IA.prototype, "name", 2);
I([
  d()
], IA.prototype, "library", 2);
I([
  d()
], IA.prototype, "src", 2);
I([
  d()
], IA.prototype, "href", 2);
I([
  d()
], IA.prototype, "target", 2);
I([
  d()
], IA.prototype, "download", 2);
I([
  d()
], IA.prototype, "label", 2);
I([
  d({ type: Boolean, reflect: !0 })
], IA.prototype, "disabled", 2);
IA = I([
  W("sl-icon-button")
], IA);
var Ld = $`
  ${Z}

  :host {
    --border-color: var(--sl-color-neutral-200);
    --border-radius: var(--sl-border-radius-medium);
    --border-width: 1px;
    --padding: var(--sl-spacing-large);

    display: inline-block;
  }

  .card {
    display: flex;
    flex-direction: column;
    background-color: var(--sl-panel-background-color);
    box-shadow: var(--sl-shadow-x-small);
    border: solid var(--border-width) var(--border-color);
    border-radius: var(--border-radius);
  }

  .card__image {
    display: flex;
    border-top-left-radius: var(--border-radius);
    border-top-right-radius: var(--border-radius);
    margin: calc(-1 * var(--border-width));
    overflow: hidden;
  }

  .card__image::slotted(img) {
    display: block;
    width: 100%;
  }

  .card:not(.card--has-image) .card__image {
    display: none;
  }

  .card__header {
    display: block;
    border-bottom: solid var(--border-width) var(--border-color);
    padding: calc(var(--padding) / 2) var(--padding);
  }

  .card:not(.card--has-header) .card__header {
    display: none;
  }

  .card:not(.card--has-image) .card__header {
    border-top-left-radius: var(--border-radius);
    border-top-right-radius: var(--border-radius);
  }

  .card__body {
    display: block;
    padding: var(--padding);
  }

  .card--has-footer .card__footer {
    display: block;
    border-top: solid var(--border-width) var(--border-color);
    padding: var(--padding);
  }

  .card:not(.card--has-footer) .card__footer {
    display: none;
  }
`, rs = class extends P {
  constructor() {
    super(...arguments), this.hasSlotController = new te(this, "footer", "header", "image");
  }
  render() {
    return Y`
      <div
        part="base"
        class=${rA({
      card: !0,
      "card--has-footer": this.hasSlotController.test("footer"),
      "card--has-image": this.hasSlotController.test("image"),
      "card--has-header": this.hasSlotController.test("header")
    })}
      >
        <slot name="image" part="image" class="card__image"></slot>
        <slot name="header" part="header" class="card__header"></slot>
        <slot part="body" class="card__body"></slot>
        <slot name="footer" part="footer" class="card__footer"></slot>
      </div>
    `;
  }
};
rs.styles = Ld;
rs = I([
  W("sl-card")
], rs);
function u(t, A, e, i) {
  var o = arguments.length, s = o < 3 ? A : i === null ? i = Object.getOwnPropertyDescriptor(A, e) : i, r;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function")
    s = Reflect.decorate(t, A, e, i);
  else
    for (var n = t.length - 1; n >= 0; n--)
      (r = t[n]) && (s = (o < 3 ? r(s) : o > 3 ? r(A, e, s) : r(A, e)) || s);
  return o > 3 && s && Object.defineProperty(A, e, s), s;
}
var Jd = $`
  ${Z}

  :host {
    --border-radius: var(--sl-border-radius-pill);
    --color: var(--sl-color-neutral-200);
    --sheen-color: var(--sl-color-neutral-300);

    display: block;
    position: relative;
  }

  .skeleton {
    display: flex;
    width: 100%;
    height: 100%;
    min-height: 1rem;
  }

  .skeleton__indicator {
    flex: 1 1 auto;
    background: var(--color);
    border-radius: var(--border-radius);
  }

  .skeleton--sheen .skeleton__indicator {
    background: linear-gradient(270deg, var(--sheen-color), var(--color), var(--color), var(--sheen-color));
    background-size: 400% 100%;
    background-size: 400% 100%;
    animation: sheen 8s ease-in-out infinite;
  }

  .skeleton--pulse .skeleton__indicator {
    animation: pulse 2s ease-in-out 0.5s infinite;
  }

  /* Forced colors mode */
  @media (forced-colors: active) {
    :host {
      --color: GrayText;
    }
  }

  @keyframes sheen {
    0% {
      background-position: 200% 0;
    }
    to {
      background-position: -200% 0;
    }
  }

  @keyframes pulse {
    0% {
      opacity: 1;
    }
    50% {
      opacity: 0.4;
    }
    100% {
      opacity: 1;
    }
  }
`, xi = class extends P {
  constructor() {
    super(...arguments), this.effect = "none";
  }
  render() {
    return Y`
      <div
        part="base"
        class=${rA({
      skeleton: !0,
      "skeleton--pulse": this.effect === "pulse",
      "skeleton--sheen": this.effect === "sheen"
    })}
      >
        <div part="indicator" class="skeleton__indicator"></div>
      </div>
    `;
  }
};
xi.styles = Jd;
I([
  d()
], xi.prototype, "effect", 2);
xi = I([
  W("sl-skeleton")
], xi);
function En(t) {
  const A = t.tagName.toLowerCase();
  return t.getAttribute("tabindex") === "-1" || t.hasAttribute("disabled") || t.hasAttribute("aria-disabled") && t.getAttribute("aria-disabled") !== "false" || A === "input" && t.getAttribute("type") === "radio" && !t.hasAttribute("checked") || t.offsetParent === null || window.getComputedStyle(t).visibility === "hidden" ? !1 : (A === "audio" || A === "video") && t.hasAttribute("controls") || t.hasAttribute("tabindex") || t.hasAttribute("contenteditable") && t.getAttribute("contenteditable") !== "false" ? !0 : ["button", "input", "select", "textarea", "a", "audio", "video", "summary"].includes(A);
}
function Al(t) {
  var A, e;
  const i = [];
  function o(n) {
    n instanceof HTMLElement && (i.push(n), n.shadowRoot !== null && n.shadowRoot.mode === "open" && o(n.shadowRoot)), [...n.children].forEach((l) => o(l));
  }
  o(t);
  const s = (A = i.find((n) => En(n))) != null ? A : null, r = (e = i.reverse().find((n) => En(n))) != null ? e : null;
  return { start: s, end: r };
}
var Ie = [], Yd = class {
  constructor(t) {
    this.tabDirection = "forward", this.element = t, this.handleFocusIn = this.handleFocusIn.bind(this), this.handleKeyDown = this.handleKeyDown.bind(this), this.handleKeyUp = this.handleKeyUp.bind(this);
  }
  activate() {
    Ie.push(this.element), document.addEventListener("focusin", this.handleFocusIn), document.addEventListener("keydown", this.handleKeyDown), document.addEventListener("keyup", this.handleKeyUp);
  }
  deactivate() {
    Ie = Ie.filter((t) => t !== this.element), document.removeEventListener("focusin", this.handleFocusIn), document.removeEventListener("keydown", this.handleKeyDown), document.removeEventListener("keyup", this.handleKeyUp);
  }
  isActive() {
    return Ie[Ie.length - 1] === this.element;
  }
  checkFocus() {
    if (this.isActive() && !this.element.matches(":focus-within")) {
      const { start: t, end: A } = Al(this.element), e = this.tabDirection === "forward" ? t : A;
      typeof e?.focus == "function" && e.focus({ preventScroll: !0 });
    }
  }
  handleFocusIn() {
    this.checkFocus();
  }
  handleKeyDown(t) {
    t.key === "Tab" && t.shiftKey && (this.tabDirection = "backward", requestAnimationFrame(() => this.checkFocus()));
  }
  handleKeyUp() {
    this.tabDirection = "forward";
  }
}, ns = /* @__PURE__ */ new Set();
function Hd() {
  const t = document.documentElement.clientWidth;
  return Math.abs(window.innerWidth - t);
}
function un(t) {
  if (ns.add(t), !document.body.classList.contains("sl-scroll-lock")) {
    const A = Hd();
    document.body.classList.add("sl-scroll-lock"), document.body.style.setProperty("--sl-scroll-lock-size", `${A}px`);
  }
}
function pn(t) {
  ns.delete(t), ns.size === 0 && (document.body.classList.remove("sl-scroll-lock"), document.body.style.removeProperty("--sl-scroll-lock-size"));
}
var Td = $`
  ${Z}

  :host {
    --width: 31rem;
    --header-spacing: var(--sl-spacing-large);
    --body-spacing: var(--sl-spacing-large);
    --footer-spacing: var(--sl-spacing-large);

    display: contents;
  }

  .dialog {
    display: flex;
    align-items: center;
    justify-content: center;
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: var(--sl-z-index-dialog);
  }

  .dialog__panel {
    display: flex;
    flex-direction: column;
    z-index: 2;
    width: var(--width);
    max-width: calc(100% - var(--sl-spacing-2x-large));
    max-height: calc(100% - var(--sl-spacing-2x-large));
    background-color: var(--sl-panel-background-color);
    border-radius: var(--sl-border-radius-medium);
    box-shadow: var(--sl-shadow-x-large);
  }

  .dialog__panel:focus {
    outline: none;
  }

  /* Ensure there's enough vertical padding for phones that don't update vh when chrome appears (e.g. iPhone) */
  @media screen and (max-width: 420px) {
    .dialog__panel {
      max-height: 80vh;
    }
  }

  .dialog--open .dialog__panel {
    display: flex;
    opacity: 1;
  }

  .dialog__header {
    flex: 0 0 auto;
    display: flex;
  }

  .dialog__title {
    flex: 1 1 auto;
    font: inherit;
    font-size: var(--sl-font-size-large);
    line-height: var(--sl-line-height-dense);
    padding: var(--header-spacing);
    margin: 0;
  }

  .dialog__header-actions {
    flex-shrink: 0;
    display: flex;
    flex-wrap: wrap;
    justify-content: end;
    gap: var(--sl-spacing-2x-small);
    padding: 0 var(--header-spacing);
  }

  .dialog__header-actions sl-icon-button,
  .dialog__header-actions ::slotted(sl-icon-button) {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    font-size: var(--sl-font-size-medium);
  }

  .dialog__body {
    flex: 1 1 auto;
    display: block;
    padding: var(--body-spacing);
    overflow: auto;
    -webkit-overflow-scrolling: touch;
  }

  .dialog__footer {
    flex: 0 0 auto;
    text-align: right;
    padding: var(--footer-spacing);
  }

  .dialog__footer ::slotted(sl-button:not(:first-of-type)) {
    margin-inline-start: var(--sl-spacing-x-small);
  }

  .dialog:not(.dialog--has-footer) .dialog__footer {
    display: none;
  }

  .dialog__overlay {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: var(--sl-overlay-background-color);
  }

  @media (forced-colors: active) {
    .dialog__panel {
      border: solid 1px var(--sl-color-neutral-0);
    }
  }
`, MA = class extends P {
  constructor() {
    super(...arguments), this.hasSlotController = new te(this, "footer"), this.localize = new XA(this), this.open = !1, this.label = "", this.noHeader = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.handleDocumentKeyDown = this.handleDocumentKeyDown.bind(this), this.modal = new Yd(this);
  }
  firstUpdated() {
    this.dialog.hidden = !this.open, this.open && (this.addOpenListeners(), this.modal.activate(), un(this));
  }
  disconnectedCallback() {
    super.disconnectedCallback(), pn(this);
  }
  requestClose(t) {
    if (this.emit("sl-request-close", {
      cancelable: !0,
      detail: { source: t }
    }).defaultPrevented) {
      const e = pA(this, "dialog.denyClose", { dir: this.localize.dir() });
      fA(this.panel, e.keyframes, e.options);
      return;
    }
    this.hide();
  }
  addOpenListeners() {
    document.addEventListener("keydown", this.handleDocumentKeyDown);
  }
  removeOpenListeners() {
    document.removeEventListener("keydown", this.handleDocumentKeyDown);
  }
  handleDocumentKeyDown(t) {
    this.open && t.key === "Escape" && (t.stopPropagation(), this.requestClose("keyboard"));
  }
  async handleOpenChange() {
    if (this.open) {
      this.emit("sl-show"), this.addOpenListeners(), this.originalTrigger = document.activeElement, this.modal.activate(), un(this);
      const t = this.querySelector("[autofocus]");
      t && t.removeAttribute("autofocus"), await Promise.all([NA(this.dialog), NA(this.overlay)]), this.dialog.hidden = !1, requestAnimationFrame(() => {
        this.emit("sl-initial-focus", { cancelable: !0 }).defaultPrevented || (t ? t.focus({ preventScroll: !0 }) : this.panel.focus({ preventScroll: !0 })), t && t.setAttribute("autofocus", "");
      });
      const A = pA(this, "dialog.show", { dir: this.localize.dir() }), e = pA(this, "dialog.overlay.show", { dir: this.localize.dir() });
      await Promise.all([
        fA(this.panel, A.keyframes, A.options),
        fA(this.overlay, e.keyframes, e.options)
      ]), this.emit("sl-after-show");
    } else {
      this.emit("sl-hide"), this.removeOpenListeners(), this.modal.deactivate(), await Promise.all([NA(this.dialog), NA(this.overlay)]);
      const t = pA(this, "dialog.hide", { dir: this.localize.dir() }), A = pA(this, "dialog.overlay.hide", { dir: this.localize.dir() });
      await Promise.all([
        fA(this.overlay, A.keyframes, A.options).then(() => {
          this.overlay.hidden = !0;
        }),
        fA(this.panel, t.keyframes, t.options).then(() => {
          this.panel.hidden = !0;
        })
      ]), this.dialog.hidden = !0, this.overlay.hidden = !1, this.panel.hidden = !1, pn(this);
      const e = this.originalTrigger;
      typeof e?.focus == "function" && setTimeout(() => e.focus()), this.emit("sl-after-hide");
    }
  }
  /** Shows the dialog. */
  async show() {
    if (!this.open)
      return this.open = !0, jA(this, "sl-after-show");
  }
  /** Hides the dialog */
  async hide() {
    if (this.open)
      return this.open = !1, jA(this, "sl-after-hide");
  }
  render() {
    return Y`
      <div
        part="base"
        class=${rA({
      dialog: !0,
      "dialog--open": this.open,
      "dialog--has-footer": this.hasSlotController.test("footer")
    })}
      >
        <div part="overlay" class="dialog__overlay" @click=${() => this.requestClose("overlay")} tabindex="-1"></div>

        <div
          part="panel"
          class="dialog__panel"
          role="dialog"
          aria-modal="true"
          aria-hidden=${this.open ? "false" : "true"}
          aria-label=${b(this.noHeader ? this.label : void 0)}
          aria-labelledby=${b(this.noHeader ? void 0 : "title")}
          tabindex="0"
        >
          ${this.noHeader ? "" : Y`
                <header part="header" class="dialog__header">
                  <h2 part="title" class="dialog__title" id="title">
                    <slot name="label"> ${this.label.length > 0 ? this.label : String.fromCharCode(65279)} </slot>
                  </h2>
                  <div part="header-actions" class="dialog__header-actions">
                    <slot name="header-actions"></slot>
                    <sl-icon-button
                      part="close-button"
                      exportparts="base:close-button__base"
                      class="dialog__close"
                      name="x-lg"
                      label=${this.localize.term("close")}
                      library="system"
                      @click="${() => this.requestClose("close-button")}"
                    ></sl-icon-button>
                  </div>
                </header>
              `}

          <slot part="body" class="dialog__body"></slot>

          <footer part="footer" class="dialog__footer">
            <slot name="footer"></slot>
          </footer>
        </div>
      </div>
    `;
  }
};
MA.styles = Td;
I([
  V(".dialog")
], MA.prototype, "dialog", 2);
I([
  V(".dialog__panel")
], MA.prototype, "panel", 2);
I([
  V(".dialog__overlay")
], MA.prototype, "overlay", 2);
I([
  d({ type: Boolean, reflect: !0 })
], MA.prototype, "open", 2);
I([
  d({ reflect: !0 })
], MA.prototype, "label", 2);
I([
  d({ attribute: "no-header", type: Boolean, reflect: !0 })
], MA.prototype, "noHeader", 2);
I([
  q("open", { waitUntilFirstUpdate: !0 })
], MA.prototype, "handleOpenChange", 1);
MA = I([
  W("sl-dialog")
], MA);
bA("dialog.show", {
  keyframes: [
    { opacity: 0, scale: 0.8 },
    { opacity: 1, scale: 1 }
  ],
  options: { duration: 250, easing: "ease" }
});
bA("dialog.hide", {
  keyframes: [
    { opacity: 1, scale: 1 },
    { opacity: 0, scale: 0.8 }
  ],
  options: { duration: 250, easing: "ease" }
});
bA("dialog.denyClose", {
  keyframes: [{ scale: 1 }, { scale: 1.02 }, { scale: 1 }],
  options: { duration: 250 }
});
bA("dialog.overlay.show", {
  keyframes: [{ opacity: 0 }, { opacity: 1 }],
  options: { duration: 250 }
});
bA("dialog.overlay.hide", {
  keyframes: [{ opacity: 1 }, { opacity: 0 }],
  options: { duration: 250 }
});
async function _s(t, A) {
  const e = new yi(), i = new yi();
  for (const o of A) {
    const s = await t.appletInfo(o);
    if (s) {
      i.set(o, s);
      for (const r of s.groupsIds)
        if (!e.has(r)) {
          const n = await t.groupProfile(r);
          n && e.set(r, n);
        }
    }
  }
  return {
    groupsProfiles: e,
    appletsInfos: i
  };
}
const Je = "we_services";
var Od = $`
  ${Z}

  :host {
    display: inline-block;
  }

  .tag {
    display: flex;
    align-items: center;
    border: solid 1px;
    line-height: 1;
    white-space: nowrap;
    user-select: none;
  }

  .tag__remove::part(base) {
    color: inherit;
    padding: 0;
  }

  /*
   * Variant modifiers
   */

  .tag--primary {
    background-color: var(--sl-color-primary-50);
    border-color: var(--sl-color-primary-200);
    color: var(--sl-color-primary-800);
  }

  .tag--primary:active > sl-icon-button {
    color: var(--sl-color-primary-600);
  }

  .tag--success {
    background-color: var(--sl-color-success-50);
    border-color: var(--sl-color-success-200);
    color: var(--sl-color-success-800);
  }

  .tag--success:active > sl-icon-button {
    color: var(--sl-color-success-600);
  }

  .tag--neutral {
    background-color: var(--sl-color-neutral-50);
    border-color: var(--sl-color-neutral-200);
    color: var(--sl-color-neutral-800);
  }

  .tag--neutral:active > sl-icon-button {
    color: var(--sl-color-neutral-600);
  }

  .tag--warning {
    background-color: var(--sl-color-warning-50);
    border-color: var(--sl-color-warning-200);
    color: var(--sl-color-warning-800);
  }

  .tag--warning:active > sl-icon-button {
    color: var(--sl-color-warning-600);
  }

  .tag--danger {
    background-color: var(--sl-color-danger-50);
    border-color: var(--sl-color-danger-200);
    color: var(--sl-color-danger-800);
  }

  .tag--danger:active > sl-icon-button {
    color: var(--sl-color-danger-600);
  }

  /*
   * Size modifiers
   */

  .tag--small {
    font-size: var(--sl-button-font-size-small);
    height: calc(var(--sl-input-height-small) * 0.8);
    line-height: calc(var(--sl-input-height-small) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-small);
    padding: 0 var(--sl-spacing-x-small);
  }

  .tag--medium {
    font-size: var(--sl-button-font-size-medium);
    height: calc(var(--sl-input-height-medium) * 0.8);
    line-height: calc(var(--sl-input-height-medium) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-medium);
    padding: 0 var(--sl-spacing-small);
  }

  .tag--large {
    font-size: var(--sl-button-font-size-large);
    height: calc(var(--sl-input-height-large) * 0.8);
    line-height: calc(var(--sl-input-height-large) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-large);
    padding: 0 var(--sl-spacing-medium);
  }

  .tag__remove {
    margin-inline-start: var(--sl-spacing-x-small);
  }

  /*
   * Pill modifier
   */

  .tag--pill {
    border-radius: var(--sl-border-radius-pill);
  }
`, ht = class extends P {
  constructor() {
    super(...arguments), this.localize = new XA(this), this.variant = "neutral", this.size = "medium", this.pill = !1, this.removable = !1;
  }
  handleRemoveClick() {
    this.emit("sl-remove");
  }
  render() {
    return Y`
      <span
        part="base"
        class=${rA({
      tag: !0,
      // Types
      "tag--primary": this.variant === "primary",
      "tag--success": this.variant === "success",
      "tag--neutral": this.variant === "neutral",
      "tag--warning": this.variant === "warning",
      "tag--danger": this.variant === "danger",
      "tag--text": this.variant === "text",
      // Sizes
      "tag--small": this.size === "small",
      "tag--medium": this.size === "medium",
      "tag--large": this.size === "large",
      // Modifiers
      "tag--pill": this.pill,
      "tag--removable": this.removable
    })}
      >
        <slot part="content" class="tag__content"></slot>

        ${this.removable ? Y`
              <sl-icon-button
                part="remove-button"
                exportparts="base:remove-button__base"
                name="x-lg"
                library="system"
                label=${this.localize.term("remove")}
                class="tag__remove"
                @click=${this.handleRemoveClick}
                tabindex="-1"
              ></sl-icon-button>
            ` : ""}
      </span>
    `;
  }
};
ht.styles = Od;
I([
  d({ reflect: !0 })
], ht.prototype, "variant", 2);
I([
  d({ reflect: !0 })
], ht.prototype, "size", 2);
I([
  d({ type: Boolean, reflect: !0 })
], ht.prototype, "pill", 2);
I([
  d({ type: Boolean })
], ht.prototype, "removable", 2);
ht = I([
  W("sl-tag")
], ht);
let Kt = class extends F {
  constructor() {
    super(...arguments), this.info = new Et(this, () => Ds(async () => {
      const A = await this.weServices.entryInfo(this.hrl);
      if (!A)
        return;
      const { groupsProfiles: e, appletsInfos: i } = await _s(this.weServices, [
        A.appletId
      ]);
      return {
        entryInfo: A,
        groupsProfiles: e,
        appletsInfos: i
      };
    }), () => [this.hrl]);
  }
  render() {
    var A, e;
    switch (this.info.value.status) {
      case "pending":
        return p`<sl-skeleton></sl-skeleton>`;
      case "complete":
        if (this.info.value.value === void 0)
          return p``;
        const { appletsInfos: i, groupsProfiles: o, entryInfo: s } = this.info.value.value;
        return p`
          <sl-tooltip
            ><div slot="content">
              <div slot="suffix" class="row" style="align-items: center">
                <span>
                  ${(A = i.get(s.appletId)) === null || A === void 0 ? void 0 : A.appletName}</span
                >
                <span style="margin-left: 8px; margin-right: 8px"
                  >${k(" in ")}</span
                >
                ${(e = i.get(s.appletId)) === null || e === void 0 ? void 0 : e.groupsIds.map((r) => {
          var n, l;
          return p`
                    <img
                      .src=${(n = o.get(r)) === null || n === void 0 ? void 0 : n.logo_src}
                      style="height: 16px; width: 16px; margin-right: 4px;"
                    />
                    <span>${(l = o.get(r)) === null || l === void 0 ? void 0 : l.name}</span>
                  `;
        })}
              </div>
            </div>
            <sl-tag
              pill
              style="cursor: pointer"
              @click=${() => this.weServices.openViews.openHrl(this.hrl, this.context)}
            >
              <div class="row" style="align-items: center">
                <sl-icon
                  .src=${s.entryInfo.icon_src}
                  style="margin-right: 8px"
                ></sl-icon>
                <span>${s.entryInfo.name}</span>
              </div>
            </sl-tag>
          </sl-tooltip>
        `;
      case "error":
        return p`<display-error
          tooltip
          .headline=${k("Error fetching the entry")}
          .error=${this.info.value.error.data.data}
        ></display-error>`;
    }
  }
};
Kt.styles = [QA];
u([
  y()
], Kt.prototype, "hrl", void 0);
u([
  y()
], Kt.prototype, "context", void 0);
u([
  vA({ context: Je, subscribe: !0 })
], Kt.prototype, "weServices", void 0);
Kt = u([
  LA(),
  H("hrl-link")
], Kt);
const Ls = "attachments_store";
let WA = class extends F {
  constructor() {
    super(...arguments), this.attachments = new Et(this, () => this.attachmentsStore.attachments.get(this.hash), () => [this.hash]), this.removing = !1;
  }
  async removeAttachment(A) {
    this.removing = !0;
    try {
      await this.attachmentsStore.client.removeAttachment(this.hash, A), this._attachmentToRemove = void 0;
    } catch (e) {
      _e(k("Error removing the attachment")), console.error(e);
    }
    this.removing = !1;
  }
  renderAttachments(A) {
    return A.length === 0 ? p`<span class="placeholder"
        >${k("There are no attachments yet.")}</span
      >` : p`
      ${this._attachmentToRemove ? p`
            <sl-dialog
              open
              .label=${k("Remove Attachment")}
              @sl-hide=${() => {
      this._attachmentToRemove = void 0;
    }}
              @sl-request-close=${(e) => {
      this.removing && e.preventDefault();
    }}
            >
              <span>${k("Do you want to remove this attachment?")}</span>

              <sl-button
                slot="footer"
                @click=${() => {
      this._attachmentToRemove = void 0;
    }}
                >${k("Cancel")}</sl-button
              >

              <sl-button
                slot="footer"
                variant="primary"
                @click=${() => this.removeAttachment(this._attachmentToRemove)}
                .loading=${this.removing}
                >${k("Remove")}</sl-button
              >
            </sl-dialog>
          ` : p``}

      <div class="column">
        ${A.map((e) => p` <div class="row">
              <hrl-link
                style="flex:1"
                .hrl=${e.hrl}
                .context=${e.context}
              ></hrl-link>
              <sl-icon-button
                .src=${HA(cC)}
                @click=${() => this._attachmentToRemove = e}
              ></sl-icon-button>
            </div>`)}
      </div>
    `;
  }
  render() {
    switch (this.attachments.value.status) {
      case "pending":
        return p`<sl-skeleton></sl-skeleton><sl-skeleton></sl-skeleton
          ><sl-skeleton></sl-skeleton>`;
      case "complete":
        return this.renderAttachments(this.attachments.value.value);
      case "error":
        return p`<display-error
          .headline=${k("Error fetching the attachments")}
          .error=${this.attachments.value.error.data.data}
        ></display-error>`;
    }
  }
};
WA.styles = [QA];
u([
  vA({ context: Ls, subscribe: !0 })
], WA.prototype, "attachmentsStore", void 0);
u([
  vA({ context: Je, subscribe: !0 })
], WA.prototype, "weServices", void 0);
u([
  y(Zt("hash"))
], WA.prototype, "hash", void 0);
u([
  _A()
], WA.prototype, "_attachmentToRemove", void 0);
u([
  _A()
], WA.prototype, "removing", void 0);
WA = u([
  H("attachments-list")
], WA);
var Kd = $`
  ${Z}

  :host {
    display: inline-block;
  }

  .dropdown::part(popup) {
    z-index: var(--sl-z-index-dropdown);
  }

  .dropdown[data-current-placement^='top']::part(popup) {
    transform-origin: bottom;
  }

  .dropdown[data-current-placement^='bottom']::part(popup) {
    transform-origin: top;
  }

  .dropdown[data-current-placement^='left']::part(popup) {
    transform-origin: right;
  }

  .dropdown[data-current-placement^='right']::part(popup) {
    transform-origin: left;
  }

  .dropdown__trigger {
    display: block;
  }

  .dropdown__panel {
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-medium);
    font-weight: var(--sl-font-weight-normal);
    box-shadow: var(--sl-shadow-large);
    border-radius: var(--sl-border-radius-medium);
    pointer-events: none;
  }

  .dropdown--open .dropdown__panel {
    display: block;
    pointer-events: all;
  }

  /* When users slot a menu, make sure it conforms to the popup's auto-size */
  ::slotted(sl-menu) {
    max-width: var(--auto-size-available-width) !important;
    max-height: var(--auto-size-available-height) !important;
  }
`, nA = class extends P {
  constructor() {
    super(...arguments), this.localize = new XA(this), this.open = !1, this.placement = "bottom-start", this.disabled = !1, this.stayOpenOnSelect = !1, this.distance = 0, this.skidding = 0, this.hoist = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.handlePanelSelect = this.handlePanelSelect.bind(this), this.handleKeyDown = this.handleKeyDown.bind(this), this.handleDocumentKeyDown = this.handleDocumentKeyDown.bind(this), this.handleDocumentMouseDown = this.handleDocumentMouseDown.bind(this), this.containingElement || (this.containingElement = this);
  }
  firstUpdated() {
    this.panel.hidden = !this.open, this.open && (this.addOpenListeners(), this.popup.active = !0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeOpenListeners(), this.hide();
  }
  focusOnTrigger() {
    const t = this.trigger.assignedElements({ flatten: !0 })[0];
    typeof t?.focus == "function" && t.focus();
  }
  getMenu() {
    return this.panel.assignedElements({ flatten: !0 }).find((t) => t.tagName.toLowerCase() === "sl-menu");
  }
  handleKeyDown(t) {
    this.open && t.key === "Escape" && (t.stopPropagation(), this.hide(), this.focusOnTrigger());
  }
  handleDocumentKeyDown(t) {
    var A;
    if (t.key === "Escape" && this.open) {
      t.stopPropagation(), this.focusOnTrigger(), this.hide();
      return;
    }
    if (t.key === "Tab") {
      if (this.open && ((A = document.activeElement) == null ? void 0 : A.tagName.toLowerCase()) === "sl-menu-item") {
        t.preventDefault(), this.hide(), this.focusOnTrigger();
        return;
      }
      setTimeout(() => {
        var e, i, o;
        const s = ((e = this.containingElement) == null ? void 0 : e.getRootNode()) instanceof ShadowRoot ? (o = (i = document.activeElement) == null ? void 0 : i.shadowRoot) == null ? void 0 : o.activeElement : document.activeElement;
        (!this.containingElement || s?.closest(this.containingElement.tagName.toLowerCase()) !== this.containingElement) && this.hide();
      });
    }
  }
  handleDocumentMouseDown(t) {
    const A = t.composedPath();
    this.containingElement && !A.includes(this.containingElement) && this.hide();
  }
  handlePanelSelect(t) {
    const A = t.target;
    !this.stayOpenOnSelect && A.tagName.toLowerCase() === "sl-menu" && (this.hide(), this.focusOnTrigger());
  }
  handleTriggerClick() {
    this.open ? this.hide() : (this.show(), this.focusOnTrigger());
  }
  handleTriggerKeyDown(t) {
    if ([" ", "Enter"].includes(t.key)) {
      t.preventDefault(), this.handleTriggerClick();
      return;
    }
    const A = this.getMenu();
    if (A) {
      const e = A.getAllItems(), i = e[0], o = e[e.length - 1];
      ["ArrowDown", "ArrowUp", "Home", "End"].includes(t.key) && (t.preventDefault(), this.open || this.show(), e.length > 0 && this.updateComplete.then(() => {
        (t.key === "ArrowDown" || t.key === "Home") && (A.setCurrentItem(i), i.focus()), (t.key === "ArrowUp" || t.key === "End") && (A.setCurrentItem(o), o.focus());
      }));
    }
  }
  handleTriggerKeyUp(t) {
    t.key === " " && t.preventDefault();
  }
  handleTriggerSlotChange() {
    this.updateAccessibleTrigger();
  }
  //
  // Slotted triggers can be arbitrary content, but we need to link them to the dropdown panel with `aria-haspopup` and
  // `aria-expanded`. These must be applied to the "accessible trigger" (the tabbable portion of the trigger element
  // that gets slotted in) so screen readers will understand them. The accessible trigger could be the slotted element,
  // a child of the slotted element, or an element in the slotted element's shadow root.
  //
  // For example, the accessible trigger of an <sl-button> is a <button> located inside its shadow root.
  //
  // To determine this, we assume the first tabbable element in the trigger slot is the "accessible trigger."
  //
  updateAccessibleTrigger() {
    const A = this.trigger.assignedElements({ flatten: !0 }).find((i) => Al(i).start);
    let e;
    if (A) {
      switch (A.tagName.toLowerCase()) {
        case "sl-button":
        case "sl-icon-button":
          e = A.button;
          break;
        default:
          e = A;
      }
      e.setAttribute("aria-haspopup", "true"), e.setAttribute("aria-expanded", this.open ? "true" : "false");
    }
  }
  /** Shows the dropdown panel. */
  async show() {
    if (!this.open)
      return this.open = !0, jA(this, "sl-after-show");
  }
  /** Hides the dropdown panel */
  async hide() {
    if (this.open)
      return this.open = !1, jA(this, "sl-after-hide");
  }
  /**
   * Instructs the dropdown menu to reposition. Useful when the position or size of the trigger changes when the menu
   * is activated.
   */
  reposition() {
    this.popup.reposition();
  }
  addOpenListeners() {
    this.panel.addEventListener("sl-select", this.handlePanelSelect), this.panel.addEventListener("keydown", this.handleKeyDown), document.addEventListener("keydown", this.handleDocumentKeyDown), document.addEventListener("mousedown", this.handleDocumentMouseDown);
  }
  removeOpenListeners() {
    this.panel && (this.panel.removeEventListener("sl-select", this.handlePanelSelect), this.panel.removeEventListener("keydown", this.handleKeyDown)), document.removeEventListener("keydown", this.handleDocumentKeyDown), document.removeEventListener("mousedown", this.handleDocumentMouseDown);
  }
  async handleOpenChange() {
    if (this.disabled) {
      this.open = !1;
      return;
    }
    if (this.updateAccessibleTrigger(), this.open) {
      this.emit("sl-show"), this.addOpenListeners(), await NA(this), this.panel.hidden = !1, this.popup.active = !0;
      const { keyframes: t, options: A } = pA(this, "dropdown.show", { dir: this.localize.dir() });
      await fA(this.popup.popup, t, A), this.emit("sl-after-show");
    } else {
      this.emit("sl-hide"), this.removeOpenListeners(), await NA(this);
      const { keyframes: t, options: A } = pA(this, "dropdown.hide", { dir: this.localize.dir() });
      await fA(this.popup.popup, t, A), this.panel.hidden = !0, this.popup.active = !1, this.emit("sl-after-hide");
    }
  }
  render() {
    return Y`
      <sl-popup
        part="base"
        id="dropdown"
        placement=${this.placement}
        distance=${this.distance}
        skidding=${this.skidding}
        strategy=${this.hoist ? "fixed" : "absolute"}
        flip
        shift
        auto-size="vertical"
        auto-size-padding="10"
        class=${rA({
      dropdown: !0,
      "dropdown--open": this.open
    })}
      >
        <slot
          name="trigger"
          slot="anchor"
          part="trigger"
          class="dropdown__trigger"
          @click=${this.handleTriggerClick}
          @keydown=${this.handleTriggerKeyDown}
          @keyup=${this.handleTriggerKeyUp}
          @slotchange=${this.handleTriggerSlotChange}
        ></slot>

        <slot
          part="panel"
          class="dropdown__panel"
          aria-hidden=${this.open ? "false" : "true"}
          aria-labelledby="dropdown"
        ></slot>
      </sl-popup>
    `;
  }
};
nA.styles = Kd;
I([
  V(".dropdown")
], nA.prototype, "popup", 2);
I([
  V(".dropdown__trigger")
], nA.prototype, "trigger", 2);
I([
  V(".dropdown__panel")
], nA.prototype, "panel", 2);
I([
  d({ type: Boolean, reflect: !0 })
], nA.prototype, "open", 2);
I([
  d({ reflect: !0 })
], nA.prototype, "placement", 2);
I([
  d({ type: Boolean, reflect: !0 })
], nA.prototype, "disabled", 2);
I([
  d({ attribute: "stay-open-on-select", type: Boolean, reflect: !0 })
], nA.prototype, "stayOpenOnSelect", 2);
I([
  d({ attribute: !1 })
], nA.prototype, "containingElement", 2);
I([
  d({ type: Number })
], nA.prototype, "distance", 2);
I([
  d({ type: Number })
], nA.prototype, "skidding", 2);
I([
  d({ type: Boolean })
], nA.prototype, "hoist", 2);
I([
  q("open", { waitUntilFirstUpdate: !0 })
], nA.prototype, "handleOpenChange", 1);
nA = I([
  W("sl-dropdown")
], nA);
bA("dropdown.show", {
  keyframes: [
    { opacity: 0, scale: 0.9 },
    { opacity: 1, scale: 1 }
  ],
  options: { duration: 100, easing: "ease" }
});
bA("dropdown.hide", {
  keyframes: [
    { opacity: 1, scale: 1 },
    { opacity: 0, scale: 0.9 }
  ],
  options: { duration: 100, easing: "ease" }
});
var $d = $`
  ${Z}

  :host {
    display: block;
    position: relative;
    background: var(--sl-panel-background-color);
    border: solid var(--sl-panel-border-width) var(--sl-panel-border-color);
    border-radius: var(--sl-border-radius-medium);
    padding: var(--sl-spacing-x-small) 0;
    overflow: auto;
    overscroll-behavior: none;
  }

  ::slotted(sl-divider) {
    --spacing: var(--sl-spacing-x-small);
  }
`, Ni = class extends P {
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "menu");
  }
  handleClick(t) {
    const e = t.target.closest("sl-menu-item");
    !e || e.disabled || e.inert || (e.type === "checkbox" && (e.checked = !e.checked), this.emit("sl-select", { detail: { item: e } }));
  }
  handleKeyDown(t) {
    if (t.key === "Enter") {
      const A = this.getCurrentItem();
      t.preventDefault(), A?.click();
    }
    if (t.key === " " && t.preventDefault(), ["ArrowDown", "ArrowUp", "Home", "End"].includes(t.key)) {
      const A = this.getAllItems(), e = this.getCurrentItem();
      let i = e ? A.indexOf(e) : 0;
      A.length > 0 && (t.preventDefault(), t.key === "ArrowDown" ? i++ : t.key === "ArrowUp" ? i-- : t.key === "Home" ? i = 0 : t.key === "End" && (i = A.length - 1), i < 0 && (i = A.length - 1), i > A.length - 1 && (i = 0), this.setCurrentItem(A[i]), A[i].focus());
    }
  }
  handleMouseDown(t) {
    const A = t.target;
    this.isMenuItem(A) && this.setCurrentItem(A);
  }
  handleSlotChange() {
    const t = this.getAllItems();
    t.length > 0 && this.setCurrentItem(t[0]);
  }
  isMenuItem(t) {
    var A;
    return t.tagName.toLowerCase() === "sl-menu-item" || ["menuitem", "menuitemcheckbox", "menuitemradio"].includes((A = t.getAttribute("role")) != null ? A : "");
  }
  /** @internal Gets all slotted menu items, ignoring dividers, headers, and other elements. */
  getAllItems() {
    return [...this.defaultSlot.assignedElements({ flatten: !0 })].filter((t) => !(t.inert || !this.isMenuItem(t)));
  }
  /**
   * @internal Gets the current menu item, which is the menu item that has `tabindex="0"` within the roving tab index.
   * The menu item may or may not have focus, but for keyboard interaction purposes it's considered the "active" item.
   */
  getCurrentItem() {
    return this.getAllItems().find((t) => t.getAttribute("tabindex") === "0");
  }
  /**
   * @internal Sets the current menu item to the specified element. This sets `tabindex="0"` on the target element and
   * `tabindex="-1"` to all other items. This method must be called prior to setting focus on a menu item.
   */
  setCurrentItem(t) {
    this.getAllItems().forEach((e) => {
      e.setAttribute("tabindex", e === t ? "0" : "-1");
    });
  }
  render() {
    return Y`
      <slot
        @slotchange=${this.handleSlotChange}
        @click=${this.handleClick}
        @keydown=${this.handleKeyDown}
        @mousedown=${this.handleMouseDown}
      ></slot>
    `;
  }
};
Ni.styles = $d;
I([
  V("slot")
], Ni.prototype, "defaultSlot", 2);
Ni = I([
  W("sl-menu")
], Ni);
var qd = $`
  ${Z}

  :host {
    display: block;
  }

  :host([inert]) {
    display: none;
  }

  .menu-item {
    position: relative;
    display: flex;
    align-items: stretch;
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-medium);
    font-weight: var(--sl-font-weight-normal);
    line-height: var(--sl-line-height-normal);
    letter-spacing: var(--sl-letter-spacing-normal);
    color: var(--sl-color-neutral-700);
    padding: var(--sl-spacing-2x-small) var(--sl-spacing-2x-small);
    transition: var(--sl-transition-fast) fill;
    user-select: none;
    white-space: nowrap;
    cursor: pointer;
  }

  .menu-item.menu-item--disabled {
    outline: none;
    opacity: 0.5;
    cursor: not-allowed;
  }

  .menu-item .menu-item__label {
    flex: 1 1 auto;
    display: inline-block;
  }

  .menu-item .menu-item__prefix {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
  }

  .menu-item .menu-item__prefix::slotted(*) {
    margin-inline-end: var(--sl-spacing-x-small);
  }

  .menu-item .menu-item__suffix {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
  }

  .menu-item .menu-item__suffix::slotted(*) {
    margin-inline-start: var(--sl-spacing-x-small);
  }

  :host(:focus-visible) {
    outline: none;
  }

  :host(:hover:not([aria-disabled='true'], :focus-visible)) .menu-item {
    background-color: var(--sl-color-neutral-100);
    color: var(--sl-color-neutral-1000);
  }

  :host(:focus-visible) .menu-item {
    outline: none;
    background-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
    opacity: 1;
  }

  .menu-item .menu-item__check,
  .menu-item .menu-item__chevron {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.5em;
    visibility: hidden;
  }

  .menu-item--checked .menu-item__check,
  .menu-item--has-submenu .menu-item__chevron {
    visibility: visible;
  }

  @media (forced-colors: active) {
    :host(:hover:not([aria-disabled='true'])) .menu-item,
    :host(:focus-visible) .menu-item {
      outline: dashed 1px SelectedItem;
      outline-offset: -1px;
    }
  }
`, BA = class extends P {
  constructor() {
    super(...arguments), this.type = "normal", this.checked = !1, this.value = "", this.disabled = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.handleHostClick = this.handleHostClick.bind(this), this.addEventListener("click", this.handleHostClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("click", this.handleHostClick);
  }
  handleDefaultSlotChange() {
    const t = this.getTextLabel();
    if (typeof this.cachedTextLabel > "u") {
      this.cachedTextLabel = t;
      return;
    }
    t !== this.cachedTextLabel && (this.cachedTextLabel = t, this.emit("slotchange", { bubbles: !0, composed: !1, cancelable: !1 }));
  }
  handleHostClick(t) {
    this.disabled && (t.preventDefault(), t.stopImmediatePropagation());
  }
  handleCheckedChange() {
    if (this.checked && this.type !== "checkbox") {
      this.checked = !1, console.error('The checked attribute can only be used on menu items with type="checkbox"', this);
      return;
    }
    this.type === "checkbox" ? this.setAttribute("aria-checked", this.checked ? "true" : "false") : this.removeAttribute("aria-checked");
  }
  handleDisabledChange() {
    this.setAttribute("aria-disabled", this.disabled ? "true" : "false");
  }
  handleTypeChange() {
    this.type === "checkbox" ? (this.setAttribute("role", "menuitemcheckbox"), this.setAttribute("aria-checked", this.checked ? "true" : "false")) : (this.setAttribute("role", "menuitem"), this.removeAttribute("aria-checked"));
  }
  /** Returns a text label based on the contents of the menu item's default slot. */
  getTextLabel() {
    return Rd(this.defaultSlot);
  }
  render() {
    return Y`
      <div
        part="base"
        class=${rA({
      "menu-item": !0,
      "menu-item--checked": this.checked,
      "menu-item--disabled": this.disabled,
      "menu-item--has-submenu": !1
      // reserved for future use
    })}
      >
        <span part="checked-icon" class="menu-item__check">
          <sl-icon name="check" library="system" aria-hidden="true"></sl-icon>
        </span>

        <slot name="prefix" part="prefix" class="menu-item__prefix"></slot>

        <slot part="label" class="menu-item__label" @slotchange=${this.handleDefaultSlotChange}></slot>

        <slot name="suffix" part="suffix" class="menu-item__suffix"></slot>

        <span class="menu-item__chevron">
          <sl-icon name="chevron-right" library="system" aria-hidden="true"></sl-icon>
        </span>
      </div>
    `;
  }
};
BA.styles = qd;
I([
  V("slot:not([name])")
], BA.prototype, "defaultSlot", 2);
I([
  V(".menu-item")
], BA.prototype, "menuItem", 2);
I([
  d()
], BA.prototype, "type", 2);
I([
  d({ type: Boolean, reflect: !0 })
], BA.prototype, "checked", 2);
I([
  d()
], BA.prototype, "value", 2);
I([
  d({ type: Boolean, reflect: !0 })
], BA.prototype, "disabled", 2);
I([
  q("checked")
], BA.prototype, "handleCheckedChange", 1);
I([
  q("disabled")
], BA.prototype, "handleDisabledChange", 1);
I([
  q("type")
], BA.prototype, "handleTypeChange", 1);
BA = I([
  W("sl-menu-item")
], BA);
var Pd = $`
  ${Z}

  :host {
    display: block;
  }

  .menu-label {
    display: inline-block;
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-small);
    font-weight: var(--sl-font-weight-semibold);
    line-height: var(--sl-line-height-normal);
    letter-spacing: var(--sl-letter-spacing-normal);
    color: var(--sl-color-neutral-500);
    padding: var(--sl-spacing-2x-small) var(--sl-spacing-x-large);
    user-select: none;
  }
`, as = class extends P {
  render() {
    return Y` <slot part="base" class="menu-label"></slot> `;
  }
};
as.styles = Pd;
as = I([
  W("sl-menu-label")
], as);
var zd = $`
  ${Z}

  :host {
    --color: var(--sl-panel-border-color);
    --width: var(--sl-panel-border-width);
    --spacing: var(--sl-spacing-medium);
  }

  :host(:not([vertical])) {
    display: block;
    border-top: solid var(--width) var(--color);
    margin: var(--spacing) 0;
  }

  :host([vertical]) {
    display: inline-block;
    height: 100%;
    border-left: solid var(--width) var(--color);
    margin: 0 var(--spacing);
  }
`, Fe = class extends P {
  constructor() {
    super(...arguments), this.vertical = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "separator");
  }
  handleVerticalChange() {
    this.setAttribute("aria-orientation", this.vertical ? "vertical" : "horizontal");
  }
};
Fe.styles = zd;
I([
  d({ type: Boolean, reflect: !0 })
], Fe.prototype, "vertical", 2);
I([
  q("vertical")
], Fe.prototype, "handleVerticalChange", 1);
Fe = I([
  W("sl-divider")
], Fe);
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const Vd = z`@media(forced-colors: active){.menu{border-style:solid;border-color:CanvasText;border-width:1px}}/*# sourceMappingURL=forced-colors-styles.css.map */
`;
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
const tl = [
  "ariaAtomic",
  "ariaAutoComplete",
  "ariaBusy",
  "ariaChecked",
  "ariaColCount",
  "ariaColIndex",
  "ariaColSpan",
  "ariaCurrent",
  "ariaDisabled",
  "ariaExpanded",
  "ariaHasPopup",
  "ariaHidden",
  "ariaInvalid",
  "ariaKeyShortcuts",
  "ariaLabel",
  "ariaLevel",
  "ariaLive",
  "ariaModal",
  "ariaMultiLine",
  "ariaMultiSelectable",
  "ariaOrientation",
  "ariaPlaceholder",
  "ariaPosInSet",
  "ariaPressed",
  "ariaReadOnly",
  "ariaRequired",
  "ariaRoleDescription",
  "ariaRowCount",
  "ariaRowIndex",
  "ariaRowSpan",
  "ariaSelected",
  "ariaSetSize",
  "ariaSort",
  "ariaValueMax",
  "ariaValueMin",
  "ariaValueNow",
  "ariaValueText"
];
tl.map(el);
function el(t) {
  return t.replace("aria", "aria-").replace(/Elements?/g, "").toLowerCase();
}
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
function Js(t) {
  for (const A of tl)
    t.createProperty(A, {
      attribute: el(A),
      reflect: !0
    });
  t.addInitializer((A) => {
    const e = {
      hostConnected() {
        A.setAttribute("role", "presentation");
      }
    };
    A.addController(e);
  });
}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
var il;
const de = {
  ArrowDown: "ArrowDown",
  ArrowUp: "ArrowUp",
  Home: "Home",
  End: "End"
}, jd = new Set(Object.values(de));
function Zd(t) {
  return jd.has(t);
}
class O extends F {
  constructor() {
    super(...arguments), this.type = "list", this.listTabIndex = 0;
  }
  render() {
    return this.renderList();
  }
  /**
   * Renders the main list element.
   */
  renderList() {
    const { ariaLabel: A } = this;
    return p`
    <ul class="md3-list"
        aria-label=${A || J}
        tabindex=${this.listTabIndex}
        role=${this.type || J}
        @keydown=${this.handleKeydown}
        >
      ${this.renderContent()}
    </ul>
  `;
  }
  /**
   * The content to be slotted into the list.
   */
  renderContent() {
    return p`<span><slot @click=${(A) => {
      A.stopPropagation();
    }}></slot></span>`;
  }
  /**
   * Handles keyboard navigation in the list.
   *
   * @param event {KeyboardEvent} The keyboard event that triggers this handler.
   */
  handleKeydown(A) {
    const e = A.key;
    if (!Zd(e))
      return;
    const i = this.items;
    if (!i.length)
      return;
    const o = O.getActiveItem(i);
    switch (o && (o.item.active = !1), A.preventDefault(), e) {
      case de.ArrowDown:
        if (o) {
          const s = O.getNextItem(i, o.index);
          s && (s.active = !0);
        } else
          O.activateFirstItem(i);
        break;
      case de.ArrowUp:
        if (o) {
          const s = O.getPrevItem(i, o.index);
          s && (s.active = !0);
        } else
          i[i.length - 1].active = !0;
        break;
      case de.Home:
        O.activateFirstItem(i);
        break;
      case de.End:
        O.activateLastItem(i);
        break;
    }
  }
  /**
   * Activates the first non-disabled item of a given array of items.
   *
   * @param items {Array<ListItem>} The items from which to activate the
   * first item.
   */
  static activateFirstItem(A) {
    const e = O.getFirstActivatableItem(A);
    e && (e.active = !0);
  }
  /**
   * Activates the last non-disabled item of a given array of items.
   *
   * @param items {Array<ListItem>} The items from which to activate the
   * last item.
   */
  static activateLastItem(A) {
    const e = O.getLastActivatableItem(A);
    e && (e.active = !0);
  }
  /**
   * Deactivates the currently active item of a given array of items.
   *
   * @param items {Array<ListItem>} The items from which to deactivate the
   * active item.
   * @returns A record of the deleselcted activated item including the item and
   * the index of the item or `null` if none are deactivated.
   */
  static deactivateActiveItem(A) {
    const e = O.getActiveItem(A);
    return e && (e.item.active = !1), e;
  }
  focus() {
    this.listRoot?.focus();
  }
  /**
   * Retrieves the the first activated item of a given array of items.
   *
   * @param items {Array<ListItem>} The items to search.
   * @returns A record of the first activated item including the item and the
   * index of the item or `null` if none are activated.
   */
  static getActiveItem(A) {
    for (let e = 0; e < A.length; e++) {
      const i = A[e];
      if (i.active)
        return {
          item: i,
          index: e
        };
    }
    return null;
  }
  /**
   * Retrieves the the first non-disabled item of a given array of items. This
   * the first item that is not disabled.
   *
   * @param items {Array<ListItem>} The items to search.
   * @returns The first activatable item or `null` if none are activatable.
   */
  static getFirstActivatableItem(A) {
    for (const e of A)
      if (!e.disabled)
        return e;
    return null;
  }
  /**
   * Retrieves the the last non-disabled item of a given array of items.
   *
   * @param items {Array<ListItem>} The items to search.
   * @returns The last activatable item or `null` if none are activatable.
   */
  static getLastActivatableItem(A) {
    for (let e = A.length - 1; e >= 0; e--) {
      const i = A[e];
      if (!i.disabled)
        return i;
    }
    return null;
  }
  /**
   * Retrieves the the next non-disabled item of a given array of items.
   *
   * @param items {Array<ListItem>} The items to search.
   * @param index {{index: number}} The index to search from.
   * @returns The next activatable item or `null` if none are activatable.
   */
  static getNextItem(A, e) {
    for (let i = 1; i < A.length; i++) {
      const o = (i + e) % A.length, s = A[o];
      if (!s.disabled)
        return s;
    }
    return null;
  }
  /**
   * Retrieves the the previous non-disabled item of a given array of items.
   *
   * @param items {Array<ListItem>} The items to search.
   * @param index {{index: number}} The index to search from.
   * @returns The previous activatable item or `null` if none are activatable.
   */
  static getPrevItem(A, e) {
    for (let i = 1; i < A.length; i++) {
      const o = (e - i + A.length) % A.length, s = A[o];
      if (!s.disabled)
        return s;
    }
    return null;
  }
}
il = O;
Js(il);
O.shadowRootOptions = { mode: "open", delegatesFocus: !0 };
u([
  y()
], O.prototype, "type", void 0);
u([
  y({ type: Number })
], O.prototype, "listTabIndex", void 0);
u([
  dt(".md3-list")
], O.prototype, "listRoot", void 0);
u([
  Jn({ flatten: !0, selector: "[md-list-item]" })
], O.prototype, "items", void 0);
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const Wd = z`:host{--_container-color: var(--md-list-container-color, var(--md-sys-color-surface, #fef7ff));color:unset;min-width:300px}.md3-list{background-color:var(--_container-color);border-radius:inherit;display:block;list-style-type:none;margin:0;min-width:inherit;outline:none;padding:8px 0;position:relative}/*# sourceMappingURL=list-styles.css.map */
`;
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
let ls = class extends O {
};
ls.styles = [Wd];
ls = u([
  H("md-list")
], ls);
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
class Wi extends F {
  constructor() {
    super(...arguments), this.visible = !1, this.inward = !1, this.htmlFor = null, this.currentControl = null;
  }
  /**
   * The element that controls the visibility of the focus ring. It is one of:
   *
   * - The element referenced by the `for` attribute.
   * - The element provided to `.attach(element)`
   * - The parent element.
   * - `null` if the focus ring is not controlled.
   */
  get control() {
    return this.hasAttribute("for") ? this.htmlFor ? this.getRootNode().querySelector(`#${this.htmlFor}`) : null : this.currentControl || this.parentElement;
  }
  /**
   * Attaches the focus ring to an interactive element.
   *
   * @param control The element that controls the focus ring.
   */
  attach(A) {
    A !== this.currentControl && (this.setCurrentControl(A), this.removeAttribute("for"));
  }
  /**
   * Detaches the focus ring from its current interactive element.
   */
  detach() {
    this.setCurrentControl(null), this.setAttribute("for", "");
  }
  connectedCallback() {
    super.connectedCallback(), this.setCurrentControl(this.control);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.setCurrentControl(null);
  }
  updated(A) {
    if (A.has("htmlFor")) {
      const { control: e } = this;
      e && this.setCurrentControl(e);
    }
  }
  /**
   * @private
   */
  handleEvent(A) {
    if (!A[fn]) {
      switch (A.type) {
        default:
          return;
        case "focusin":
          this.visible = this.control?.matches(":focus-visible") ?? !1;
          break;
        case "focusout":
        case "pointerdown":
          this.visible = !1;
          break;
      }
      A[fn] = !0;
    }
  }
  setCurrentControl(A) {
    for (const e of ["focusin", "focusout", "pointerdown"])
      this.currentControl?.removeEventListener(e, this), A?.addEventListener(e, this);
    this.currentControl = A;
  }
}
u([
  y({ type: Boolean, reflect: !0 })
], Wi.prototype, "visible", void 0);
u([
  y({ type: Boolean, reflect: !0 })
], Wi.prototype, "inward", void 0);
u([
  y({ attribute: "for", reflect: !0 })
], Wi.prototype, "htmlFor", void 0);
const fn = Symbol("handledByFocusRing");
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const Xd = z`:host{--_active-width: var(--md-focus-ring-active-width, 8px);--_color: var(--md-focus-ring-color, var(--md-sys-color-secondary, #625b71));--_duration: var(--md-focus-ring-duration, 600ms);--_inward-offset: var(--md-focus-ring-inward-offset, 0px);--_outward-offset: var(--md-focus-ring-outward-offset, 2px);--_shape: var(--md-focus-ring-shape, 9999px);--_width: var(--md-focus-ring-width, 3px);--_shape-start-start: var(--md-focus-ring-shape-start-start, var(--_shape));--_shape-start-end: var(--md-focus-ring-shape-start-end, var(--_shape));--_shape-end-end: var(--md-focus-ring-shape-end-end, var(--_shape));--_shape-end-start: var(--md-focus-ring-shape-end-start, var(--_shape));animation-delay:0s,calc(var(--_duration)*.25);animation-duration:calc(var(--_duration)*.25),calc(var(--_duration)*.75);animation-timing-function:cubic-bezier(0.2, 0, 0, 1);box-sizing:border-box;color:var(--_color);display:none;pointer-events:none;position:absolute}:host([visible]){display:flex}:host(:not([inward])){animation-name:outward-grow,outward-shrink;border-end-end-radius:calc(var(--_shape-end-end) + var(--_outward-offset));border-end-start-radius:calc(var(--_shape-end-start) + var(--_outward-offset));border-start-end-radius:calc(var(--_shape-start-end) + var(--_outward-offset));border-start-start-radius:calc(var(--_shape-start-start) + var(--_outward-offset));inset:calc(-1*(var(--_outward-offset)));outline:var(--_width) solid currentColor}:host([inward]){animation-name:inward-grow,inward-shrink;border-end-end-radius:calc(var(--_shape-end-end) - var(--_inward-offset));border-end-start-radius:calc(var(--_shape-end-start) - var(--_inward-offset));border-start-end-radius:calc(var(--_shape-start-end) - var(--_inward-offset));border-start-start-radius:calc(var(--_shape-start-start) - var(--_inward-offset));border:var(--_width) solid currentColor;inset:var(--_inward-offset)}@keyframes outward-grow{from{outline-width:0}to{outline-width:var(--_active-width)}}@keyframes outward-shrink{from{outline-width:var(--_active-width)}}@keyframes inward-grow{from{border-width:0}to{border-width:var(--_active-width)}}@keyframes inward-shrink{from{border-width:var(--_active-width)}}@media(prefers-reduced-motion){:host{animation:none}}/*# sourceMappingURL=focus-ring-styles.css.map */
`;
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
let gs = class extends Wi {
};
gs.styles = [Xd];
gs = u([
  H("md-focus-ring")
], gs);
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
class AB extends F {
  render() {
    return p`<span class="shadow"></span>`;
  }
}
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const tB = z`:host{--_level: var(--md-elevation-level, 0);--_shadow-color: var(--md-elevation-shadow-color, var(--md-sys-color-shadow, #000));display:flex;pointer-events:none}:host,.shadow,.shadow::before,.shadow::after{border-radius:inherit;inset:0;position:absolute;transition-duration:inherit;transition-timing-function:inherit}.shadow::before,.shadow::after{content:"";transition-property:box-shadow,opacity}.shadow::before{box-shadow:0px calc(1px*(clamp(0,var(--_level),1) + clamp(0,var(--_level) - 3,1) + 2*clamp(0,var(--_level) - 4,1))) calc(1px*(2*clamp(0,var(--_level),1) + clamp(0,var(--_level) - 2,1) + clamp(0,var(--_level) - 4,1))) 0px var(--_shadow-color);opacity:.3}.shadow::after{box-shadow:0px calc(1px*(clamp(0,var(--_level),1) + clamp(0,var(--_level) - 1,1) + 2*clamp(0,var(--_level) - 2,3))) calc(1px*(3*clamp(0,var(--_level),2) + 2*clamp(0,var(--_level) - 2,3))) calc(1px*(clamp(0,var(--_level),4) + 2*clamp(0,var(--_level) - 4,1))) var(--_shadow-color);opacity:.15}/*# sourceMappingURL=elevation-styles.css.map */
`;
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
let Is = class extends AB {
};
Is.styles = [tB];
Is = u([
  H("md-elevation")
], Is);
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Ui = $i(class extends qi {
  constructor(t) {
    var A;
    if (super(t), t.type !== ks.ATTRIBUTE || t.name !== "class" || ((A = t.strings) === null || A === void 0 ? void 0 : A.length) > 2)
      throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.");
  }
  render(t) {
    return " " + Object.keys(t).filter((A) => t[A]).join(" ") + " ";
  }
  update(t, [A]) {
    var e, i;
    if (this.it === void 0) {
      this.it = /* @__PURE__ */ new Set(), t.strings !== void 0 && (this.nt = new Set(t.strings.join(" ").split(/\s/).filter((s) => s !== "")));
      for (const s in A)
        A[s] && !(!((e = this.nt) === null || e === void 0) && e.has(s)) && this.it.add(s);
      return this.render(A);
    }
    const o = t.element.classList;
    this.it.forEach((s) => {
      s in A || (o.remove(s), this.it.delete(s));
    });
    for (const s in A) {
      const r = !!A[s];
      r === this.it.has(s) || !((i = this.nt) === null || i === void 0) && i.has(s) || (r ? (o.add(s), this.it.add(s)) : (o.remove(s), this.it.delete(s)));
    }
    return GA;
  }
});
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const ol = "important", eB = " !" + ol, iB = $i(class extends qi {
  constructor(t) {
    var A;
    if (super(t), t.type !== ks.ATTRIBUTE || t.name !== "style" || ((A = t.strings) === null || A === void 0 ? void 0 : A.length) > 2)
      throw Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.");
  }
  render(t) {
    return Object.keys(t).reduce((A, e) => {
      const i = t[e];
      return i == null ? A : A + `${e = e.includes("-") ? e : e.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g, "-$&").toLowerCase()}:${i};`;
    }, "");
  }
  update(t, [A]) {
    const { style: e } = t.element;
    if (this.ut === void 0) {
      this.ut = /* @__PURE__ */ new Set();
      for (const i in A)
        this.ut.add(i);
      return this.render(A);
    }
    this.ut.forEach((i) => {
      A[i] == null && (this.ut.delete(i), i.includes("-") ? e.removeProperty(i) : e[i] = "");
    });
    for (const i in A) {
      const o = A[i];
      if (o != null) {
        this.ut.add(i);
        const s = typeof o == "string" && o.endsWith(eB);
        i.includes("-") || s ? e.setProperty(i, s ? o.slice(0, -11) : o, s ? ol : "") : e[i] = o;
      }
    }
    return GA;
  }
});
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
const Be = {
  STANDARD: "cubic-bezier(0.2, 0, 0, 1)",
  STANDARD_ACCELERATE: "cubic-bezier(.3,0,1,1)",
  STANDARD_DECELERATE: "cubic-bezier(0,0,0,1)",
  EMPHASIZED: "cubic-bezier(.3,0,0,1)",
  EMPHASIZED_ACCELERATE: "cubic-bezier(.3,0,.8,.15)",
  EMPHASIZED_DECELERATE: "cubic-bezier(.05,.7,.1,1)"
};
function oB() {
  let t = null;
  return {
    start() {
      return t?.abort(), t = new AbortController(), t.signal;
    },
    finish() {
      t = null;
    }
  };
}
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
class sB extends Event {
  constructor(A, e) {
    super("close-menu", { bubbles: !0, composed: !0 }), this.initiator = A, this.reason = e, this.itemPath = [A];
  }
}
class rB extends Event {
  constructor() {
    super("stay-open-on-focusout", { bubbles: !0, composed: !0 });
  }
}
class yn extends Event {
  constructor() {
    super("close-on-focusout", { bubbles: !0, composed: !0 });
  }
}
const wn = sB;
class nB extends Event {
  constructor() {
    super("deactivate-items", { bubbles: !0, composed: !0 });
  }
}
class aB extends Event {
  constructor() {
    super("deactivate-typeahead", { bubbles: !0, composed: !0 });
  }
}
class mn extends Event {
  constructor() {
    super("activate-typeahead", { bubbles: !0, composed: !0 });
  }
}
const Ai = {
  UP: "ArrowUp",
  DOWN: "ArrowDown",
  RIGHT: "ArrowRight",
  LEFT: "ArrowLeft"
}, we = {
  SPACE: "Space",
  ENTER: "Enter"
}, cs = {
  CLICK_SELECTION: "CLICK_SELECTION",
  KEYDOWN: "KEYDOWN"
}, hs = {
  ESCAPE: "Escape",
  SPACE: we.SPACE,
  ENTER: we.ENTER
};
function lB(t) {
  return Object.values(hs).some((A) => A === t);
}
function gB(t, A) {
  const e = new Event("md-contains", { bubbles: !0, composed: !0 });
  let i = [];
  const o = (r) => {
    i = r.composedPath();
  };
  return A.addEventListener("md-contains", o), t.dispatchEvent(e), A.removeEventListener("md-contains", o), i.length > 0;
}
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
class IB {
  /**
   * @param host The host to connect the controller to.
   * @param getProperties A function that returns the properties for the
   * controller.
   */
  constructor(A, e) {
    this.host = A, this.getProperties = e, this.surfaceStylesInternal = {
      display: "none"
    }, this.lastValues = { isOpen: !1 }, this.host.addController(this);
  }
  /**
   * The StyleInfo map to apply to the surface via Lit's stylemap
   */
  get surfaceStyles() {
    return this.surfaceStylesInternal;
  }
  /**
   * Calculates the surface's new position required so that the surface's
   * `surfaceCorner` aligns to the anchor's `anchorCorner` while keeping the
   * surface inside the window viewport. This positioning also respects RTL by
   * checking `getComputedStyle()` on the surface element.
   */
  async position() {
    const { surfaceEl: A, anchorEl: e, anchorCorner: i, surfaceCorner: o, isTopLayer: s, xOffset: r, yOffset: n } = this.getProperties(), l = i.toUpperCase().trim(), a = o.toUpperCase().trim();
    if (!A || !e)
      return;
    this.surfaceStylesInternal = {
      display: "block",
      opacity: "0"
    }, this.host.requestUpdate(), await this.host.updateComplete;
    const h = A.getSurfacePositionClientRect ? A.getSurfacePositionClientRect() : A.getBoundingClientRect(), g = e.getSurfacePositionClientRect ? e.getSurfacePositionClientRect() : e.getBoundingClientRect(), [c, C] = a.split("_"), [B, Q] = l.split("_"), E = s ? 1 : 0, f = getComputedStyle(A).direction === "ltr" ? 1 : 0, w = f ? 0 : 1, v = C === "START" ? 1 : 0, x = C === "END" ? 1 : 0, N = c === "START" ? 1 : 0, R = c === "END" ? 1 : 0, M = Q !== C ? 1 : 0, j = B !== c ? 1 : 0, lA = M * g.width + r, He = v * g.left + x * (window.innerWidth - g.right), Te = v * (window.innerWidth - g.right) + x * g.left, iA = f * He + w * Te, EA = Math.min(0, window.innerWidth - iA - lA - h.width), JA = E * iA + lA + EA, uA = j * g.height + n, hA = N * g.top + R * (window.innerHeight - g.bottom), aA = Math.min(0, window.innerHeight - hA - uA - h.height), At = E * hA + uA + aA, ie = c === "START" ? "inset-block-start" : "inset-block-end", eo = C === "START" ? "inset-inline-start" : "inset-inline-end";
    this.surfaceStylesInternal = {
      display: "block",
      opacity: "1",
      [ie]: `${At}px`,
      [eo]: `${JA}px`
    }, this.host.requestUpdate();
  }
  hostUpdate() {
    this.onUpdate();
  }
  hostUpdated() {
    this.onUpdate();
  }
  /**
   * Checks whether the properties passed into the controller have changed since
   * the last positioning. If so, it will reposition if the surface is open or
   * close it if the surface should close.
   */
  async onUpdate() {
    const A = this.getProperties();
    let e = !1;
    for (const [r, n] of Object.entries(A))
      if (e = e || n !== this.lastValues[r], e)
        break;
    const i = this.lastValues.isOpen !== A.isOpen, o = !!A.anchorEl, s = !!A.surfaceEl;
    e && o && s && (this.lastValues.isOpen = A.isOpen, A.isOpen ? (this.lastValues = A, await this.position(), A.onOpen()) : i && (await A.beforeClose(), this.close(), A.onClose()));
  }
  /**
   * Hides the surface.
   */
  close() {
    this.surfaceStylesInternal = {
      display: "none"
    }, this.host.requestUpdate();
  }
}
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
const kA = {
  INDEX: 0,
  ITEM: 1,
  TEXT: 2
};
class cB {
  /**
   * @param getProperties A function that returns the options of the typeahead
   * controller:
   *
   * {
   *   getItems: A function that returns an array of menu items to be searched.
   *   typeaheadBufferTime: The maximum time between each keystroke to keep the
   *       current type buffer alive.
   * }
   */
  constructor(A) {
    this.getProperties = A, this.typeaheadRecords = [], this.typaheadBuffer = "", this.cancelTypeaheadTimeout = 0, this.isTypingAhead = !1, this.lastActiveRecord = null, this.onKeydown = (e) => {
      this.isTypingAhead ? this.typeahead(e) : this.beginTypeahead(e);
    }, this.endTypeahead = () => {
      this.isTypingAhead = !1, this.typaheadBuffer = "", this.typeaheadRecords = [];
    };
  }
  get items() {
    return this.getProperties().getItems();
  }
  get active() {
    return this.getProperties().active;
  }
  /**
   * Sets up typingahead
   */
  beginTypeahead(A) {
    this.active && (A.code === "Space" || A.code === "Enter" || A.code.startsWith("Arrow") || A.code === "Escape" || (this.isTypingAhead = !0, this.typeaheadRecords = this.items.map((e, i) => [i, e, e.headline.trim().toLowerCase()]), this.lastActiveRecord = this.typeaheadRecords.find((e) => e[kA.ITEM].active) ?? null, this.lastActiveRecord && (this.lastActiveRecord[kA.ITEM].active = !1), this.typeahead(A)));
  }
  /**
   * Performs the typeahead. Based on the normalized items and the current text
   * buffer, finds the _next_ item with matching text and activates it.
   *
   * @example
   *
   * items: Apple, Banana, Olive, Orange, Cucumber
   * buffer: ''
   * user types: o
   *
   * activates Olive
   *
   * @example
   *
   * items: Apple, Banana, Olive (active), Orange, Cucumber
   * buffer: 'o'
   * user types: l
   *
   * activates Olive
   *
   * @example
   *
   * items: Apple, Banana, Olive (active), Orange, Cucumber
   * buffer: ''
   * user types: o
   *
   * activates Orange
   *
   * @example
   *
   * items: Apple, Banana, Olive, Orange (active), Cucumber
   * buffer: ''
   * user types: o
   *
   * activates Olive
   */
  typeahead(A) {
    if (clearTimeout(this.cancelTypeaheadTimeout), A.code === "Enter" || A.code.startsWith("Arrow") || A.code === "Escape") {
      this.endTypeahead(), this.lastActiveRecord && (this.lastActiveRecord[kA.ITEM].active = !1);
      return;
    }
    A.code === "Space" && (A.stopPropagation(), A.preventDefault()), this.cancelTypeaheadTimeout = setTimeout(this.endTypeahead, this.getProperties().typeaheadBufferTime), this.typaheadBuffer += A.key.toLowerCase();
    const e = this.lastActiveRecord ? this.lastActiveRecord[kA.INDEX] : -1, i = this.typeaheadRecords.length, o = (l) => (l[kA.INDEX] + i - e) % i, s = this.typeaheadRecords.filter((l) => !l[kA.ITEM].disabled && l[kA.TEXT].startsWith(this.typaheadBuffer)).sort((l, a) => o(l) - o(a));
    if (s.length === 0) {
      clearTimeout(this.cancelTypeaheadTimeout), this.lastActiveRecord && (this.lastActiveRecord[kA.ITEM].active = !1), this.endTypeahead();
      return;
    }
    const r = this.typaheadBuffer.length === 1;
    let n;
    this.lastActiveRecord === s[0] && r ? n = s[1] ?? s[0] : n = s[0], this.lastActiveRecord && (this.lastActiveRecord[kA.ITEM].active = !1), this.lastActiveRecord = n, n[kA.ITEM].active = !0;
  }
}
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
var sl;
const hB = 200;
function rl(t = document) {
  const A = t.activeElement;
  return A ? A.shadowRoot ? rl(A.shadowRoot) ?? A : A : null;
}
class T extends F {
  constructor() {
    super(...arguments), this.anchor = null, this.fixed = !1, this.quick = !1, this.hasOverflow = !1, this.open = !1, this.xOffset = 0, this.yOffset = 0, this.listTabIndex = 0, this.type = "menu", this.typeaheadBufferTime = hB, this.anchorCorner = "END_START", this.menuCorner = "START_START", this.stayOpenOnOutsideClick = !1, this.stayOpenOnFocusout = !1, this.skipRestoreFocus = !1, this.defaultFocus = "LIST_ROOT", this.typeaheadActive = !0, this.openCloseAnimationSignal = oB(), this.lastFocusedElement = null, this.typeaheadController = new cB(() => ({
      getItems: () => this.items,
      typeaheadBufferTime: this.typeaheadBufferTime,
      active: this.typeaheadActive
    })), this.menuPositionController = new IB(this, () => ({
      anchorCorner: this.anchorCorner,
      surfaceCorner: this.menuCorner,
      surfaceEl: this.surfaceEl,
      anchorEl: this.anchor,
      isTopLayer: this.fixed,
      isOpen: this.open,
      xOffset: this.xOffset,
      yOffset: this.yOffset,
      onOpen: this.onOpened,
      beforeClose: this.beforeClose,
      onClose: this.onClosed
    })), this.onOpened = () => {
      if (this.lastFocusedElement = rl(), !this.listElement)
        return;
      const A = this.listElement.items, e = O.getActiveItem(A);
      switch (e && this.defaultFocus !== "NONE" && (e.item.active = !1), this.defaultFocus) {
        case "FIRST_ITEM":
          const i = O.getFirstActivatableItem(A);
          i && (i.active = !0);
          break;
        case "LAST_ITEM":
          const o = O.getLastActivatableItem(A);
          o && (o.active = !0);
          break;
        case "LIST_ROOT":
          this.listElement?.focus();
          break;
        default:
        case "NONE":
          break;
      }
      this.quick ? (this.dispatchEvent(new Event("opening")), this.dispatchEvent(new Event("opened"))) : this.animateOpen();
    }, this.beforeClose = async () => {
      this.open = !1, this.skipRestoreFocus || this.lastFocusedElement?.focus?.(), this.quick || await this.animateClose();
    }, this.onClosed = () => {
      this.quick && (this.dispatchEvent(new Event("closing")), this.dispatchEvent(new Event("closed")));
    }, this.onWindowClick = (A) => {
      !this.stayOpenOnOutsideClick && !A.composedPath().includes(this) && (this.open = !1);
    };
  }
  /**
   * Whether the menu is animating upwards or downwards when opening. This is
   * helpful for calculating some animation calculations.
   */
  get openDirection() {
    return this.menuCorner.split("_")[0] === "START" ? "DOWN" : "UP";
  }
  /**
   * The menu items associated with this menu. The items must be `MenuItem`s and
   * have both the `md-menu-item` and `md-list-item` attributes.
   */
  get items() {
    const A = this.listElement;
    return A ? A.items.filter((e) => e.hasAttribute("md-menu-item")) : [];
  }
  render() {
    return this.renderSurface();
  }
  /**
   * Renders the positionable surface element and its contents.
   */
  renderSurface() {
    return p`
       <div
          class="menu ${Ui(this.getSurfaceClasses())}"
          style=${iB(this.menuPositionController.surfaceStyles)}
          @focusout=${this.handleFocusout}>
        ${this.renderElevation()}
        ${this.renderList()}
        ${this.renderFocusRing()}
       </div>
     `;
  }
  /**
   * Renders the List element and its items
   */
  renderList() {
    const { ariaLabel: A } = this;
    return p`
      <md-list
          id="list"
          aria-label=${A || J}
          type=${this.type}
          listTabIndex=${this.listTabIndex}
          @keydown=${this.handleListKeydown}>
        ${this.renderMenuItems()}
      </md-list>`;
  }
  /**
   * Renders the menu items' slot
   */
  renderMenuItems() {
    return p`<slot
        @close-menu=${this.onCloseMenu}
        @deactivate-items=${this.onDeactivateItems}
        @deactivate-typeahead=${this.handleDeactivateTypeahead}
        @activate-typeahead=${this.handleActivateTypeahead}
        @stay-open-on-focusout=${this.handleStayOpenOnFocusout}
        @close-on-focusout=${this.handleCloseOnFocusout}></slot>`;
  }
  /**
   * Renders the elevation component.
   */
  renderElevation() {
    return p`<md-elevation></md-elevation>`;
  }
  /**
   * Renders the focus ring component.
   */
  renderFocusRing() {
    return p`<md-focus-ring for="list"></md-focus-ring>`;
  }
  getSurfaceClasses() {
    return {
      open: this.open,
      fixed: this.fixed,
      "has-overflow": this.hasOverflow
    };
  }
  async handleFocusout(A) {
    if (this.stayOpenOnFocusout || (A.stopPropagation(), A.relatedTarget && gB(A.relatedTarget, this)))
      return;
    const e = this.skipRestoreFocus;
    this.skipRestoreFocus = !0, this.close(), await this.updateComplete, this.skipRestoreFocus = e;
  }
  // Capture so that we can grab the event before it reaches the list item
  // istelf. Specifically useful for the case where typeahead encounters a space
  // and we don't want the menu item to close the menu.
  handleListKeydown(A) {
    this.typeaheadController.onKeydown(A);
  }
  /**
   * Performs the opening animation:
   *
   * https://direct.googleplex.com/#/spec/295000003+271060003
   */
  animateOpen() {
    const A = this.surfaceEl, e = this.slotEl;
    if (!A || !e)
      return;
    const i = this.openDirection;
    this.dispatchEvent(new Event("opening")), A.classList.toggle("animating", !0);
    const o = this.openCloseAnimationSignal.start(), s = A.offsetHeight, r = i === "UP", n = this.items, l = 500, a = 50, h = 250, g = (l - h) / n.length, c = A.animate([{ height: "0px" }, { height: `${s}px` }], {
      duration: l,
      easing: Be.EMPHASIZED
    }), C = e.animate([
      { transform: r ? `translateY(-${s}px)` : "" },
      { transform: "" }
    ], { duration: l, easing: Be.EMPHASIZED }), B = A.animate([{ opacity: 0 }, { opacity: 1 }], a), Q = [];
    for (let E = 0; E < n.length; E++) {
      const f = r ? n.length - 1 - E : E, w = n[f], v = w.animate([{ opacity: 0 }, { opacity: 1 }], {
        duration: h,
        delay: g * E
      });
      w.classList.toggle("hidden", !0), v.addEventListener("finish", () => {
        w.classList.toggle("hidden", !1);
      }), Q.push([w, v]);
    }
    o.addEventListener("abort", () => {
      c.cancel(), C.cancel(), B.cancel(), Q.forEach(([E, f]) => {
        E.classList.toggle("hidden", !1), f.cancel();
      });
    }), c.addEventListener("finish", () => {
      A.classList.toggle("animating", !1), this.openCloseAnimationSignal.finish(), this.dispatchEvent(new Event("opened"));
    });
  }
  /**
   * Performs the closing animation:
   *
   * https://direct.googleplex.com/#/spec/295000003+271060003
   */
  animateClose() {
    let A, e;
    const i = new Promise((R, M) => {
      A = R, e = M;
    }), o = this.surfaceEl, s = this.slotEl;
    if (!o || !s)
      return e(), i;
    const n = this.openDirection === "UP";
    this.dispatchEvent(new Event("closing")), o.classList.toggle("animating", !0);
    const l = this.openCloseAnimationSignal.start(), a = o.offsetHeight, h = this.items, g = 150, c = 50, C = g - c, B = 50, Q = 50, E = 0.35, f = (g - Q - B) / h.length, w = o.animate([
      { height: `${a}px` },
      { height: `${a * E}px` }
    ], {
      duration: g,
      easing: Be.EMPHASIZED_ACCELERATE
    }), v = s.animate([
      { transform: "" },
      {
        transform: n ? `translateY(-${a * (1 - E)}px)` : ""
      }
    ], { duration: g, easing: Be.EMPHASIZED_ACCELERATE }), x = o.animate([{ opacity: 1 }, { opacity: 0 }], { duration: c, delay: C }), N = [];
    for (let R = 0; R < h.length; R++) {
      const M = n ? R : h.length - 1 - R, j = h[M], lA = j.animate([{ opacity: 1 }, { opacity: 0 }], {
        duration: B,
        delay: Q + f * R
      });
      lA.addEventListener("finish", () => {
        j.classList.toggle("hidden", !0);
      }), N.push([j, lA]);
    }
    return l.addEventListener("abort", () => {
      w.cancel(), v.cancel(), x.cancel(), N.forEach(([R, M]) => {
        M.cancel(), R.classList.toggle("hidden", !1);
      }), e();
    }), w.addEventListener("finish", () => {
      o.classList.toggle("animating", !1), N.forEach(([R]) => {
        R.classList.toggle("hidden", !1);
      }), this.openCloseAnimationSignal.finish(), this.dispatchEvent(new Event("closed")), A(!0);
    }), i;
  }
  connectedCallback() {
    super.connectedCallback(), window.addEventListener("click", this.onWindowClick, { capture: !0 });
  }
  disconnectedCallback() {
    super.disconnectedCallback(), window.removeEventListener("click", this.onWindowClick, { capture: !0 });
  }
  onCloseMenu() {
    this.close();
  }
  onDeactivateItems(A) {
    A.stopPropagation();
    const e = this.items;
    for (const i of e)
      i.active = !1, i.selected = !1;
  }
  handleDeactivateTypeahead(A) {
    A.stopPropagation(), this.typeaheadActive = !1;
  }
  handleActivateTypeahead(A) {
    A.stopPropagation(), this.typeaheadActive = !0;
  }
  handleStayOpenOnFocusout(A) {
    A.stopPropagation(), this.stayOpenOnFocusout = !0;
  }
  handleCloseOnFocusout(A) {
    A.stopPropagation(), this.stayOpenOnFocusout = !1;
  }
  focus() {
    this.listElement?.focus();
  }
  close() {
    this.open = !1, this.items.forEach((A) => {
      A.close?.();
    });
  }
  show() {
    this.open = !0;
  }
}
sl = T;
Js(sl);
u([
  dt("md-list")
], T.prototype, "listElement", void 0);
u([
  dt(".menu")
], T.prototype, "surfaceEl", void 0);
u([
  dt("slot")
], T.prototype, "slotEl", void 0);
u([
  y({ attribute: !1 })
], T.prototype, "anchor", void 0);
u([
  y({ type: Boolean })
], T.prototype, "fixed", void 0);
u([
  y({ type: Boolean })
], T.prototype, "quick", void 0);
u([
  y({ type: Boolean, attribute: "has-overflow" })
], T.prototype, "hasOverflow", void 0);
u([
  y({ type: Boolean, reflect: !0 })
], T.prototype, "open", void 0);
u([
  y({ type: Number, attribute: "x-offset" })
], T.prototype, "xOffset", void 0);
u([
  y({ type: Number, attribute: "y-offset" })
], T.prototype, "yOffset", void 0);
u([
  y({ type: Number, attribute: "list-tab-index" })
], T.prototype, "listTabIndex", void 0);
u([
  y()
], T.prototype, "type", void 0);
u([
  y({ type: Number, attribute: "typeahead-delay" })
], T.prototype, "typeaheadBufferTime", void 0);
u([
  y({ attribute: "anchor-corner" })
], T.prototype, "anchorCorner", void 0);
u([
  y({ attribute: "menu-corner" })
], T.prototype, "menuCorner", void 0);
u([
  y({ type: Boolean, attribute: "stay-open-on-outside-click" })
], T.prototype, "stayOpenOnOutsideClick", void 0);
u([
  y({ type: Boolean, attribute: "stay-open-on-focusout" })
], T.prototype, "stayOpenOnFocusout", void 0);
u([
  y({ type: Boolean, attribute: "skip-restore-focus" })
], T.prototype, "skipRestoreFocus", void 0);
u([
  y({ attribute: "default-focus" })
], T.prototype, "defaultFocus", void 0);
u([
  _A()
], T.prototype, "typeaheadActive", void 0);
u([
  _l({ capture: !0 })
], T.prototype, "handleListKeydown", null);
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const CB = z`:host{--_container-color: var(--md-menu-container-color, var(--md-sys-color-surface-container, #f3edf7));--_container-elevation: var(--md-menu-container-elevation, 2);--_container-shadow-color: var(--md-menu-container-shadow-color, var(--md-sys-color-shadow, #000));--_container-shape: var(--md-menu-container-shape, 4px);--md-list-container-color: var(--_container-color);--md-elevation-level:var(--_container-elevation);--md-elevation-shadow-color:var(--_container-shadow-color);--md-focus-ring-shape: var(--_container-shape);min-width:300px}.menu{border-radius:var(--_container-shape);display:none;opacity:0;z-index:20;position:absolute;user-select:none;max-height:inherit;height:inherit;min-width:inherit}.menu.fixed{position:fixed}.menu md-list{height:inherit;max-height:inherit;display:block;overflow:auto;min-width:inherit;border-radius:inherit}.menu.has-overflow md-list{overflow:visible}.menu.animating md-list{pointer-events:none;overflow:hidden}.menu.animating ::slotted(.hidden){opacity:0}.menu slot{display:block;height:inherit;max-height:inherit}/*# sourceMappingURL=menu-styles.css.map */
`;
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
let Cs = class extends T {
};
Cs.styles = [CB, Vd];
Cs = u([
  H("md-menu")
], Cs);
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const nl = z`@media(forced-colors: active){:host{--md-list-item-list-item-disabled-label-text-color: GrayText;--md-list-item-list-item-disabled-label-text-opacity: 1;--md-list-item-list-item-disabled-leading-icon-color: GrayText;--md-list-item-list-item-disabled-leading-icon-opacity: 1;--md-list-item-list-item-disabled-trailing-icon-color: GrayText;--md-list-item-list-item-disabled-trailing-icon-opacity: 1}}/*# sourceMappingURL=forced-colors-styles.css.map */
`;
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const al = z`:host{--_list-item-container-color: var(--md-list-item-list-item-container-color, var(--md-sys-color-surface, #fef7ff));--_list-item-container-shape: var(--md-list-item-list-item-container-shape, 0px);--_list-item-disabled-label-text-color: var(--md-list-item-list-item-disabled-label-text-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-disabled-label-text-opacity: var(--md-list-item-list-item-disabled-label-text-opacity, 0.3);--_list-item-disabled-leading-icon-color: var(--md-list-item-list-item-disabled-leading-icon-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-disabled-leading-icon-opacity: var(--md-list-item-list-item-disabled-leading-icon-opacity, 0.38);--_list-item-disabled-trailing-icon-color: var(--md-list-item-list-item-disabled-trailing-icon-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-disabled-trailing-icon-opacity: var(--md-list-item-list-item-disabled-trailing-icon-opacity, 0.38);--_list-item-focus-label-text-color: var(--md-list-item-list-item-focus-label-text-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-focus-leading-icon-icon-color: var(--md-list-item-list-item-focus-leading-icon-icon-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-focus-state-layer-color: var(--md-list-item-list-item-focus-state-layer-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-focus-state-layer-opacity: var(--md-list-item-list-item-focus-state-layer-opacity, 0.12);--_list-item-focus-trailing-icon-icon-color: var(--md-list-item-list-item-focus-trailing-icon-icon-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-hover-label-text-color: var(--md-list-item-list-item-hover-label-text-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-hover-leading-icon-icon-color: var(--md-list-item-list-item-hover-leading-icon-icon-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-hover-state-layer-color: var(--md-list-item-list-item-hover-state-layer-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-hover-state-layer-opacity: var(--md-list-item-list-item-hover-state-layer-opacity, 0.08);--_list-item-hover-trailing-icon-icon-color: var(--md-list-item-list-item-hover-trailing-icon-icon-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-label-text-color: var(--md-list-item-list-item-label-text-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-label-text-line-height: var(--md-list-item-list-item-label-text-line-height, 1.5rem);--_list-item-label-text-type: var(--md-list-item-list-item-label-text-type, var(--md-sys-typescale-body-large, 400 1rem / 1.5rem var(--md-ref-typeface-plain, Roboto)));--_list-item-large-leading-video-height: var(--md-list-item-list-item-large-leading-video-height, 69px);--_list-item-leading-avatar-label-color: var(--md-list-item-list-item-leading-avatar-label-color, var(--md-sys-color-on-primary-container, #21005d));--_list-item-leading-avatar-label-type: var(--md-list-item-list-item-leading-avatar-label-type, var(--md-sys-typescale-title-medium, 500 1rem / 1.5rem var(--md-ref-typeface-plain, Roboto)));--_list-item-leading-avatar-color: var(--md-list-item-list-item-leading-avatar-color, var(--md-sys-color-primary-container, #eaddff));--_list-item-leading-avatar-shape: var(--md-list-item-list-item-leading-avatar-shape, 9999px);--_list-item-leading-avatar-size: var(--md-list-item-list-item-leading-avatar-size, 40px);--_list-item-leading-icon-color: var(--md-list-item-list-item-leading-icon-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-leading-icon-size: var(--md-list-item-list-item-leading-icon-size, 18px);--_list-item-leading-image-height: var(--md-list-item-list-item-leading-image-height, 56px);--_list-item-leading-image-shape: var(--md-list-item-list-item-leading-image-shape, 0px);--_list-item-leading-image-width: var(--md-list-item-list-item-leading-image-width, 56px);--_list-item-leading-video-shape: var(--md-list-item-list-item-leading-video-shape, 0px);--_list-item-leading-video-width: var(--md-list-item-list-item-leading-video-width, 100px);--_list-item-one-line-container-height: var(--md-list-item-list-item-one-line-container-height, 56px);--_list-item-pressed-label-text-color: var(--md-list-item-list-item-pressed-label-text-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-pressed-leading-icon-icon-color: var(--md-list-item-list-item-pressed-leading-icon-icon-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-pressed-state-layer-color: var(--md-list-item-list-item-pressed-state-layer-color, var(--md-sys-color-on-surface, #1d1b20));--_list-item-pressed-state-layer-opacity: var(--md-list-item-list-item-pressed-state-layer-opacity, 0.12);--_list-item-pressed-trailing-icon-icon-color: var(--md-list-item-list-item-pressed-trailing-icon-icon-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-small-leading-video-height: var(--md-list-item-list-item-small-leading-video-height, 56px);--_list-item-supporting-text-color: var(--md-list-item-list-item-supporting-text-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-supporting-text-type: var(--md-list-item-list-item-supporting-text-type, var(--md-sys-typescale-body-medium, 400 0.875rem / 1.25rem var(--md-ref-typeface-plain, Roboto)));--_list-item-three-line-container-height: var(--md-list-item-list-item-three-line-container-height, 88px);--_list-item-trailing-icon-color: var(--md-list-item-list-item-trailing-icon-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-trailing-icon-size: var(--md-list-item-list-item-trailing-icon-size, 24px);--_list-item-trailing-supporting-text-color: var(--md-list-item-list-item-trailing-supporting-text-color, var(--md-sys-color-on-surface-variant, #49454f));--_list-item-trailing-supporting-text-line-height: var(--md-list-item-list-item-trailing-supporting-text-line-height, 1rem);--_list-item-trailing-supporting-text-type: var(--md-list-item-list-item-trailing-supporting-text-type, var(--md-sys-typescale-label-small, 500 0.688rem / 1rem var(--md-ref-typeface-plain, Roboto)));--_list-item-two-line-container-height: var(--md-list-item-list-item-two-line-container-height, 72px);--_list-item-leading-element-leading-space: var(--md-list-item-list-item-leading-element-leading-space, 16px);--_list-item-leading-space: var(--md-list-item-list-item-leading-space, 16px);--_list-item-leading-video-leading-space: var(--md-list-item-list-item-leading-video-leading-space, 0px);--_list-item-trailing-element-headline-trailing-element-space: var(--md-list-item-list-item-trailing-element-headline-trailing-element-space, 16px);--_list-item-trailing-space: var(--md-list-item-list-item-trailing-space, 16px)}:host{color:unset;--md-focus-ring-shape: 8px;--md-ripple-hover-color: var(--_list-item-hover-state-layer-color);--md-ripple-hover-opacity: var(--_list-item-hover-state-layer-opacity);--md-ripple-pressed-color: var(--_list-item-pressed-state-layer-color);--md-ripple-pressed-opacity: var(--_list-item-pressed-state-layer-opacity);--md-ripple-focus-color: var(--_list-item-focus-state-layer-color);--md-ripple-focus-opacity: var(--_list-item-focus-state-layer-opacity)}.list-item{align-items:center;box-sizing:border-box;display:flex;outline:none;position:relative;width:100%;text-decoration:none;background-color:var(--_list-item-container-color);border-radius:var(--_list-item-container-shape);-webkit-tap-highlight-color:rgba(0,0,0,0)}.list-item:not(.disabled):not(.noninteractive){cursor:pointer}.list-item.disabled{pointer-events:none}.content-wrapper{display:flex;width:100%;border-radius:inherit}md-ripple{border-radius:inherit}.with-one-line{min-height:var(--_list-item-one-line-container-height)}.with-two-line{min-height:var(--_list-item-two-line-container-height)}.with-three-line{min-height:var(--_list-item-three-line-container-height)}.start{display:inline-flex;flex-direction:column;justify-content:center;align-items:center;flex:0 0 auto;z-index:1}.with-three-line .start{justify-content:start}slot[name=start]::slotted([data-variant=icon]),slot[name=start]::slotted([data-variant=image]),slot[name=start]::slotted([data-variant=avatar]){margin-inline-start:var(--_list-item-leading-element-leading-space)}.body{display:inline-flex;justify-content:center;flex-direction:column;box-sizing:border-box;flex:1 0 0;padding-inline-start:var(--_list-item-leading-space);padding-inline-end:var(--_list-item-trailing-space);z-index:1}.end{display:inline-flex;flex-direction:column;justify-content:center;flex:0 0 auto;z-index:1}.with-three-line .end{justify-content:start}slot[name=end]::slotted(*),.trailing-supporting-text{margin-inline-end:var(--_list-item-trailing-element-headline-trailing-element-space)}.label-text{display:flex;color:var(--_list-item-label-text-color);font:var(--_list-item-label-text-type)}:hover .label-text{color:var(--_list-item-hover-label-text-color)}:focus .label-text{color:var(--_list-item-focus-label-text-color)}:active .label-text{color:var(--_list-item-pressed-label-text-color)}.disabled .label-text{color:var(--_list-item-disabled-label-text-color);opacity:var(--_list-item-disabled-label-text-opacity)}.supporting-text{text-overflow:ellipsis;white-space:normal;overflow:hidden;width:100%;color:var(--_list-item-supporting-text-color);font:var(--_list-item-supporting-text-type);-webkit-box-orient:vertical;-webkit-line-clamp:1;display:-webkit-box}.disabled .supporting-text{color:var(--_list-item-disabled-label-text-color);opacity:var(--_list-item-disabled-label-text-opacity)}.supporting-text--multi-line{-webkit-line-clamp:2}.trailing-supporting-text{padding-inline-start:16px;font:var(--_list-item-trailing-supporting-text-type)}.list-item:not(.disabled) .trailing-supporting-text{color:var(--_list-item-trailing-supporting-text-color)}.disabled .trailing-supporting-text{color:var(--_list-item-disabled-label-text-color);opacity:var(--_list-item-disabled-label-text-opacity)}.with-three-line .trailing-supporting-text{padding-block-start:calc((var(--_list-item-label-text-line-height) - var(--_list-item-trailing-supporting-text-line-height))/2)}.focus-ring{z-index:1}::slotted([data-variant=image]){display:inline-flex;height:var(--_list-item-leading-image-height);width:var(--_list-item-leading-image-width);border-radius:var(--_list-item-leading-image-shape);padding-block:calc((var(--_list-item-two-line-container-height) - var(--_list-item-leading-image-height))/2)}.with-three-line ::slotted([data-variant=image]){padding-block:0}slot[name=start]::slotted([data-variant=icon]){--md-icon-color:var(--_list-item-leading-icon-color);--md-icon-size:var(--_list-item-leading-icon-size)}.with-three-line slot[name=start]::slotted([data-variant=icon]){padding-block-start:calc((var(--_list-item-label-text-line-height) - var(--_list-item-leading-icon-size))/2)}slot[name=end]::slotted([data-variant=icon]){--md-icon-color:var(--_list-item-trailing-icon-color);--md-icon-size:var(--_list-item-trailing-icon-size)}.with-three-line slot[name=end]::slotted([data-variant=icon]){padding-block-start:calc((var(--_list-item-label-text-line-height) - var(--_list-item-trailing-icon-size))/2)}:hover slot[name=start]::slotted([data-variant=icon]){--md-icon-color:var(--_list-item-hover-leading-icon-icon-color)}:hover slot[name=end]::slotted([data-variant=icon]){--md-icon-color:var(--_list-item-hover-trailing-icon-icon-color)}:focus slot[name=start]::slotted([data-variant=icon]){--md-icon-color:var(--_list-item-focus-leading-icon-icon-color)}:focus slot[name=end]::slotted([data-variant=icon]){--md-icon-color:var(--_list-item-focus-trailing-icon-icon-color)}:active slot[name=start]::slotted([data-variant=icon]){--md-icon-color:var(--_list-item-pressed-leading-icon-icon-color)}:active slot[name=end]::slotted([data-variant=icon]){--md-icon-color:var(--_list-item-pressed-trailing-icon-icon-color)}.disabled slot[name=start]::slotted([data-variant=icon]){opacity:var(--_list-item-disabled-leading-icon-opacity);--md-icon-color:var(--_list-item-disabled-leading-icon-color)}.disabled slot[name=end]::slotted([data-variant=icon]){opacity:var(--_list-item-disabled-trailing-icon-opacity);--md-icon-color:var(--_list-item-disabled-trailing-icon-color)}::slotted([data-variant=avatar]){display:inline-flex;justify-content:center;align-items:center;background-color:var(--_list-item-leading-avatar-color);height:var(--_list-item-leading-avatar-size);width:var(--_list-item-leading-avatar-size);border-radius:var(--_list-item-leading-avatar-shape);color:var(--_list-item-leading-avatar-label-color);font:var(--_list-item-leading-avatar-label-type)}::slotted([data-variant=video]),::slotted([data-variant=video-large]){display:inline-flex;object-fit:cover;height:var(--_list-item-small-leading-video-height);width:var(--_list-item-leading-video-width);border-radius:var(--_list-item-leading-video-shape);margin-inline-start:var(--_list-item-leading-video-leading-space);padding-block:calc((var(--_list-item-three-line-container-height) - var(--_list-item-small-leading-video-height))/2)}.with-three-line ::slotted([data-variant=video]),.with-three-line ::slotted([data-variant=video-large]){padding-block:0}::slotted([data-variant=video-large]){padding-block:calc((var(--_list-item-three-line-container-height) - var(--_list-item-large-leading-video-height))/2);height:var(--_list-item-large-leading-video-height)}/*# sourceMappingURL=list-item-styles.css.map */
`;
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const ll = z`@media(forced-colors: active){.list-item{position:relative}:host([selected]) .list-item:not(:has(.focus-ring[visible]))::before{content:"";position:absolute;inset:0;box-sizing:border-box;border-radius:inherit;pointer-events:none;border:3px double CanvasText}}/*# sourceMappingURL=forced-colors-styles.css.map */
`;
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const gl = z`:host{--_list-item-selected-container-color: var(--md-menu-item-list-item-selected-container-color, var(--md-sys-color-surface-container-highest, #e6e0e9));--_list-item-container-color: var(--md-menu-item-list-item-container-color, var(--md-sys-color-surface-container, #f3edf7));--md-list-item-list-item-container-color: var(--_list-item-container-color)}:host([selected]) .list-item{background-color:var(--_list-item-selected-container-color)}.list-item:has(.submenu:hover){--md-ripple-hover-opacity: 0}/*# sourceMappingURL=menu-item-styles.css.map */
`;
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
const dB = 450, vn = 225, BB = 0.2, QB = 10, EB = 75, uB = 0.35, pB = "::after", fB = "forwards";
var oA;
(function(t) {
  t[t.INACTIVE = 0] = "INACTIVE", t[t.TOUCH_DELAY = 1] = "TOUCH_DELAY", t[t.HOLDING = 2] = "HOLDING", t[t.WAITING_FOR_CLICK = 3] = "WAITING_FOR_CLICK";
})(oA || (oA = {}));
const yB = 150;
class ut extends F {
  constructor() {
    super(...arguments), this.unbounded = !1, this.disabled = !1, this.hovered = !1, this.focused = !1, this.pressed = !1, this.rippleSize = "", this.rippleScale = "", this.initialSize = 0, this.state = oA.INACTIVE, this.checkBoundsAfterContextMenu = !1;
  }
  handlePointerenter(A) {
    this.shouldReactToEvent(A) && (this.hovered = !0);
  }
  handlePointerleave(A) {
    this.shouldReactToEvent(A) && (this.hovered = !1, this.state !== oA.INACTIVE && this.endPressAnimation());
  }
  handleFocusin() {
    this.focused = !0;
  }
  handleFocusout() {
    this.focused = !1;
  }
  handlePointerup(A) {
    if (this.shouldReactToEvent(A)) {
      if (this.state === oA.HOLDING) {
        this.state = oA.WAITING_FOR_CLICK;
        return;
      }
      if (this.state === oA.TOUCH_DELAY) {
        this.state = oA.WAITING_FOR_CLICK, this.startPressAnimation(this.rippleStartEvent);
        return;
      }
    }
  }
  async handlePointerdown(A) {
    if (this.shouldReactToEvent(A)) {
      if (this.rippleStartEvent = A, !this.isTouch(A)) {
        this.state = oA.WAITING_FOR_CLICK, this.startPressAnimation(A);
        return;
      }
      this.checkBoundsAfterContextMenu && !this.inBounds(A) || (this.checkBoundsAfterContextMenu = !1, this.state = oA.TOUCH_DELAY, await new Promise((e) => {
        setTimeout(e, yB);
      }), this.state === oA.TOUCH_DELAY && (this.state = oA.HOLDING, this.startPressAnimation(A)));
    }
  }
  handleClick() {
    if (!this.disabled) {
      if (this.state === oA.WAITING_FOR_CLICK) {
        this.endPressAnimation();
        return;
      }
      this.state === oA.INACTIVE && (this.startPressAnimation(), this.endPressAnimation());
    }
  }
  handlePointercancel(A) {
    this.shouldReactToEvent(A) && this.endPressAnimation();
  }
  handleContextmenu() {
    this.disabled || (this.checkBoundsAfterContextMenu = !0, this.endPressAnimation());
  }
  render() {
    const A = {
      hovered: this.hovered,
      focused: this.focused,
      pressed: this.pressed,
      unbounded: this.unbounded
    };
    return p`<div class="surface ${Ui(A)}"></div>`;
  }
  update(A) {
    A.has("disabled") && this.disabled && (this.hovered = !1, this.focused = !1, this.pressed = !1), super.update(A);
  }
  getDimensions() {
    return (this.parentElement ?? this).getBoundingClientRect();
  }
  determineRippleSize() {
    const { height: A, width: e } = this.getDimensions(), i = Math.max(A, e), o = Math.max(uB * i, EB);
    let s = i, r = Math.floor(i * BB);
    s = Math.sqrt(e ** 2 + A ** 2) + QB, this.unbounded && (r = r - r % 2), this.initialSize = r, this.rippleScale = `${(s + o) / r}`, this.rippleSize = `${this.initialSize}px`;
  }
  getNormalizedPointerEventCoords(A) {
    const { scrollX: e, scrollY: i } = window, { left: o, top: s } = this.getDimensions(), r = e + o, n = i + s, { pageX: l, pageY: a } = A;
    return { x: l - r, y: a - n };
  }
  getTranslationCoordinates(A) {
    const { height: e, width: i } = this.getDimensions(), o = {
      x: (i - this.initialSize) / 2,
      y: (e - this.initialSize) / 2
    };
    let s;
    return A instanceof PointerEvent ? s = this.getNormalizedPointerEventCoords(A) : s = {
      x: i / 2,
      y: e / 2
    }, s = {
      x: s.x - this.initialSize / 2,
      y: s.y - this.initialSize / 2
    }, { startPoint: s, endPoint: o };
  }
  startPressAnimation(A) {
    if (!this.mdRoot)
      return;
    this.pressed = !0, this.growAnimation?.cancel(), this.determineRippleSize();
    const { startPoint: e, endPoint: i } = this.getTranslationCoordinates(A), o = `${e.x}px, ${e.y}px`, s = `${i.x}px, ${i.y}px`;
    this.growAnimation = this.mdRoot.animate({
      top: [0, 0],
      left: [0, 0],
      height: [this.rippleSize, this.rippleSize],
      width: [this.rippleSize, this.rippleSize],
      transform: [
        `translate(${o}) scale(1)`,
        `translate(${s}) scale(${this.rippleScale})`
      ]
    }, {
      pseudoElement: pB,
      duration: dB,
      easing: Be.STANDARD,
      fill: fB
    });
  }
  async endPressAnimation() {
    this.state = oA.INACTIVE;
    const A = this.growAnimation, e = A?.currentTime ?? 1 / 0;
    if (e >= vn) {
      this.pressed = !1;
      return;
    }
    await new Promise((i) => {
      setTimeout(i, vn - e);
    }), this.growAnimation === A && (this.pressed = !1);
  }
  /**
   * Returns `true` if
   *  - the ripple element is enabled
   *  - the pointer is primary for the input type
   *  - the pointer is the pointer that started the interaction, or will start
   * the interaction
   *  - the pointer is a touch, or the pointer state has the primary button
   * held, or the pointer is hovering
   */
  shouldReactToEvent(A) {
    if (this.disabled || !A.isPrimary || this.rippleStartEvent && this.rippleStartEvent.pointerId !== A.pointerId)
      return !1;
    if (A.type === "pointerenter" || A.type === "pointerleave")
      return !this.isTouch(A);
    const e = A.buttons === 1;
    return this.isTouch(A) || e;
  }
  /**
   * Check if the event is within the bounds of the element.
   *
   * This is only needed for the "stuck" contextmenu longpress on Chrome.
   */
  inBounds({ x: A, y: e }) {
    const { top: i, left: o, bottom: s, right: r } = this.getBoundingClientRect();
    return A >= o && A <= r && e >= i && e <= s;
  }
  isTouch({ pointerType: A }) {
    return A === "touch";
  }
}
u([
  y({ type: Boolean, reflect: !0 })
], ut.prototype, "unbounded", void 0);
u([
  y({ type: Boolean, reflect: !0 })
], ut.prototype, "disabled", void 0);
u([
  _A()
], ut.prototype, "hovered", void 0);
u([
  _A()
], ut.prototype, "focused", void 0);
u([
  _A()
], ut.prototype, "pressed", void 0);
u([
  dt(".surface")
], ut.prototype, "mdRoot", void 0);
/**
  * @license
  * Copyright 2022 Google LLC
  * SPDX-License-Identifier: Apache-2.0
  */
const wB = z`:host{--_focus-color: var(--md-ripple-focus-color, var(--md-sys-color-on-surface, #1d1b20));--_focus-opacity: var(--md-ripple-focus-opacity, 0.12);--_hover-color: var(--md-ripple-hover-color, var(--md-sys-color-on-surface, #1d1b20));--_hover-opacity: var(--md-ripple-hover-opacity, 0.08);--_pressed-color: var(--md-ripple-pressed-color, var(--md-sys-color-on-surface, #1d1b20));--_pressed-opacity: var(--md-ripple-pressed-opacity, 0.12);display:flex}:host([disabled]){opacity:0}:host,.surface{border-radius:inherit;position:absolute;inset:0;pointer-events:none;overflow:hidden}.surface{outline:none;-webkit-tap-highlight-color:rgba(0,0,0,0)}.surface::before,.surface::after{position:absolute;opacity:0;pointer-events:none;content:""}.surface::before{background-color:var(--_hover-color);transition:opacity 15ms linear,background-color 15ms linear;inset:0}.surface::after{background:radial-gradient(closest-side, var(--_pressed-color) max(100% - 70px, 65%), transparent 100%);transition:opacity 375ms linear;transform-origin:center center}.hovered::before{background-color:var(--_hover-color);opacity:var(--_hover-opacity)}.focused::before{background-color:var(--_focus-color);opacity:var(--_focus-opacity);transition-duration:75ms}.pressed::after{opacity:var(--_pressed-opacity);transition-duration:105ms}@media screen and (forced-colors: active){:host{display:none}}/*# sourceMappingURL=ripple-styles.css.map */
`;
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
let ds = class extends ut {
};
ds.styles = [wB];
ds = u([
  H("md-ripple")
], ds);
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
class mB extends qi {
  constructor(A) {
    if (super(A), this.rippleGetter = async () => null, A.type !== ks.ELEMENT)
      throw new Error("The `ripple` directive must be used on an element");
  }
  render(A) {
    return GA;
  }
  // Use EventListenerObject::handleEvent interface to handle events without
  // generating bound event handlers
  async handleEvent(A) {
    const e = await this.rippleGetter();
    if (e)
      switch (A.type) {
        case "click":
          e.handleClick();
          break;
        case "contextmenu":
          e.handleContextmenu();
          break;
        case "pointercancel":
          e.handlePointercancel(A);
          break;
        case "pointerdown":
          await e.handlePointerdown(A);
          break;
        case "pointerenter":
          e.handlePointerenter(A);
          break;
        case "pointerleave":
          e.handlePointerleave(A);
          break;
        case "pointerup":
          e.handlePointerup(A);
          break;
      }
  }
  update(A, [e]) {
    return this.element || (this.element = A.element, this.element.addEventListener("click", this), this.element.addEventListener("contextmenu", this), this.element.addEventListener("pointercancel", this), this.element.addEventListener("pointerdown", this), this.element.addEventListener("pointerenter", this), this.element.addEventListener("pointerleave", this), this.element.addEventListener("pointerup", this)), this.rippleGetter = typeof e == "function" ? e : () => e, GA;
  }
}
const vB = $i(mB);
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
var Il;
class cA extends F {
  constructor() {
    super(...arguments), this.headline = "", this.supportingText = "", this.multiLineSupportingText = !1, this.trailingSupportingText = "", this.disabled = !1, this.itemTabIndex = -1, this.active = !1, this.isListItem = !0, this.listItemRole = "listitem", this.showRipple = !1, this.focusOnActivation = !0, this.getRipple = () => (this.showRipple = !0, this.ripple), this.isFirstUpdate = !0;
  }
  willUpdate(A) {
    A.has("active") && !this.disabled && (this.active ? this.itemTabIndex = 0 : this.isFirstUpdate || (this.itemTabIndex = -1));
  }
  render() {
    return this.renderListItem(p`
      <div class="content-wrapper">
        ${this.renderStart()}
        ${this.renderBody()}
        ${this.renderEnd()}
        ${this.renderRipple()}
        ${this.renderFocusRing()}
      </div>`);
  }
  /**
   * Renders the root list item.
   *
   * @param content {unkown} the child content of the list item.
   */
  renderListItem(A) {
    return p`
      <li
          id="item"
          tabindex=${this.disabled ? -1 : this.itemTabIndex}
          role=${this.listItemRole}
          aria-selected=${this.ariaSelected || J}
          aria-checked=${this.ariaChecked || J}
          class="list-item ${Ui(this.getRenderClasses())}"
          @click=${this.onClick}
          @pointerenter=${this.onPointerenter}
          @pointerleave=${this.onPointerleave}
          @keydown=${this.onKeydown}
          ${vB(this.getRipple)}>${A}</li>`;
  }
  /**
   * Handles rendering of the ripple element.
   */
  renderRipple() {
    return this.showRipple ? p`<md-ripple ?disabled="${this.disabled}"></md-ripple>` : J;
  }
  /**
   * Handles rendering of the focus ring.
   */
  renderFocusRing() {
    return p`<md-focus-ring class="focus-ring" for="item" inward></md-focus-ring>`;
  }
  /**
   * Classes applied to the list item root.
   */
  getRenderClasses() {
    return {
      "with-one-line": this.supportingText === "",
      "with-two-line": this.supportingText !== "" && !this.multiLineSupportingText,
      "with-three-line": this.supportingText !== "" && this.multiLineSupportingText,
      disabled: this.disabled
    };
  }
  /**
   * The content rendered at the start of the list item.
   */
  renderStart() {
    return p`<div class="start"><slot name="start"></slot></div>`;
  }
  /**
   * Handles rendering the headline and supporting text.
   */
  renderBody() {
    const A = this.supportingText !== "" ? this.renderSupportingText() : "";
    return p`<div class="body"
      ><span class="label-text">${this.headline}</span>${A}</div>`;
  }
  /**
   * Renders the one-line supporting text.
   */
  renderSupportingText() {
    return p`<span
        class="supporting-text ${Ui(this.getSupportingTextClasses())}"
      >${this.supportingText}</span>`;
  }
  /**
   * Gets the classes for the supporting text node
   */
  getSupportingTextClasses() {
    return { "supporting-text--multi-line": this.multiLineSupportingText };
  }
  /**
   * The content rendered at the end of the list item.
   */
  renderEnd() {
    const A = this.trailingSupportingText !== "" ? this.renderTrailingSupportingText() : "";
    return p`<div class="end"
      ><slot name="end">${A}</slot></div>`;
  }
  /**
   * Renders the supporting text at the end of the list item.
   */
  renderTrailingSupportingText() {
    return p`<span class="trailing-supporting-text"
      >${this.trailingSupportingText}</span>`;
  }
  updated(A) {
    super.updated(A), A.has("active") && !this.isFirstUpdate && this.active && this.focusOnActivation && this.focus(), this.isFirstUpdate = !1;
  }
  focus() {
    this.listItemRoot?.focus?.();
  }
}
Il = cA;
Js(Il);
u([
  y()
], cA.prototype, "headline", void 0);
u([
  y()
], cA.prototype, "supportingText", void 0);
u([
  y({ type: Boolean })
], cA.prototype, "multiLineSupportingText", void 0);
u([
  y()
], cA.prototype, "trailingSupportingText", void 0);
u([
  y({ type: Boolean })
], cA.prototype, "disabled", void 0);
u([
  y({ type: Number })
], cA.prototype, "itemTabIndex", void 0);
u([
  y({ type: Boolean, reflect: !0 })
], cA.prototype, "active", void 0);
u([
  y({ type: Boolean, attribute: "md-list-item", reflect: !0 })
], cA.prototype, "isListItem", void 0);
u([
  Ll("md-ripple")
], cA.prototype, "ripple", void 0);
u([
  dt(".list-item")
], cA.prototype, "listItemRoot", void 0);
u([
  _A()
], cA.prototype, "showRipple", void 0);
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
class Xi extends cA {
  constructor() {
    super(...arguments), this.isMenuItem = !0, this.keepOpen = !1, this.keepOpenOnClick = !1, this.listItemRole = "menuitem";
  }
  onClick() {
    this.keepOpen || this.keepOpenOnClick || this.dispatchEvent(new wn(this, { kind: cs.CLICK_SELECTION }));
  }
  onKeydown(A) {
    if (this.keepOpen)
      return;
    const e = A.code;
    !A.defaultPrevented && lB(e) && (A.preventDefault(), this.dispatchEvent(new wn(this, { kind: cs.KEYDOWN, key: e })));
  }
}
u([
  y({ type: Boolean, attribute: "md-menu-item", reflect: !0 })
], Xi.prototype, "isMenuItem", void 0);
u([
  y({ type: Boolean, attribute: "keep-open" })
], Xi.prototype, "keepOpen", void 0);
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
function bn(t) {
  t.stopPropagation();
}
class pt extends Xi {
  constructor() {
    super(...arguments), this.anchorCorner = "START_END", this.menuCorner = "START_START", this.hoverOpenDelay = 400, this.hoverCloseDelay = 400, this.selected = !1, this.keepOpenOnClick = !0, this.previousOpenTimeout = 0, this.previousCloseTimeout = 0, this.onPointerenter = () => {
      clearTimeout(this.previousOpenTimeout), clearTimeout(this.previousCloseTimeout), !this.submenuEl?.open && (this.hoverOpenDelay ? this.previousOpenTimeout = setTimeout(() => {
        this.show();
      }, this.hoverOpenDelay) : this.show());
    }, this.onPointerleave = () => {
      clearTimeout(this.previousCloseTimeout), clearTimeout(this.previousOpenTimeout), this.hoverCloseDelay ? this.previousCloseTimeout = setTimeout(() => {
        this.close();
      }, this.hoverCloseDelay) : this.close();
    };
  }
  get submenuEl() {
    return this.menus[0];
  }
  onClick() {
    this.show();
  }
  /**
   * On item keydown handles opening the submenu.
   */
  onKeydown(A) {
    const e = this.isSubmenuOpenKey(A.code);
    if (A.code === we.SPACE && A.preventDefault(), !e) {
      super.onKeydown(A);
      return;
    }
    const i = this.submenuEl;
    if (!i)
      return;
    const o = i.items, s = O.getFirstActivatableItem(o);
    if (s) {
      this.show(() => {
        s.active = !0;
      });
      return;
    }
  }
  /**
   * Render the submenu at the end
   */
  renderEnd() {
    return p`${super.renderEnd()}${this.renderSubMenu()}`;
  }
  /**
   * Renders the slot for the submenu.
   */
  renderSubMenu() {
    return p`<span class="submenu"><slot
        name="submenu"
        @pointerdown=${bn}
        @click=${bn}
        @keydown=${this.onSubMenuKeydown}
        @close-menu=${this.onCloseSubmenu}
    ></slot></span>`;
  }
  onCloseSubmenu(A) {
    if (A.itemPath.push(this), this.dispatchEvent(new yn()), this.dispatchEvent(new mn()), A.reason.kind === cs.KEYDOWN && A.reason.key === hs.ESCAPE) {
      A.stopPropagation(), this.active = !0, this.selected = !1, this.listItemRoot?.focus();
      return;
    }
    this.active = !1, this.selected = !1;
  }
  async onSubMenuKeydown(A) {
    A.stopPropagation(), this.isSubmenuCloseKey(A.code) && this.close(() => {
      O.deactivateActiveItem(this.submenuEl.items), this.listItemRoot?.focus(), this.active = !0;
    });
  }
  /**
   * Shows the submenu.
   *
   * @param onOpened A function to call after the menu is opened.
   */
  show(A = () => {
  }) {
    const e = this.submenuEl;
    if (!e)
      return;
    e.quick = !0, e.hasOverflow = !0, e.anchorCorner = this.anchorCorner, e.menuCorner = this.menuCorner, e.anchor = this, e.defaultFocus = "LIST_ROOT", e.skipRestoreFocus = !0, e.stayOpenOnOutsideClick = !0, e.stayOpenOnFocusout = !0;
    const i = e.open;
    this.dispatchEvent(new rB()), e.show(), this.dispatchEvent(new nB()), this.dispatchEvent(new aB()), this.selected = !0, i ? A() : e.addEventListener("opened", A, { once: !0 });
  }
  /**
   * Closes the submenu.
   *
   * @param onClosed A function to call after the menu is closed.
   */
  close(A = () => {
  }) {
    const e = this.submenuEl;
    !e || !e.open || (this.dispatchEvent(new mn()), e.quick = !0, e.close(), this.dispatchEvent(new yn()), this.active = !1, this.selected = !1, e.addEventListener("closed", A, { once: !0 }));
  }
  /**
   * Determines whether the given KeyboardEvent code is one that should open
   * the submenu. This is RTL-aware. By default, left, right, space, or enter.
   *
   * @param code The native KeyboardEvent code.
   * @return Whether or not the key code should open the submenu.
   */
  isSubmenuOpenKey(A) {
    const i = getComputedStyle(this).direction === "rtl" ? Ai.LEFT : Ai.RIGHT;
    switch (A) {
      case i:
      case we.SPACE:
      case we.ENTER:
        return !0;
      default:
        return !1;
    }
  }
  /**
   * Determines whether the given KeyboardEvent code is one that should close
   * the submenu. This is RTL-aware. By default right, left, or escape.
   *
   * @param code The native KeyboardEvent code.
   * @return Whether or not the key code should close the submenu.
   */
  isSubmenuCloseKey(A) {
    const i = getComputedStyle(this).direction === "rtl" ? Ai.RIGHT : Ai.LEFT;
    switch (A) {
      case i:
      case hs.ESCAPE:
        return !0;
      default:
        return !1;
    }
  }
}
u([
  y({ attribute: "anchor-corner" })
], pt.prototype, "anchorCorner", void 0);
u([
  y({ attribute: "menu-corner" })
], pt.prototype, "menuCorner", void 0);
u([
  y({ type: Number, attribute: "hover-open-delay" })
], pt.prototype, "hoverOpenDelay", void 0);
u([
  y({ type: Number, attribute: "hover-close-delay" })
], pt.prototype, "hoverCloseDelay", void 0);
u([
  y({ type: Boolean, reflect: !0 })
], pt.prototype, "selected", void 0);
u([
  Jn({ slot: "submenu", flatten: !0 })
], pt.prototype, "menus", void 0);
/**
 * @license
 * Copyright 2023 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
let Bs = class extends pt {
};
Bs.styles = [al, gl, nl, ll];
Bs = u([
  H("md-sub-menu-item")
], Bs);
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
let Qs = class extends Xi {
};
Qs.styles = [al, gl, nl, ll];
Qs = u([
  H("md-menu-item")
], Qs);
let $t = class extends F {
  constructor() {
    super(...arguments), this.appletsInfosAndGroupsProfiles = new Et(this, () => Ds(async () => _s(this.weServices, Array.from(this.weServices.attachmentTypes.keys()))), () => []);
  }
  async createAttachment(A) {
    try {
      const e = await this.attachmentsStore.client.getDnaHash(), i = await A.create([e, this.hash]);
      await this.attachmentsStore.client.addAttachment(this.hash, i), this.weServices.openViews.openHrl(i.hrl, i.context);
    } catch (e) {
      _e(k("Error creating the attachment")), console.error(e);
    }
  }
  renderMenuItems() {
    switch (this.appletsInfosAndGroupsProfiles.value.status) {
      case "pending":
        return Array(3).map(() => p`<md-menu-item disabled
              ><sl-skeleton></sl-skeleton
            ></md-menu-item>`);
      case "complete":
        const { appletsInfos: A, groupsProfiles: e } = this.appletsInfosAndGroupsProfiles.value.value, i = Array.from(this.weServices.attachmentTypes.entries());
        if (i.length === 0)
          return p`<md-menu-item disabled
            >${k("There are no attachment types yet.")}</md-menu-item
          >`;
        const o = {};
        for (const [s, r] of i)
          for (const [n, l] of Object.entries(r)) {
            const a = JSON.stringify({
              label: l.label,
              icon_src: l.icon_src
            });
            o[a] || (o[a] = new yi()), o[a].set(s, l);
          }
        return Object.entries(o).map(([s, r]) => {
          const { label: n, icon_src: l } = JSON.parse(s);
          return p` <md-sub-menu-item .headline=${n}>
              <sl-icon
                slot="start"
                .src=${l}
                style="margin-left: 16px"
              ></sl-icon>
              <md-menu slot="submenu">
                ${Array.from(r.entries()).map(([a, h]) => {
            var g, c;
            return p`
                    <md-menu-item
                      .headline=${(g = A.get(a)) === null || g === void 0 ? void 0 : g.appletName}
                      @click=${() => this.createAttachment(h)}
                    >
                      ${(c = A.get(a)) === null || c === void 0 ? void 0 : c.groupsIds.map((C) => {
              var B;
              return p`
                            <img
                              slot="start"
                              .src=${(B = e.get(C)) === null || B === void 0 ? void 0 : B.logo_src}
                              style="height: 32px; width: 32px; border-radius: 50%; margin-right: 4px; margin-left: 16px"
                            />
                          `;
            })}
                    </md-menu-item>
                  `;
          })}
              </md-menu>
            </md-sub-menu-item>`;
        });
      case "error":
        return p`<display-error
          .headline=${k("Error fetching the attachment types")}
        ></display-error>`;
    }
  }
  render() {
    return p`
      <sl-icon-button
        .src=${HA(IC)}
        @click=${(A) => {
      var e;
      const i = (e = this.shadowRoot) === null || e === void 0 ? void 0 : e.getElementById("menu");
      i.anchor = A.target, setTimeout(() => {
        i.show();
      }, 10);
    }}
      >
      </sl-icon-button>

      <md-menu fixed id="menu" has-overflow>
        ${this.renderMenuItems()}
      </md-menu>
    `;
  }
};
$t.styles = [QA];
u([
  vA({ context: Ls, subscribe: !0 })
], $t.prototype, "attachmentsStore", void 0);
u([
  vA({ context: Je, subscribe: !0 })
], $t.prototype, "weServices", void 0);
u([
  y(Zt("hash"))
], $t.prototype, "hash", void 0);
$t = u([
  LA(),
  H("create-attachment")
], $t);
let Fi = class extends F {
  render() {
    return p`
      <sl-card style="flex: 1">
        <div class="row" style="align-items: center" slot="header">
          <span style="flex: 1" class="title">${k("Attachments")}</span>

          <create-attachment .hash=${this.hash}></create-attachment>
        </div>

        <attachments-list .hash=${this.hash} style="flex: 1"></attachments-list>
      </sl-card>
    `;
  }
};
Fi.styles = [
  QA,
  z`
      :host {
        display: flex;
      }
    `
];
u([
  y(Zt("hash"))
], Fi.prototype, "hash", void 0);
Fi = u([
  LA(),
  H("attachments-card")
], Fi);
var cl = $`
  .form-control .form-control__label {
    display: none;
  }

  .form-control .form-control__help-text {
    display: none;
  }

  /* Label */
  .form-control--has-label .form-control__label {
    display: inline-block;
    color: var(--sl-input-label-color);
    margin-bottom: var(--sl-spacing-3x-small);
  }

  .form-control--has-label.form-control--small .form-control__label {
    font-size: var(--sl-input-label-font-size-small);
  }

  .form-control--has-label.form-control--medium .form-control__label {
    font-size: var(--sl-input-label-font-size-medium);
  }

  .form-control--has-label.form-control--large .form-control__label {
    font-size: var(--sl-input-label-font-size-large);
  }

  :host([required]) .form-control--has-label .form-control__label::after {
    content: var(--sl-input-required-content);
    margin-inline-start: var(--sl-input-required-content-offset);
    color: var(--sl-input-required-content-color);
  }

  /* Help text */
  .form-control--has-help-text .form-control__help-text {
    display: block;
    color: var(--sl-input-help-text-color);
    margin-top: var(--sl-spacing-3x-small);
  }

  .form-control--has-help-text.form-control--small .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-small);
  }

  .form-control--has-help-text.form-control--medium .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-medium);
  }

  .form-control--has-help-text.form-control--large .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-large);
  }

  .form-control--has-help-text.form-control--radio-group .form-control__help-text {
    margin-top: var(--sl-spacing-2x-small);
  }
`, bB = $`
  ${Z}
  ${cl}

  :host {
    display: block;
  }

  .textarea {
    display: flex;
    align-items: center;
    position: relative;
    width: 100%;
    font-family: var(--sl-input-font-family);
    font-weight: var(--sl-input-font-weight);
    line-height: var(--sl-line-height-normal);
    letter-spacing: var(--sl-input-letter-spacing);
    vertical-align: middle;
    transition: var(--sl-transition-fast) color, var(--sl-transition-fast) border, var(--sl-transition-fast) box-shadow,
      var(--sl-transition-fast) background-color;
    cursor: text;
  }

  /* Standard textareas */
  .textarea--standard {
    background-color: var(--sl-input-background-color);
    border: solid var(--sl-input-border-width) var(--sl-input-border-color);
  }

  .textarea--standard:hover:not(.textarea--disabled) {
    background-color: var(--sl-input-background-color-hover);
    border-color: var(--sl-input-border-color-hover);
  }
  .textarea--standard:hover:not(.textarea--disabled) .textarea__control {
    color: var(--sl-input-color-hover);
  }

  .textarea--standard.textarea--focused:not(.textarea--disabled) {
    background-color: var(--sl-input-background-color-focus);
    border-color: var(--sl-input-border-color-focus);
    color: var(--sl-input-color-focus);
    box-shadow: 0 0 0 var(--sl-focus-ring-width) var(--sl-input-focus-ring-color);
  }

  .textarea--standard.textarea--focused:not(.textarea--disabled) .textarea__control {
    color: var(--sl-input-color-focus);
  }

  .textarea--standard.textarea--disabled {
    background-color: var(--sl-input-background-color-disabled);
    border-color: var(--sl-input-border-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .textarea--standard.textarea--disabled .textarea__control {
    color: var(--sl-input-color-disabled);
  }

  .textarea--standard.textarea--disabled .textarea__control::placeholder {
    color: var(--sl-input-placeholder-color-disabled);
  }

  /* Filled textareas */
  .textarea--filled {
    border: none;
    background-color: var(--sl-input-filled-background-color);
    color: var(--sl-input-color);
  }

  .textarea--filled:hover:not(.textarea--disabled) {
    background-color: var(--sl-input-filled-background-color-hover);
  }

  .textarea--filled.textarea--focused:not(.textarea--disabled) {
    background-color: var(--sl-input-filled-background-color-focus);
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .textarea--filled.textarea--disabled {
    background-color: var(--sl-input-filled-background-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .textarea__control {
    flex: 1 1 auto;
    font-family: inherit;
    font-size: inherit;
    font-weight: inherit;
    line-height: 1.4;
    color: var(--sl-input-color);
    border: none;
    background: none;
    box-shadow: none;
    cursor: inherit;
    -webkit-appearance: none;
  }

  .textarea__control::-webkit-search-decoration,
  .textarea__control::-webkit-search-cancel-button,
  .textarea__control::-webkit-search-results-button,
  .textarea__control::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  .textarea__control::placeholder {
    color: var(--sl-input-placeholder-color);
    user-select: none;
  }

  .textarea__control:focus {
    outline: none;
  }

  /*
   * Size modifiers
   */

  .textarea--small {
    border-radius: var(--sl-input-border-radius-small);
    font-size: var(--sl-input-font-size-small);
  }

  .textarea--small .textarea__control {
    padding: 0.5em var(--sl-input-spacing-small);
  }

  .textarea--medium {
    border-radius: var(--sl-input-border-radius-medium);
    font-size: var(--sl-input-font-size-medium);
  }

  .textarea--medium .textarea__control {
    padding: 0.5em var(--sl-input-spacing-medium);
  }

  .textarea--large {
    border-radius: var(--sl-input-border-radius-large);
    font-size: var(--sl-input-font-size-large);
  }

  .textarea--large .textarea__control {
    padding: 0.5em var(--sl-input-spacing-large);
  }

  /*
   * Resize types
   */

  .textarea--resize-none .textarea__control {
    resize: none;
  }

  .textarea--resize-vertical .textarea__control {
    resize: vertical;
  }

  .textarea--resize-auto .textarea__control {
    height: auto;
    resize: none;
    overflow-y: hidden;
  }
`, DB = (t) => t.strings === void 0, kB = {}, SB = (t, A = kB) => t._$AH = A, hl = Oa(class extends Ka {
  constructor(t) {
    if (super(t), t.type !== st.PROPERTY && t.type !== st.ATTRIBUTE && t.type !== st.BOOLEAN_ATTRIBUTE)
      throw Error("The `live` directive is not allowed on child or event bindings");
    if (!DB(t))
      throw Error("`live` bindings can only contain a single expression");
  }
  render(t) {
    return t;
  }
  update(t, [A]) {
    if (A === yA || A === K)
      return A;
    const e = t.element, i = t.name;
    if (t.type === st.PROPERTY) {
      if (A === e[i])
        return yA;
    } else if (t.type === st.BOOLEAN_ATTRIBUTE) {
      if (!!A === e.hasAttribute(i))
        return yA;
    } else if (t.type === st.ATTRIBUTE && e.getAttribute(i) === A + "")
      return yA;
    return SB(t), A;
  }
});
/*! Bundled license information:

lit-html/directive-helpers.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directives/live.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var Cl = (t = "value") => (A, e) => {
  const i = A.constructor, o = i.prototype.attributeChangedCallback;
  i.prototype.attributeChangedCallback = function(s, r, n) {
    var l;
    const a = i.getPropertyOptions(t), h = typeof a.attribute == "string" ? a.attribute : t;
    if (s === h) {
      const g = a.converter || Se, C = (typeof g == "function" ? g : (l = g?.fromAttribute) != null ? l : Se.fromAttribute)(n, a.type);
      this[t] !== C && (this[e] = C);
    }
    o.call(this, s, r, n);
  };
}, S = class extends P {
  constructor() {
    super(...arguments), this.formControlController = new Rs(this, {
      assumeInteractionOn: ["sl-blur", "sl-input"]
    }), this.hasSlotController = new te(this, "help-text", "label"), this.hasFocus = !1, this.title = "", this.name = "", this.value = "", this.size = "medium", this.filled = !1, this.label = "", this.helpText = "", this.placeholder = "", this.rows = 4, this.resize = "vertical", this.disabled = !1, this.readonly = !1, this.form = "", this.required = !1, this.spellcheck = !0, this.defaultValue = "";
  }
  /** Gets the validity state object */
  get validity() {
    return this.input.validity;
  }
  /** Gets the validation message */
  get validationMessage() {
    return this.input.validationMessage;
  }
  connectedCallback() {
    super.connectedCallback(), this.resizeObserver = new ResizeObserver(() => this.setTextareaHeight()), this.updateComplete.then(() => {
      this.setTextareaHeight(), this.resizeObserver.observe(this.input);
    });
  }
  firstUpdated() {
    this.formControlController.updateValidity();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.resizeObserver.unobserve(this.input);
  }
  handleBlur() {
    this.hasFocus = !1, this.emit("sl-blur");
  }
  handleChange() {
    this.value = this.input.value, this.setTextareaHeight(), this.emit("sl-change");
  }
  handleFocus() {
    this.hasFocus = !0, this.emit("sl-focus");
  }
  handleInput() {
    this.value = this.input.value, this.emit("sl-input");
  }
  handleInvalid(t) {
    this.formControlController.setValidity(!1), this.formControlController.emitInvalidEvent(t);
  }
  setTextareaHeight() {
    this.resize === "auto" ? (this.input.style.height = "auto", this.input.style.height = `${this.input.scrollHeight}px`) : this.input.style.height = void 0;
  }
  handleDisabledChange() {
    this.formControlController.setValidity(this.disabled);
  }
  handleRowsChange() {
    this.setTextareaHeight();
  }
  async handleValueChange() {
    await this.updateComplete, this.formControlController.updateValidity(), this.setTextareaHeight();
  }
  /** Sets focus on the textarea. */
  focus(t) {
    this.input.focus(t);
  }
  /** Removes focus from the textarea. */
  blur() {
    this.input.blur();
  }
  /** Selects all the text in the textarea. */
  select() {
    this.input.select();
  }
  /** Gets or sets the textarea's scroll position. */
  scrollPosition(t) {
    if (t) {
      typeof t.top == "number" && (this.input.scrollTop = t.top), typeof t.left == "number" && (this.input.scrollLeft = t.left);
      return;
    }
    return {
      top: this.input.scrollTop,
      left: this.input.scrollTop
    };
  }
  /** Sets the start and end positions of the text selection (0-based). */
  setSelectionRange(t, A, e = "none") {
    this.input.setSelectionRange(t, A, e);
  }
  /** Replaces a range of text with a new string. */
  setRangeText(t, A, e, i) {
    this.input.setRangeText(t, A, e, i), this.value !== this.input.value && (this.value = this.input.value), this.value !== this.input.value && (this.value = this.input.value, this.setTextareaHeight());
  }
  /** Checks for validity but does not show a validation message. Returns `true` when valid and `false` when invalid. */
  checkValidity() {
    return this.input.checkValidity();
  }
  /** Gets the associated form, if one exists. */
  getForm() {
    return this.formControlController.getForm();
  }
  /** Checks for validity and shows the browser's validation message if the control is invalid. */
  reportValidity() {
    return this.input.reportValidity();
  }
  /** Sets a custom validation message. Pass an empty string to restore validity. */
  setCustomValidity(t) {
    this.input.setCustomValidity(t), this.formControlController.updateValidity();
  }
  render() {
    const t = this.hasSlotController.test("label"), A = this.hasSlotController.test("help-text"), e = this.label ? !0 : !!t, i = this.helpText ? !0 : !!A;
    return Y`
      <div
        part="form-control"
        class=${rA({
      "form-control": !0,
      "form-control--small": this.size === "small",
      "form-control--medium": this.size === "medium",
      "form-control--large": this.size === "large",
      "form-control--has-label": e,
      "form-control--has-help-text": i
    })}
      >
        <label
          part="form-control-label"
          class="form-control__label"
          for="input"
          aria-hidden=${e ? "false" : "true"}
        >
          <slot name="label">${this.label}</slot>
        </label>

        <div part="form-control-input" class="form-control-input">
          <div
            part="base"
            class=${rA({
      textarea: !0,
      "textarea--small": this.size === "small",
      "textarea--medium": this.size === "medium",
      "textarea--large": this.size === "large",
      "textarea--standard": !this.filled,
      "textarea--filled": this.filled,
      "textarea--disabled": this.disabled,
      "textarea--focused": this.hasFocus,
      "textarea--empty": !this.value,
      "textarea--resize-none": this.resize === "none",
      "textarea--resize-vertical": this.resize === "vertical",
      "textarea--resize-auto": this.resize === "auto"
    })}
          >
            <textarea
              part="textarea"
              id="input"
              class="textarea__control"
              title=${this.title}
              name=${b(this.name)}
              .value=${hl(this.value)}
              ?disabled=${this.disabled}
              ?readonly=${this.readonly}
              ?required=${this.required}
              placeholder=${b(this.placeholder)}
              rows=${b(this.rows)}
              minlength=${b(this.minlength)}
              maxlength=${b(this.maxlength)}
              autocapitalize=${b(this.autocapitalize)}
              autocorrect=${b(this.autocorrect)}
              ?autofocus=${this.autofocus}
              spellcheck=${b(this.spellcheck)}
              enterkeyhint=${b(this.enterkeyhint)}
              inputmode=${b(this.inputmode)}
              aria-describedby="help-text"
              @change=${this.handleChange}
              @input=${this.handleInput}
              @invalid=${this.handleInvalid}
              @focus=${this.handleFocus}
              @blur=${this.handleBlur}
            ></textarea>
          </div>
        </div>

        <slot
          name="help-text"
          part="form-control-help-text"
          id="help-text"
          class="form-control__help-text"
          aria-hidden=${i ? "false" : "true"}
        >
          ${this.helpText}
        </slot>
      </div>
    `;
  }
};
S.styles = bB;
I([
  V(".textarea__control")
], S.prototype, "input", 2);
I([
  Wt()
], S.prototype, "hasFocus", 2);
I([
  d()
], S.prototype, "title", 2);
I([
  d()
], S.prototype, "name", 2);
I([
  d()
], S.prototype, "value", 2);
I([
  d({ reflect: !0 })
], S.prototype, "size", 2);
I([
  d({ type: Boolean, reflect: !0 })
], S.prototype, "filled", 2);
I([
  d()
], S.prototype, "label", 2);
I([
  d({ attribute: "help-text" })
], S.prototype, "helpText", 2);
I([
  d()
], S.prototype, "placeholder", 2);
I([
  d({ type: Number })
], S.prototype, "rows", 2);
I([
  d()
], S.prototype, "resize", 2);
I([
  d({ type: Boolean, reflect: !0 })
], S.prototype, "disabled", 2);
I([
  d({ type: Boolean, reflect: !0 })
], S.prototype, "readonly", 2);
I([
  d({ reflect: !0 })
], S.prototype, "form", 2);
I([
  d({ type: Boolean, reflect: !0 })
], S.prototype, "required", 2);
I([
  d({ type: Number })
], S.prototype, "minlength", 2);
I([
  d({ type: Number })
], S.prototype, "maxlength", 2);
I([
  d()
], S.prototype, "autocapitalize", 2);
I([
  d()
], S.prototype, "autocorrect", 2);
I([
  d()
], S.prototype, "autocomplete", 2);
I([
  d({ type: Boolean })
], S.prototype, "autofocus", 2);
I([
  d()
], S.prototype, "enterkeyhint", 2);
I([
  d({
    type: Boolean,
    converter: {
      // Allow "true|false" attribute values but keep the property boolean
      fromAttribute: (t) => !(!t || t === "false"),
      toAttribute: (t) => t ? "true" : "false"
    }
  })
], S.prototype, "spellcheck", 2);
I([
  d()
], S.prototype, "inputmode", 2);
I([
  Cl()
], S.prototype, "defaultValue", 2);
I([
  q("disabled", { waitUntilFirstUpdate: !0 })
], S.prototype, "handleDisabledChange", 1);
I([
  q("rows", { waitUntilFirstUpdate: !0 })
], S.prototype, "handleRowsChange", 1);
I([
  q("value", { waitUntilFirstUpdate: !0 })
], S.prototype, "handleValueChange", 1);
S = I([
  W("sl-textarea")
], S);
var xB = $`
  ${Z}
  ${cl}

  :host {
    display: block;
  }

  .input {
    flex: 1 1 auto;
    display: inline-flex;
    align-items: stretch;
    justify-content: start;
    position: relative;
    width: 100%;
    font-family: var(--sl-input-font-family);
    font-weight: var(--sl-input-font-weight);
    letter-spacing: var(--sl-input-letter-spacing);
    vertical-align: middle;
    overflow: hidden;
    cursor: text;
    transition: var(--sl-transition-fast) color, var(--sl-transition-fast) border, var(--sl-transition-fast) box-shadow,
      var(--sl-transition-fast) background-color;
  }

  /* Standard inputs */
  .input--standard {
    background-color: var(--sl-input-background-color);
    border: solid var(--sl-input-border-width) var(--sl-input-border-color);
  }

  .input--standard:hover:not(.input--disabled) {
    background-color: var(--sl-input-background-color-hover);
    border-color: var(--sl-input-border-color-hover);
  }

  .input--standard.input--focused:not(.input--disabled) {
    background-color: var(--sl-input-background-color-focus);
    border-color: var(--sl-input-border-color-focus);
    box-shadow: 0 0 0 var(--sl-focus-ring-width) var(--sl-input-focus-ring-color);
  }

  .input--standard.input--focused:not(.input--disabled) .input__control {
    color: var(--sl-input-color-focus);
  }

  .input--standard.input--disabled {
    background-color: var(--sl-input-background-color-disabled);
    border-color: var(--sl-input-border-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .input--standard.input--disabled .input__control {
    color: var(--sl-input-color-disabled);
  }

  .input--standard.input--disabled .input__control::placeholder {
    color: var(--sl-input-placeholder-color-disabled);
  }

  /* Filled inputs */
  .input--filled {
    border: none;
    background-color: var(--sl-input-filled-background-color);
    color: var(--sl-input-color);
  }

  .input--filled:hover:not(.input--disabled) {
    background-color: var(--sl-input-filled-background-color-hover);
  }

  .input--filled.input--focused:not(.input--disabled) {
    background-color: var(--sl-input-filled-background-color-focus);
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .input--filled.input--disabled {
    background-color: var(--sl-input-filled-background-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .input__control {
    flex: 1 1 auto;
    font-family: inherit;
    font-size: inherit;
    font-weight: inherit;
    min-width: 0;
    height: 100%;
    color: var(--sl-input-color);
    border: none;
    background: none;
    box-shadow: none;
    padding: 0;
    margin: 0;
    cursor: inherit;
    -webkit-appearance: none;
  }

  .input__control::-webkit-search-decoration,
  .input__control::-webkit-search-cancel-button,
  .input__control::-webkit-search-results-button,
  .input__control::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  .input__control:-webkit-autofill,
  .input__control:-webkit-autofill:hover,
  .input__control:-webkit-autofill:focus,
  .input__control:-webkit-autofill:active {
    box-shadow: 0 0 0 var(--sl-input-height-large) var(--sl-input-background-color-hover) inset !important;
    -webkit-text-fill-color: var(--sl-color-primary-500);
    caret-color: var(--sl-input-color);
  }

  .input--filled .input__control:-webkit-autofill,
  .input--filled .input__control:-webkit-autofill:hover,
  .input--filled .input__control:-webkit-autofill:focus,
  .input--filled .input__control:-webkit-autofill:active {
    box-shadow: 0 0 0 var(--sl-input-height-large) var(--sl-input-filled-background-color) inset !important;
  }

  .input__control::placeholder {
    color: var(--sl-input-placeholder-color);
    user-select: none;
  }

  .input:hover:not(.input--disabled) .input__control {
    color: var(--sl-input-color-hover);
  }

  .input__control:focus {
    outline: none;
  }

  .input__prefix,
  .input__suffix {
    display: inline-flex;
    flex: 0 0 auto;
    align-items: center;
    cursor: default;
  }

  .input__prefix::slotted(sl-icon),
  .input__suffix::slotted(sl-icon) {
    color: var(--sl-input-icon-color);
  }

  /*
   * Size modifiers
   */

  .input--small {
    border-radius: var(--sl-input-border-radius-small);
    font-size: var(--sl-input-font-size-small);
    height: var(--sl-input-height-small);
  }

  .input--small .input__control {
    height: calc(var(--sl-input-height-small) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-small);
  }

  .input--small .input__clear,
  .input--small .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-small) * 2);
  }

  .input--small .input__prefix::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-small);
  }

  .input--small .input__suffix::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-small);
  }

  .input--medium {
    border-radius: var(--sl-input-border-radius-medium);
    font-size: var(--sl-input-font-size-medium);
    height: var(--sl-input-height-medium);
  }

  .input--medium .input__control {
    height: calc(var(--sl-input-height-medium) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-medium);
  }

  .input--medium .input__clear,
  .input--medium .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-medium) * 2);
  }

  .input--medium .input__prefix::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-medium);
  }

  .input--medium .input__suffix::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-medium);
  }

  .input--large {
    border-radius: var(--sl-input-border-radius-large);
    font-size: var(--sl-input-font-size-large);
    height: var(--sl-input-height-large);
  }

  .input--large .input__control {
    height: calc(var(--sl-input-height-large) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-large);
  }

  .input--large .input__clear,
  .input--large .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-large) * 2);
  }

  .input--large .input__prefix::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-large);
  }

  .input--large .input__suffix::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-large);
  }

  /*
   * Pill modifier
   */

  .input--pill.input--small {
    border-radius: var(--sl-input-height-small);
  }

  .input--pill.input--medium {
    border-radius: var(--sl-input-height-medium);
  }

  .input--pill.input--large {
    border-radius: var(--sl-input-height-large);
  }

  /*
   * Clearable + Password Toggle
   */

  .input__clear,
  .input__password-toggle {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: inherit;
    color: var(--sl-input-icon-color);
    border: none;
    background: none;
    padding: 0;
    transition: var(--sl-transition-fast) color;
    cursor: pointer;
  }

  .input__clear:hover,
  .input__password-toggle:hover {
    color: var(--sl-input-icon-color-hover);
  }

  .input__clear:focus,
  .input__password-toggle:focus {
    outline: none;
  }

  .input--empty .input__clear {
    visibility: hidden;
  }

  /* Don't show the browser's password toggle in Edge */
  ::-ms-reveal {
    display: none;
  }

  /* Hide the built-in number spinner */
  .input--no-spin-buttons input[type='number']::-webkit-outer-spin-button,
  .input--no-spin-buttons input[type='number']::-webkit-inner-spin-button {
    -webkit-appearance: none;
    display: none;
  }

  .input--no-spin-buttons input[type='number'] {
    -moz-appearance: textfield;
  }
`, D = class extends P {
  constructor() {
    super(...arguments), this.formControlController = new Rs(this, {
      assumeInteractionOn: ["sl-blur", "sl-input"]
    }), this.hasSlotController = new te(this, "help-text", "label"), this.localize = new XA(this), this.hasFocus = !1, this.title = "", this.type = "text", this.name = "", this.value = "", this.defaultValue = "", this.size = "medium", this.filled = !1, this.pill = !1, this.label = "", this.helpText = "", this.clearable = !1, this.disabled = !1, this.placeholder = "", this.readonly = !1, this.passwordToggle = !1, this.passwordVisible = !1, this.noSpinButtons = !1, this.form = "", this.required = !1, this.spellcheck = !0;
  }
  //
  // NOTE: We use an in-memory input for these getters/setters instead of the one in the template because the properties
  // can be set before the component is rendered.
  //
  /** Gets or sets the current value as a `Date` object. Returns `null` if the value can't be converted. */
  get valueAsDate() {
    const t = document.createElement("input");
    return t.type = "date", t.value = this.value, t.valueAsDate;
  }
  set valueAsDate(t) {
    const A = document.createElement("input");
    A.type = "date", A.valueAsDate = t, this.value = A.value;
  }
  /** Gets or sets the current value as a number. Returns `NaN` if the value can't be converted. */
  get valueAsNumber() {
    const t = document.createElement("input");
    return t.type = "number", t.value = this.value, t.valueAsNumber;
  }
  set valueAsNumber(t) {
    const A = document.createElement("input");
    A.type = "number", A.valueAsNumber = t, this.value = A.value;
  }
  /** Gets the validity state object */
  get validity() {
    return this.input.validity;
  }
  /** Gets the validation message */
  get validationMessage() {
    return this.input.validationMessage;
  }
  firstUpdated() {
    this.formControlController.updateValidity();
  }
  handleBlur() {
    this.hasFocus = !1, this.emit("sl-blur");
  }
  handleChange() {
    this.value = this.input.value, this.emit("sl-change");
  }
  handleClearClick(t) {
    this.value = "", this.emit("sl-clear"), this.emit("sl-input"), this.emit("sl-change"), this.input.focus(), t.stopPropagation();
  }
  handleFocus() {
    this.hasFocus = !0, this.emit("sl-focus");
  }
  handleInput() {
    this.value = this.input.value, this.formControlController.updateValidity(), this.emit("sl-input");
  }
  handleInvalid(t) {
    this.formControlController.setValidity(!1), this.formControlController.emitInvalidEvent(t);
  }
  handleKeyDown(t) {
    const A = t.metaKey || t.ctrlKey || t.shiftKey || t.altKey;
    t.key === "Enter" && !A && setTimeout(() => {
      !t.defaultPrevented && !t.isComposing && this.formControlController.submit();
    });
  }
  handlePasswordToggle() {
    this.passwordVisible = !this.passwordVisible;
  }
  handleDisabledChange() {
    this.formControlController.setValidity(this.disabled);
  }
  handleStepChange() {
    this.input.step = String(this.step), this.formControlController.updateValidity();
  }
  async handleValueChange() {
    await this.updateComplete, this.formControlController.updateValidity();
  }
  /** Sets focus on the input. */
  focus(t) {
    this.input.focus(t);
  }
  /** Removes focus from the input. */
  blur() {
    this.input.blur();
  }
  /** Selects all the text in the input. */
  select() {
    this.input.select();
  }
  /** Sets the start and end positions of the text selection (0-based). */
  setSelectionRange(t, A, e = "none") {
    this.input.setSelectionRange(t, A, e);
  }
  /** Replaces a range of text with a new string. */
  setRangeText(t, A, e, i) {
    this.input.setRangeText(t, A, e, i), this.value !== this.input.value && (this.value = this.input.value);
  }
  /** Displays the browser picker for an input element (only works if the browser supports it for the input type). */
  showPicker() {
    "showPicker" in HTMLInputElement.prototype && this.input.showPicker();
  }
  /** Increments the value of a numeric input type by the value of the step attribute. */
  stepUp() {
    this.input.stepUp(), this.value !== this.input.value && (this.value = this.input.value);
  }
  /** Decrements the value of a numeric input type by the value of the step attribute. */
  stepDown() {
    this.input.stepDown(), this.value !== this.input.value && (this.value = this.input.value);
  }
  /** Checks for validity but does not show a validation message. Returns `true` when valid and `false` when invalid. */
  checkValidity() {
    return this.input.checkValidity();
  }
  /** Gets the associated form, if one exists. */
  getForm() {
    return this.formControlController.getForm();
  }
  /** Checks for validity and shows the browser's validation message if the control is invalid. */
  reportValidity() {
    return this.input.reportValidity();
  }
  /** Sets a custom validation message. Pass an empty string to restore validity. */
  setCustomValidity(t) {
    this.input.setCustomValidity(t), this.formControlController.updateValidity();
  }
  render() {
    const t = this.hasSlotController.test("label"), A = this.hasSlotController.test("help-text"), e = this.label ? !0 : !!t, i = this.helpText ? !0 : !!A, o = this.clearable && !this.disabled && !this.readonly && (typeof this.value == "number" || this.value.length > 0);
    return Y`
      <div
        part="form-control"
        class=${rA({
      "form-control": !0,
      "form-control--small": this.size === "small",
      "form-control--medium": this.size === "medium",
      "form-control--large": this.size === "large",
      "form-control--has-label": e,
      "form-control--has-help-text": i
    })}
      >
        <label
          part="form-control-label"
          class="form-control__label"
          for="input"
          aria-hidden=${e ? "false" : "true"}
        >
          <slot name="label">${this.label}</slot>
        </label>

        <div part="form-control-input" class="form-control-input">
          <div
            part="base"
            class=${rA({
      input: !0,
      // Sizes
      "input--small": this.size === "small",
      "input--medium": this.size === "medium",
      "input--large": this.size === "large",
      // States
      "input--pill": this.pill,
      "input--standard": !this.filled,
      "input--filled": this.filled,
      "input--disabled": this.disabled,
      "input--focused": this.hasFocus,
      "input--empty": !this.value,
      "input--no-spin-buttons": this.noSpinButtons
    })}
          >
            <slot name="prefix" part="prefix" class="input__prefix"></slot>
            <input
              part="input"
              id="input"
              class="input__control"
              type=${this.type === "password" && this.passwordVisible ? "text" : this.type}
              title=${this.title}
              name=${b(this.name)}
              ?disabled=${this.disabled}
              ?readonly=${this.readonly}
              ?required=${this.required}
              placeholder=${b(this.placeholder)}
              minlength=${b(this.minlength)}
              maxlength=${b(this.maxlength)}
              min=${b(this.min)}
              max=${b(this.max)}
              step=${b(this.step)}
              .value=${hl(this.value)}
              autocapitalize=${b(this.autocapitalize)}
              autocomplete=${b(this.autocomplete)}
              autocorrect=${b(this.autocorrect)}
              ?autofocus=${this.autofocus}
              spellcheck=${this.spellcheck}
              pattern=${b(this.pattern)}
              enterkeyhint=${b(this.enterkeyhint)}
              inputmode=${b(this.inputmode)}
              aria-describedby="help-text"
              @change=${this.handleChange}
              @input=${this.handleInput}
              @invalid=${this.handleInvalid}
              @keydown=${this.handleKeyDown}
              @focus=${this.handleFocus}
              @blur=${this.handleBlur}
            />

            ${o ? Y`
                    <button
                      part="clear-button"
                      class="input__clear"
                      type="button"
                      aria-label=${this.localize.term("clearEntry")}
                      @click=${this.handleClearClick}
                      tabindex="-1"
                    >
                      <slot name="clear-icon">
                        <sl-icon name="x-circle-fill" library="system"></sl-icon>
                      </slot>
                    </button>
                  ` : ""}
            ${this.passwordToggle && !this.disabled ? Y`
                    <button
                      part="password-toggle-button"
                      class="input__password-toggle"
                      type="button"
                      aria-label=${this.localize.term(this.passwordVisible ? "hidePassword" : "showPassword")}
                      @click=${this.handlePasswordToggle}
                      tabindex="-1"
                    >
                      ${this.passwordVisible ? Y`
                            <slot name="show-password-icon">
                              <sl-icon name="eye-slash" library="system"></sl-icon>
                            </slot>
                          ` : Y`
                            <slot name="hide-password-icon">
                              <sl-icon name="eye" library="system"></sl-icon>
                            </slot>
                          `}
                    </button>
                  ` : ""}

            <slot name="suffix" part="suffix" class="input__suffix"></slot>
          </div>
        </div>

        <slot
          name="help-text"
          part="form-control-help-text"
          id="help-text"
          class="form-control__help-text"
          aria-hidden=${i ? "false" : "true"}
        >
          ${this.helpText}
        </slot>
        </div>
      </div>
    `;
  }
};
D.styles = xB;
I([
  V(".input__control")
], D.prototype, "input", 2);
I([
  Wt()
], D.prototype, "hasFocus", 2);
I([
  d()
], D.prototype, "title", 2);
I([
  d({ reflect: !0 })
], D.prototype, "type", 2);
I([
  d()
], D.prototype, "name", 2);
I([
  d()
], D.prototype, "value", 2);
I([
  Cl()
], D.prototype, "defaultValue", 2);
I([
  d({ reflect: !0 })
], D.prototype, "size", 2);
I([
  d({ type: Boolean, reflect: !0 })
], D.prototype, "filled", 2);
I([
  d({ type: Boolean, reflect: !0 })
], D.prototype, "pill", 2);
I([
  d()
], D.prototype, "label", 2);
I([
  d({ attribute: "help-text" })
], D.prototype, "helpText", 2);
I([
  d({ type: Boolean })
], D.prototype, "clearable", 2);
I([
  d({ type: Boolean, reflect: !0 })
], D.prototype, "disabled", 2);
I([
  d()
], D.prototype, "placeholder", 2);
I([
  d({ type: Boolean, reflect: !0 })
], D.prototype, "readonly", 2);
I([
  d({ attribute: "password-toggle", type: Boolean })
], D.prototype, "passwordToggle", 2);
I([
  d({ attribute: "password-visible", type: Boolean })
], D.prototype, "passwordVisible", 2);
I([
  d({ attribute: "no-spin-buttons", type: Boolean })
], D.prototype, "noSpinButtons", 2);
I([
  d({ reflect: !0 })
], D.prototype, "form", 2);
I([
  d({ type: Boolean, reflect: !0 })
], D.prototype, "required", 2);
I([
  d()
], D.prototype, "pattern", 2);
I([
  d({ type: Number })
], D.prototype, "minlength", 2);
I([
  d({ type: Number })
], D.prototype, "maxlength", 2);
I([
  d()
], D.prototype, "min", 2);
I([
  d()
], D.prototype, "max", 2);
I([
  d()
], D.prototype, "step", 2);
I([
  d()
], D.prototype, "autocapitalize", 2);
I([
  d()
], D.prototype, "autocorrect", 2);
I([
  d()
], D.prototype, "autocomplete", 2);
I([
  d({ type: Boolean })
], D.prototype, "autofocus", 2);
I([
  d()
], D.prototype, "enterkeyhint", 2);
I([
  d({
    type: Boolean,
    converter: {
      // Allow "true|false" attribute values but keep the property boolean
      fromAttribute: (t) => !(!t || t === "false"),
      toAttribute: (t) => t ? "true" : "false"
    }
  })
], D.prototype, "spellcheck", 2);
I([
  d()
], D.prototype, "inputmode", 2);
I([
  q("disabled", { waitUntilFirstUpdate: !0 })
], D.prototype, "handleDisabledChange", 1);
I([
  q("step", { waitUntilFirstUpdate: !0 })
], D.prototype, "handleStepChange", 1);
I([
  q("value", { waitUntilFirstUpdate: !0 })
], D.prototype, "handleValueChange", 1);
D = I([
  W("sl-input")
], D);
const ee = "hc_zome_posts/store";
var NB = Object.defineProperty, UB = Object.getOwnPropertyDescriptor, Ye = (t, A, e, i) => {
  for (var o = i > 1 ? void 0 : i ? UB(A, e) : A, s = t.length - 1, r; s >= 0; s--)
    (r = t[s]) && (o = (i ? r(A, e, o) : r(o)) || o);
  return i && o && NB(A, e, o), o;
};
let Ct = class extends F {
  constructor() {
    super(...arguments), this.committing = !1;
  }
  firstUpdated() {
    this.shadowRoot?.querySelector("form").reset();
  }
  async updatePost(t) {
    const A = {
      title: t.title,
      content: t.content
    };
    try {
      this.committing = !0;
      const e = await this.postsStore.client.updatePost(
        this.originalPostHash,
        this.currentRecord.actionHash,
        A
      );
      this.dispatchEvent(new CustomEvent("post-updated", {
        composed: !0,
        bubbles: !0,
        detail: {
          originalPostHash: this.originalPostHash,
          previousPostHash: this.currentRecord.actionHash,
          updatedPostHash: e.actionHash
        }
      }));
    } catch (e) {
      console.error(e), _e(k("Error updating the post"));
    }
    this.committing = !1;
  }
  render() {
    return p`
      <sl-card>
        <span slot="header">${k("Edit Post")}</span>

        <form 
          style="display: flex; flex: 1; flex-direction: column;"
          ${ba((t) => this.updatePost(t))}
        >  
          <div style="margin-bottom: 16px">
        <sl-input name="title" .label=${k("Title")}  required .defaultValue=${this.currentRecord.entry.title}></sl-input>          </div>

          <div style="margin-bottom: 16px">
        <sl-textarea name="content" .label=${k("Content")}  required .defaultValue=${this.currentRecord.entry.content}></sl-textarea>          </div>



          <div style="display: flex; flex-direction: row">
            <sl-button
              @click=${() => this.dispatchEvent(new CustomEvent("edit-canceled", {
      bubbles: !0,
      composed: !0
    }))}
              style="flex: 1;"
            >${k("Cancel")}</sl-button>
            <sl-button
              type="submit"
              variant="primary"
              style="flex: 1;"
              .loading=${this.committing}
            >${k("Save")}</sl-button>

          </div>
        </form>
      </sl-card>`;
  }
};
Ct.styles = [QA];
Ye([
  y(Zt("original-post-hash"))
], Ct.prototype, "originalPostHash", 2);
Ye([
  y()
], Ct.prototype, "currentRecord", 2);
Ye([
  vA({ context: ee })
], Ct.prototype, "postsStore", 2);
Ye([
  _A()
], Ct.prototype, "committing", 2);
Ct = Ye([
  LA(),
  H("edit-post")
], Ct);
var FB = Object.defineProperty, GB = Object.getOwnPropertyDescriptor, Ao = (t, A, e, i) => {
  for (var o = i > 1 ? void 0 : i ? GB(A, e) : A, s = t.length - 1, r; s >= 0; s--)
    (r = t[s]) && (o = (i ? r(A, e, o) : r(o)) || o);
  return i && o && FB(A, e, o), o;
};
let qt = class extends F {
  constructor() {
    super(...arguments), this._post = new Et(
      this,
      () => this.postsStore.posts.get(this.postHash)
    ), this._editing = !1;
  }
  async deletePost() {
    try {
      await this.postsStore.client.deletePost(this.postHash), this.dispatchEvent(
        new CustomEvent("post-deleted", {
          bubbles: !0,
          composed: !0,
          detail: {
            postHash: this.postHash
          }
        })
      );
    } catch (t) {
      console.error(t), _e(k("Error deleting the post"));
    }
  }
  renderDetail(t) {
    return p`
      <sl-card>
        <div slot="header" style="display: flex; flex-direction: row">
          <span style="font-size: 18px; flex: 1;">${k("Post")}</span>

          <sl-icon-button
            style="margin-left: 8px"
            .src=${HA(CC)}
            @click=${() => {
      this._editing = !0;
    }}
          ></sl-icon-button>
          <sl-icon-button
            style="margin-left: 8px"
            .src=${HA(hC)}
            @click=${() => this.deletePost()}
          ></sl-icon-button>
        </div>

        <div style="display: flex; flex-direction: column">
          <div
            style="display: flex; flex-direction: column; margin-bottom: 16px"
          >
            <span style="margin-bottom: 8px"
              ><strong>${k("Title")}:</strong></span
            >
            <span style="white-space: pre-line"
              >${t.entry.title}</span
            >
          </div>

          <div
            style="display: flex; flex-direction: column; margin-bottom: 16px"
          >
            <span style="margin-bottom: 8px"
              ><strong>${k("Content")}:</strong></span
            >
            <span style="white-space: pre-line"
              >${t.entry.content}</span
            >
          </div>
        </div>
      </sl-card>
      <attachments-card .hash=${this.postHash}></attachments-card>
    `;
  }
  render() {
    switch (this._post.value.status) {
      case "pending":
        return p`<sl-card>
          <div
            style="display: flex; flex: 1; align-items: center; justify-content: center"
          >
            <sl-spinner style="font-size: 2rem;"></sl-spinner>
          </div>
        </sl-card>`;
      case "complete":
        const t = this._post.value.value;
        return t ? this._editing ? p`<edit-post
            .originalPostHash=${this.postHash}
            .currentRecord=${t}
            @post-updated=${async () => {
          this._editing = !1;
        }}
            @edit-canceled=${() => {
          this._editing = !1;
        }}
            style="display: flex; flex: 1;"
          ></edit-post>` : this.renderDetail(t) : p`<span>${k("The requested post doesn't exist")}</span>`;
      case "error":
        return p`<sl-card>
          <display-error
            .headline=${k("Error fetching the post")}
            .error=${this._post.value.error.data.data}
          ></display-error>
        </sl-card>`;
    }
  }
};
qt.styles = [QA];
Ao([
  y(Zt("post-hash"))
], qt.prototype, "postHash", 2);
Ao([
  vA({ context: ee, subscribe: !0 })
], qt.prototype, "postsStore", 2);
Ao([
  _A()
], qt.prototype, "_editing", 2);
qt = Ao([
  LA(),
  H("post-detail")
], qt);
var RB = Object.defineProperty, MB = Object.getOwnPropertyDescriptor, dl = (t, A, e, i) => {
  for (var o = i > 1 ? void 0 : i ? MB(A, e) : A, s = t.length - 1, r; s >= 0; s--)
    (r = t[s]) && (o = (i ? r(A, e, o) : r(o)) || o);
  return i && o && RB(A, e, o), o;
};
let Gi = class extends F {
  render() {
    return p`<slot></slot>`;
  }
};
Gi.styles = z`
    :host {
      display: contents;
    }
  `;
dl([
  Pi({ context: ee }),
  y({ type: Object })
], Gi.prototype, "store", 2);
Gi = dl([
  H("posts-context")
], Gi);
const _B = "hc_zome_profiles/store";
let Ri = class extends F {
  render() {
    return p`<slot></slot>`;
  }
};
Ri.styles = z`
    :host {
      display: contents;
    }
  `;
u([
  Pi({ context: _B }),
  y({ type: Object })
], Ri.prototype, "store", void 0);
Ri = u([
  H("profiles-context")
], Ri);
let Mi = class extends F {
  render() {
    return p`<slot></slot>`;
  }
};
Mi.styles = z`
    :host {
      display: contents;
    }
  `;
u([
  Pi({ context: Je }),
  y({ type: Object })
], Mi.prototype, "services", void 0);
Mi = u([
  H("we-services-context")
], Mi);
var LB = Object.defineProperty, JB = Object.getOwnPropertyDescriptor, Ys = (t, A, e, i) => {
  for (var o = i > 1 ? void 0 : i ? JB(A, e) : A, s = t.length - 1, r; s >= 0; s--)
    (r = t[s]) && (o = (i ? r(A, e, o) : r(o)) || o);
  return i && o && LB(A, e, o), o;
};
let Ge = class extends F {
  constructor() {
    super(...arguments), this._post = new Et(this, () => this.postsStore.posts.get(this.postHash));
  }
  renderSummary(t) {
    return p`
      <div style="display: flex; flex-direction: column">

          <div style="display: flex; flex-direction: column; margin-bottom: 16px">
	    <span style="margin-bottom: 8px"><strong>${k("Title")}:</strong></span>
 	    <span style="white-space: pre-line">${t.entry.title}</span>
	  </div>

          <div style="display: flex; flex-direction: column; margin-bottom: 16px">
	    <span style="margin-bottom: 8px"><strong>${k("Content")}:</strong></span>
 	    <span style="white-space: pre-line">${t.entry.content}</span>
	  </div>

      </div>
    `;
  }
  renderPost() {
    switch (this._post.value.status) {
      case "pending":
        return p`<div
          style="display: flex; flex: 1; align-items: center; justify-content: center"
        >
            <sl-spinner style="font-size: 2rem;"></sl-spinner>
        </div>`;
      case "complete":
        return this._post.value.value ? this.renderSummary(this._post.value.value) : p`<span>${k("The requested post doesn't exist")}</span>`;
      case "error":
        return p`<display-error
          .headline=${k("Error fetching the post")}
          .error=${this._post.value.error.data.data}
        ></display-error>`;
    }
  }
  render() {
    return p`<sl-card style="flex: 1; cursor: grab;" @click=${() => this.dispatchEvent(new CustomEvent("post-selected", {
      composed: !0,
      bubbles: !0,
      detail: {
        postHash: this.postHash
      }
    }))}>
        ${this.renderPost()}
    </sl-card>`;
  }
};
Ge.styles = [QA];
Ys([
  y(Zt("post-hash"))
], Ge.prototype, "postHash", 2);
Ys([
  vA({ context: ee, subscribe: !0 })
], Ge.prototype, "postsStore", 2);
Ge = Ys([
  LA(),
  H("post-summary")
], Ge);
var YB = Object.defineProperty, HB = Object.getOwnPropertyDescriptor, Bl = (t, A, e, i) => {
  for (var o = i > 1 ? void 0 : i ? HB(A, e) : A, s = t.length - 1, r; s >= 0; s--)
    (r = t[s]) && (o = (i ? r(A, e, o) : r(o)) || o);
  return i && o && YB(A, e, o), o;
};
let _i = class extends F {
  constructor() {
    super(...arguments), this._allPosts = new Et(this, () => this.postsStore.allPosts);
  }
  renderList(t) {
    return t.length === 0 ? p` <div class="column center-content">
        <sl-icon
          .src=${HA(ka)}
          style="color: grey; height: 64px; width: 64px; margin-bottom: 16px"
        ></sl-icon>
        <span class="placeholder">${k("No posts found")}</span>
      </div>` : p`
      <div style="display: flex; flex-direction: column; flex: 1">
        ${t.map(
      (A) => p`<post-summary
              .postHash=${A}
              style="margin-bottom: 16px;"
            ></post-summary>`
    )}
      </div>
    `;
  }
  render() {
    switch (this._allPosts.value.status) {
      case "pending":
        return p`<div
          style="display: flex; flex: 1; align-items: center; justify-content: center"
        >
          <sl-spinner style="font-size: 2rem;"></sl-spinner>
        </div>`;
      case "complete":
        return this.renderList(this._allPosts.value.value);
      case "error":
        return p`<display-error
          .headline=${k("Error fetching the posts")}
          .error=${this._allPosts.value.error}
        ></display-error>`;
    }
  }
};
_i.styles = [QA];
Bl([
  vA({ context: ee, subscribe: !0 })
], _i.prototype, "postsStore", 2);
_i = Bl([
  LA(),
  H("all-posts")
], _i);
var TB = Object.defineProperty, OB = Object.getOwnPropertyDescriptor, to = (t, A, e, i) => {
  for (var o = i > 1 ? void 0 : i ? OB(A, e) : A, s = t.length - 1, r; s >= 0; s--)
    (r = t[s]) && (o = (i ? r(A, e, o) : r(o)) || o);
  return i && o && TB(A, e, o), o;
};
let Pt = class extends F {
  constructor() {
    super(...arguments), this.committing = !1;
  }
  async createPost(t) {
    if (this.committing)
      return;
    const A = {
      title: t.title,
      content: t.content
    };
    try {
      this.committing = !0;
      const e = await this.postsStore.client.createPost(A);
      this.dispatchEvent(new CustomEvent("post-created", {
        composed: !0,
        bubbles: !0,
        detail: {
          postHash: e.actionHash
        }
      })), this.form.reset();
    } catch (e) {
      console.error(e), _e(k("Error creating the post"));
    }
    this.committing = !1;
  }
  render() {
    return p`
      <sl-card style="flex: 1;">
        <span slot="header">${k("Create Post")}</span>

        <form 
          id="create-form"
          style="display: flex; flex: 1; flex-direction: column;"
          ${ba((t) => this.createPost(t))}
        >  
          <div style="margin-bottom: 16px;">
          <sl-input name="title" .label=${k("Title")}  required></sl-input>          </div>

          <div style="margin-bottom: 16px;">
          <sl-textarea name="content" .label=${k("Content")}  required></sl-textarea>          </div>


          <sl-button
            variant="primary"
            type="submit"
            .loading=${this.committing}
          >${k("Create Post")}</sl-button>
        </form> 
      </sl-card>`;
  }
};
Pt.styles = [QA];
to([
  vA({ context: ee, subscribe: !0 })
], Pt.prototype, "postsStore", 2);
to([
  _A()
], Pt.prototype, "committing", 2);
to([
  dt("#create-form")
], Pt.prototype, "form", 2);
Pt = to([
  LA(),
  H("create-post")
], Pt);
var KB = Object.defineProperty, $B = Object.getOwnPropertyDescriptor, qB = (t, A, e, i) => {
  for (var o = i > 1 ? void 0 : i ? $B(A, e) : A, s = t.length - 1, r; s >= 0; s--)
    (r = t[s]) && (o = (i ? r(A, e, o) : r(o)) || o);
  return i && o && KB(A, e, o), o;
};
let Es = class extends F {
  render() {
    return p`
      <create-post></create-post>
      <all-posts></all-posts>
    `;
  }
};
Es.styles = [
  z`
      :host {
        display: flex;
        flex: 1;
      }
    `,
  QA
];
Es = qB([
  LA(),
  H("applet-main")
], Es);
var PB = Object.defineProperty, zB = Object.getOwnPropertyDescriptor, Hs = (t, A, e, i) => {
  for (var o = i > 1 ? void 0 : i ? zB(A, e) : A, s = t.length - 1, r; s >= 0; s--)
    (r = t[s]) && (o = (i ? r(A, e, o) : r(o)) || o);
  return i && o && PB(A, e, o), o;
};
let Re = class extends F {
  constructor() {
    super(...arguments), this.appletsInfo = new Et(
      this,
      () => Ds(
        async () => _s(
          this.weServices,
          Array.from(this.applets.keys())
        )
      ),
      () => []
    );
  }
  render() {
    return p``;
  }
};
Re.styles = [
  z`
      :host {
        display: flex;
        flex: 1;
      }
    `,
  QA
];
Hs([
  y()
], Re.prototype, "applets", 2);
Hs([
  vA({ context: Je, subscribe: !0 })
], Re.prototype, "weServices", 2);
Re = Hs([
  LA(),
  H("cross-applet-main")
], Re);
class VB {
  constructor(A) {
    this.client = A, this.posts = new wa(
      (e) => jo(async () => this.client.getPost(e), 4e3)
    ), this.allPosts = jo(async () => (await this.client.getAllPosts()).map((i) => i.actionHash), 4e3);
  }
}
class Li extends ya {
  constructor(A, e, i = "posts") {
    super(A, e, i), this.client = A, this.roleName = e, this.zomeName = i;
  }
  /** Post */
  async createPost(A) {
    const e = await this.callZome("create_post", A);
    return new je(e);
  }
  async getPost(A) {
    const e = await this.callZome("get_post", A);
    return e ? new je(e) : void 0;
  }
  deletePost(A) {
    return this.callZome("delete_post", A);
  }
  async updatePost(A, e, i) {
    const o = await this.callZome("update_post", {
      original_post_hash: A,
      previous_post_hash: e,
      updated_post: i
    });
    return new je(o);
  }
  /** All Posts */
  async getAllPosts() {
    return (await this.callZome("get_all_posts", null)).map((e) => new je(e));
  }
}
function jB(t) {
  for (var A = t.length, e = 0, i = 0; i < A; ) {
    var o = t.charCodeAt(i++);
    if (o & 4294967168)
      if (!(o & 4294965248))
        e += 2;
      else {
        if (o >= 55296 && o <= 56319 && i < A) {
          var s = t.charCodeAt(i);
          (s & 64512) === 56320 && (++i, o = ((o & 1023) << 10) + (s & 1023) + 65536);
        }
        o & 4294901760 ? e += 4 : e += 3;
      }
    else {
      e++;
      continue;
    }
  }
  return e;
}
function ZB(t, A, e) {
  for (var i = t.length, o = e, s = 0; s < i; ) {
    var r = t.charCodeAt(s++);
    if (r & 4294967168)
      if (!(r & 4294965248))
        A[o++] = r >> 6 & 31 | 192;
      else {
        if (r >= 55296 && r <= 56319 && s < i) {
          var n = t.charCodeAt(s);
          (n & 64512) === 56320 && (++s, r = ((r & 1023) << 10) + (n & 1023) + 65536);
        }
        r & 4294901760 ? (A[o++] = r >> 18 & 7 | 240, A[o++] = r >> 12 & 63 | 128, A[o++] = r >> 6 & 63 | 128) : (A[o++] = r >> 12 & 15 | 224, A[o++] = r >> 6 & 63 | 128);
      }
    else {
      A[o++] = r;
      continue;
    }
    A[o++] = r & 63 | 128;
  }
}
var WB = new TextEncoder(), XB = 50;
function AQ(t, A, e) {
  WB.encodeInto(t, A.subarray(e));
}
function tQ(t, A, e) {
  t.length > XB ? AQ(t, A, e) : ZB(t, A, e);
}
var eQ = 4096;
function Ql(t, A, e) {
  for (var i = A, o = i + e, s = [], r = ""; i < o; ) {
    var n = t[i++];
    if (!(n & 128))
      s.push(n);
    else if ((n & 224) === 192) {
      var l = t[i++] & 63;
      s.push((n & 31) << 6 | l);
    } else if ((n & 240) === 224) {
      var l = t[i++] & 63, a = t[i++] & 63;
      s.push((n & 31) << 12 | l << 6 | a);
    } else if ((n & 248) === 240) {
      var l = t[i++] & 63, a = t[i++] & 63, h = t[i++] & 63, g = (n & 7) << 18 | l << 12 | a << 6 | h;
      g > 65535 && (g -= 65536, s.push(g >>> 10 & 1023 | 55296), g = 56320 | g & 1023), s.push(g);
    } else
      s.push(n);
    s.length >= eQ && (r += String.fromCharCode.apply(String, s), s.length = 0);
  }
  return s.length > 0 && (r += String.fromCharCode.apply(String, s)), r;
}
var iQ = new TextDecoder(), oQ = 200;
function sQ(t, A, e) {
  var i = t.subarray(A, A + e);
  return iQ.decode(i);
}
function rQ(t, A, e) {
  return e > oQ ? sQ(t, A, e) : Ql(t, A, e);
}
var ti = (
  /** @class */
  function() {
    function t(A, e) {
      this.type = A, this.data = e;
    }
    return t;
  }()
), nQ = globalThis && globalThis.__extends || function() {
  var t = function(A, e) {
    return t = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, o) {
      i.__proto__ = o;
    } || function(i, o) {
      for (var s in o)
        Object.prototype.hasOwnProperty.call(o, s) && (i[s] = o[s]);
    }, t(A, e);
  };
  return function(A, e) {
    if (typeof e != "function" && e !== null)
      throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
    t(A, e);
    function i() {
      this.constructor = A;
    }
    A.prototype = e === null ? Object.create(e) : (i.prototype = e.prototype, new i());
  };
}(), xA = (
  /** @class */
  function(t) {
    nQ(A, t);
    function A(e) {
      var i = t.call(this, e) || this, o = Object.create(A.prototype);
      return Object.setPrototypeOf(i, o), Object.defineProperty(i, "name", {
        configurable: !0,
        enumerable: !1,
        value: A.name
      }), i;
    }
    return A;
  }(Error)
), ce = 4294967295;
function aQ(t, A, e) {
  var i = e / 4294967296, o = e;
  t.setUint32(A, i), t.setUint32(A + 4, o);
}
function El(t, A, e) {
  var i = Math.floor(e / 4294967296), o = e;
  t.setUint32(A, i), t.setUint32(A + 4, o);
}
function ul(t, A) {
  var e = t.getInt32(A), i = t.getUint32(A + 4);
  return e * 4294967296 + i;
}
function lQ(t, A) {
  var e = t.getUint32(A), i = t.getUint32(A + 4);
  return e * 4294967296 + i;
}
var gQ = -1, IQ = 4294967296 - 1, cQ = 17179869184 - 1;
function hQ(t) {
  var A = t.sec, e = t.nsec;
  if (A >= 0 && e >= 0 && A <= cQ)
    if (e === 0 && A <= IQ) {
      var i = new Uint8Array(4), o = new DataView(i.buffer);
      return o.setUint32(0, A), i;
    } else {
      var s = A / 4294967296, r = A & 4294967295, i = new Uint8Array(8), o = new DataView(i.buffer);
      return o.setUint32(0, e << 2 | s & 3), o.setUint32(4, r), i;
    }
  else {
    var i = new Uint8Array(12), o = new DataView(i.buffer);
    return o.setUint32(0, e), El(o, 4, A), i;
  }
}
function CQ(t) {
  var A = t.getTime(), e = Math.floor(A / 1e3), i = (A - e * 1e3) * 1e6, o = Math.floor(i / 1e9);
  return {
    sec: e + o,
    nsec: i - o * 1e9
  };
}
function dQ(t) {
  if (t instanceof Date) {
    var A = CQ(t);
    return hQ(A);
  } else
    return null;
}
function BQ(t) {
  var A = new DataView(t.buffer, t.byteOffset, t.byteLength);
  switch (t.byteLength) {
    case 4: {
      var e = A.getUint32(0), i = 0;
      return { sec: e, nsec: i };
    }
    case 8: {
      var o = A.getUint32(0), s = A.getUint32(4), e = (o & 3) * 4294967296 + s, i = o >>> 2;
      return { sec: e, nsec: i };
    }
    case 12: {
      var e = ul(A, 4), i = A.getUint32(0);
      return { sec: e, nsec: i };
    }
    default:
      throw new xA("Unrecognized data size for timestamp (expected 4, 8, or 12): ".concat(t.length));
  }
}
function QQ(t) {
  var A = BQ(t);
  return new Date(A.sec * 1e3 + A.nsec / 1e6);
}
var EQ = {
  type: gQ,
  encode: dQ,
  decode: QQ
}, pl = (
  /** @class */
  function() {
    function t() {
      this.builtInEncoders = [], this.builtInDecoders = [], this.encoders = [], this.decoders = [], this.register(EQ);
    }
    return t.prototype.register = function(A) {
      var e = A.type, i = A.encode, o = A.decode;
      if (e >= 0)
        this.encoders[e] = i, this.decoders[e] = o;
      else {
        var s = 1 + e;
        this.builtInEncoders[s] = i, this.builtInDecoders[s] = o;
      }
    }, t.prototype.tryToEncode = function(A, e) {
      for (var i = 0; i < this.builtInEncoders.length; i++) {
        var o = this.builtInEncoders[i];
        if (o != null) {
          var s = o(A, e);
          if (s != null) {
            var r = -1 - i;
            return new ti(r, s);
          }
        }
      }
      for (var i = 0; i < this.encoders.length; i++) {
        var o = this.encoders[i];
        if (o != null) {
          var s = o(A, e);
          if (s != null) {
            var r = i;
            return new ti(r, s);
          }
        }
      }
      return A instanceof ti ? A : null;
    }, t.prototype.decode = function(A, e, i) {
      var o = e < 0 ? this.builtInDecoders[-1 - e] : this.decoders[e];
      return o ? o(A, e, i) : new ti(e, A);
    }, t.defaultCodec = new t(), t;
  }()
);
function Ji(t) {
  return t instanceof Uint8Array ? t : ArrayBuffer.isView(t) ? new Uint8Array(t.buffer, t.byteOffset, t.byteLength) : t instanceof ArrayBuffer ? new Uint8Array(t) : Uint8Array.from(t);
}
function uQ(t) {
  if (t instanceof ArrayBuffer)
    return new DataView(t);
  var A = Ji(t);
  return new DataView(A.buffer, A.byteOffset, A.byteLength);
}
var pQ = 100, fQ = 2048, yQ = (
  /** @class */
  function() {
    function t(A) {
      var e, i, o, s, r, n, l, a;
      this.extensionCodec = (e = A?.extensionCodec) !== null && e !== void 0 ? e : pl.defaultCodec, this.context = A?.context, this.useBigInt64 = (i = A?.useBigInt64) !== null && i !== void 0 ? i : !1, this.maxDepth = (o = A?.maxDepth) !== null && o !== void 0 ? o : pQ, this.initialBufferSize = (s = A?.initialBufferSize) !== null && s !== void 0 ? s : fQ, this.sortKeys = (r = A?.sortKeys) !== null && r !== void 0 ? r : !1, this.forceFloat32 = (n = A?.forceFloat32) !== null && n !== void 0 ? n : !1, this.ignoreUndefined = (l = A?.ignoreUndefined) !== null && l !== void 0 ? l : !1, this.forceIntegerToFloat = (a = A?.forceIntegerToFloat) !== null && a !== void 0 ? a : !1, this.pos = 0, this.view = new DataView(new ArrayBuffer(this.initialBufferSize)), this.bytes = new Uint8Array(this.view.buffer);
    }
    return t.prototype.reinitializeState = function() {
      this.pos = 0;
    }, t.prototype.encodeSharedRef = function(A) {
      return this.reinitializeState(), this.doEncode(A, 1), this.bytes.subarray(0, this.pos);
    }, t.prototype.encode = function(A) {
      return this.reinitializeState(), this.doEncode(A, 1), this.bytes.slice(0, this.pos);
    }, t.prototype.doEncode = function(A, e) {
      if (e > this.maxDepth)
        throw new Error("Too deep objects in depth ".concat(e));
      A == null ? this.encodeNil() : typeof A == "boolean" ? this.encodeBoolean(A) : typeof A == "number" ? this.forceIntegerToFloat ? this.encodeNumberAsFloat(A) : this.encodeNumber(A) : typeof A == "string" ? this.encodeString(A) : this.useBigInt64 && typeof A == "bigint" ? this.encodeBigInt64(A) : this.encodeObject(A, e);
    }, t.prototype.ensureBufferSizeToWrite = function(A) {
      var e = this.pos + A;
      this.view.byteLength < e && this.resizeBuffer(e * 2);
    }, t.prototype.resizeBuffer = function(A) {
      var e = new ArrayBuffer(A), i = new Uint8Array(e), o = new DataView(e);
      i.set(this.bytes), this.view = o, this.bytes = i;
    }, t.prototype.encodeNil = function() {
      this.writeU8(192);
    }, t.prototype.encodeBoolean = function(A) {
      A === !1 ? this.writeU8(194) : this.writeU8(195);
    }, t.prototype.encodeNumber = function(A) {
      !this.forceIntegerToFloat && Number.isSafeInteger(A) ? A >= 0 ? A < 128 ? this.writeU8(A) : A < 256 ? (this.writeU8(204), this.writeU8(A)) : A < 65536 ? (this.writeU8(205), this.writeU16(A)) : A < 4294967296 ? (this.writeU8(206), this.writeU32(A)) : this.useBigInt64 ? this.encodeNumberAsFloat(A) : (this.writeU8(207), this.writeU64(A)) : A >= -32 ? this.writeU8(224 | A + 32) : A >= -128 ? (this.writeU8(208), this.writeI8(A)) : A >= -32768 ? (this.writeU8(209), this.writeI16(A)) : A >= -2147483648 ? (this.writeU8(210), this.writeI32(A)) : this.useBigInt64 ? this.encodeNumberAsFloat(A) : (this.writeU8(211), this.writeI64(A)) : this.encodeNumberAsFloat(A);
    }, t.prototype.encodeNumberAsFloat = function(A) {
      this.forceFloat32 ? (this.writeU8(202), this.writeF32(A)) : (this.writeU8(203), this.writeF64(A));
    }, t.prototype.encodeBigInt64 = function(A) {
      A >= BigInt(0) ? (this.writeU8(207), this.writeBigUint64(A)) : (this.writeU8(211), this.writeBigInt64(A));
    }, t.prototype.writeStringHeader = function(A) {
      if (A < 32)
        this.writeU8(160 + A);
      else if (A < 256)
        this.writeU8(217), this.writeU8(A);
      else if (A < 65536)
        this.writeU8(218), this.writeU16(A);
      else if (A < 4294967296)
        this.writeU8(219), this.writeU32(A);
      else
        throw new Error("Too long string: ".concat(A, " bytes in UTF-8"));
    }, t.prototype.encodeString = function(A) {
      var e = 5, i = jB(A);
      this.ensureBufferSizeToWrite(e + i), this.writeStringHeader(i), tQ(A, this.bytes, this.pos), this.pos += i;
    }, t.prototype.encodeObject = function(A, e) {
      var i = this.extensionCodec.tryToEncode(A, this.context);
      if (i != null)
        this.encodeExtension(i);
      else if (Array.isArray(A))
        this.encodeArray(A, e);
      else if (ArrayBuffer.isView(A))
        this.encodeBinary(A);
      else if (typeof A == "object")
        this.encodeMap(A, e);
      else
        throw new Error("Unrecognized object: ".concat(Object.prototype.toString.apply(A)));
    }, t.prototype.encodeBinary = function(A) {
      var e = A.byteLength;
      if (e < 256)
        this.writeU8(196), this.writeU8(e);
      else if (e < 65536)
        this.writeU8(197), this.writeU16(e);
      else if (e < 4294967296)
        this.writeU8(198), this.writeU32(e);
      else
        throw new Error("Too large binary: ".concat(e));
      var i = Ji(A);
      this.writeU8a(i);
    }, t.prototype.encodeArray = function(A, e) {
      var i = A.length;
      if (i < 16)
        this.writeU8(144 + i);
      else if (i < 65536)
        this.writeU8(220), this.writeU16(i);
      else if (i < 4294967296)
        this.writeU8(221), this.writeU32(i);
      else
        throw new Error("Too large array: ".concat(i));
      for (var o = 0, s = A; o < s.length; o++) {
        var r = s[o];
        this.doEncode(r, e + 1);
      }
    }, t.prototype.countWithoutUndefined = function(A, e) {
      for (var i = 0, o = 0, s = e; o < s.length; o++) {
        var r = s[o];
        A[r] !== void 0 && i++;
      }
      return i;
    }, t.prototype.encodeMap = function(A, e) {
      var i = Object.keys(A);
      this.sortKeys && i.sort();
      var o = this.ignoreUndefined ? this.countWithoutUndefined(A, i) : i.length;
      if (o < 16)
        this.writeU8(128 + o);
      else if (o < 65536)
        this.writeU8(222), this.writeU16(o);
      else if (o < 4294967296)
        this.writeU8(223), this.writeU32(o);
      else
        throw new Error("Too large map object: ".concat(o));
      for (var s = 0, r = i; s < r.length; s++) {
        var n = r[s], l = A[n];
        this.ignoreUndefined && l === void 0 || (this.encodeString(n), this.doEncode(l, e + 1));
      }
    }, t.prototype.encodeExtension = function(A) {
      var e = A.data.length;
      if (e === 1)
        this.writeU8(212);
      else if (e === 2)
        this.writeU8(213);
      else if (e === 4)
        this.writeU8(214);
      else if (e === 8)
        this.writeU8(215);
      else if (e === 16)
        this.writeU8(216);
      else if (e < 256)
        this.writeU8(199), this.writeU8(e);
      else if (e < 65536)
        this.writeU8(200), this.writeU16(e);
      else if (e < 4294967296)
        this.writeU8(201), this.writeU32(e);
      else
        throw new Error("Too large extension object: ".concat(e));
      this.writeI8(A.type), this.writeU8a(A.data);
    }, t.prototype.writeU8 = function(A) {
      this.ensureBufferSizeToWrite(1), this.view.setUint8(this.pos, A), this.pos++;
    }, t.prototype.writeU8a = function(A) {
      var e = A.length;
      this.ensureBufferSizeToWrite(e), this.bytes.set(A, this.pos), this.pos += e;
    }, t.prototype.writeI8 = function(A) {
      this.ensureBufferSizeToWrite(1), this.view.setInt8(this.pos, A), this.pos++;
    }, t.prototype.writeU16 = function(A) {
      this.ensureBufferSizeToWrite(2), this.view.setUint16(this.pos, A), this.pos += 2;
    }, t.prototype.writeI16 = function(A) {
      this.ensureBufferSizeToWrite(2), this.view.setInt16(this.pos, A), this.pos += 2;
    }, t.prototype.writeU32 = function(A) {
      this.ensureBufferSizeToWrite(4), this.view.setUint32(this.pos, A), this.pos += 4;
    }, t.prototype.writeI32 = function(A) {
      this.ensureBufferSizeToWrite(4), this.view.setInt32(this.pos, A), this.pos += 4;
    }, t.prototype.writeF32 = function(A) {
      this.ensureBufferSizeToWrite(4), this.view.setFloat32(this.pos, A), this.pos += 4;
    }, t.prototype.writeF64 = function(A) {
      this.ensureBufferSizeToWrite(8), this.view.setFloat64(this.pos, A), this.pos += 8;
    }, t.prototype.writeU64 = function(A) {
      this.ensureBufferSizeToWrite(8), aQ(this.view, this.pos, A), this.pos += 8;
    }, t.prototype.writeI64 = function(A) {
      this.ensureBufferSizeToWrite(8), El(this.view, this.pos, A), this.pos += 8;
    }, t.prototype.writeBigUint64 = function(A) {
      this.ensureBufferSizeToWrite(8), this.view.setBigUint64(this.pos, A), this.pos += 8;
    }, t.prototype.writeBigInt64 = function(A) {
      this.ensureBufferSizeToWrite(8), this.view.setBigInt64(this.pos, A), this.pos += 8;
    }, t;
  }()
);
function Dn(t, A) {
  var e = new yQ(A);
  return e.encodeSharedRef(t);
}
function Fo(t) {
  return "".concat(t < 0 ? "-" : "", "0x").concat(Math.abs(t).toString(16).padStart(2, "0"));
}
var wQ = 16, mQ = 16, vQ = (
  /** @class */
  function() {
    function t(A, e) {
      A === void 0 && (A = wQ), e === void 0 && (e = mQ), this.maxKeyLength = A, this.maxLengthPerKey = e, this.hit = 0, this.miss = 0, this.caches = [];
      for (var i = 0; i < this.maxKeyLength; i++)
        this.caches.push([]);
    }
    return t.prototype.canBeCached = function(A) {
      return A > 0 && A <= this.maxKeyLength;
    }, t.prototype.find = function(A, e, i) {
      var o = this.caches[i - 1];
      A:
        for (var s = 0, r = o; s < r.length; s++) {
          for (var n = r[s], l = n.bytes, a = 0; a < i; a++)
            if (l[a] !== A[e + a])
              continue A;
          return n.str;
        }
      return null;
    }, t.prototype.store = function(A, e) {
      var i = this.caches[A.length - 1], o = { bytes: A, str: e };
      i.length >= this.maxLengthPerKey ? i[Math.random() * i.length | 0] = o : i.push(o);
    }, t.prototype.decode = function(A, e, i) {
      var o = this.find(A, e, i);
      if (o != null)
        return this.hit++, o;
      this.miss++;
      var s = Ql(A, e, i), r = Uint8Array.prototype.slice.call(A, e, e + i);
      return this.store(r, s), s;
    }, t;
  }()
), bQ = globalThis && globalThis.__awaiter || function(t, A, e, i) {
  function o(s) {
    return s instanceof e ? s : new e(function(r) {
      r(s);
    });
  }
  return new (e || (e = Promise))(function(s, r) {
    function n(h) {
      try {
        a(i.next(h));
      } catch (g) {
        r(g);
      }
    }
    function l(h) {
      try {
        a(i.throw(h));
      } catch (g) {
        r(g);
      }
    }
    function a(h) {
      h.done ? s(h.value) : o(h.value).then(n, l);
    }
    a((i = i.apply(t, A || [])).next());
  });
}, Go = globalThis && globalThis.__generator || function(t, A) {
  var e = { label: 0, sent: function() {
    if (s[0] & 1)
      throw s[1];
    return s[1];
  }, trys: [], ops: [] }, i, o, s, r;
  return r = { next: n(0), throw: n(1), return: n(2) }, typeof Symbol == "function" && (r[Symbol.iterator] = function() {
    return this;
  }), r;
  function n(a) {
    return function(h) {
      return l([a, h]);
    };
  }
  function l(a) {
    if (i)
      throw new TypeError("Generator is already executing.");
    for (; r && (r = 0, a[0] && (e = 0)), e; )
      try {
        if (i = 1, o && (s = a[0] & 2 ? o.return : a[0] ? o.throw || ((s = o.return) && s.call(o), 0) : o.next) && !(s = s.call(o, a[1])).done)
          return s;
        switch (o = 0, s && (a = [a[0] & 2, s.value]), a[0]) {
          case 0:
          case 1:
            s = a;
            break;
          case 4:
            return e.label++, { value: a[1], done: !1 };
          case 5:
            e.label++, o = a[1], a = [0];
            continue;
          case 7:
            a = e.ops.pop(), e.trys.pop();
            continue;
          default:
            if (s = e.trys, !(s = s.length > 0 && s[s.length - 1]) && (a[0] === 6 || a[0] === 2)) {
              e = 0;
              continue;
            }
            if (a[0] === 3 && (!s || a[1] > s[0] && a[1] < s[3])) {
              e.label = a[1];
              break;
            }
            if (a[0] === 6 && e.label < s[1]) {
              e.label = s[1], s = a;
              break;
            }
            if (s && e.label < s[2]) {
              e.label = s[2], e.ops.push(a);
              break;
            }
            s[2] && e.ops.pop(), e.trys.pop();
            continue;
        }
        a = A.call(t, e);
      } catch (h) {
        a = [6, h], o = 0;
      } finally {
        i = s = 0;
      }
    if (a[0] & 5)
      throw a[1];
    return { value: a[0] ? a[1] : void 0, done: !0 };
  }
}, kn = globalThis && globalThis.__asyncValues || function(t) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var A = t[Symbol.asyncIterator], e;
  return A ? A.call(t) : (t = typeof __values == "function" ? __values(t) : t[Symbol.iterator](), e = {}, i("next"), i("throw"), i("return"), e[Symbol.asyncIterator] = function() {
    return this;
  }, e);
  function i(s) {
    e[s] = t[s] && function(r) {
      return new Promise(function(n, l) {
        r = t[s](r), o(n, l, r.done, r.value);
      });
    };
  }
  function o(s, r, n, l) {
    Promise.resolve(l).then(function(a) {
      s({ value: a, done: n });
    }, r);
  }
}, Rt = globalThis && globalThis.__await || function(t) {
  return this instanceof Rt ? (this.v = t, this) : new Rt(t);
}, DQ = globalThis && globalThis.__asyncGenerator || function(t, A, e) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var i = e.apply(t, A || []), o, s = [];
  return o = {}, r("next"), r("throw"), r("return"), o[Symbol.asyncIterator] = function() {
    return this;
  }, o;
  function r(c) {
    i[c] && (o[c] = function(C) {
      return new Promise(function(B, Q) {
        s.push([c, C, B, Q]) > 1 || n(c, C);
      });
    });
  }
  function n(c, C) {
    try {
      l(i[c](C));
    } catch (B) {
      g(s[0][3], B);
    }
  }
  function l(c) {
    c.value instanceof Rt ? Promise.resolve(c.value.v).then(a, h) : g(s[0][2], c);
  }
  function a(c) {
    n("next", c);
  }
  function h(c) {
    n("throw", c);
  }
  function g(c, C) {
    c(C), s.shift(), s.length && n(s[0][0], s[0][1]);
  }
}, Sn = "array", ei = "map_key", kQ = "map_value", SQ = function(t) {
  return typeof t == "string" || typeof t == "number";
}, he = -1, Ts = new DataView(new ArrayBuffer(0)), xQ = new Uint8Array(Ts.buffer);
try {
  Ts.getInt8(0);
} catch (t) {
  if (!(t instanceof RangeError))
    throw new Error("This module is not supported in the current JavaScript engine because DataView does not throw RangeError on out-of-bounds access");
}
var us = RangeError, xn = new us("Insufficient data"), NQ = new vQ(), UQ = (
  /** @class */
  function() {
    function t(A) {
      var e, i, o, s, r, n, l;
      this.totalPos = 0, this.pos = 0, this.view = Ts, this.bytes = xQ, this.headByte = he, this.stack = [], this.extensionCodec = (e = A?.extensionCodec) !== null && e !== void 0 ? e : pl.defaultCodec, this.context = A?.context, this.useBigInt64 = (i = A?.useBigInt64) !== null && i !== void 0 ? i : !1, this.maxStrLength = (o = A?.maxStrLength) !== null && o !== void 0 ? o : ce, this.maxBinLength = (s = A?.maxBinLength) !== null && s !== void 0 ? s : ce, this.maxArrayLength = (r = A?.maxArrayLength) !== null && r !== void 0 ? r : ce, this.maxMapLength = (n = A?.maxMapLength) !== null && n !== void 0 ? n : ce, this.maxExtLength = (l = A?.maxExtLength) !== null && l !== void 0 ? l : ce, this.keyDecoder = A?.keyDecoder !== void 0 ? A.keyDecoder : NQ;
    }
    return t.prototype.reinitializeState = function() {
      this.totalPos = 0, this.headByte = he, this.stack.length = 0;
    }, t.prototype.setBuffer = function(A) {
      this.bytes = Ji(A), this.view = uQ(this.bytes), this.pos = 0;
    }, t.prototype.appendBuffer = function(A) {
      if (this.headByte === he && !this.hasRemaining(1))
        this.setBuffer(A);
      else {
        var e = this.bytes.subarray(this.pos), i = Ji(A), o = new Uint8Array(e.length + i.length);
        o.set(e), o.set(i, e.length), this.setBuffer(o);
      }
    }, t.prototype.hasRemaining = function(A) {
      return this.view.byteLength - this.pos >= A;
    }, t.prototype.createExtraByteError = function(A) {
      var e = this, i = e.view, o = e.pos;
      return new RangeError("Extra ".concat(i.byteLength - o, " of ").concat(i.byteLength, " byte(s) found at buffer[").concat(A, "]"));
    }, t.prototype.decode = function(A) {
      this.reinitializeState(), this.setBuffer(A);
      var e = this.doDecodeSync();
      if (this.hasRemaining(1))
        throw this.createExtraByteError(this.pos);
      return e;
    }, t.prototype.decodeMulti = function(A) {
      return Go(this, function(e) {
        switch (e.label) {
          case 0:
            this.reinitializeState(), this.setBuffer(A), e.label = 1;
          case 1:
            return this.hasRemaining(1) ? [4, this.doDecodeSync()] : [3, 3];
          case 2:
            return e.sent(), [3, 1];
          case 3:
            return [
              2
              /*return*/
            ];
        }
      });
    }, t.prototype.decodeAsync = function(A) {
      var e, i, o, s, r, n, l;
      return bQ(this, void 0, void 0, function() {
        var a, h, g, c, C, B, Q, E;
        return Go(this, function(f) {
          switch (f.label) {
            case 0:
              a = !1, f.label = 1;
            case 1:
              f.trys.push([1, 6, 7, 12]), e = !0, i = kn(A), f.label = 2;
            case 2:
              return [4, i.next()];
            case 3:
              if (o = f.sent(), s = o.done, !!s)
                return [3, 5];
              l = o.value, e = !1;
              try {
                if (g = l, a)
                  throw this.createExtraByteError(this.totalPos);
                this.appendBuffer(g);
                try {
                  h = this.doDecodeSync(), a = !0;
                } catch (w) {
                  if (!(w instanceof us))
                    throw w;
                }
                this.totalPos += this.pos;
              } finally {
                e = !0;
              }
              f.label = 4;
            case 4:
              return [3, 2];
            case 5:
              return [3, 12];
            case 6:
              return c = f.sent(), r = { error: c }, [3, 12];
            case 7:
              return f.trys.push([7, , 10, 11]), !e && !s && (n = i.return) ? [4, n.call(i)] : [3, 9];
            case 8:
              f.sent(), f.label = 9;
            case 9:
              return [3, 11];
            case 10:
              if (r)
                throw r.error;
              return [
                7
                /*endfinally*/
              ];
            case 11:
              return [
                7
                /*endfinally*/
              ];
            case 12:
              if (a) {
                if (this.hasRemaining(1))
                  throw this.createExtraByteError(this.totalPos);
                return [2, h];
              }
              throw C = this, B = C.headByte, Q = C.pos, E = C.totalPos, new RangeError("Insufficient data in parsing ".concat(Fo(B), " at ").concat(E, " (").concat(Q, " in the current buffer)"));
          }
        });
      });
    }, t.prototype.decodeArrayStream = function(A) {
      return this.decodeMultiAsync(A, !0);
    }, t.prototype.decodeStream = function(A) {
      return this.decodeMultiAsync(A, !1);
    }, t.prototype.decodeMultiAsync = function(A, e) {
      return DQ(this, arguments, function() {
        var o, s, r, n, l, a, h, g, c, C, B, Q;
        return Go(this, function(E) {
          switch (E.label) {
            case 0:
              o = e, s = -1, E.label = 1;
            case 1:
              E.trys.push([1, 15, 16, 21]), r = !0, n = kn(A), E.label = 2;
            case 2:
              return [4, Rt(n.next())];
            case 3:
              if (l = E.sent(), c = l.done, !!c)
                return [3, 14];
              Q = l.value, r = !1, E.label = 4;
            case 4:
              if (E.trys.push([4, , 12, 13]), a = Q, e && s === 0)
                throw this.createExtraByteError(this.totalPos);
              this.appendBuffer(a), o && (s = this.readArraySize(), o = !1, this.complete()), E.label = 5;
            case 5:
              E.trys.push([5, 10, , 11]), E.label = 6;
            case 6:
              return [4, Rt(this.doDecodeSync())];
            case 7:
              return [4, E.sent()];
            case 8:
              return E.sent(), --s === 0 ? [3, 9] : [3, 6];
            case 9:
              return [3, 11];
            case 10:
              if (h = E.sent(), !(h instanceof us))
                throw h;
              return [3, 11];
            case 11:
              return this.totalPos += this.pos, [3, 13];
            case 12:
              return r = !0, [
                7
                /*endfinally*/
              ];
            case 13:
              return [3, 2];
            case 14:
              return [3, 21];
            case 15:
              return g = E.sent(), C = { error: g }, [3, 21];
            case 16:
              return E.trys.push([16, , 19, 20]), !r && !c && (B = n.return) ? [4, Rt(B.call(n))] : [3, 18];
            case 17:
              E.sent(), E.label = 18;
            case 18:
              return [3, 20];
            case 19:
              if (C)
                throw C.error;
              return [
                7
                /*endfinally*/
              ];
            case 20:
              return [
                7
                /*endfinally*/
              ];
            case 21:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    }, t.prototype.doDecodeSync = function() {
      A:
        for (; ; ) {
          var A = this.readHeadByte(), e = void 0;
          if (A >= 224)
            e = A - 256;
          else if (A < 192)
            if (A < 128)
              e = A;
            else if (A < 144) {
              var i = A - 128;
              if (i !== 0) {
                this.pushMapState(i), this.complete();
                continue A;
              } else
                e = {};
            } else if (A < 160) {
              var i = A - 144;
              if (i !== 0) {
                this.pushArrayState(i), this.complete();
                continue A;
              } else
                e = [];
            } else {
              var o = A - 160;
              e = this.decodeUtf8String(o, 0);
            }
          else if (A === 192)
            e = null;
          else if (A === 194)
            e = !1;
          else if (A === 195)
            e = !0;
          else if (A === 202)
            e = this.readF32();
          else if (A === 203)
            e = this.readF64();
          else if (A === 204)
            e = this.readU8();
          else if (A === 205)
            e = this.readU16();
          else if (A === 206)
            e = this.readU32();
          else if (A === 207)
            this.useBigInt64 ? e = this.readU64AsBigInt() : e = this.readU64();
          else if (A === 208)
            e = this.readI8();
          else if (A === 209)
            e = this.readI16();
          else if (A === 210)
            e = this.readI32();
          else if (A === 211)
            this.useBigInt64 ? e = this.readI64AsBigInt() : e = this.readI64();
          else if (A === 217) {
            var o = this.lookU8();
            e = this.decodeUtf8String(o, 1);
          } else if (A === 218) {
            var o = this.lookU16();
            e = this.decodeUtf8String(o, 2);
          } else if (A === 219) {
            var o = this.lookU32();
            e = this.decodeUtf8String(o, 4);
          } else if (A === 220) {
            var i = this.readU16();
            if (i !== 0) {
              this.pushArrayState(i), this.complete();
              continue A;
            } else
              e = [];
          } else if (A === 221) {
            var i = this.readU32();
            if (i !== 0) {
              this.pushArrayState(i), this.complete();
              continue A;
            } else
              e = [];
          } else if (A === 222) {
            var i = this.readU16();
            if (i !== 0) {
              this.pushMapState(i), this.complete();
              continue A;
            } else
              e = {};
          } else if (A === 223) {
            var i = this.readU32();
            if (i !== 0) {
              this.pushMapState(i), this.complete();
              continue A;
            } else
              e = {};
          } else if (A === 196) {
            var i = this.lookU8();
            e = this.decodeBinary(i, 1);
          } else if (A === 197) {
            var i = this.lookU16();
            e = this.decodeBinary(i, 2);
          } else if (A === 198) {
            var i = this.lookU32();
            e = this.decodeBinary(i, 4);
          } else if (A === 212)
            e = this.decodeExtension(1, 0);
          else if (A === 213)
            e = this.decodeExtension(2, 0);
          else if (A === 214)
            e = this.decodeExtension(4, 0);
          else if (A === 215)
            e = this.decodeExtension(8, 0);
          else if (A === 216)
            e = this.decodeExtension(16, 0);
          else if (A === 199) {
            var i = this.lookU8();
            e = this.decodeExtension(i, 1);
          } else if (A === 200) {
            var i = this.lookU16();
            e = this.decodeExtension(i, 2);
          } else if (A === 201) {
            var i = this.lookU32();
            e = this.decodeExtension(i, 4);
          } else
            throw new xA("Unrecognized type byte: ".concat(Fo(A)));
          this.complete();
          for (var s = this.stack; s.length > 0; ) {
            var r = s[s.length - 1];
            if (r.type === Sn)
              if (r.array[r.position] = e, r.position++, r.position === r.size)
                s.pop(), e = r.array;
              else
                continue A;
            else if (r.type === ei) {
              if (!SQ(e))
                throw new xA("The type of key must be string or number but " + typeof e);
              if (e === "__proto__")
                throw new xA("The key __proto__ is not allowed");
              r.key = e, r.type = kQ;
              continue A;
            } else if (r.map[r.key] = e, r.readCount++, r.readCount === r.size)
              s.pop(), e = r.map;
            else {
              r.key = null, r.type = ei;
              continue A;
            }
          }
          return e;
        }
    }, t.prototype.readHeadByte = function() {
      return this.headByte === he && (this.headByte = this.readU8()), this.headByte;
    }, t.prototype.complete = function() {
      this.headByte = he;
    }, t.prototype.readArraySize = function() {
      var A = this.readHeadByte();
      switch (A) {
        case 220:
          return this.readU16();
        case 221:
          return this.readU32();
        default: {
          if (A < 160)
            return A - 144;
          throw new xA("Unrecognized array type byte: ".concat(Fo(A)));
        }
      }
    }, t.prototype.pushMapState = function(A) {
      if (A > this.maxMapLength)
        throw new xA("Max length exceeded: map length (".concat(A, ") > maxMapLengthLength (").concat(this.maxMapLength, ")"));
      this.stack.push({
        type: ei,
        size: A,
        key: null,
        readCount: 0,
        map: {}
      });
    }, t.prototype.pushArrayState = function(A) {
      if (A > this.maxArrayLength)
        throw new xA("Max length exceeded: array length (".concat(A, ") > maxArrayLength (").concat(this.maxArrayLength, ")"));
      this.stack.push({
        type: Sn,
        size: A,
        array: new Array(A),
        position: 0
      });
    }, t.prototype.decodeUtf8String = function(A, e) {
      var i;
      if (A > this.maxStrLength)
        throw new xA("Max length exceeded: UTF-8 byte length (".concat(A, ") > maxStrLength (").concat(this.maxStrLength, ")"));
      if (this.bytes.byteLength < this.pos + e + A)
        throw xn;
      var o = this.pos + e, s;
      return this.stateIsMapKey() && (!((i = this.keyDecoder) === null || i === void 0) && i.canBeCached(A)) ? s = this.keyDecoder.decode(this.bytes, o, A) : s = rQ(this.bytes, o, A), this.pos += e + A, s;
    }, t.prototype.stateIsMapKey = function() {
      if (this.stack.length > 0) {
        var A = this.stack[this.stack.length - 1];
        return A.type === ei;
      }
      return !1;
    }, t.prototype.decodeBinary = function(A, e) {
      if (A > this.maxBinLength)
        throw new xA("Max length exceeded: bin length (".concat(A, ") > maxBinLength (").concat(this.maxBinLength, ")"));
      if (!this.hasRemaining(A + e))
        throw xn;
      var i = this.pos + e, o = this.bytes.subarray(i, i + A);
      return this.pos += e + A, o;
    }, t.prototype.decodeExtension = function(A, e) {
      if (A > this.maxExtLength)
        throw new xA("Max length exceeded: ext length (".concat(A, ") > maxExtLength (").concat(this.maxExtLength, ")"));
      var i = this.view.getInt8(this.pos + e), o = this.decodeBinary(
        A,
        e + 1
        /* extType */
      );
      return this.extensionCodec.decode(o, i, this.context);
    }, t.prototype.lookU8 = function() {
      return this.view.getUint8(this.pos);
    }, t.prototype.lookU16 = function() {
      return this.view.getUint16(this.pos);
    }, t.prototype.lookU32 = function() {
      return this.view.getUint32(this.pos);
    }, t.prototype.readU8 = function() {
      var A = this.view.getUint8(this.pos);
      return this.pos++, A;
    }, t.prototype.readI8 = function() {
      var A = this.view.getInt8(this.pos);
      return this.pos++, A;
    }, t.prototype.readU16 = function() {
      var A = this.view.getUint16(this.pos);
      return this.pos += 2, A;
    }, t.prototype.readI16 = function() {
      var A = this.view.getInt16(this.pos);
      return this.pos += 2, A;
    }, t.prototype.readU32 = function() {
      var A = this.view.getUint32(this.pos);
      return this.pos += 4, A;
    }, t.prototype.readI32 = function() {
      var A = this.view.getInt32(this.pos);
      return this.pos += 4, A;
    }, t.prototype.readU64 = function() {
      var A = lQ(this.view, this.pos);
      return this.pos += 8, A;
    }, t.prototype.readI64 = function() {
      var A = ul(this.view, this.pos);
      return this.pos += 8, A;
    }, t.prototype.readU64AsBigInt = function() {
      var A = this.view.getBigUint64(this.pos);
      return this.pos += 8, A;
    }, t.prototype.readI64AsBigInt = function() {
      var A = this.view.getBigInt64(this.pos);
      return this.pos += 8, A;
    }, t.prototype.readF32 = function() {
      var A = this.view.getFloat32(this.pos);
      return this.pos += 4, A;
    }, t.prototype.readF64 = function() {
      var A = this.view.getFloat64(this.pos);
      return this.pos += 8, A;
    }, t;
  }()
);
function FQ(t, A) {
  var e = new UQ(A);
  return e.decode(t);
}
class GQ extends ya {
  constructor(A, e, i = "attachments") {
    super(A, e, i), this.client = A, this.roleName = e, this.zomeName = i;
  }
  async getDnaHash() {
    const A = await this.client.appInfo();
    return aC(this.roleName, A)[0];
  }
  addAttachment(A, e) {
    return this.callZome("add_attachment", {
      hash: A,
      hrl_with_context: {
        hrl: {
          dna_hash: e.hrl[0],
          resource_hash: e.hrl[1]
        },
        context: Dn(e.context)
      }
    });
  }
  async getAttachments(A) {
    return (await this.callZome("get_attachments", A)).map((i) => ({
      hrl: [i.hrl.dna_hash, i.hrl.resource_hash],
      context: FQ(i.context)
    }));
  }
  removeAttachment(A, e) {
    return this.callZome("remove_attachment", {
      hash: A,
      hrl_with_context: {
        hrl: {
          dna_hash: e.hrl[0],
          resource_hash: e.hrl[1]
        },
        context: Dn(e.context)
      }
    });
  }
}
class RQ {
  constructor(A) {
    this.client = A, this.attachments = new wa((e) => jo(() => this.client.getAttachments(e), 2e3));
  }
}
let Yi = class extends F {
  render() {
    return p`<slot></slot>`;
  }
};
Yi.styles = z`
    :host {
      display: contents;
    }
  `;
u([
  Pi({ context: Ls }),
  y({ type: Object })
], Yi.prototype, "store", void 0);
Yi = u([
  H("attachments-context")
], Yi);
function Nn(t, A, e, i) {
  const o = new VB(new Li(t, "forum"));
  return p`
    <posts-context .store=${o}>
      <we-services-context .services=${e}>
        <attachments-context
          .store=${new RQ(new GQ(t, "forum"))}
        >
          ${i}
        </attachments-context>
      </we-services-context>
    </posts-context>
  `;
}
async function MQ(t, A, e, i) {
  return {
    main: (o) => Ci(
      Nn(
        t,
        e,
        i,
        p`
            <applet-main
              @post-selected=${async (s) => {
          const n = (await t.appInfo()).cell_info.forum[0][tA.Provisioned].cell_id[0];
          i.openViews.openHrl([n, s.detail.postHash], {});
        }}
            ></applet-main>
          `
      ),
      o
    ),
    blocks: {},
    entries: {
      forum: {
        posts_integrity: {
          post: {
            info: async (o) => {
              const r = await new Li(t, "forum").getPost(o[1]);
              if (r)
                return {
                  name: r.entry.title,
                  icon_src: HA(Sa)
                };
            },
            view: (o, s, r) => Ci(
              Nn(
                t,
                e,
                i,
                p` <post-detail .postHash=${s[1]}></post-detail> `
              ),
              o
            )
          }
        }
      }
    }
  };
}
async function _Q(t, A) {
  return {
    main: (e) => Ci(
      p`
          <we-services-context .services=${A}>
            <cross-applet-main .applets=${t}></cross-applet-main>
          </we-services-context>
        `,
      e
    ),
    blocks: {}
  };
}
const pE = {
  appletViews: MQ,
  crossAppletViews: _Q,
  attachmentTypes: async (t) => ({
    post: {
      async create(A) {
        const i = await new Li(t, "forum").createPost({
          title: `Post about hrl://${kt(
            A[0]
          )}/${kt(A[1])}`,
          content: ""
        });
        return { hrl: [(await t.appInfo()).cell_info.forum[0][tA.Provisioned].cell_id[0], i.actionHash], context: null };
      },
      icon_src: HA(Sa),
      label: k("Post")
    }
  }),
  search: async (t, A) => {
    const i = (await t.appInfo()).cell_info.forum[0][tA.Provisioned].cell_id[0];
    return (await new Li(t, "forum").getAllPosts()).filter(
      (n) => n.entry.title.includes(A)
    ).map((n) => ({
      hrl: [i, n.actionHash],
      context: null
    }));
  }
};
export {
  pE as default
};
