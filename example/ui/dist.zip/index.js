/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const rs = window, nn = rs.ShadowRoot && (rs.ShadyCSS === void 0 || rs.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, an = Symbol(), Pn = /* @__PURE__ */ new WeakMap();
let ig = class {
  constructor(t, A, i) {
    if (this._$cssResult$ = !0, i !== an)
      throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = A;
  }
  get styleSheet() {
    let t = this.o;
    const A = this.t;
    if (nn && t === void 0) {
      const i = A !== void 0 && A.length === 1;
      i && (t = Pn.get(A)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), i && Pn.set(A, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const Qh = (e) => new ig(typeof e == "string" ? e : e + "", void 0, an), ae = (e, ...t) => {
  const A = e.length === 1 ? e[0] : t.reduce((i, s, o) => i + ((r) => {
    if (r._$cssResult$ === !0)
      return r.cssText;
    if (typeof r == "number")
      return r;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + r + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(s) + e[o + 1], e[0]);
  return new ig(A, e, an);
}, Eh = (e, t) => {
  nn ? e.adoptedStyleSheets = t.map((A) => A instanceof CSSStyleSheet ? A : A.styleSheet) : t.forEach((A) => {
    const i = document.createElement("style"), s = rs.litNonce;
    s !== void 0 && i.setAttribute("nonce", s), i.textContent = A.cssText, e.appendChild(i);
  });
}, qn = nn ? (e) => e : (e) => e instanceof CSSStyleSheet ? ((t) => {
  let A = "";
  for (const i of t.cssRules)
    A += i.cssText;
  return Qh(A);
})(e) : e;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var yo;
const Qs = window, Vn = Qs.trustedTypes, fh = Vn ? Vn.emptyScript : "", zn = Qs.reactiveElementPolyfillSupport, Cr = { toAttribute(e, t) {
  switch (t) {
    case Boolean:
      e = e ? fh : null;
      break;
    case Object:
    case Array:
      e = e == null ? e : JSON.stringify(e);
  }
  return e;
}, fromAttribute(e, t) {
  let A = e;
  switch (t) {
    case Boolean:
      A = e !== null;
      break;
    case Number:
      A = e === null ? null : Number(e);
      break;
    case Object:
    case Array:
      try {
        A = JSON.parse(e);
      } catch {
        A = null;
      }
  }
  return A;
} }, sg = (e, t) => t !== e && (t == t || e == e), vo = { attribute: !0, type: String, converter: Cr, reflect: !1, hasChanged: sg };
let eA = class extends HTMLElement {
  constructor() {
    super(), this._$Ei = /* @__PURE__ */ new Map(), this.isUpdatePending = !1, this.hasUpdated = !1, this._$El = null, this.u();
  }
  static addInitializer(t) {
    var A;
    this.finalize(), ((A = this.h) !== null && A !== void 0 ? A : this.h = []).push(t);
  }
  static get observedAttributes() {
    this.finalize();
    const t = [];
    return this.elementProperties.forEach((A, i) => {
      const s = this._$Ep(i, A);
      s !== void 0 && (this._$Ev.set(s, i), t.push(s));
    }), t;
  }
  static createProperty(t, A = vo) {
    if (A.state && (A.attribute = !1), this.finalize(), this.elementProperties.set(t, A), !A.noAccessor && !this.prototype.hasOwnProperty(t)) {
      const i = typeof t == "symbol" ? Symbol() : "__" + t, s = this.getPropertyDescriptor(t, i, A);
      s !== void 0 && Object.defineProperty(this.prototype, t, s);
    }
  }
  static getPropertyDescriptor(t, A, i) {
    return { get() {
      return this[A];
    }, set(s) {
      const o = this[t];
      this[A] = s, this.requestUpdate(t, o, i);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) || vo;
  }
  static finalize() {
    if (this.hasOwnProperty("finalized"))
      return !1;
    this.finalized = !0;
    const t = Object.getPrototypeOf(this);
    if (t.finalize(), t.h !== void 0 && (this.h = [...t.h]), this.elementProperties = new Map(t.elementProperties), this._$Ev = /* @__PURE__ */ new Map(), this.hasOwnProperty("properties")) {
      const A = this.properties, i = [...Object.getOwnPropertyNames(A), ...Object.getOwnPropertySymbols(A)];
      for (const s of i)
        this.createProperty(s, A[s]);
    }
    return this.elementStyles = this.finalizeStyles(this.styles), !0;
  }
  static finalizeStyles(t) {
    const A = [];
    if (Array.isArray(t)) {
      const i = new Set(t.flat(1 / 0).reverse());
      for (const s of i)
        A.unshift(qn(s));
    } else
      t !== void 0 && A.push(qn(t));
    return A;
  }
  static _$Ep(t, A) {
    const i = A.attribute;
    return i === !1 ? void 0 : typeof i == "string" ? i : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  u() {
    var t;
    this._$E_ = new Promise((A) => this.enableUpdating = A), this._$AL = /* @__PURE__ */ new Map(), this._$Eg(), this.requestUpdate(), (t = this.constructor.h) === null || t === void 0 || t.forEach((A) => A(this));
  }
  addController(t) {
    var A, i;
    ((A = this._$ES) !== null && A !== void 0 ? A : this._$ES = []).push(t), this.renderRoot !== void 0 && this.isConnected && ((i = t.hostConnected) === null || i === void 0 || i.call(t));
  }
  removeController(t) {
    var A;
    (A = this._$ES) === null || A === void 0 || A.splice(this._$ES.indexOf(t) >>> 0, 1);
  }
  _$Eg() {
    this.constructor.elementProperties.forEach((t, A) => {
      this.hasOwnProperty(A) && (this._$Ei.set(A, this[A]), delete this[A]);
    });
  }
  createRenderRoot() {
    var t;
    const A = (t = this.shadowRoot) !== null && t !== void 0 ? t : this.attachShadow(this.constructor.shadowRootOptions);
    return Eh(A, this.constructor.elementStyles), A;
  }
  connectedCallback() {
    var t;
    this.renderRoot === void 0 && (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (t = this._$ES) === null || t === void 0 || t.forEach((A) => {
      var i;
      return (i = A.hostConnected) === null || i === void 0 ? void 0 : i.call(A);
    });
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    var t;
    (t = this._$ES) === null || t === void 0 || t.forEach((A) => {
      var i;
      return (i = A.hostDisconnected) === null || i === void 0 ? void 0 : i.call(A);
    });
  }
  attributeChangedCallback(t, A, i) {
    this._$AK(t, i);
  }
  _$EO(t, A, i = vo) {
    var s;
    const o = this.constructor._$Ep(t, i);
    if (o !== void 0 && i.reflect === !0) {
      const r = (((s = i.converter) === null || s === void 0 ? void 0 : s.toAttribute) !== void 0 ? i.converter : Cr).toAttribute(A, i.type);
      this._$El = t, r == null ? this.removeAttribute(o) : this.setAttribute(o, r), this._$El = null;
    }
  }
  _$AK(t, A) {
    var i;
    const s = this.constructor, o = s._$Ev.get(t);
    if (o !== void 0 && this._$El !== o) {
      const r = s.getPropertyOptions(o), n = typeof r.converter == "function" ? { fromAttribute: r.converter } : ((i = r.converter) === null || i === void 0 ? void 0 : i.fromAttribute) !== void 0 ? r.converter : Cr;
      this._$El = o, this[o] = n.fromAttribute(A, r.type), this._$El = null;
    }
  }
  requestUpdate(t, A, i) {
    let s = !0;
    t !== void 0 && (((i = i || this.constructor.getPropertyOptions(t)).hasChanged || sg)(this[t], A) ? (this._$AL.has(t) || this._$AL.set(t, A), i.reflect === !0 && this._$El !== t && (this._$EC === void 0 && (this._$EC = /* @__PURE__ */ new Map()), this._$EC.set(t, i))) : s = !1), !this.isUpdatePending && s && (this._$E_ = this._$Ej());
  }
  async _$Ej() {
    this.isUpdatePending = !0;
    try {
      await this._$E_;
    } catch (A) {
      Promise.reject(A);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var t;
    if (!this.isUpdatePending)
      return;
    this.hasUpdated, this._$Ei && (this._$Ei.forEach((s, o) => this[o] = s), this._$Ei = void 0);
    let A = !1;
    const i = this._$AL;
    try {
      A = this.shouldUpdate(i), A ? (this.willUpdate(i), (t = this._$ES) === null || t === void 0 || t.forEach((s) => {
        var o;
        return (o = s.hostUpdate) === null || o === void 0 ? void 0 : o.call(s);
      }), this.update(i)) : this._$Ek();
    } catch (s) {
      throw A = !1, this._$Ek(), s;
    }
    A && this._$AE(i);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    var A;
    (A = this._$ES) === null || A === void 0 || A.forEach((i) => {
      var s;
      return (s = i.hostUpdated) === null || s === void 0 ? void 0 : s.call(i);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$Ek() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$E_;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$EC !== void 0 && (this._$EC.forEach((A, i) => this._$EO(i, this[i], A)), this._$EC = void 0), this._$Ek();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
eA.finalized = !0, eA.elementProperties = /* @__PURE__ */ new Map(), eA.elementStyles = [], eA.shadowRootOptions = { mode: "open" }, zn?.({ ReactiveElement: eA }), ((yo = Qs.reactiveElementVersions) !== null && yo !== void 0 ? yo : Qs.reactiveElementVersions = []).push("1.6.1");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var mo;
const Es = window, dA = Es.trustedTypes, Kn = dA ? dA.createPolicy("lit-html", { createHTML: (e) => e }) : void 0, Br = "$lit$", de = `lit$${(Math.random() + "").slice(9)}$`, og = "?" + de, ph = `<${og}>`, CA = document, Ci = () => CA.createComment(""), Bi = (e) => e === null || typeof e != "object" && typeof e != "function", rg = Array.isArray, wh = (e) => rg(e) || typeof e?.[Symbol.iterator] == "function", bo = `[ 	
\f\r]`, $A = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, jn = /-->/g, Zn = />/g, xe = RegExp(`>|${bo}(?:([^\\s"'>=/]+)(${bo}*=${bo}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Wn = /'/g, Xn = /"/g, ng = /^(?:script|style|textarea|title)$/i, yh = (e) => (t, ...A) => ({ _$litType$: e, strings: t, values: A }), w = yh(1), BA = Symbol.for("lit-noChange"), et = Symbol.for("lit-nothing"), ta = /* @__PURE__ */ new WeakMap(), aA = CA.createTreeWalker(CA, 129, null, !1), vh = (e, t) => {
  const A = e.length - 1, i = [];
  let s, o = t === 2 ? "<svg>" : "", r = $A;
  for (let l = 0; l < A; l++) {
    const a = e[l];
    let c, g, h = -1, u = 0;
    for (; u < a.length && (r.lastIndex = u, g = r.exec(a), g !== null); )
      u = r.lastIndex, r === $A ? g[1] === "!--" ? r = jn : g[1] !== void 0 ? r = Zn : g[2] !== void 0 ? (ng.test(g[2]) && (s = RegExp("</" + g[2], "g")), r = xe) : g[3] !== void 0 && (r = xe) : r === xe ? g[0] === ">" ? (r = s ?? $A, h = -1) : g[1] === void 0 ? h = -2 : (h = r.lastIndex - g[2].length, c = g[1], r = g[3] === void 0 ? xe : g[3] === '"' ? Xn : Wn) : r === Xn || r === Wn ? r = xe : r === jn || r === Zn ? r = $A : (r = xe, s = void 0);
    const C = r === xe && e[l + 1].startsWith("/>") ? " " : "";
    o += r === $A ? a + ph : h >= 0 ? (i.push(c), a.slice(0, h) + Br + a.slice(h) + de + C) : a + de + (h === -2 ? (i.push(void 0), l) : C);
  }
  const n = o + (e[A] || "<?>") + (t === 2 ? "</svg>" : "");
  if (!Array.isArray(e) || !e.hasOwnProperty("raw"))
    throw Error("invalid template strings array");
  return [Kn !== void 0 ? Kn.createHTML(n) : n, i];
};
let Qr = class ag {
  constructor({ strings: t, _$litType$: A }, i) {
    let s;
    this.parts = [];
    let o = 0, r = 0;
    const n = t.length - 1, l = this.parts, [a, c] = vh(t, A);
    if (this.el = ag.createElement(a, i), aA.currentNode = this.el.content, A === 2) {
      const g = this.el.content, h = g.firstChild;
      h.remove(), g.append(...h.childNodes);
    }
    for (; (s = aA.nextNode()) !== null && l.length < n; ) {
      if (s.nodeType === 1) {
        if (s.hasAttributes()) {
          const g = [];
          for (const h of s.getAttributeNames())
            if (h.endsWith(Br) || h.startsWith(de)) {
              const u = c[r++];
              if (g.push(h), u !== void 0) {
                const C = s.getAttribute(u.toLowerCase() + Br).split(de), B = /([.?@])?(.*)/.exec(u);
                l.push({ type: 1, index: o, name: B[2], strings: C, ctor: B[1] === "." ? bh : B[1] === "?" ? kh : B[1] === "@" ? Sh : js });
              } else
                l.push({ type: 6, index: o });
            }
          for (const h of g)
            s.removeAttribute(h);
        }
        if (ng.test(s.tagName)) {
          const g = s.textContent.split(de), h = g.length - 1;
          if (h > 0) {
            s.textContent = dA ? dA.emptyScript : "";
            for (let u = 0; u < h; u++)
              s.append(g[u], Ci()), aA.nextNode(), l.push({ type: 2, index: ++o });
            s.append(g[h], Ci());
          }
        }
      } else if (s.nodeType === 8)
        if (s.data === og)
          l.push({ type: 2, index: o });
        else {
          let g = -1;
          for (; (g = s.data.indexOf(de, g + 1)) !== -1; )
            l.push({ type: 7, index: o }), g += de.length - 1;
        }
      o++;
    }
  }
  static createElement(t, A) {
    const i = CA.createElement("template");
    return i.innerHTML = t, i;
  }
};
function QA(e, t, A = e, i) {
  var s, o, r, n;
  if (t === BA)
    return t;
  let l = i !== void 0 ? (s = A._$Co) === null || s === void 0 ? void 0 : s[i] : A._$Cl;
  const a = Bi(t) ? void 0 : t._$litDirective$;
  return l?.constructor !== a && ((o = l?._$AO) === null || o === void 0 || o.call(l, !1), a === void 0 ? l = void 0 : (l = new a(e), l._$AT(e, A, i)), i !== void 0 ? ((r = (n = A)._$Co) !== null && r !== void 0 ? r : n._$Co = [])[i] = l : A._$Cl = l), l !== void 0 && (t = QA(e, l._$AS(e, t.values), l, i)), t;
}
let mh = class {
  constructor(t, A) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = A;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    var A;
    const { el: { content: i }, parts: s } = this._$AD, o = ((A = t?.creationScope) !== null && A !== void 0 ? A : CA).importNode(i, !0);
    aA.currentNode = o;
    let r = aA.nextNode(), n = 0, l = 0, a = s[0];
    for (; a !== void 0; ) {
      if (n === a.index) {
        let c;
        a.type === 2 ? c = new ln(r, r.nextSibling, this, t) : a.type === 1 ? c = new a.ctor(r, a.name, a.strings, this, t) : a.type === 6 && (c = new xh(r, this, t)), this._$AV.push(c), a = s[++l];
      }
      n !== a?.index && (r = aA.nextNode(), n++);
    }
    return o;
  }
  v(t) {
    let A = 0;
    for (const i of this._$AV)
      i !== void 0 && (i.strings !== void 0 ? (i._$AI(t, i, A), A += i.strings.length - 2) : i._$AI(t[A])), A++;
  }
}, ln = class lg {
  constructor(t, A, i, s) {
    var o;
    this.type = 2, this._$AH = et, this._$AN = void 0, this._$AA = t, this._$AB = A, this._$AM = i, this.options = s, this._$Cp = (o = s?.isConnected) === null || o === void 0 || o;
  }
  get _$AU() {
    var t, A;
    return (A = (t = this._$AM) === null || t === void 0 ? void 0 : t._$AU) !== null && A !== void 0 ? A : this._$Cp;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const A = this._$AM;
    return A !== void 0 && t?.nodeType === 11 && (t = A.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, A = this) {
    t = QA(this, t, A), Bi(t) ? t === et || t == null || t === "" ? (this._$AH !== et && this._$AR(), this._$AH = et) : t !== this._$AH && t !== BA && this._(t) : t._$litType$ !== void 0 ? this.g(t) : t.nodeType !== void 0 ? this.$(t) : wh(t) ? this.T(t) : this._(t);
  }
  k(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  $(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.k(t));
  }
  _(t) {
    this._$AH !== et && Bi(this._$AH) ? this._$AA.nextSibling.data = t : this.$(CA.createTextNode(t)), this._$AH = t;
  }
  g(t) {
    var A;
    const { values: i, _$litType$: s } = t, o = typeof s == "number" ? this._$AC(t) : (s.el === void 0 && (s.el = Qr.createElement(s.h, this.options)), s);
    if (((A = this._$AH) === null || A === void 0 ? void 0 : A._$AD) === o)
      this._$AH.v(i);
    else {
      const r = new mh(o, this), n = r.u(this.options);
      r.v(i), this.$(n), this._$AH = r;
    }
  }
  _$AC(t) {
    let A = ta.get(t.strings);
    return A === void 0 && ta.set(t.strings, A = new Qr(t)), A;
  }
  T(t) {
    rg(this._$AH) || (this._$AH = [], this._$AR());
    const A = this._$AH;
    let i, s = 0;
    for (const o of t)
      s === A.length ? A.push(i = new lg(this.k(Ci()), this.k(Ci()), this, this.options)) : i = A[s], i._$AI(o), s++;
    s < A.length && (this._$AR(i && i._$AB.nextSibling, s), A.length = s);
  }
  _$AR(t = this._$AA.nextSibling, A) {
    var i;
    for ((i = this._$AP) === null || i === void 0 || i.call(this, !1, !0, A); t && t !== this._$AB; ) {
      const s = t.nextSibling;
      t.remove(), t = s;
    }
  }
  setConnected(t) {
    var A;
    this._$AM === void 0 && (this._$Cp = t, (A = this._$AP) === null || A === void 0 || A.call(this, t));
  }
}, js = class {
  constructor(t, A, i, s, o) {
    this.type = 1, this._$AH = et, this._$AN = void 0, this.element = t, this.name = A, this._$AM = s, this.options = o, i.length > 2 || i[0] !== "" || i[1] !== "" ? (this._$AH = Array(i.length - 1).fill(new String()), this.strings = i) : this._$AH = et;
  }
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t, A = this, i, s) {
    const o = this.strings;
    let r = !1;
    if (o === void 0)
      t = QA(this, t, A, 0), r = !Bi(t) || t !== this._$AH && t !== BA, r && (this._$AH = t);
    else {
      const n = t;
      let l, a;
      for (t = o[0], l = 0; l < o.length - 1; l++)
        a = QA(this, n[i + l], A, l), a === BA && (a = this._$AH[l]), r || (r = !Bi(a) || a !== this._$AH[l]), a === et ? t = et : t !== et && (t += (a ?? "") + o[l + 1]), this._$AH[l] = a;
    }
    r && !s && this.j(t);
  }
  j(t) {
    t === et ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}, bh = class extends js {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === et ? void 0 : t;
  }
};
const Dh = dA ? dA.emptyScript : "";
let kh = class extends js {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    t && t !== et ? this.element.setAttribute(this.name, Dh) : this.element.removeAttribute(this.name);
  }
};
class Sh extends js {
  constructor(t, A, i, s, o) {
    super(t, A, i, s, o), this.type = 5;
  }
  _$AI(t, A = this) {
    var i;
    if ((t = (i = QA(this, t, A, 0)) !== null && i !== void 0 ? i : et) === BA)
      return;
    const s = this._$AH, o = t === et && s !== et || t.capture !== s.capture || t.once !== s.once || t.passive !== s.passive, r = t !== et && (s === et || o);
    o && this.element.removeEventListener(this.name, this, s), r && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var A, i;
    typeof this._$AH == "function" ? this._$AH.call((i = (A = this.options) === null || A === void 0 ? void 0 : A.host) !== null && i !== void 0 ? i : this.element, t) : this._$AH.handleEvent(t);
  }
}
let xh = class {
  constructor(t, A, i) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = A, this.options = i;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    QA(this, t);
  }
};
const ea = Es.litHtmlPolyfillSupport;
ea?.(Qr, ln), ((mo = Es.litHtmlVersions) !== null && mo !== void 0 ? mo : Es.litHtmlVersions = []).push("2.7.3");
const fs = (e, t, A) => {
  var i, s;
  const o = (i = A?.renderBefore) !== null && i !== void 0 ? i : t;
  let r = o._$litPart$;
  if (r === void 0) {
    const n = (s = A?.renderBefore) !== null && s !== void 0 ? s : null;
    o._$litPart$ = r = new ln(t.insertBefore(Ci(), n), n, void 0, A ?? {});
  }
  return r._$AI(e), r;
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var Do, ko;
let q = class extends eA {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var t, A;
    const i = super.createRenderRoot();
    return (t = (A = this.renderOptions).renderBefore) !== null && t !== void 0 || (A.renderBefore = i.firstChild), i;
  }
  update(t) {
    const A = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = fs(A, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var t;
    super.connectedCallback(), (t = this._$Do) === null || t === void 0 || t.setConnected(!0);
  }
  disconnectedCallback() {
    var t;
    super.disconnectedCallback(), (t = this._$Do) === null || t === void 0 || t.setConnected(!1);
  }
  render() {
    return BA;
  }
};
q.finalized = !0, q._$litElement$ = !0, (Do = globalThis.litElementHydrateSupport) === null || Do === void 0 || Do.call(globalThis, { LitElement: q });
const Aa = globalThis.litElementPolyfillSupport;
Aa?.({ LitElement: q });
((ko = globalThis.litElementVersions) !== null && ko !== void 0 ? ko : globalThis.litElementVersions = []).push("3.3.2");
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const It = (e) => (t) => typeof t == "function" ? ((A, i) => (customElements.define(A, i), i))(e, t) : ((A, i) => {
  const { kind: s, elements: o } = i;
  return { kind: s, elements: o, finisher(r) {
    customElements.define(A, r);
  } };
})(e, t);
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const Nh = (e, t) => t.kind === "method" && t.descriptor && !("value" in t.descriptor) ? { ...t, finisher(A) {
  A.createProperty(t.key, e);
} } : { kind: "field", key: Symbol(), placement: "own", descriptor: {}, originalKey: t.key, initializer() {
  typeof t.initializer == "function" && (this[t.key] = t.initializer.call(this));
}, finisher(A) {
  A.createProperty(t.key, e);
} };
function W(e) {
  return (t, A) => A !== void 0 ? ((i, s, o) => {
    s.constructor.createProperty(o, i);
  })(e, t, A) : Nh(e, t);
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function Mi(e) {
  return W({ ...e, state: !0 });
}
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const gn = ({ finisher: e, descriptor: t }) => (A, i) => {
  var s;
  if (i === void 0) {
    const o = (s = A.originalKey) !== null && s !== void 0 ? s : A.key, r = t != null ? { kind: "method", placement: "prototype", key: o, descriptor: t(A.key) } : { ...A, key: o };
    return e != null && (r.finisher = function(n) {
      e(n, o);
    }), r;
  }
  {
    const o = A.constructor;
    t !== void 0 && Object.defineProperty(A, i, t(i)), e?.(o, i);
  }
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function Fh(e, t) {
  return gn({ descriptor: (A) => {
    const i = { get() {
      var s, o;
      return (o = (s = this.renderRoot) === null || s === void 0 ? void 0 : s.querySelector(e)) !== null && o !== void 0 ? o : null;
    }, enumerable: !0, configurable: !0 };
    if (t) {
      const s = typeof A == "symbol" ? Symbol() : "__" + A;
      i.get = function() {
        var o, r;
        return this[s] === void 0 && (this[s] = (r = (o = this.renderRoot) === null || o === void 0 ? void 0 : o.querySelector(e)) !== null && r !== void 0 ? r : null), this[s];
      };
    }
    return i;
  } });
}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var So;
((So = window.HTMLSlotElement) === null || So === void 0 ? void 0 : So.prototype.assignedElements) != null;
function ns() {
}
function Rh(e, t) {
  return e != e ? t == t : e !== t || e && typeof e == "object" || typeof e == "function";
}
function Uh(e, ...t) {
  if (e == null)
    return ns;
  const A = e.subscribe(...t);
  return A.unsubscribe ? () => A.unsubscribe() : A;
}
function Gh(e) {
  let t;
  return Uh(e, (A) => t = A)(), t;
}
const Mh = [
  "allowfullscreen",
  "allowpaymentrequest",
  "async",
  "autofocus",
  "autoplay",
  "checked",
  "controls",
  "default",
  "defer",
  "disabled",
  "formnovalidate",
  "hidden",
  "inert",
  "ismap",
  "loop",
  "multiple",
  "muted",
  "nomodule",
  "novalidate",
  "open",
  "playsinline",
  "readonly",
  "required",
  "reversed",
  "selected"
];
[...Mh];
const Ze = [];
function gg(e, t) {
  return {
    subscribe: Lh(e, t).subscribe
  };
}
function Lh(e, t = ns) {
  let A;
  const i = /* @__PURE__ */ new Set();
  function s(n) {
    if (Rh(e, n) && (e = n, A)) {
      const l = !Ze.length;
      for (const a of i)
        a[1](), Ze.push(a, e);
      if (l) {
        for (let a = 0; a < Ze.length; a += 2)
          Ze[a][0](Ze[a + 1]);
        Ze.length = 0;
      }
    }
  }
  function o(n) {
    s(n(e));
  }
  function r(n, l = ns) {
    const a = [n, l];
    return i.add(a), i.size === 1 && (A = t(s) || ns), n(e), () => {
      i.delete(a), i.size === 0 && A && (A(), A = null);
    };
  }
  return { set: s, update: o, subscribe: r };
}
function Jh() {
  this.__data__ = [], this.size = 0;
}
function cg(e, t) {
  return e === t || e !== e && t !== t;
}
function Zs(e, t) {
  for (var A = e.length; A--; )
    if (cg(e[A][0], t))
      return A;
  return -1;
}
var Yh = Array.prototype, Hh = Yh.splice;
function _h(e) {
  var t = this.__data__, A = Zs(t, e);
  if (A < 0)
    return !1;
  var i = t.length - 1;
  return A == i ? t.pop() : Hh.call(t, A, 1), --this.size, !0;
}
function Th(e) {
  var t = this.__data__, A = Zs(t, e);
  return A < 0 ? void 0 : t[A][1];
}
function Oh(e) {
  return Zs(this.__data__, e) > -1;
}
function $h(e, t) {
  var A = this.__data__, i = Zs(A, e);
  return i < 0 ? (++this.size, A.push([e, t])) : A[i][1] = t, this;
}
function le(e) {
  var t = -1, A = e == null ? 0 : e.length;
  for (this.clear(); ++t < A; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
le.prototype.clear = Jh;
le.prototype.delete = _h;
le.prototype.get = Th;
le.prototype.has = Oh;
le.prototype.set = $h;
function Ph() {
  this.__data__ = new le(), this.size = 0;
}
function qh(e) {
  var t = this.__data__, A = t.delete(e);
  return this.size = t.size, A;
}
function Vh(e) {
  return this.__data__.get(e);
}
function zh(e) {
  return this.__data__.has(e);
}
var Kh = typeof global == "object" && global && global.Object === Object && global;
const hg = Kh;
var jh = typeof self == "object" && self && self.Object === Object && self, Zh = hg || jh || Function("return this")();
const ge = Zh;
var Wh = ge.Symbol;
const EA = Wh;
var Ig = Object.prototype, Xh = Ig.hasOwnProperty, tI = Ig.toString, PA = EA ? EA.toStringTag : void 0;
function eI(e) {
  var t = Xh.call(e, PA), A = e[PA];
  try {
    e[PA] = void 0;
    var i = !0;
  } catch {
  }
  var s = tI.call(e);
  return i && (t ? e[PA] = A : delete e[PA]), s;
}
var AI = Object.prototype, iI = AI.toString;
function sI(e) {
  return iI.call(e);
}
var oI = "[object Null]", rI = "[object Undefined]", ia = EA ? EA.toStringTag : void 0;
function Li(e) {
  return e == null ? e === void 0 ? rI : oI : ia && ia in Object(e) ? eI(e) : sI(e);
}
function ug(e) {
  var t = typeof e;
  return e != null && (t == "object" || t == "function");
}
var nI = "[object AsyncFunction]", aI = "[object Function]", lI = "[object GeneratorFunction]", gI = "[object Proxy]";
function dg(e) {
  if (!ug(e))
    return !1;
  var t = Li(e);
  return t == aI || t == lI || t == nI || t == gI;
}
var cI = ge["__core-js_shared__"];
const xo = cI;
var sa = function() {
  var e = /[^.]+$/.exec(xo && xo.keys && xo.keys.IE_PROTO || "");
  return e ? "Symbol(src)_1." + e : "";
}();
function hI(e) {
  return !!sa && sa in e;
}
var II = Function.prototype, uI = II.toString;
function Ve(e) {
  if (e != null) {
    try {
      return uI.call(e);
    } catch {
    }
    try {
      return e + "";
    } catch {
    }
  }
  return "";
}
var dI = /[\\^$.*+?()[\]{}|]/g, CI = /^\[object .+?Constructor\]$/, BI = Function.prototype, QI = Object.prototype, EI = BI.toString, fI = QI.hasOwnProperty, pI = RegExp(
  "^" + EI.call(fI).replace(dI, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function wI(e) {
  if (!ug(e) || hI(e))
    return !1;
  var t = dg(e) ? pI : CI;
  return t.test(Ve(e));
}
function yI(e, t) {
  return e?.[t];
}
function SA(e, t) {
  var A = yI(e, t);
  return wI(A) ? A : void 0;
}
var vI = SA(ge, "Map");
const Qi = vI;
var mI = SA(Object, "create");
const Ei = mI;
function bI() {
  this.__data__ = Ei ? Ei(null) : {}, this.size = 0;
}
function DI(e) {
  var t = this.has(e) && delete this.__data__[e];
  return this.size -= t ? 1 : 0, t;
}
var kI = "__lodash_hash_undefined__", SI = Object.prototype, xI = SI.hasOwnProperty;
function NI(e) {
  var t = this.__data__;
  if (Ei) {
    var A = t[e];
    return A === kI ? void 0 : A;
  }
  return xI.call(t, e) ? t[e] : void 0;
}
var FI = Object.prototype, RI = FI.hasOwnProperty;
function UI(e) {
  var t = this.__data__;
  return Ei ? t[e] !== void 0 : RI.call(t, e);
}
var GI = "__lodash_hash_undefined__";
function MI(e, t) {
  var A = this.__data__;
  return this.size += this.has(e) ? 0 : 1, A[e] = Ei && t === void 0 ? GI : t, this;
}
function _e(e) {
  var t = -1, A = e == null ? 0 : e.length;
  for (this.clear(); ++t < A; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
_e.prototype.clear = bI;
_e.prototype.delete = DI;
_e.prototype.get = NI;
_e.prototype.has = UI;
_e.prototype.set = MI;
function LI() {
  this.size = 0, this.__data__ = {
    hash: new _e(),
    map: new (Qi || le)(),
    string: new _e()
  };
}
function JI(e) {
  var t = typeof e;
  return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null;
}
function Ws(e, t) {
  var A = e.__data__;
  return JI(t) ? A[typeof t == "string" ? "string" : "hash"] : A.map;
}
function YI(e) {
  var t = Ws(this, e).delete(e);
  return this.size -= t ? 1 : 0, t;
}
function HI(e) {
  return Ws(this, e).get(e);
}
function _I(e) {
  return Ws(this, e).has(e);
}
function TI(e, t) {
  var A = Ws(this, e), i = A.size;
  return A.set(e, t), this.size += A.size == i ? 0 : 1, this;
}
function ze(e) {
  var t = -1, A = e == null ? 0 : e.length;
  for (this.clear(); ++t < A; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
ze.prototype.clear = LI;
ze.prototype.delete = YI;
ze.prototype.get = HI;
ze.prototype.has = _I;
ze.prototype.set = TI;
var OI = 200;
function $I(e, t) {
  var A = this.__data__;
  if (A instanceof le) {
    var i = A.__data__;
    if (!Qi || i.length < OI - 1)
      return i.push([e, t]), this.size = ++A.size, this;
    A = this.__data__ = new ze(i);
  }
  return A.set(e, t), this.size = A.size, this;
}
function Be(e) {
  var t = this.__data__ = new le(e);
  this.size = t.size;
}
Be.prototype.clear = Ph;
Be.prototype.delete = qh;
Be.prototype.get = Vh;
Be.prototype.has = zh;
Be.prototype.set = $I;
var PI = "__lodash_hash_undefined__";
function qI(e) {
  return this.__data__.set(e, PI), this;
}
function VI(e) {
  return this.__data__.has(e);
}
function ps(e) {
  var t = -1, A = e == null ? 0 : e.length;
  for (this.__data__ = new ze(); ++t < A; )
    this.add(e[t]);
}
ps.prototype.add = ps.prototype.push = qI;
ps.prototype.has = VI;
function zI(e, t) {
  for (var A = -1, i = e == null ? 0 : e.length; ++A < i; )
    if (t(e[A], A, e))
      return !0;
  return !1;
}
function KI(e, t) {
  return e.has(t);
}
var jI = 1, ZI = 2;
function Cg(e, t, A, i, s, o) {
  var r = A & jI, n = e.length, l = t.length;
  if (n != l && !(r && l > n))
    return !1;
  var a = o.get(e), c = o.get(t);
  if (a && c)
    return a == t && c == e;
  var g = -1, h = !0, u = A & ZI ? new ps() : void 0;
  for (o.set(e, t), o.set(t, e); ++g < n; ) {
    var C = e[g], B = t[g];
    if (i)
      var E = r ? i(B, C, g, t, e, o) : i(C, B, g, e, t, o);
    if (E !== void 0) {
      if (E)
        continue;
      h = !1;
      break;
    }
    if (u) {
      if (!zI(t, function(f, p) {
        if (!KI(u, p) && (C === f || s(C, f, A, i, o)))
          return u.push(p);
      })) {
        h = !1;
        break;
      }
    } else if (!(C === B || s(C, B, A, i, o))) {
      h = !1;
      break;
    }
  }
  return o.delete(e), o.delete(t), h;
}
var WI = ge.Uint8Array;
const oa = WI;
function XI(e) {
  var t = -1, A = Array(e.size);
  return e.forEach(function(i, s) {
    A[++t] = [s, i];
  }), A;
}
function tu(e) {
  var t = -1, A = Array(e.size);
  return e.forEach(function(i) {
    A[++t] = i;
  }), A;
}
var eu = 1, Au = 2, iu = "[object Boolean]", su = "[object Date]", ou = "[object Error]", ru = "[object Map]", nu = "[object Number]", au = "[object RegExp]", lu = "[object Set]", gu = "[object String]", cu = "[object Symbol]", hu = "[object ArrayBuffer]", Iu = "[object DataView]", ra = EA ? EA.prototype : void 0, No = ra ? ra.valueOf : void 0;
function uu(e, t, A, i, s, o, r) {
  switch (A) {
    case Iu:
      if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset)
        return !1;
      e = e.buffer, t = t.buffer;
    case hu:
      return !(e.byteLength != t.byteLength || !o(new oa(e), new oa(t)));
    case iu:
    case su:
    case nu:
      return cg(+e, +t);
    case ou:
      return e.name == t.name && e.message == t.message;
    case au:
    case gu:
      return e == t + "";
    case ru:
      var n = XI;
    case lu:
      var l = i & eu;
      if (n || (n = tu), e.size != t.size && !l)
        return !1;
      var a = r.get(e);
      if (a)
        return a == t;
      i |= Au, r.set(e, t);
      var c = Cg(n(e), n(t), i, s, o, r);
      return r.delete(e), c;
    case cu:
      if (No)
        return No.call(e) == No.call(t);
  }
  return !1;
}
function du(e, t) {
  for (var A = -1, i = t.length, s = e.length; ++A < i; )
    e[s + A] = t[A];
  return e;
}
var Cu = Array.isArray;
const ws = Cu;
function Bu(e, t, A) {
  var i = t(e);
  return ws(e) ? i : du(i, A(e));
}
function Qu(e, t) {
  for (var A = -1, i = e == null ? 0 : e.length, s = 0, o = []; ++A < i; ) {
    var r = e[A];
    t(r, A, e) && (o[s++] = r);
  }
  return o;
}
function Eu() {
  return [];
}
var fu = Object.prototype, pu = fu.propertyIsEnumerable, na = Object.getOwnPropertySymbols, wu = na ? function(e) {
  return e == null ? [] : (e = Object(e), Qu(na(e), function(t) {
    return pu.call(e, t);
  }));
} : Eu;
const yu = wu;
function vu(e, t) {
  for (var A = -1, i = Array(e); ++A < e; )
    i[A] = t(A);
  return i;
}
function fi(e) {
  return e != null && typeof e == "object";
}
var mu = "[object Arguments]";
function aa(e) {
  return fi(e) && Li(e) == mu;
}
var Bg = Object.prototype, bu = Bg.hasOwnProperty, Du = Bg.propertyIsEnumerable, ku = aa(function() {
  return arguments;
}()) ? aa : function(e) {
  return fi(e) && bu.call(e, "callee") && !Du.call(e, "callee");
};
const Su = ku;
function xu() {
  return !1;
}
var Qg = typeof exports == "object" && exports && !exports.nodeType && exports, la = Qg && typeof module == "object" && module && !module.nodeType && module, Nu = la && la.exports === Qg, ga = Nu ? ge.Buffer : void 0, Fu = ga ? ga.isBuffer : void 0, Ru = Fu || xu;
const Er = Ru;
var Uu = 9007199254740991, Gu = /^(?:0|[1-9]\d*)$/;
function Mu(e, t) {
  var A = typeof e;
  return t = t ?? Uu, !!t && (A == "number" || A != "symbol" && Gu.test(e)) && e > -1 && e % 1 == 0 && e < t;
}
var Lu = 9007199254740991;
function Eg(e) {
  return typeof e == "number" && e > -1 && e % 1 == 0 && e <= Lu;
}
var Ju = "[object Arguments]", Yu = "[object Array]", Hu = "[object Boolean]", _u = "[object Date]", Tu = "[object Error]", Ou = "[object Function]", $u = "[object Map]", Pu = "[object Number]", qu = "[object Object]", Vu = "[object RegExp]", zu = "[object Set]", Ku = "[object String]", ju = "[object WeakMap]", Zu = "[object ArrayBuffer]", Wu = "[object DataView]", Xu = "[object Float32Array]", td = "[object Float64Array]", ed = "[object Int8Array]", Ad = "[object Int16Array]", id = "[object Int32Array]", sd = "[object Uint8Array]", od = "[object Uint8ClampedArray]", rd = "[object Uint16Array]", nd = "[object Uint32Array]", J = {};
J[Xu] = J[td] = J[ed] = J[Ad] = J[id] = J[sd] = J[od] = J[rd] = J[nd] = !0;
J[Ju] = J[Yu] = J[Zu] = J[Hu] = J[Wu] = J[_u] = J[Tu] = J[Ou] = J[$u] = J[Pu] = J[qu] = J[Vu] = J[zu] = J[Ku] = J[ju] = !1;
function ad(e) {
  return fi(e) && Eg(e.length) && !!J[Li(e)];
}
function ld(e) {
  return function(t) {
    return e(t);
  };
}
var fg = typeof exports == "object" && exports && !exports.nodeType && exports, ni = fg && typeof module == "object" && module && !module.nodeType && module, gd = ni && ni.exports === fg, Fo = gd && hg.process, cd = function() {
  try {
    var e = ni && ni.require && ni.require("util").types;
    return e || Fo && Fo.binding && Fo.binding("util");
  } catch {
  }
}();
const ca = cd;
var ha = ca && ca.isTypedArray, hd = ha ? ld(ha) : ad;
const pg = hd;
var Id = Object.prototype, ud = Id.hasOwnProperty;
function dd(e, t) {
  var A = ws(e), i = !A && Su(e), s = !A && !i && Er(e), o = !A && !i && !s && pg(e), r = A || i || s || o, n = r ? vu(e.length, String) : [], l = n.length;
  for (var a in e)
    (t || ud.call(e, a)) && !(r && // Safari 9 has enumerable `arguments.length` in strict mode.
    (a == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    s && (a == "offset" || a == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    o && (a == "buffer" || a == "byteLength" || a == "byteOffset") || // Skip index properties.
    Mu(a, l))) && n.push(a);
  return n;
}
var Cd = Object.prototype;
function Bd(e) {
  var t = e && e.constructor, A = typeof t == "function" && t.prototype || Cd;
  return e === A;
}
function Qd(e, t) {
  return function(A) {
    return e(t(A));
  };
}
var Ed = Qd(Object.keys, Object);
const fd = Ed;
var pd = Object.prototype, wd = pd.hasOwnProperty;
function yd(e) {
  if (!Bd(e))
    return fd(e);
  var t = [];
  for (var A in Object(e))
    wd.call(e, A) && A != "constructor" && t.push(A);
  return t;
}
function vd(e) {
  return e != null && Eg(e.length) && !dg(e);
}
function md(e) {
  return vd(e) ? dd(e) : yd(e);
}
function Ia(e) {
  return Bu(e, md, yu);
}
var bd = 1, Dd = Object.prototype, kd = Dd.hasOwnProperty;
function Sd(e, t, A, i, s, o) {
  var r = A & bd, n = Ia(e), l = n.length, a = Ia(t), c = a.length;
  if (l != c && !r)
    return !1;
  for (var g = l; g--; ) {
    var h = n[g];
    if (!(r ? h in t : kd.call(t, h)))
      return !1;
  }
  var u = o.get(e), C = o.get(t);
  if (u && C)
    return u == t && C == e;
  var B = !0;
  o.set(e, t), o.set(t, e);
  for (var E = r; ++g < l; ) {
    h = n[g];
    var f = e[h], p = t[h];
    if (i)
      var D = r ? i(p, f, h, t, e, o) : i(f, p, h, e, t, o);
    if (!(D === void 0 ? f === p || s(f, p, A, i, o) : D)) {
      B = !1;
      break;
    }
    E || (E = h == "constructor");
  }
  if (B && !E) {
    var N = e.constructor, M = t.constructor;
    N != M && "constructor" in e && "constructor" in t && !(typeof N == "function" && N instanceof N && typeof M == "function" && M instanceof M) && (B = !1);
  }
  return o.delete(e), o.delete(t), B;
}
var xd = SA(ge, "DataView");
const fr = xd;
var Nd = SA(ge, "Promise");
const pr = Nd;
var Fd = SA(ge, "Set");
const wr = Fd;
var Rd = SA(ge, "WeakMap");
const yr = Rd;
var ua = "[object Map]", Ud = "[object Object]", da = "[object Promise]", Ca = "[object Set]", Ba = "[object WeakMap]", Qa = "[object DataView]", Gd = Ve(fr), Md = Ve(Qi), Ld = Ve(pr), Jd = Ve(wr), Yd = Ve(yr), Ue = Li;
(fr && Ue(new fr(new ArrayBuffer(1))) != Qa || Qi && Ue(new Qi()) != ua || pr && Ue(pr.resolve()) != da || wr && Ue(new wr()) != Ca || yr && Ue(new yr()) != Ba) && (Ue = function(e) {
  var t = Li(e), A = t == Ud ? e.constructor : void 0, i = A ? Ve(A) : "";
  if (i)
    switch (i) {
      case Gd:
        return Qa;
      case Md:
        return ua;
      case Ld:
        return da;
      case Jd:
        return Ca;
      case Yd:
        return Ba;
    }
  return t;
});
const Ea = Ue;
var Hd = 1, fa = "[object Arguments]", pa = "[object Array]", Oi = "[object Object]", _d = Object.prototype, wa = _d.hasOwnProperty;
function Td(e, t, A, i, s, o) {
  var r = ws(e), n = ws(t), l = r ? pa : Ea(e), a = n ? pa : Ea(t);
  l = l == fa ? Oi : l, a = a == fa ? Oi : a;
  var c = l == Oi, g = a == Oi, h = l == a;
  if (h && Er(e)) {
    if (!Er(t))
      return !1;
    r = !0, c = !1;
  }
  if (h && !c)
    return o || (o = new Be()), r || pg(e) ? Cg(e, t, A, i, s, o) : uu(e, t, l, A, i, s, o);
  if (!(A & Hd)) {
    var u = c && wa.call(e, "__wrapped__"), C = g && wa.call(t, "__wrapped__");
    if (u || C) {
      var B = u ? e.value() : e, E = C ? t.value() : t;
      return o || (o = new Be()), s(B, E, A, i, o);
    }
  }
  return h ? (o || (o = new Be()), Sd(e, t, A, i, s, o)) : !1;
}
function wg(e, t, A, i, s) {
  return e === t ? !0 : e == null || t == null || !fi(e) && !fi(t) ? e !== e && t !== t : Td(e, t, A, i, wg, s);
}
function yg(e, t) {
  return wg(e, t);
}
class Ke {
  constructor(t, A, i) {
    this.host = t, this.getStore = A, this.resubscribeIfChanged = i, t.addController(this);
  }
  hostUpdate() {
    const t = this.store();
    this.shouldResubscribe(t) && (this.unsubscribe(), t && (this._unsubscribe = t.subscribe((A) => {
      this.value = A, this.host.requestUpdate();
    })), this._previousStore = t);
  }
  hostDisconnected() {
    this.unsubscribe();
  }
  unsubscribe() {
    this._unsubscribe && (this._unsubscribe(), this._unsubscribe = void 0);
  }
  shouldResubscribe(t) {
    if (this.resubscribeIfChanged) {
      const A = this.resubscribeIfChanged(), i = this._previousArgs;
      return this._previousArgs = A, !yg(A, i);
    } else
      return !(t === this._previousStore || t && this._previousStore && Gh(t) === this.value);
  }
  store() {
    return this.getStore();
  }
}
const vg = new Array(32).fill(void 0);
vg.push(void 0, null, !0, !1);
vg.length;
const Ro = new TextEncoder("utf-8");
Ro.encodeInto;
const Od = new TextDecoder("utf-8", { ignoreBOM: !0, fatal: !0 });
Od.decode();
const $d = [62, 0, 0, 0, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 0, 0, 0, 0, 0, 0, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51];
function $i(e) {
  return $d[e - 43];
}
function Pd(e) {
  let t = e.endsWith("==") ? 2 : e.endsWith("=") ? 1 : 0, A = e.length, i = new Uint8Array(3 * (A / 4)), s;
  for (let o = 0, r = 0; o < A; o += 4, r += 3)
    s = $i(e.charCodeAt(o)) << 18 | $i(e.charCodeAt(o + 1)) << 12 | $i(e.charCodeAt(o + 2)) << 6 | $i(e.charCodeAt(o + 3)), i[r] = s >> 16, i[r + 1] = s >> 8 & 255, i[r + 2] = s & 255;
  return i.subarray(0, i.length - t);
}
Pd("AGFzbQEAAAABrAEYYAJ/fwF/YAN/f38Bf2ABfwF/YAJ/fwBgAX8AYAN/f38AYAABf2AFf39/f38AYAR/f39/AGAAAGABfwF+YAZ/f39/f38AYAR/f39/AX9gBX9/f39/AX9gBn9/f39/fwF/YAl/f39/f39+fn4AYAd/f39/f39/AX9gA35/fwF/YAV/f35/fwBgBH9+f38AYAV/f3x/fwBgBH98f38AYAV/f31/fwBgBH99f38AArAJJAN3YmcaX193YmluZGdlbl9vYmplY3RfZHJvcF9yZWYABAN3YmcVX193YmluZGdlbl9zdHJpbmdfZ2V0AAMDd2JnFF9fd2JpbmRnZW5faXNfb2JqZWN0AAIDd2JnFF9fd2JpbmRnZW5fZXJyb3JfbmV3AAADd2JnEl9fd2JpbmRnZW5faXNfbnVsbAACA3diZxdfX3diaW5kZ2VuX2lzX3VuZGVmaW5lZAACA3diZxZfX3diaW5kZ2VuX2Jvb2xlYW5fZ2V0AAIDd2JnFV9fd2JpbmRnZW5fbnVtYmVyX2dldAADA3diZx1fX3diZ19TdHJpbmdfOWFhMTdkNjI0OGQ1MTlhNQADA3diZxpfX3diZ19nZXRfNzIzZjgzYmEwYzM0ODcxYQAAA3diZxtfX3diaW5kZ2VuX29iamVjdF9jbG9uZV9yZWYAAgN3YmcWX193YmluZGdlbl9pc19mdW5jdGlvbgACA3diZxtfX3diZ19uZXh0XzU3OWU1ODNkMzM1NjZhODYAAgN3YmcbX193YmdfbmV4dF9hYWVmN2M4YWE1ZTIxMmFjAAIDd2JnG19fd2JnX2RvbmVfMWI3M2IwNjcyZTE1ZjIzNAACA3diZxxfX3diZ192YWx1ZV8xY2NjMzZiYzAzNDYyZDcxAAIDd2JnH19fd2JnX2l0ZXJhdG9yXzZmOWQ0ZjI4ODQ1ZjQyNmMABgN3YmcaX193YmdfZ2V0Xzc2NTIwMTU0NGEyYjY4NjkAAAN3YmcbX193YmdfY2FsbF85N2FlOWQ4NjQ1ZGMzODhiAAADd2JnFV9fd2JpbmRnZW5fc3RyaW5nX25ldwAAA3diZx5fX3diZ19pc0FycmF5XzI3YzQ2YzY3ZjQ5OGUxNWQAAgN3YmctX193YmdfaW5zdGFuY2VvZl9BcnJheUJ1ZmZlcl9lNWU0OGY0NzYyYzU2MTBiAAIDd2JnHV9fd2JnX3ZhbHVlc19lNDI2NzFhY2JmMTFlYzA0AAIDd2JnGl9fd2JnX25ld184ZDJhZjAwYmMxZTMyOWVlAAADd2JnJF9fd2JnX2lzU2FmZUludGVnZXJfZGZhMDU5M2U4ZDdhYzM1YQACA3diZx1fX3diZ19idWZmZXJfM2YzZDc2NGQ0NzQ3ZDU2NAACA3diZxpfX3diZ19uZXdfOGMzZjAwNTIyNzJhNDU3YQACA3diZxpfX3diZ19zZXRfODNkYjk2OTBmOTM1M2U3OQAFA3diZx1fX3diZ19sZW5ndGhfOWUxYWUxOTAwY2IwZmJkNQACA3diZyxfX3diZ19pbnN0YW5jZW9mX1VpbnQ4QXJyYXlfOTcxZWVkYTY5ZWI3NTAwMwACA3diZxpfX3diZ19uZXdfYWJkYTc2ZTg4M2JhOGE1ZgAGA3diZxxfX3diZ19zdGFja182NTgyNzlmZTQ0NTQxY2Y2AAMDd2JnHF9fd2JnX2Vycm9yX2Y4NTE2NjdhZjcxYmNmYzYAAwN3YmcXX193YmluZGdlbl9kZWJ1Z19zdHJpbmcAAwN3YmcQX193YmluZGdlbl90aHJvdwADA3diZxFfX3diaW5kZ2VuX21lbW9yeQAGA9IB0AECAAQBAAABAwUOCAEBAAMFAQMDAQAPCwALAhAAAAARAAEDBAAGAwIHAAACAgAFBQUDDAcICAMCAwsDAAMAAwIGBwABAAAFAAADBQAAAAADAAMAAAAAAAAAAAQJAQEBAQUDAA0JCQMCBAAAAAAAAwUFAwQEBAEFAA4DABIUBxYNAwQIAAECAAIDAAEAAAwAAwIAAAcAAAQAAAMCAAICAgICAgMCAAAFBQUAAwEAAAIAAAkAAAICAgIDAQABAQEAAAAAAAAAAAIGAAACAgMKCgoEBAcBcAGJAYkBBQMBABEGCQF/AUGAgMAACweSAQcGbWVtb3J5AgAMaGFzaFpvbWVDYWxsAFsRX193YmluZGdlbl9tYWxsb2MAigESX193YmluZGdlbl9yZWFsbG9jAJgBH19fd2JpbmRnZW5fYWRkX3RvX3N0YWNrX3BvaW50ZXIA0QEPX193YmluZGdlbl9mcmVlALIBFF9fd2JpbmRnZW5fZXhuX3N0b3JlALkBCfABAQBBAQuIAfMBugHiAdIB5QHkAecB4QHmAeMBtQEotwHMAaQBggFBdvMBrgGkAYIBQfMBUGCkAYIBQfMBmgHzAfMB8wHvAe8B7wGRAZEBgQFAbl7zAYEBQG+1AaQBggFBd/MBT/MBjwGsAaIBXKABogGbAacBpQGgAaABoQGfAZ4B8wGBAUBwpAGCAUF48wGxAZYB8wGNAfMBqQFlefMBqQHVAbcBpgHPAZ0BhQFHuwFy8wF/P3GOAdYBpAHxAfABlwFJWYQBvAHyAYsBkAHzAYABxwFzyAFntAG+AbUBamg78wHyAdABN016zgFMdd0BCquLBdAB3yECD38BfiMAQRBrIggkAAJAAkAgAEH1AU8EQEEIQQgQrwEhAkEUQQgQrwEhA0EQQQgQrwEhBUEAQRBBCBCvAUECdGsiBEGAgHwgBSACIANqamtBd3FBA2siAiACIARLGyAATQ0CIABBBGpBCBCvASEEQZTnwAAoAgBFDQFBACAEayEBAkACQAJ/QQAgBEGAAkkNABpBHyAEQf///wdLDQAaIARBBiAEQQh2ZyIAa3ZBAXEgAEEBdGtBPmoLIgdBAnRBoOnAAGooAgAiAARAIAQgBxCqAXQhBkEAIQNBACECA0ACQCAAENcBIgUgBEkNACAFIARrIgUgAU8NACAAIQIgBSIBDQBBACEBDAMLIABBFGooAgAiBSADIAUgACAGQR12QQRxakEQaigCACIARxsgAyAFGyEDIAZBAXQhBiAADQALIAMEQCADIQAMAgsgAg0CC0EAIQJBASAHdBCzAUGU58AAKAIAcSIARQ0DIAAQwwFoQQJ0QaDpwABqKAIAIgBFDQMLA0AgACACIAAQ1wEiAiAETyACIARrIgMgAUlxIgUbIQIgAyABIAUbIQEgABCoASIADQALIAJFDQILIARBoOrAACgCACIATSABIAAgBGtPcQ0BIAIgBBDrASEAIAIQRgJAQRBBCBCvASABTQRAIAIgBBDFASAAIAEQqwEgAUGAAk8EQCAAIAEQRQwCCyABQXhxQZjnwABqIQMCf0GQ58AAKAIAIgVBASABQQN2dCIBcQRAIAMoAggMAQtBkOfAACABIAVyNgIAIAMLIQEgAyAANgIIIAEgADYCDCAAIAM2AgwgACABNgIIDAELIAIgASAEahCjAQsgAhDtASIBRQ0BDAILQRAgAEEEakEQQQgQrwFBBWsgAEsbQQgQrwEhBAJAAkACQAJ/AkACQEGQ58AAKAIAIgUgBEEDdiIBdiIAQQNxRQRAIARBoOrAACgCAE0NByAADQFBlOfAACgCACIARQ0HIAAQwwFoQQJ0QaDpwABqKAIAIgIQ1wEgBGshASACEKgBIgAEQANAIAAQ1wEgBGsiAyABIAEgA0siAxshASAAIAIgAxshAiAAEKgBIgANAAsLIAIgBBDrASEFIAIQRkEQQQgQrwEgAUsNBSACIAQQxQEgBSABEKsBQaDqwAAoAgAiBkUNBCAGQXhxQZjnwABqIQBBqOrAACgCACEDQZDnwAAoAgAiB0EBIAZBA3Z0IgZxRQ0CIAAoAggMAwsCQCAAQX9zQQFxIAFqIgBBA3QiA0Gg58AAaigCACIBQQhqKAIAIgIgA0GY58AAaiIDRwRAIAIgAzYCDCADIAI2AggMAQtBkOfAACAFQX4gAHdxNgIACyABIABBA3QQowEgARDtASEBDAcLAkBBASABQR9xIgF0ELMBIAAgAXRxEMMBaCIAQQN0IgNBoOfAAGooAgAiAkEIaigCACIBIANBmOfAAGoiA0cEQCABIAM2AgwgAyABNgIIDAELQZDnwABBkOfAACgCAEF+IAB3cTYCAAsgAiAEEMUBIAIgBBDrASIFIABBA3QgBGsiBBCrAUGg6sAAKAIAIgMEQCADQXhxQZjnwABqIQBBqOrAACgCACEBAn9BkOfAACgCACIGQQEgA0EDdnQiA3EEQCAAKAIIDAELQZDnwAAgAyAGcjYCACAACyEDIAAgATYCCCADIAE2AgwgASAANgIMIAEgAzYCCAtBqOrAACAFNgIAQaDqwAAgBDYCACACEO0BIQEMBgtBkOfAACAGIAdyNgIAIAALIQYgACADNgIIIAYgAzYCDCADIAA2AgwgAyAGNgIIC0Go6sAAIAU2AgBBoOrAACABNgIADAELIAIgASAEahCjAQsgAhDtASIBDQELAkACQAJAAkACQAJAAkACQCAEQaDqwAAoAgAiAUsEQEGk6sAAKAIAIgAgBEsNAkEIQQgQrwEgBGpBFEEIEK8BakEQQQgQrwFqQYCABBCvASIBQRB2QAAhACAIQQA2AgggCEEAIAFBgIB8cSAAQX9GIgEbNgIEIAhBACAAQRB0IAEbNgIAIAgoAgAiAQ0BQQAhAQwJC0Go6sAAKAIAIQBBEEEIEK8BIAEgBGsiAUsEQEGo6sAAQQA2AgBBoOrAACgCACEBQaDqwABBADYCACAAIAEQowEgABDtASEBDAkLIAAgBBDrASECQaDqwAAgATYCAEGo6sAAIAI2AgAgAiABEKsBIAAgBBDFASAAEO0BIQEMCAsgCCgCCCEFQbDqwAAgCCgCBCIDQbDqwAAoAgBqIgA2AgBBtOrAAEG06sAAKAIAIgIgACAAIAJJGzYCAAJAAkBBrOrAACgCAARAQbjqwAAhAANAIAAQxgEgAUYNAiAAKAIIIgANAAsMAgtBzOrAACgCACIARSAAIAFLcg0DDAcLIAAQ2QENACAAENoBIAVHDQAgACgCACICQazqwAAoAgAiBk0EfyACIAAoAgRqIAZLBUEACw0DC0HM6sAAQczqwAAoAgAiACABIAAgAUkbNgIAIAEgA2ohAkG46sAAIQACQAJAA0AgAiAAKAIARwRAIAAoAggiAA0BDAILCyAAENkBDQAgABDaASAFRg0BC0Gs6sAAKAIAIQJBuOrAACEAAkADQCACIAAoAgBPBEAgABDGASACSw0CCyAAKAIIIgANAAtBACEACyACIAAQxgEiD0EUQQgQrwEiDmtBF2siABDtASIGQQgQrwEgBmsgAGoiACAAQRBBCBCvASACakkbIgYQ7QEhByAGIA4Q6wEhAEEIQQgQrwEhCUEUQQgQrwEhC0EQQQgQrwEhDEGs6sAAIAEgARDtASIKQQgQrwEgCmsiDRDrASIKNgIAQaTqwAAgA0EIaiAMIAkgC2pqIA1qayIJNgIAIAogCUEBcjYCBEEIQQgQrwEhC0EUQQgQrwEhDEEQQQgQrwEhDSAKIAkQ6wEgDSAMIAtBCGtqajYCBEHI6sAAQYCAgAE2AgAgBiAOEMUBQbjqwAApAgAhECAHQQhqQcDqwAApAgA3AgAgByAQNwIAQcTqwAAgBTYCAEG86sAAIAM2AgBBuOrAACABNgIAQcDqwAAgBzYCAANAIABBBBDrASAAQQc2AgQiAEEEaiAPSQ0ACyACIAZGDQcgAiAGIAJrIgAgAiAAEOsBEJkBIABBgAJPBEAgAiAAEEUMCAsgAEF4cUGY58AAaiEBAn9BkOfAACgCACIDQQEgAEEDdnQiAHEEQCABKAIIDAELQZDnwAAgACADcjYCACABCyEAIAEgAjYCCCAAIAI2AgwgAiABNgIMIAIgADYCCAwHCyAAKAIAIQUgACABNgIAIAAgACgCBCADajYCBCABEO0BIgBBCBCvASECIAUQ7QEiA0EIEK8BIQYgASACIABraiICIAQQ6wEhASACIAQQxQEgBSAGIANraiIAIAIgBGprIQRBrOrAACgCACAARwRAIABBqOrAACgCAEYNBCAAKAIEQQNxQQFHDQUCQCAAENcBIgNBgAJPBEAgABBGDAELIABBDGooAgAiBSAAQQhqKAIAIgZHBEAgBiAFNgIMIAUgBjYCCAwBC0GQ58AAQZDnwAAoAgBBfiADQQN2d3E2AgALIAMgBGohBCAAIAMQ6wEhAAwFC0Gs6sAAIAE2AgBBpOrAAEGk6sAAKAIAIARqIgA2AgAgASAAQQFyNgIEIAIQ7QEhAQwHC0Gk6sAAIAAgBGsiATYCAEGs6sAAQazqwAAoAgAiACAEEOsBIgI2AgAgAiABQQFyNgIEIAAgBBDFASAAEO0BIQEMBgtBzOrAACABNgIADAMLIAAgACgCBCADajYCBEGk6sAAKAIAIANqIQFBrOrAACgCACIAIAAQ7QEiAEEIEK8BIABrIgIQ6wEhAEGk6sAAIAEgAmsiATYCAEGs6sAAIAA2AgAgACABQQFyNgIEQQhBCBCvASECQRRBCBCvASEDQRBBCBCvASEFIAAgARDrASAFIAMgAkEIa2pqNgIEQcjqwABBgICAATYCAAwDC0Go6sAAIAE2AgBBoOrAAEGg6sAAKAIAIARqIgA2AgAgASAAEKsBIAIQ7QEhAQwDCyABIAQgABCZASAEQYACTwRAIAEgBBBFIAIQ7QEhAQwDCyAEQXhxQZjnwABqIQACf0GQ58AAKAIAIgNBASAEQQN2dCIFcQRAIAAoAggMAQtBkOfAACADIAVyNgIAIAALIQMgACABNgIIIAMgATYCDCABIAA2AgwgASADNgIIIAIQ7QEhAQwCC0HQ6sAAQf8fNgIAQcTqwAAgBTYCAEG86sAAIAM2AgBBuOrAACABNgIAQaTnwABBmOfAADYCAEGs58AAQaDnwAA2AgBBoOfAAEGY58AANgIAQbTnwABBqOfAADYCAEGo58AAQaDnwAA2AgBBvOfAAEGw58AANgIAQbDnwABBqOfAADYCAEHE58AAQbjnwAA2AgBBuOfAAEGw58AANgIAQcznwABBwOfAADYCAEHA58AAQbjnwAA2AgBB1OfAAEHI58AANgIAQcjnwABBwOfAADYCAEHc58AAQdDnwAA2AgBB0OfAAEHI58AANgIAQeTnwABB2OfAADYCAEHY58AAQdDnwAA2AgBB4OfAAEHY58AANgIAQeznwABB4OfAADYCAEHo58AAQeDnwAA2AgBB9OfAAEHo58AANgIAQfDnwABB6OfAADYCAEH858AAQfDnwAA2AgBB+OfAAEHw58AANgIAQYTowABB+OfAADYCAEGA6MAAQfjnwAA2AgBBjOjAAEGA6MAANgIAQYjowABBgOjAADYCAEGU6MAAQYjowAA2AgBBkOjAAEGI6MAANgIAQZzowABBkOjAADYCAEGY6MAAQZDowAA2AgBBpOjAAEGY6MAANgIAQazowABBoOjAADYCAEGg6MAAQZjowAA2AgBBtOjAAEGo6MAANgIAQajowABBoOjAADYCAEG86MAAQbDowAA2AgBBsOjAAEGo6MAANgIAQcTowABBuOjAADYCAEG46MAAQbDowAA2AgBBzOjAAEHA6MAANgIAQcDowABBuOjAADYCAEHU6MAAQcjowAA2AgBByOjAAEHA6MAANgIAQdzowABB0OjAADYCAEHQ6MAAQcjowAA2AgBB5OjAAEHY6MAANgIAQdjowABB0OjAADYCAEHs6MAAQeDowAA2AgBB4OjAAEHY6MAANgIAQfTowABB6OjAADYCAEHo6MAAQeDowAA2AgBB/OjAAEHw6MAANgIAQfDowABB6OjAADYCAEGE6cAAQfjowAA2AgBB+OjAAEHw6MAANgIAQYzpwABBgOnAADYCAEGA6cAAQfjowAA2AgBBlOnAAEGI6cAANgIAQYjpwABBgOnAADYCAEGc6cAAQZDpwAA2AgBBkOnAAEGI6cAANgIAQZjpwABBkOnAADYCAEEIQQgQrwEhAkEUQQgQrwEhBUEQQQgQrwEhBkGs6sAAIAEgARDtASIAQQgQrwEgAGsiARDrASIANgIAQaTqwAAgA0EIaiAGIAIgBWpqIAFqayIBNgIAIAAgAUEBcjYCBEEIQQgQrwEhAkEUQQgQrwEhA0EQQQgQrwEhBSAAIAEQ6wEgBSADIAJBCGtqajYCBEHI6sAAQYCAgAE2AgALQQAhAUGk6sAAKAIAIgAgBE0NAEGk6sAAIAAgBGsiATYCAEGs6sAAQazqwAAoAgAiACAEEOsBIgI2AgAgAiABQQFyNgIEIAAgBBDFASAAEO0BIQELIAhBEGokACABC5wJAQd/AkAgAUH/CU0EQCABQQV2IQUCQAJAAkAgACgCACIEBEAgACAEQQJ0aiECIAAgBCAFakECdGohBiAEQQFrIgNBJ0shBANAIAQNBCADIAVqIgdBKE8NAiAGIAIoAgA2AgAgBkEEayEGIAJBBGshAiADQQFrIgNBf0cNAAsLIAFBIEkNBCAAQQA2AgQgAUHAAE8NAQwECyAHQShBtN7AABBpAAsgAEEIakEANgIAIAVBASAFQQFLGyICQQJGDQIgAEEMakEANgIAIAJBA0YNAiAAQRBqQQA2AgAgAkEERg0CIABBFGpBADYCACACQQVGDQIgAEEYakEANgIAIAJBBkYNAiAAQRxqQQA2AgAgAkEHRg0CIABBIGpBADYCACACQQhGDQIgAEEkakEANgIAIAJBCUYNAiAAQShqQQA2AgAgAkEKRg0CIABBLGpBADYCACACQQtGDQIgAEEwakEANgIAIAJBDEYNAiAAQTRqQQA2AgAgAkENRg0CIABBOGpBADYCACACQQ5GDQIgAEE8akEANgIAIAJBD0YNAiAAQUBrQQA2AgAgAkEQRg0CIABBxABqQQA2AgAgAkERRg0CIABByABqQQA2AgAgAkESRg0CIABBzABqQQA2AgAgAkETRg0CIABB0ABqQQA2AgAgAkEURg0CIABB1ABqQQA2AgAgAkEVRg0CIABB2ABqQQA2AgAgAkEWRg0CIABB3ABqQQA2AgAgAkEXRg0CIABB4ABqQQA2AgAgAkEYRg0CIABB5ABqQQA2AgAgAkEZRg0CIABB6ABqQQA2AgAgAkEaRg0CIABB7ABqQQA2AgAgAkEbRg0CIABB8ABqQQA2AgAgAkEcRg0CIABB9ABqQQA2AgAgAkEdRg0CIABB+ABqQQA2AgAgAkEeRg0CIABB/ABqQQA2AgAgAkEfRg0CIABBgAFqQQA2AgAgAkEgRg0CIABBhAFqQQA2AgAgAkEhRg0CIABBiAFqQQA2AgAgAkEiRg0CIABBjAFqQQA2AgAgAkEjRg0CIABBkAFqQQA2AgAgAkEkRg0CIABBlAFqQQA2AgAgAkElRg0CIABBmAFqQQA2AgAgAkEmRg0CIABBnAFqQQA2AgAgAkEnRg0CIABBoAFqQQA2AgAgAkEoRg0CQShBKEG03sAAEGkACyADQShBtN7AABBpAAtB3t7AAEEdQbTewAAQgwEACyAAKAIAIAVqIQIgAUEfcSIHRQRAIAAgAjYCACAADwsCQCACQQFrIgNBJ00EQCACIQQgACADQQJ0akEEaigCACIGQQAgAWsiAXYiA0UNASACQSdNBEAgACACQQJ0akEEaiADNgIAIAJBAWohBAwCCyACQShBtN7AABBpAAsgA0EoQbTewAAQaQALAkAgAiAFQQFqIghLBEAgAUEfcSEBIAJBAnQgAGpBBGshAwNAIAJBAmtBKE8NAiADQQRqIAYgB3QgAygCACIGIAF2cjYCACADQQRrIQMgCCACQQFrIgJJDQALCyAAIAVBAnRqQQRqIgEgASgCACAHdDYCACAAIAQ2AgAgAA8LQX9BKEG03sAAEGkAC5EHAQV/IAAQ7gEiACAAENcBIgIQ6wEhAQJAAkACQCAAENgBDQAgACgCACEDAkAgABDEAUUEQCACIANqIQIgACADEOwBIgBBqOrAACgCAEcNASABKAIEQQNxQQNHDQJBoOrAACACNgIAIAAgAiABEJkBDwsgAiADakEQaiEADAILIANBgAJPBEAgABBGDAELIABBDGooAgAiBCAAQQhqKAIAIgVHBEAgBSAENgIMIAQgBTYCCAwBC0GQ58AAQZDnwAAoAgBBfiADQQN2d3E2AgALAkAgARC9AQRAIAAgAiABEJkBDAELAkACQAJAQazqwAAoAgAgAUcEQCABQajqwAAoAgBHDQFBqOrAACAANgIAQaDqwABBoOrAACgCACACaiIBNgIAIAAgARCrAQ8LQazqwAAgADYCAEGk6sAAQaTqwAAoAgAgAmoiATYCACAAIAFBAXI2AgQgAEGo6sAAKAIARg0BDAILIAEQ1wEiAyACaiECAkAgA0GAAk8EQCABEEYMAQsgAUEMaigCACIEIAFBCGooAgAiAUcEQCABIAQ2AgwgBCABNgIIDAELQZDnwABBkOfAACgCAEF+IANBA3Z3cTYCAAsgACACEKsBIABBqOrAACgCAEcNAkGg6sAAIAI2AgAMAwtBoOrAAEEANgIAQajqwABBADYCAAtByOrAACgCACABTw0BQQhBCBCvASEAQRRBCBCvASEBQRBBCBCvASEDQQBBEEEIEK8BQQJ0ayICQYCAfCADIAAgAWpqa0F3cUEDayIAIAAgAksbRQ0BQazqwAAoAgBFDQFBCEEIEK8BIQBBFEEIEK8BIQFBEEEIEK8BIQJBAAJAQaTqwAAoAgAiBCACIAEgAEEIa2pqIgJNDQBBrOrAACgCACEBQbjqwAAhAAJAA0AgASAAKAIATwRAIAAQxgEgAUsNAgsgACgCCCIADQALQQAhAAsgABDZAQ0AIABBDGooAgAaDAALQQAQSGtHDQFBpOrAACgCAEHI6sAAKAIATQ0BQcjqwABBfzYCAA8LIAJBgAJJDQEgACACEEVB0OrAAEHQ6sAAKAIAQQFrIgA2AgAgAA0AEEgaDwsPCyACQXhxQZjnwABqIQECf0GQ58AAKAIAIgNBASACQQN2dCICcQRAIAEoAggMAQtBkOfAACACIANyNgIAIAELIQMgASAANgIIIAMgADYCDCAAIAE2AgwgACADNgIIC40HAQh/AkACQCAAKAIIIgpBAUcgACgCECIDQQFHcUUEQAJAIANBAUcNACABIAJqIQkgAEEUaigCAEEBaiEHIAEhBANAAkAgBCEDIAdBAWsiB0UNACADIAlGDQICfyADLAAAIgVBAE4EQCAFQf8BcSEFIANBAWoMAQsgAy0AAUE/cSEIIAVBH3EhBCAFQV9NBEAgBEEGdCAIciEFIANBAmoMAQsgAy0AAkE/cSAIQQZ0ciEIIAVBcEkEQCAIIARBDHRyIQUgA0EDagwBCyAEQRJ0QYCA8ABxIAMtAANBP3EgCEEGdHJyIgVBgIDEAEYNAyADQQRqCyIEIAYgA2tqIQYgBUGAgMQARw0BDAILCyADIAlGDQAgAywAACIEQQBOIARBYElyIARBcElyRQRAIARB/wFxQRJ0QYCA8ABxIAMtAANBP3EgAy0AAkE/cUEGdCADLQABQT9xQQx0cnJyQYCAxABGDQELAkACQCAGRQ0AIAIgBk0EQEEAIQMgAiAGRg0BDAILQQAhAyABIAZqLAAAQUBIDQELIAEhAwsgBiACIAMbIQIgAyABIAMbIQELIApFDQIgAEEMaigCACEGAkAgAkEQTwRAIAEgAhApIQQMAQsgAkUEQEEAIQQMAQsgAkEDcSEFAkAgAkEBa0EDSQRAQQAhBCABIQMMAQsgAkF8cSEHQQAhBCABIQMDQCAEIAMsAABBv39KaiADLAABQb9/SmogAywAAkG/f0pqIAMsAANBv39KaiEEIANBBGohAyAHQQRrIgcNAAsLIAVFDQADQCAEIAMsAABBv39KaiEEIANBAWohAyAFQQFrIgUNAAsLIAQgBkkEQCAGIARrIgQhBgJAAkACQEEAIAAtACAiAyADQQNGG0EDcSIDQQFrDgIAAQILQQAhBiAEIQMMAQsgBEEBdiEDIARBAWpBAXYhBgsgA0EBaiEDIABBHGooAgAhBCAAQRhqKAIAIQUgACgCBCEAAkADQCADQQFrIgNFDQEgBSAAIAQoAhARAABFDQALQQEPC0EBIQMgAEGAgMQARg0CIAUgASACIAQoAgwRAQANAkEAIQMDQCADIAZGBEBBAA8LIANBAWohAyAFIAAgBCgCEBEAAEUNAAsgA0EBayAGSQ8LDAILIAAoAhggASACIABBHGooAgAoAgwRAQAhAwsgAw8LIAAoAhggASACIABBHGooAgAoAgwRAQAL0wgBAX8jAEEwayICJAACfwJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAALQAAQQFrDhEBAgMEBQYHCAkKCwwNDg8QEQALIAIgAC0AAToACCACQSxqQQE2AgAgAkICNwIcIAJBpKHAADYCGCACQdsANgIUIAIgAkEQajYCKCACIAJBCGo2AhAgASACQRhqEGsMEQsgAiAAKQMINwMIIAJBLGpBATYCACACQgI3AhwgAkGIocAANgIYIAJB3AA2AhQgAiACQRBqNgIoIAIgAkEIajYCECABIAJBGGoQawwQCyACIAApAwg3AwggAkEsakEBNgIAIAJCAjcCHCACQYihwAA2AhggAkHdADYCFCACIAJBEGo2AiggAiACQQhqNgIQIAEgAkEYahBrDA8LIAIgACsDCDkDCCACQSxqQQE2AgAgAkICNwIcIAJB7KDAADYCGCACQd4ANgIUIAIgAkEQajYCKCACIAJBCGo2AhAgASACQRhqEGsMDgsgAiAAKAIENgIIIAJBLGpBATYCACACQgI3AhwgAkHMoMAANgIYIAJB3wA2AhQgAiACQRBqNgIoIAIgAkEIajYCECABIAJBGGoQawwNCyACIAApAgQ3AwggAkEsakEBNgIAIAJCATcCHCACQbigwAA2AhggAkHgADYCFCACIAJBEGo2AiggAiACQQhqNgIQIAEgAkEYahBrDAwLIAJBLGpBADYCACACQdiewAA2AiggAkIBNwIcIAJBqKDAADYCGCABIAJBGGoQawwLCyACQSxqQQA2AgAgAkHYnsAANgIoIAJCATcCHCACQZSgwAA2AhggASACQRhqEGsMCgsgAkEsakEANgIAIAJB2J7AADYCKCACQgE3AhwgAkGAoMAANgIYIAEgAkEYahBrDAkLIAJBLGpBADYCACACQdiewAA2AiggAkIBNwIcIAJB7J/AADYCGCABIAJBGGoQawwICyACQSxqQQA2AgAgAkHYnsAANgIoIAJCATcCHCACQdSfwAA2AhggASACQRhqEGsMBwsgAkEsakEANgIAIAJB2J7AADYCKCACQgE3AhwgAkHEn8AANgIYIAEgAkEYahBrDAYLIAJBLGpBADYCACACQdiewAA2AiggAkIBNwIcIAJBuJ/AADYCGCABIAJBGGoQawwFCyACQSxqQQA2AgAgAkHYnsAANgIoIAJCATcCHCACQayfwAA2AhggASACQRhqEGsMBAsgAkEsakEANgIAIAJB2J7AADYCKCACQgE3AhwgAkGYn8AANgIYIAEgAkEYahBrDAMLIAJBLGpBADYCACACQdiewAA2AiggAkIBNwIcIAJBgJ/AADYCGCABIAJBGGoQawwCCyACQSxqQQA2AgAgAkHYnsAANgIoIAJCATcCHCACQeiewAA2AhggASACQRhqEGsMAQsgASAAKAIEIABBCGooAgAQrQELIAJBMGokAAvYBgEIfwJAAkAgAEEDakF8cSICIABrIgQgAUsgBEEES3INACABIARrIgZBBEkNACAGQQNxIQdBACEBAkAgACACRg0AIARBA3EhAwJAIAIgAEF/c2pBA0kEQCAAIQIMAQsgBEF8cSEIIAAhAgNAIAEgAiwAAEG/f0pqIAIsAAFBv39KaiACLAACQb9/SmogAiwAA0G/f0pqIQEgAkEEaiECIAhBBGsiCA0ACwsgA0UNAANAIAEgAiwAAEG/f0pqIQEgAkEBaiECIANBAWsiAw0ACwsgACAEaiEAAkAgB0UNACAAIAZBfHFqIgIsAABBv39KIQUgB0EBRg0AIAUgAiwAAUG/f0pqIQUgB0ECRg0AIAUgAiwAAkG/f0pqIQULIAZBAnYhBCABIAVqIQMDQCAAIQEgBEUNAiAEQcABIARBwAFJGyIFQQNxIQYgBUECdCEIAkAgBUH8AXEiB0UEQEEAIQIMAQsgASAHQQJ0aiEJQQAhAgNAIABFDQEgAiAAKAIAIgJBf3NBB3YgAkEGdnJBgYKECHFqIABBBGooAgAiAkF/c0EHdiACQQZ2ckGBgoQIcWogAEEIaigCACICQX9zQQd2IAJBBnZyQYGChAhxaiAAQQxqKAIAIgJBf3NBB3YgAkEGdnJBgYKECHFqIQIgAEEQaiIAIAlHDQALCyAEIAVrIQQgASAIaiEAIAJBCHZB/4H8B3EgAkH/gfwHcWpBgYAEbEEQdiADaiEDIAZFDQALAn9BACABRQ0AGiABIAdBAnRqIgEoAgAiAEF/c0EHdiAAQQZ2ckGBgoQIcSIAIAZBAUYNABogACABKAIEIgBBf3NBB3YgAEEGdnJBgYKECHFqIgAgBkECRg0AGiAAIAEoAggiAEF/c0EHdiAAQQZ2ckGBgoQIcWoLIgBBCHZB/4EccSAAQf+B/AdxakGBgARsQRB2IANqDwsgAUUEQEEADwsgAUEDcSECAkAgAUEBa0EDSQRADAELIAFBfHEhAQNAIAMgACwAAEG/f0pqIAAsAAFBv39KaiAALAACQb9/SmogACwAA0G/f0pqIQMgAEEEaiEAIAFBBGsiAQ0ACwsgAkUNAANAIAMgACwAAEG/f0pqIQMgAEEBaiEAIAJBAWsiAg0ACwsgAwu0BwEOfwJAAkAgAigCGCILQSIgAkEcaigCACINKAIQIg4RAABFBEACQCABRQRADAELIAAgAWohDyAAIQcCQANAAkAgBywAACICQQBOBEAgB0EBaiEJIAJB/wFxIQQMAQsgBy0AAUE/cSEFIAJBH3EhBCACQV9NBEAgBEEGdCAFciEEIAdBAmohCQwBCyAHLQACQT9xIAVBBnRyIQUgB0EDaiEJIAJBcEkEQCAFIARBDHRyIQQMAQsgBEESdEGAgPAAcSAJLQAAQT9xIAVBBnRyciIEQYCAxABGDQIgB0EEaiEJC0EwIQVBgoDEACECAkACfwJAAkACQAJAAkACQAJAIAQOIwgBAQEBAQEBAQIEAQEDAQEBAQEBAQEBAQEBAQEBAQEBAQEFAAsgBEHcAEYNBAsgBBA9RQ0EIARBAXJnQQJ2QQdzDAULQfQAIQUMBQtB8gAhBQwEC0HuACEFDAMLIAQhBQwCC0GBgMQAIQIgBCEFIAQQTg0BIARBAXJnQQJ2QQdzCyEFIAQhAgsCQAJAIAJBgIDEAGsiCkEDIApBA0kbQQFGDQAgAyAGSw0BAkAgA0UNACABIANNBEAgASADRg0BDAMLIAAgA2osAABBQEgNAgsCQCAGRQ0AIAEgBk0EQCABIAZHDQMMAQsgACAGaiwAAEG/f0wNAgsgCyAAIANqIAYgA2sgDSgCDBEBAARAQQEPC0EFIQgDQCAIIQwgAiEKQYGAxAAhAkHcACEDAkACQAJAAkACQAJAIApBgIDEAGsiEEEDIBBBA0kbQQFrDgMBBQACC0EAIQhB/QAhAyAKIQICQAJAAkAgDEH/AXFBAWsOBQcFAAECBAtBAiEIQfsAIQMMBQtBAyEIQfUAIQMMBAtBBCEIQdwAIQMMAwtBgIDEACECIAUiA0GAgMQARw0DCwJ/QQEgBEGAAUkNABpBAiAEQYAQSQ0AGkEDQQQgBEGAgARJGwsgBmohAwwECyAMQQEgBRshCEEwQdcAIAogBUECdHZBD3EiAkEKSRsgAmohAyAFQQFrQQAgBRshBQsgCiECCyALIAMgDhEAAEUNAAtBAQ8LIAYgB2sgCWohBiAJIgcgD0cNAQwCCwsgACABIAMgBkGgzsAAELYBAAsgA0UEQEEAIQMMAQsgASADTQRAIAEgA0YNAQwECyAAIANqLAAAQb9/TA0DCyALIAAgA2ogASADayANKAIMEQEARQ0BC0EBDwsgC0EiIA4RAAAPCyAAIAEgAyABQbDOwAAQtgEAC7YGAgJ+BX8CQAJAAkACQAJAAkAgAUEHcSIEBEACQAJAIAAoAgAiBUEpSQRAIAVFBEBBACEFDAMLIARBAnRBqLDAAGo1AgAhAyAAQQRqIQQgBUEBa0H/////A3EiB0EBaiIGQQNxIQggB0EDSQ0BIAZB/P///wdxIQcDQCAEIAQ1AgAgA34gAnwiAj4CACAEQQRqIgYgBjUCACADfiACQiCIfCICPgIAIARBCGoiBiAGNQIAIAN+IAJCIIh8IgI+AgAgBEEMaiIGIAY1AgAgA34gAkIgiHwiAj4CACACQiCIIQIgBEEQaiEEIAdBBGsiBw0ACwwBCyAFQShBtN7AABDKAQALIAgEQANAIAQgBDUCACADfiACfCICPgIAIARBBGohBCACQiCIIQIgCEEBayIIDQALCyACpyIERQ0AIAVBJ0sNAiAAIAVBAnRqQQRqIAQ2AgAgBUEBaiEFCyAAIAU2AgALIAFBCHFFDQQgACgCACIFQSlPDQEgBUUEQEEAIQUMBAsgAEEEaiEEIAVBAWtB/////wNxIgdBAWoiBkEDcSEIIAdBA0kEQEIAIQIMAwsgBkH8////B3EhB0IAIQIDQCAEIAQ1AgBCgMLXL34gAnwiAj4CACAEQQRqIgYgBjUCAEKAwtcvfiACQiCIfCICPgIAIARBCGoiBiAGNQIAQoDC1y9+IAJCIIh8IgI+AgAgBEEMaiIGIAY1AgBCgMLXL34gAkIgiHwiAj4CACACQiCIIQIgBEEQaiEEIAdBBGsiBw0ACwwCCyAFQShBtN7AABBpAAsgBUEoQbTewAAQygEACyAIBEADQCAEIAQ1AgBCgMLXL34gAnwiAj4CACAEQQRqIQQgAkIgiCECIAhBAWsiCA0ACwsgAqciBEUNACAFQSdLDQIgACAFQQJ0akEEaiAENgIAIAVBAWohBQsgACAFNgIACyABQRBxBEAgAEH4sMAAQQIQLAsgAUEgcQRAIABBgLHAAEEEECwLIAFBwABxBEAgAEGQscAAQQcQLAsgAUGAAXEEQCAAQayxwABBDhAsCyABQYACcQRAIABB5LHAAEEbECwLDwsgBUEoQbTewAAQaQAL8wUCDH8CfiMAQaABayIDJAAgA0EAQaABEN4BIQkCQAJAIAIgACgCACIFTQRAIAVBKUkEQCABIAJBAnRqIQsgBUUNAiAFQQFqIQwgAEEEaiENIAVBAnQhDgNAIAkgB0ECdGohBANAIAchAiAEIQMgASALRg0FIANBBGohBCACQQFqIQcgASgCACEGIAFBBGoiCiEBIAZFDQALIAatIRBCACEPIA4hBiACIQEgDSEEAkACQANAIAFBJ0sNASADIA8gAzUCAHwgBDUCACAQfnwiDz4CACAPQiCIIQ8gA0EEaiEDIAFBAWohASAEQQRqIQQgBkEEayIGDQALIAUhAyAPpyIBRQ0BIAIgBWoiA0EnTQRAIAkgA0ECdGogATYCACAMIQMMAgsgA0EoQbTewAAQaQALIAFBKEG03sAAEGkACyAIIAIgA2oiASABIAhJGyEIIAohAQwACwALIAVBKEG03sAAEMoBAAsgBUEpSQRAIABBBGoiBCAFQQJ0aiELIAJBAnQhDCACQQFqIQ1BACEFA0AgCSAFQQJ0aiEHA0AgBSEKIAchAyAEIAtGDQQgA0EEaiEHIApBAWohBSAEKAIAIQYgBEEEaiIOIQQgBkUNAAsgBq0hEEIAIQ8gDCEGIAohBCABIQcCQAJAA0AgBEEnSw0BIAMgDyADNQIAfCAHNQIAIBB+fCIPPgIAIA9CIIghDyADQQRqIQMgBEEBaiEEIAdBBGohByAGQQRrIgYNAAsgAiEDIA+nIgRFDQEgAiAKaiIDQSdNBEAgCSADQQJ0aiAENgIAIA0hAwwCCyADQShBtN7AABBpAAsgBEEoQbTewAAQaQALIAggAyAKaiIDIAMgCEkbIQggDiEEDAALAAsgBUEoQbTewAAQygEAC0EAIQMDQCABIAtGDQEgA0EBaiEDIAEoAgAgAUEEaiEBRQ0AIAggA0EBayICIAIgCEkbIQgMAAsACyAAQQRqIAlBoAEQ4AEaIAAgCDYCACAJQaABaiQAC4AGAQd/An8gAQRAQStBgIDEACAAKAIAIghBAXEiARshCiABIAVqDAELIAAoAgAhCEEtIQogBUEBagshBwJAIAhBBHFFBEBBACECDAELAkAgA0EQTwRAIAIgAxApIQYMAQsgA0UEQAwBCyADQQNxIQkCQCADQQFrQQNJBEAgAiEBDAELIANBfHEhCyACIQEDQCAGIAEsAABBv39KaiABLAABQb9/SmogASwAAkG/f0pqIAEsAANBv39KaiEGIAFBBGohASALQQRrIgsNAAsLIAlFDQADQCAGIAEsAABBv39KaiEGIAFBAWohASAJQQFrIgkNAAsLIAYgB2ohBwsCQAJAIAAoAghFBEBBASEBIABBGGooAgAiByAAQRxqKAIAIgAgCiACIAMQhgENAQwCCwJAAkACQAJAIAcgAEEMaigCACIGSQRAIAhBCHENBCAGIAdrIgYhB0EBIAAtACAiASABQQNGG0EDcSIBQQFrDgIBAgMLQQEhASAAQRhqKAIAIgcgAEEcaigCACIAIAogAiADEIYBDQQMBQtBACEHIAYhAQwBCyAGQQF2IQEgBkEBakEBdiEHCyABQQFqIQEgAEEcaigCACEGIABBGGooAgAhCCAAKAIEIQACQANAIAFBAWsiAUUNASAIIAAgBigCEBEAAEUNAAtBAQ8LQQEhASAAQYCAxABGDQEgCCAGIAogAiADEIYBDQEgCCAEIAUgBigCDBEBAA0BQQAhAQJ/A0AgByABIAdGDQEaIAFBAWohASAIIAAgBigCEBEAAEUNAAsgAUEBawsgB0khAQwBCyAAKAIEIQsgAEEwNgIEIAAtACAhDEEBIQEgAEEBOgAgIABBGGooAgAiCCAAQRxqKAIAIgkgCiACIAMQhgENACAGIAdrQQFqIQECQANAIAFBAWsiAUUNASAIQTAgCSgCEBEAAEUNAAtBAQ8LQQEhASAIIAQgBSAJKAIMEQEADQAgACAMOgAgIAAgCzYCBEEADwsgAQ8LIAcgBCAFIAAoAgwRAQALlAUBBn8jAEEgayIIJAACQAJAAkAgA0EgTwRAIANBgAJJDQEgA0GAgARJDQIgCEESOwEQIAhBEGoQSiEJIAEoAgQiBiABKAIIIgRGBEAgASAEQQEQUiABKAIEIQYgASgCCCEECyABIARBAWoiBTYCCCABKAIAIgcgBGogCToAACAGIAVrQQNNBEAgASAFQQQQUiABKAIAIQcgASgCCCEFCyABIAVBBGoiBDYCCCAFIAdqIANBCHRBgID8B3EgA0EYdHIgA0EIdkGA/gNxIANBGHZycjYAAAwDCyAIIANBCHRBD3I7AQAgCBBKIQYgASgCCCIFIAEoAgRGBEAgASAFQQEQUiABKAIIIQULIAEgBUEBaiIENgIIIAEoAgAiByAFaiAGOgAADAILIAhBEDsBCCAIQQhqEEohCSABKAIEIgYgASgCCCIERgRAIAEgBEEBEFIgASgCBCEGIAEoAgghBAsgASAEQQFqIgU2AgggASgCACIHIARqIAk6AAAgBSAGRgRAIAEgBkEBEFIgASgCACEHIAEoAgghBQsgASAFQQFqIgQ2AgggBSAHaiADOgAADAELIAhBETsBGCAIQRhqEEohCSABKAIEIgYgASgCCCIERgRAIAEgBEEBEFIgASgCBCEGIAEoAgghBAsgASAEQQFqIgU2AgggASgCACIHIARqIAk6AAAgBiAFa0EBTQRAIAEgBUECEFIgASgCACEHIAEoAgghBQsgASAFQQJqIgQ2AgggBSAHaiADQQh0IANBgP4DcUEIdnI7AAALIAMgASgCBCAEa0sEQCABIAQgAxBSIAEoAgAhByABKAIIIQQLIAQgB2ogAiADEOABGiAAQQI2AgAgASADIARqNgIIIAhBIGokAAv8BAEIfyMAQRBrIgckAAJ/IAIoAgQiBARAQQEgACACKAIAIAQgASgCDBEBAA0BGgtBACACQQxqKAIAIgNFDQAaIAIoAggiBCADQQxsaiEIIAdBDGohCQNAAkACQAJAAkAgBC8BAEEBaw4CAgEACwJAIAQoAgQiAkHBAE8EQCABQQxqKAIAIQMDQEEBIABBxM3AAEHAACADEQEADQcaIAJBQGoiAkHAAEsNAAsMAQsgAkUNAwsCQCACQT9NBEAgAkHEzcAAaiwAAEG/f0wNAQsgAEHEzcAAIAIgAUEMaigCABEBAEUNA0EBDAULQcTNwABBwABBACACQYTOwAAQtgEACyAAIAQoAgQgBEEIaigCACABQQxqKAIAEQEARQ0BQQEMAwsgBC8BAiECIAlBADoAACAHQQA2AggCQAJAAn8CQAJAAkAgBC8BAEEBaw4CAQACCyAEQQhqDAILIAQvAQIiA0HoB08EQEEEQQUgA0GQzgBJGyEFDAMLQQEhBSADQQpJDQJBAkEDIANB5ABJGyEFDAILIARBBGoLKAIAIgVBBkkEQCAFDQFBACEFDAILIAVBBUG0zcAAEMoBAAsgB0EIaiAFaiEGAkAgBUEBcUUEQCACIQMMAQsgBkEBayIGIAIgAkEKbiIDQQpsa0EwcjoAAAsgBUEBRg0AIAZBAmshAgNAIAIgA0H//wNxIgZBCm4iCkEKcEEwcjoAACACQQFqIAMgCkEKbGtBMHI6AAAgBkHkAG4hAyACIAdBCGpGIAJBAmshAkUNAAsLIAAgB0EIaiAFIAFBDGooAgARAQBFDQBBAQwCCyAEQQxqIgQgCEcNAAtBAAsgB0EQaiQAC/8EAQp/IwBBMGsiAyQAIANBJGogATYCACADQQM6ACggA0KAgICAgAQ3AwggAyAANgIgIANBADYCGCADQQA2AhACfwJAAkAgAigCCCIKRQRAIAJBFGooAgAiAEUNASACKAIQIQEgAEEDdCEFIABBAWtB/////wFxQQFqIQcgAigCACEAA0AgAEEEaigCACIEBEAgAygCICAAKAIAIAQgAygCJCgCDBEBAA0ECyABKAIAIANBCGogAUEEaigCABEAAA0DIAFBCGohASAAQQhqIQAgBUEIayIFDQALDAELIAJBDGooAgAiAEUNACAAQQV0IQsgAEEBa0H///8/cUEBaiEHIAIoAgAhAANAIABBBGooAgAiAQRAIAMoAiAgACgCACABIAMoAiQoAgwRAQANAwsgAyAFIApqIgRBHGotAAA6ACggAyAEQQRqKQIAQiCJNwMIIARBGGooAgAhBiACKAIQIQhBACEJQQAhAQJAAkACQCAEQRRqKAIAQQFrDgIAAgELIAZBA3QgCGoiDEEEaigCAEH3AEcNASAMKAIAKAIAIQYLQQEhAQsgAyAGNgIUIAMgATYCECAEQRBqKAIAIQECQAJAAkAgBEEMaigCAEEBaw4CAAIBCyABQQN0IAhqIgZBBGooAgBB9wBHDQEgBigCACgCACEBC0EBIQkLIAMgATYCHCADIAk2AhggCCAEKAIAQQN0aiIBKAIAIANBCGogASgCBBEAAA0CIABBCGohACALIAVBIGoiBUcNAAsLIAIoAgQgB0sEQCADKAIgIAIoAgAgB0EDdGoiACgCACAAKAIEIAMoAiQoAgwRAQANAQtBAAwBC0EBCyADQTBqJAAL8AQBCX8jAEEQayIEJAACQAJAAn8CQCAAKAIIQQFGBEAgAEEMaigCACEHIARBDGogAUEMaigCACIFNgIAIAQgASgCCCICNgIIIAQgASgCBCIDNgIEIAQgASgCACIBNgIAIAAtACAhCSAAKAIEIQogAC0AAEEIcQ0BIAohCCAJIQYgAwwCCyAAQRhqKAIAIABBHGooAgAgARAvIQIMAwsgACgCGCABIAMgAEEcaigCACgCDBEBAA0BQQEhBiAAQQE6ACBBMCEIIABBMDYCBCAEQQA2AgQgBEHIr8AANgIAQQAgByADayIDIAMgB0sbIQdBAAshASAFBEAgBUEMbCEDA0ACfwJAAkACQCACLwEAQQFrDgICAQALIAJBBGooAgAMAgsgAkEIaigCAAwBCyACQQJqLwEAIgVB6AdPBEBBBEEFIAVBkM4ASRsMAQtBASAFQQpJDQAaQQJBAyAFQeQASRsLIQUgAkEMaiECIAEgBWohASADQQxrIgMNAAsLAn8CQCABIAdJBEAgByABayIBIQMCQAJAAkAgBkEDcSICQQFrDgMAAQACC0EAIQMgASECDAELIAFBAXYhAiABQQFqQQF2IQMLIAJBAWohAiAAQRxqKAIAIQEgAEEYaigCACEGA0AgAkEBayICRQ0CIAYgCCABKAIQEQAARQ0ACwwDCyAAQRhqKAIAIABBHGooAgAgBBAvDAELIAYgASAEEC8NAUEAIQIDQEEAIAIgA0YNARogAkEBaiECIAYgCCABKAIQEQAARQ0ACyACQQFrIANJCyECIAAgCToAICAAIAo2AgQMAQtBASECCyAEQRBqJAAgAgvVBAEEfyAAIAEQ6wEhAgJAAkACQCAAENgBDQAgACgCACEDAkAgABDEAUUEQCABIANqIQEgACADEOwBIgBBqOrAACgCAEcNASACKAIEQQNxQQNHDQJBoOrAACABNgIAIAAgASACEJkBDwsgASADakEQaiEADAILIANBgAJPBEAgABBGDAELIABBDGooAgAiBCAAQQhqKAIAIgVHBEAgBSAENgIMIAQgBTYCCAwBC0GQ58AAQZDnwAAoAgBBfiADQQN2d3E2AgALIAIQvQEEQCAAIAEgAhCZAQwCCwJAQazqwAAoAgAgAkcEQCACQajqwAAoAgBHDQFBqOrAACAANgIAQaDqwABBoOrAACgCACABaiIBNgIAIAAgARCrAQ8LQazqwAAgADYCAEGk6sAAQaTqwAAoAgAgAWoiATYCACAAIAFBAXI2AgQgAEGo6sAAKAIARw0BQaDqwABBADYCAEGo6sAAQQA2AgAPCyACENcBIgMgAWohAQJAIANBgAJPBEAgAhBGDAELIAJBDGooAgAiBCACQQhqKAIAIgJHBEAgAiAENgIMIAQgAjYCCAwBC0GQ58AAQZDnwAAoAgBBfiADQQN2d3E2AgALIAAgARCrASAAQajqwAAoAgBHDQFBoOrAACABNgIACw8LIAFBgAJPBEAgACABEEUPCyABQXhxQZjnwABqIQICf0GQ58AAKAIAIgNBASABQQN2dCIBcQRAIAIoAggMAQtBkOfAACABIANyNgIAIAILIQEgAiAANgIIIAEgADYCDCAAIAI2AgwgACABNgIIC4kEAQV/IwBBIGsiBiQAAn8CQCACQYACTwRAIAJBgIAESQ0BIAZBFTsBECAGQRBqEEohByABKAIEIgUgASgCCCIDRgRAIAEgA0EBEFIgASgCBCEFIAEoAgghAwsgASADQQFqIgQ2AgggAyABKAIAIgNqIAc6AAAgBSAEa0EDTQRAIAEgBEEEEFIgASgCACEDIAEoAgghBAsgASAEQQRqNgIIIAMgBGogAkEIdEGAgPwHcSACQRh0ciACQQh2QYD+A3EgAkEYdnJyNgAAQRUMAgsgBkETOwEIIAZBCGoQSiEHIAEoAgQiBSABKAIIIgNGBEAgASADQQEQUiABKAIEIQUgASgCCCEDCyABIANBAWoiBDYCCCADIAEoAgAiA2ogBzoAACAEIAVGBEAgASAFQQEQUiABKAIAIQMgASgCCCEECyABIARBAWo2AgggAyAEaiACOgAAQRMMAQsgBkEUOwEYIAZBGGoQSiEHIAEoAgQiBSABKAIIIgNGBEAgASADQQEQUiABKAIEIQUgASgCCCEDCyABIANBAWoiBDYCCCADIAEoAgAiA2ogBzoAACAFIARrQQFNBEAgASAEQQIQUiABKAIAIQMgASgCCCEECyABIARBAmo2AgggAyAEaiACQQh0IAJBgP4DcUEIdnI7AABBFAshASAAQQI2AgAgACABOgAEIAZBIGokAAuqBQMFfwF+AXwjAEHQAGsiAyQAQQchBgJAAkAgACgCACIFEARBAUYNACAFEAVBAUYNAAJAAkACQCAFEAYOAgEAAgtBASEEC0EAIQBBACEGDAILIANBEGogBRAHIAMoAhAEQEEDIQYgAysDGCEJQQAhAAwCCyADQQhqIAUQAQJ/IAMoAggiBQRAIAMoAgwhBCADIAU2AiAgAyAENgIoIAMgBDYCJEEFIQZBAQwBCwJAAkAgABDCAUUEQCAAEMEBRQ0CIAMgABDpATYCICADQThqIANBIGoQXyADKQI8IQggAygCOCEFIAMoAiAiBEEkSQ0BIAQQAAwBCyADQThqIAAQXyADKQI8IQggAygCOCEFCyAFRQ0AIAhCIIinIQRBASEHQQYhBkEADAELIANBKzYCNCADIAA2AjAgA0EBNgJMIANCATcCPCADQdCQwAA2AjggAyADQTBqNgJIIANBIGogA0E4ahA1QREhBiADKAIgIQUgAygCKCEEQQELIQAgBK2/IQkMAQtBACEACyADIAk5A0AgAyAFNgI8IAMgBDoAOSADIAY6ADgjAEEwayIEJAAgBCACNgIEIAQgATYCACAEQRRqQTA2AgAgBEEMNgIMIAQgA0E4ajYCCCAEIAQ2AhAgBEECNgIsIARCAjcCHCAEQciSwAA2AhggBCAEQQhqNgIoAn8jAEFAaiIBJAAgAUEANgIIIAFCATcDACABQRBqIgIgAUHwkMAAEJIBIARBGGogAhBqRQRAIAEoAgAgASgCCBDoASABKAIEBEAgASgCABAmCyABQUBrJAAMAQtBiJHAAEE3IAFBOGpBwJHAAEGcksAAEGQACyAEQTBqJAAgB0UgCKdFckUEQCAFECYLAkAgAEUNACADKAIkRQ0AIAUQJgsgA0HQAGokAAvoAwEGfyMAQTBrIgUkAAJAAkACQAJAAkAgASgCBCIDBEAgASgCACEHIANBAWtB/////wFxIgNBAWoiBkEHcSEEAn8gA0EHSQRAQQAhAyAHDAELIAdBPGohAiAGQfj///8DcSEGQQAhAwNAIAIoAgAgAkEIaygCACACQRBrKAIAIAJBGGsoAgAgAkEgaygCACACQShrKAIAIAJBMGsoAgAgAkE4aygCACADampqampqamohAyACQUBrIQIgBkEIayIGDQALIAJBPGsLIQIgBARAIAJBBGohAgNAIAIoAgAgA2ohAyACQQhqIQIgBEEBayIEDQALCyABQRRqKAIADQEgAyEEDAMLQQAhAyABQRRqKAIADQFBASECDAQLIAcoAgQNACADQRBJDQILIAMgA2oiBCADSQ0BCyAERQ0AAkAgBEEATgRAIARBARC4ASICRQ0BIAQhAwwDCxCIAQALIARBARDbAQALQQEhAkEAIQMLIABBADYCCCAAIAM2AgQgACACNgIAIAUgADYCDCAFQSBqIAFBEGopAgA3AwAgBUEYaiABQQhqKQIANwMAIAUgASkCADcDECAFQQxqQfytwAAgBUEQahAwBEBB3K7AAEEzIAVBKGpBkK/AAEG4r8AAEGQACyAFQTBqJAALxgUCCX8BfiMAQdAAayICJAAgASgCACEJAkACQAJAAkAgAUEIaigCACIDQVhGBEAQYyEDIABBADYCACAAIAM2AgQMAQsgA0UNAyADQQBIDQEgA0EBELgBIgRFDQIgBCAJIAMQ4AEhByADQQJNDQMgAkEoaiEEIwBBIGsiBiQAIAZBEGoiBUEDNgIEIAVBzJjAADYCAAJAAkACQAJAAkAgBigCFEEDRgRAIAcgBigCEEEDEN8BRQ0BCyAGQQhqIgVBCzYCBCAFQc+YwAA2AgAgBigCCCEKAkAgBigCDCIFRQRAQQEhCAwBCyAFQQBIDQMgBUEBELgBIghFDQQLIAggCiAFEOABIQggBCAFNgIMIAQgBTYCCCAEIAg2AgQgBEEDOgAAIAQgBy8AADsAASAEQQNqIAdBAmotAAA6AAAMAQsgBEEGOgAACyAGQSBqJAAMAgsQiAEACyAFQQEQ2wEACyACLQAoIgRBBkYEQCAAIAM2AgggACADNgIEIAAgBzYCAAwBCyACQQZqIgMgAi0AKzoAACACIAIvACk7AQQgAikCLCELIAIoAjQhBiAHECYgAiAEOgAIIAIgAi8BBDsACSACIAMtAAA6AAsgAiAGNgIUIAIgCzcCDCACQRo2AkQgAiACQQhqNgJAIAJBATYCPCACQgE3AiwgAkGcicAANgIoIAIgAkFAayIDNgI4IAJBGGogAkEoaiIEEDUgAkHIAGogAkEgaigCADYCACACIAIpAxg3A0AgBCADEHQgAigCKCIDIAIoAjAQ6AEhBCACKAIsBEAgAxAmCyACKAJEBEAgAigCQBAmCwJAIAItAAhBA0cNACACKAIQRQ0AIAIoAgwQJgsgAEEANgIAIAAgBDYCBAsgAUEEaigCAARAIAkQJgsgAkHQAGokAA8LEIgBAAsgA0EBENsBAAtBAyADQbyNwAAQygEAC7QFAQt/IwBBMGsiBSQAIAVBCjYCKCAFQoqAgIAQNwMgIAUgAjYCHCAFQQA2AhggBSACNgIUIAUgATYCECAFIAI2AgwgBUEANgIIIAAoAgQhCiAAKAIAIQsgACgCCCEMAn8DQAJAIAZFBEACQCACIAhJDQADQCABIAhqIQcCfyACIAhrIgRBCE8EQAJAAkACQAJAIAdBA2pBfHEiACAHRg0AIAAgB2siACAEIAAgBEkbIgNFDQBBACEAQQEhBgNAIAAgB2otAABBCkYNBCADIABBAWoiAEcNAAsgAyAEQQhrIgBLDQIMAQsgBEEIayEAQQAhAwsDQAJAIAMgB2oiDSgCAEGKlKjQAHMiBkF/cyAGQYGChAhrcUGAgYKEeHENACANQQRqKAIAQYqUqNAAcyIGQX9zIAZBgYKECGtxQYCBgoR4cQ0AIANBCGoiAyAATQ0BCwsgAyAETQ0AIAMgBEHkzsAAEMkBAAtBACEGIAMgBEcEQANAIAMgB2otAABBCkYEQCADIQBBASEGDAMLIAQgA0EBaiIDRw0ACwsgBCEACyAFIAA2AgQgBSAGNgIAIAUoAgQhACAFKAIADAELQQAhAEEAIARFDQAaA0BBASAAIAdqLQAAQQpGDQEaIAQgAEEBaiIARw0ACyAEIQBBAAtBAUcEQCACIQgMAgsCQCAAIAhqIgBBAWoiCEUgAiAISXINACAAIAFqLQAAQQpHDQBBACEGIAgiBCEADAQLIAIgCE8NAAsLQQEhBiACIgAgCSIERw0BC0EADAILAkAgDC0AAARAIAtB5MrAAEEEIAooAgwRAQANAQsgASAJaiEDIAAgCWshByAMIAAgCUcEfyADIAdqQQFrLQAAQQpGBUEACzoAACAEIQkgCyADIAcgCigCDBEBAEUNAQsLQQELIAVBMGokAAuPAwEFfwJAAkACQAJAIAFBCU8EQEEQQQgQrwEgAUsNAQwCCyAAECQhBAwCC0EQQQgQrwEhAQtBCEEIEK8BIQNBFEEIEK8BIQJBEEEIEK8BIQVBAEEQQQgQrwFBAnRrIgZBgIB8IAUgAiADamprQXdxQQNrIgMgAyAGSxsgAWsgAE0NACABQRAgAEEEakEQQQgQrwFBBWsgAEsbQQgQrwEiA2pBEEEIEK8BakEEaxAkIgJFDQAgAhDuASEAAkAgAUEBayIEIAJxRQRAIAAhAQwBCyACIARqQQAgAWtxEO4BIQJBEEEIEK8BIQQgABDXASACQQAgASACIABrIARLG2oiASAAayICayEEIAAQxAFFBEAgASAEEJQBIAAgAhCUASAAIAIQMgwBCyAAKAIAIQAgASAENgIEIAEgACACajYCAAsgARDEAQ0BIAEQ1wEiAkEQQQgQrwEgA2pNDQEgASADEOsBIQAgASADEJQBIAAgAiADayIDEJQBIAAgAxAyDAELIAQPCyABEO0BIAEQxAEaC/UCAQN/AkACQAJAAkACQAJAAkAgByAIVgRAIAcgCH0gCFgNByAGIAcgBn1UIAcgBkIBhn0gCEIBhlpxDQEgBiAIVgRAIAcgBiAIfSIGfSAGWA0DCwwHCwwGCyACIANJDQEMBAsgAiADSQ0BIAEhCwJAA0AgAyAJRg0BIAlBAWohCSALQQFrIgsgA2oiCi0AAEE5Rg0ACyAKIAotAABBAWo6AAAgAyAJa0EBaiADTw0DIApBAWpBMCAJQQFrEN4BGgwDCwJ/QTEgA0UNABogAUExOgAAQTAgA0EBRg0AGiABQQFqQTAgA0EBaxDeARpBMAshCSAEQRB0QYCABGpBEHUiBCAFQRB0QRB1TCACIANNcg0CIAEgA2ogCToAACADQQFqIQMMAgsgAyACQdzFwAAQygEACyADIAJB7MXAABDKAQALIAIgA08NACADIAJB/MXAABDKAQALIAAgBDsBCCAAIAM2AgQgACABNgIADwsgAEEANgIAC5cDAQJ/AkACQAJAIAIEQCABLQAAQTFJDQECQCADQRB0QRB1IgdBAEoEQCAFIAE2AgRBAiEGIAVBAjsBACADQf//A3EiAyACTw0BIAVBAjsBGCAFQQI7AQwgBSADNgIIIAVBIGogAiADayICNgIAIAVBHGogASADajYCACAFQRRqQQE2AgAgBUEQakGqx8AANgIAQQMhBiACIARPDQUgBCACayEEDAQLIAVBAjsBGCAFQQA7AQwgBUECNgIIIAVBqMfAADYCBCAFQQI7AQAgBUEgaiACNgIAIAVBHGogATYCACAFQRBqQQAgB2siATYCAEEDIQYgAiAETw0EIAEgBCACayICTw0EIAIgB2ohBAwDCyAFQQA7AQwgBSACNgIIIAVBEGogAyACazYCACAERQ0DIAVBAjsBGCAFQSBqQQE2AgAgBUEcakGqx8AANgIADAILQYzEwABBIUGwxsAAEIMBAAtBwMbAAEEhQeTGwAAQgwEACyAFQQA7ASQgBUEoaiAENgIAQQQhBgsgACAGNgIEIAAgBTYCAAvTAwEHf0EBIQMCQCABKAIYIgZBJyABQRxqKAIAKAIQIgcRAAANAEGCgMQAIQFBMCECAkACfwJAAkACQAJAAkACQAJAIAAoAgAiAA4oCAEBAQEBAQEBAgQBAQMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBBQALIABB3ABGDQQLIAAQPUUNBCAAQQFyZ0ECdkEHcwwFC0H0ACECDAULQfIAIQIMBAtB7gAhAgwDCyAAIQIMAgtBgYDEACEBIAAQTgRAIAAhAgwCCyAAQQFyZ0ECdkEHcwshAiAAIQELQQUhBANAIAQhBSABIQBBgYDEACEBQdwAIQMCQAJAAkACQAJAAkAgAEGAgMQAayIIQQMgCEEDSRtBAWsOAwEFAAILQQAhBEH9ACEDIAAhAQJAAkACQCAFQf8BcUEBaw4FBwUAAQIEC0ECIQRB+wAhAwwFC0EDIQRB9QAhAwwEC0EEIQRB3AAhAwwDC0GAgMQAIQEgAiEDIAJBgIDEAEcNAwsgBkEnIAcRAAAhAwwECyAFQQEgAhshBEEwQdcAIAAgAkECdHZBD3EiAUEKSRsgAWohAyACQQFrQQAgAhshAgsgACEBCyAGIAMgBxEAAEUNAAtBAQ8LIAMLvwIBAX8jAEHwAGsiBiQAIAYgATYCDCAGIAA2AgggBiADNgIUIAYgAjYCECAGQbXJwAA2AhggBkECNgIcAkAgBCgCAEUEQCAGQcwAakH7ADYCACAGQcQAakH7ADYCACAGQewAakEDNgIAIAZCBDcCXCAGQZjKwAA2AlggBkH6ADYCPCAGIAZBOGo2AmgMAQsgBkEwaiAEQRBqKQIANwMAIAZBKGogBEEIaikCADcDACAGIAQpAgA3AyAgBkHsAGpBBDYCACAGQdQAakH8ADYCACAGQcwAakH7ADYCACAGQcQAakH7ADYCACAGQgQ3AlwgBkH0ycAANgJYIAZB+gA2AjwgBiAGQThqNgJoIAYgBkEgajYCUAsgBiAGQRBqNgJIIAYgBkEIajYCQCAGIAZBGGo2AjggBkHYAGogBRCJAQAL9wIBBX8gAEELdCEEQSEhAkEhIQMCQANAAkACQEF/IAJBAXYgAWoiAkECdEHA38AAaigCAEELdCIFIARHIAQgBUsbIgVBAUYEQCACIQMMAQsgBUH/AXFB/wFHDQEgAkEBaiEBCyADIAFrIQIgASADSQ0BDAILCyACQQFqIQELAkACQCABQSBNBEAgAUECdCEFQdcFIQMgAUEgRwRAIAVBxN/AAGooAgBBFXYhAwtBACECIAEgAUEBayIETwRAIARBIU8NAiAEQQJ0QcDfwABqKAIAQf///wBxIQILIAMgBUHA38AAaigCAEEVdiIBQX9zakUNAiAAIAJrIQQgAUHXBSABQdcFSxshAiADQQFrIQBBACEDA0ACQCABIAJHBEAgAyABQcTgwABqLQAAaiIDIARNDQEMBQsgAkHXBUGc5sAAEGkACyAAIAFBAWoiAUcNAAsgACEBDAILIAFBIUGc5sAAEGkACyAEQSFBhN7AABBpAAsgAUEBcQvdAgEHf0EBIQkCQAJAIAJFDQAgASACQQF0aiEKIABBgP4DcUEIdiELIABB/wFxIQ0DQCABQQJqIQwgByABLQABIgJqIQggCyABLQAAIgFHBEAgASALSw0CIAghByAMIgEgCkYNAgwBCwJAAkAgByAITQRAIAQgCEkNASADIAdqIQEDQCACRQ0DIAJBAWshAiABLQAAIAFBAWohASANRw0AC0EAIQkMBQsgByAIQcDSwAAQywEACyAIIARBwNLAABDKAQALIAghByAMIgEgCkcNAAsLIAZFDQAgBSAGaiEDIABB//8DcSEBA0ACQCAFQQFqIQAgBS0AACICQRh0QRh1IgRBAE4EfyAABSAAIANGDQEgBS0AASAEQf8AcUEIdHIhAiAFQQJqCyEFIAEgAmsiAUEASA0CIAlBAXMhCSADIAVHDQEMAgsLQa3EwABBK0HQ0sAAEIMBAAsgCUEBcQuYBAEFfyMAQRBrIgMkACAAKAIAIQACQAJ/AkAgAUGAAU8EQCADQQA2AgwgAUGAEE8NASADIAFBP3FBgAFyOgANIAMgAUEGdkHAAXI6AAxBAgwCCyAAKAIIIgIgACgCBEYEQCMAQSBrIgQkAAJAAkAgAkEBaiICRQ0AIABBBGooAgAiBUEBdCIGIAIgAiAGSRsiAkEIIAJBCEsbIgJBf3NBH3YhBgJAIAUEQCAEQQE2AhggBCAFNgIUIAQgACgCADYCEAwBCyAEQQA2AhgLIAQgAiAGIARBEGoQWCAEKAIEIQUgBCgCAEUEQCAAIAU2AgAgAEEEaiACNgIADAILIARBCGooAgAiAkGBgICAeEYNASACRQ0AIAUgAhDbAQALEIgBAAsgBEEgaiQAIAAoAgghAgsgACACQQFqNgIIIAAoAgAgAmogAToAAAwCCyABQYCABE8EQCADIAFBP3FBgAFyOgAPIAMgAUEGdkE/cUGAAXI6AA4gAyABQQx2QT9xQYABcjoADSADIAFBEnZBB3FB8AFyOgAMQQQMAQsgAyABQT9xQYABcjoADiADIAFBDHZB4AFyOgAMIAMgAUEGdkE/cUGAAXI6AA1BAwshASABIABBBGooAgAgACgCCCICa0sEQCAAIAIgARBTIAAoAgghAgsgACgCACACaiADQQxqIAEQ4AEaIAAgASACajYCCAsgA0EQaiQAQQAL1QIBAn8jAEEQayICJAAgACgCACEAAkACfwJAIAFBgAFPBEAgAkEANgIMIAFBgBBPDQEgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAgsgACgCCCIDIAAoAgRGBH8gACADEFQgACgCCAUgAwsgACgCAGogAToAACAAIAAoAghBAWo2AggMAgsgAUGAgARPBEAgAiABQT9xQYABcjoADyACIAFBBnZBP3FBgAFyOgAOIAIgAUEMdkE/cUGAAXI6AA0gAiABQRJ2QQdxQfABcjoADEEEDAELIAIgAUE/cUGAAXI6AA4gAiABQQx2QeABcjoADCACIAFBBnZBP3FBgAFyOgANQQMLIQEgASAAKAIEIAAoAggiA2tLBEAgACADIAEQUiAAKAIIIQMLIAAoAgAgA2ogAkEMaiABEOABGiAAIAEgA2o2AggLIAJBEGokAEEAC84CAQJ/IwBBEGsiAiQAAkACfwJAIAFBgAFPBEAgAkEANgIMIAFBgBBPDQEgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAgsgACgCCCIDIAAoAgRGBH8gACADEFQgACgCCAUgAwsgACgCAGogAToAACAAIAAoAghBAWo2AggMAgsgAUGAgARPBEAgAiABQT9xQYABcjoADyACIAFBBnZBP3FBgAFyOgAOIAIgAUEMdkE/cUGAAXI6AA0gAiABQRJ2QQdxQfABcjoADEEEDAELIAIgAUE/cUGAAXI6AA4gAiABQQx2QeABcjoADCACIAFBBnZBP3FBgAFyOgANQQMLIQEgASAAKAIEIAAoAggiA2tLBEAgACADIAEQUiAAKAIIIQMLIAAoAgAgA2ogAkEMaiABEOABGiAAIAEgA2o2AggLIAJBEGokAEEAC8ACAgV/AX4jAEEwayIFJABBJyEDAkAgAEKQzgBUBEAgACEIDAELA0AgBUEJaiADaiIEQQRrIAAgAEKQzgCAIghCkM4Afn2nIgZB//8DcUHkAG4iB0EBdEG2y8AAai8AADsAACAEQQJrIAYgB0HkAGxrQf//A3FBAXRBtsvAAGovAAA7AAAgA0EEayEDIABC/8HXL1YgCCEADQALCyAIpyIEQeMASwRAIANBAmsiAyAFQQlqaiAIpyIEIARB//8DcUHkAG4iBEHkAGxrQf//A3FBAXRBtsvAAGovAAA7AAALAkAgBEEKTwRAIANBAmsiAyAFQQlqaiAEQQF0QbbLwABqLwAAOwAADAELIANBAWsiAyAFQQlqaiAEQTBqOgAACyACIAFByK/AAEEAIAVBCWogA2pBJyADaxAtIAVBMGokAAvBAgEDfyMAQYABayIEJAACQAJAAkACQCABKAIAIgJBEHFFBEAgAkEgcQ0BIAA1AgBBASABEEIhAAwECyAAKAIAIQBBACECA0AgAiAEakH/AGpBMEHXACAAQQ9xIgNBCkkbIANqOgAAIAJBAWshAiAAQQ9LIABBBHYhAA0ACyACQYABaiIAQYEBTw0BIAFBAUG0y8AAQQIgAiAEakGAAWpBACACaxAtIQAMAwsgACgCACEAQQAhAgNAIAIgBGpB/wBqQTBBNyAAQQ9xIgNBCkkbIANqOgAAIAJBAWshAiAAQQ9LIABBBHYhAA0ACyACQYABaiIAQYEBTw0BIAFBAUG0y8AAQQIgAiAEakGAAWpBACACaxAtIQAMAgsgAEGAAUGky8AAEMkBAAsgAEGAAUGky8AAEMkBAAsgBEGAAWokACAAC9cCAgR/An4jAEFAaiIDJAAgAAJ/IAAtAAgEQCAAKAIEIQVBAQwBCyAAKAIEIQUgACgCACIEKAIAIgZBBHFFBEBBASAEKAIYQerKwABBgcvAACAFG0ECQQEgBRsgBEEcaigCACgCDBEBAA0BGiABIAQgAigCDBEAAAwBCyAFRQRAIAQoAhhB/8rAAEECIARBHGooAgAoAgwRAQAEQEEAIQVBAQwCCyAEKAIAIQYLIANBAToAFyADQTRqQczKwAA2AgAgAyAGNgIYIAMgBCkCGDcDCCADIANBF2o2AhAgBCkCCCEHIAQpAhAhCCADIAQtACA6ADggAyAEKAIENgIcIAMgCDcDKCADIAc3AyAgAyADQQhqNgIwQQEgASADQRhqIAIoAgwRAAANABogAygCMEHoysAAQQIgAygCNCgCDBEBAAs6AAggACAFQQFqNgIEIANBQGskACAAC6MCAQR/IABCADcCECAAAn9BACABQYACSQ0AGkEfIAFB////B0sNABogAUEGIAFBCHZnIgJrdkEBcSACQQF0a0E+agsiAjYCHCACQQJ0QaDpwABqIQMCQAJAAkACQEGU58AAKAIAIgRBASACdCIFcQRAIAMoAgAhAyACEKoBIQIgAxDXASABRw0BIAMhAgwCC0GU58AAIAQgBXI2AgAgAyAANgIADAMLIAEgAnQhBANAIAMgBEEddkEEcWpBEGoiBSgCACICRQ0CIARBAXQhBCACIgMQ1wEgAUcNAAsLIAIoAggiASAANgIMIAIgADYCCCAAIAI2AgwgACABNgIIIABBADYCGA8LIAUgADYCAAsgACADNgIYIAAgADYCCCAAIAA2AgwLtgIBBX8gACgCGCEEAkACQCAAIAAoAgxGBEAgAEEUQRAgAEEUaiIBKAIAIgMbaigCACICDQFBACEBDAILIAAoAggiAiAAKAIMIgE2AgwgASACNgIIDAELIAEgAEEQaiADGyEDA0AgAyEFIAIiAUEUaiIDKAIAIgJFBEAgAUEQaiEDIAEoAhAhAgsgAg0ACyAFQQA2AgALAkAgBEUNAAJAIAAgACgCHEECdEGg6cAAaiICKAIARwRAIARBEEEUIAQoAhAgAEYbaiABNgIAIAENAQwCCyACIAE2AgAgAQ0AQZTnwABBlOfAACgCAEF+IAAoAhx3cTYCAA8LIAEgBDYCGCAAKAIQIgIEQCABIAI2AhAgAiABNgIYCyAAQRRqKAIAIgBFDQAgAUEUaiAANgIAIAAgATYCGAsLmAIBAX8jAEEQayICJAAgACgCACEAAn8CQCABKAIIQQFHBEAgASgCEEEBRw0BCyACQQA2AgwgASACQQxqAn8gAEGAAU8EQCAAQYAQTwRAIABBgIAETwRAIAIgAEE/cUGAAXI6AA8gAiAAQRJ2QfABcjoADCACIABBBnZBP3FBgAFyOgAOIAIgAEEMdkE/cUGAAXI6AA1BBAwDCyACIABBP3FBgAFyOgAOIAIgAEEMdkHgAXI6AAwgAiAAQQZ2QT9xQYABcjoADUEDDAILIAIgAEE/cUGAAXI6AA0gAiAAQQZ2QcABcjoADEECDAELIAIgADoADEEBCxAnDAELIAEoAhggACABQRxqKAIAKAIQEQAACyACQRBqJAALYAEMf0HA6sAAKAIAIgIEQEG46sAAIQYDQCACIgEoAgghAiABKAIEIQMgASgCACEEIAFBDGooAgAaIAEhBiAFQQFqIQUgAg0ACwtB0OrAACAFQf8fIAVB/x9LGzYCACAIC4sCAgR/AX4jAEEwayICJAAgAUEEaiEEIAEoAgRFBEAgASgCACEDIAJBEGoiBUEANgIAIAJCATcDCCACIAJBCGo2AhQgAkEoaiADQRBqKQIANwMAIAJBIGogA0EIaikCADcDACACIAMpAgA3AxggAkEUakHAocAAIAJBGGoQMBogBEEIaiAFKAIANgIAIAQgAikDCDcCAAsgAkEgaiIDIARBCGooAgA2AgAgAUEMakEANgIAIAQpAgAhBiABQgE3AgQgAiAGNwMYQQxBBBC4ASIBRQRAQQxBBBDbAQALIAEgAikDGDcCACABQQhqIAMoAgA2AgAgAEGAp8AANgIEIAAgATYCACACQTBqJAALzwIBAX9BwAEhAQJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAALQAAQQJrDiMjAQIDBAUGBwgJCgsMDQ4PEBESExQVFhcYGRobHB0eHyAhIgALIAAtAAEPC0HDAQ8LQcIBDwtBzAEPC0HNAQ8LQc4BDwtBzwEPC0HQAQ8LQdEBDwtB0gEPC0HTAQ8LQcoBDwtBywEPCyAALQABQR9xQaB/cg8LQdkBDwtB2gEPC0HbAQ8LQcQBDwtBxQEPC0HGAQ8LIAAtAAFBD3FBkH9yDwtB3AEPC0HdAQ8LIAAtAAFBD3FBgH9yDwtB3gEPC0HfAQ8LQdQBDwtB1QEPC0HWAQ8LQdcBDwtB2AEPC0HHAQ8LQcgBDwtByQEPC0HBASEBCyABC4kCAQJ/IwBBIGsiBSQAIAVBEGogASACIAMQLgJAIAUoAhAiAkECRgRAIAQoAgAhBiAFQRBqIAEgBEEIaigCACICEDMgBSgCECIDQQJGBEAgAiABKAIEIAEoAggiA2tLBH8gASADIAIQUiABKAIIBSADCyABKAIAaiAGIAIQ4AEaIABBBTYCACABIAEoAgggAmo2AggMAgsgBUEMaiAFQRpqIgEvAQAiAjsBACAFIAUoARYiBDYCCCAFLwEUIQYgASACOwEAIAUgBjsBFCAFIAM2AhAgBSAENgEWIAAgBUEQahCcAQwBCyAFIAUpAhQ3AhQgBSACNgIQIAAgBUEQahCcAQsgBUEgaiQAC+UBAQF/IwBBEGsiAiQAIAAoAgAgAkEANgIMIAJBDGoCfyABQYABTwRAIAFBgBBPBEAgAUGAgARPBEAgAiABQT9xQYABcjoADyACIAFBBnZBP3FBgAFyOgAOIAIgAUEMdkE/cUGAAXI6AA0gAiABQRJ2QQdxQfABcjoADEEEDAMLIAIgAUE/cUGAAXI6AA4gAiABQQx2QeABcjoADCACIAFBBnZBP3FBgAFyOgANQQMMAgsgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAQsgAiABOgAMQQELEDcgAkEQaiQAC+IBAQF/IwBBEGsiAiQAIAJBADYCDCAAIAJBDGoCfyABQYABTwRAIAFBgBBPBEAgAUGAgARPBEAgAiABQT9xQYABcjoADyACIAFBBnZBP3FBgAFyOgAOIAIgAUEMdkE/cUGAAXI6AA0gAiABQRJ2QQdxQfABcjoADEEEDAMLIAIgAUE/cUGAAXI6AA4gAiABQQx2QeABcjoADCACIAFBBnZBP3FBgAFyOgANQQMMAgsgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAQsgAiABOgAMQQELEDcgAkEQaiQAC+EBAAJAIABBIEkNAAJAAn9BASAAQf8ASQ0AGiAAQYCABEkNAQJAIABBgIAITwRAIABBsMcMa0HQuitJIABBy6YMa0EFSXINBCAAQZ70C2tB4gtJIABB4dcLa0GfGElyDQQgAEF+cUGe8ApGIABBop0La0EOSXINBCAAQWBxQeDNCkcNAQwECyAAQf7XwABBLEHW2MAAQcQBQZrawABBwgMQPg8LQQAgAEG67gprQQZJDQAaIABBgIDEAGtB8IN0SQsPCyAAQeDSwABBKEGw08AAQZ8CQc/VwABBrwIQPg8LQQALyAMCA34GfyMAQSBrIgckAAJAQbTmwAAoAgANAEHgksAAIQQCf0EAIABFDQAaIAAoAgAhBSAAQQA2AgBBACAFQQFHDQAaIAAoAhQhBiAAKAIMIQQgACgCCCEIIAAoAgQhCSAAKAIQCyEAQbTmwAApAgAhAUG05sAAQQE2AgBBuObAACAJNgIAQbzmwAApAgAhAkG85sAAIAg2AgBBwObAACAENgIAQcTmwAApAgAhA0HE5sAAIAA2AgBByObAACAGNgIAIAdBGGogAzcDACAHQRBqIgAgAjcDACAHIAE3AwggAadFDQACQCAAKAIAIghFDQACQCAAKAIMIgVFBEAgAEEEaigCACEADAELIAAoAgQiAEEIaiEGIAApAwBCf4VCgIGChIiQoMCAf4MhASAAIQQDQCABUARAA0AgBEHgAGshBCAGKQMAIAZBCGohBkJ/hUKAgYKEiJCgwIB/gyIBUA0ACwsgBUEBayEFIAQgAXqnQQN2QXRsakEEaygCACIJQSRPBEAgCRAACyABQgF9IAGDIQEgBQ0ACwsgCCAIQQFqrUIMfqdBB2pBeHEiBGpBd0YNACAAIARrECYLCyAHQSBqJABBuObAAAvpAQECfyMAQSBrIgIkACACIAA2AgwgAiABKAIYQajfwABBESABQRxqKAIAKAIMEQEAOgAYIAIgATYCECACQQA6ABkgAkEANgIUIAJBEGogAkEMakGY38AAEEQhAAJ/IAItABgiASACKAIUIgNFDQAaIAFB/wFxIQFBASABDQAaIAAoAgAhAAJAIANBAUcNACACLQAZRQ0AIAAtAABBBHENAEEBIAAoAhhBgsvAAEEBIABBHGooAgAoAgwRAQANARoLIAAoAhhB7MfAAEEBIABBHGooAgAoAgwRAQALIAJBIGokAEH/AXFBAEcL4QEAAkAgASgCAEECRgRAIAAgAikCADcCACAAQQhqIAJBCGooAgA2AgAMAQsgACABKQIANwIAIABBCGogAUEIaigCADYCAAJAAkACQAJAIAIoAgAOAwABBAELIAItAARBA0cNAyACQQhqIgAoAgAiASgCACABKAIEKAIAEQQAIAEoAgQiAkEEaigCAA0BDAILIAItAARBA0cNAiACQQhqIgAoAgAiASgCACABKAIEKAIAEQQAIAEoAgQiAkEEaigCAEUNAQsgAkEIaigCABogASgCABAmIAAoAgAhAQsgARAmCwvOAQECfyMAQSBrIgMkAAJAAkAgASABIAJqIgFLDQAgAEEEaigCACICQQF0IgQgASABIARJGyIBQQggAUEISxsiAUF/c0EfdiEEAkAgAgRAIANBATYCGCADIAI2AhQgAyAAKAIANgIQDAELIANBADYCGAsgAyABIAQgA0EQahBXIAMoAgQhAiADKAIARQRAIAAgAjYCACAAQQRqIAE2AgAMAgsgA0EIaigCACIAQYGAgIB4Rg0BIABFDQAgAiAAENsBAAsQiAEACyADQSBqJAALzgEBAn8jAEEgayIDJAACQAJAIAEgASACaiIBSw0AIABBBGooAgAiAkEBdCIEIAEgASAESRsiAUEIIAFBCEsbIgFBf3NBH3YhBAJAIAIEQCADQQE2AhggAyACNgIUIAMgACgCADYCEAwBCyADQQA2AhgLIAMgASAEIANBEGoQWCADKAIEIQIgAygCAEUEQCAAIAI2AgAgAEEEaiABNgIADAILIANBCGooAgAiAEGBgICAeEYNASAARQ0AIAIgABDbAQALEIgBAAsgA0EgaiQAC8wBAQN/IwBBIGsiAiQAAkACQCABQQFqIgFFDQAgAEEEaigCACIDQQF0IgQgASABIARJGyIBQQggAUEISxsiAUF/c0EfdiEEAkAgAwRAIAJBATYCGCACIAM2AhQgAiAAKAIANgIQDAELIAJBADYCGAsgAiABIAQgAkEQahBXIAIoAgQhAyACKAIARQRAIAAgAzYCACAAQQRqIAE2AgAMAgsgAkEIaigCACIAQYGAgIB4Rg0BIABFDQAgAyAAENsBAAsQiAEACyACQSBqJAAL0gEBAX8jAEEQayIEJAAgBCAAKAIYIAEgAiAAQRxqKAIAKAIMEQEAOgAIIAQgADYCACAEIAJFOgAJIARBADYCBCAEIANB6JzAABBEIQACfyAELQAIIgEgBCgCBCICRQ0AGkEBIAENABogACgCACEAAkAgAkEBRw0AIAQtAAlFDQAgAC0AAEEEcQ0AQQEgACgCGEGCy8AAQQEgAEEcaigCACgCDBEBAA0BGgsgACgCGEHsx8AAQQEgAEEcaigCACgCDBEBAAsgBEEQaiQAQf8BcUEARwuIAgECfyMAQSBrIgUkAEGE58AAQYTnwAAoAgAiBkEBajYCAAJAAkAgBkEASA0AQdzqwABB3OrAACgCAEEBaiIGNgIAIAZBAksNACAFIAQ6ABggBSADNgIUIAUgAjYCECAFQcinwAA2AgwgBUHYocAANgIIQfTmwAAoAgAiAkEASA0AQfTmwAAgAkEBaiICNgIAQfTmwABB/ObAACgCAAR/IAUgACABKAIQEQMAIAUgBSkDADcDCEH85sAAKAIAIAVBCGpBgOfAACgCACgCFBEDAEH05sAAKAIABSACC0EBazYCACAGQQFLDQAgBA0BCwALIwBBEGsiAiQAIAIgATYCDCACIAA2AggAC7oBAAJAIAIEQAJAAkACfwJAAkAgAUEATgRAIAMoAggNASABDQJBASECDAQLDAYLIAMoAgQiAkUEQCABRQRAQQEhAgwECyABQQEQuAEMAgsgAygCACACQQEgARCwAQwBCyABQQEQuAELIgJFDQELIAAgAjYCBCAAQQhqIAE2AgAgAEEANgIADwsgACABNgIEIABBCGpBATYCACAAQQE2AgAPCyAAIAE2AgQLIABBCGpBADYCACAAQQE2AgALrQEBAX8CQCACBEACfwJAAkACQCABQQBOBEAgAygCCEUNAiADKAIEIgQNASABDQMgAgwECyAAQQhqQQA2AgAMBQsgAygCACAEIAIgARCwAQwCCyABDQAgAgwBCyABIAIQuAELIgMEQCAAIAM2AgQgAEEIaiABNgIAIABBADYCAA8LIAAgATYCBCAAQQhqIAI2AgAMAQsgACABNgIEIABBCGpBADYCAAsgAEEBNgIAC6wBAQN/IwBBMGsiAiQAIAFBBGohAyABKAIERQRAIAEoAgAhASACQRBqIgRBADYCACACQgE3AwggAiACQQhqNgIUIAJBKGogAUEQaikCADcDACACQSBqIAFBCGopAgA3AwAgAiABKQIANwMYIAJBFGpBwKHAACACQRhqEDAaIANBCGogBCgCADYCACADIAIpAwg3AgALIABBgKfAADYCBCAAIAM2AgAgAkEwaiQAC6YBAQF/IwBB4ABrIgEkACABQRhqIABBEGopAgA3AwAgAUEQaiAAQQhqKQIANwMAIAEgACkCADcDCCABQQA2AiggAUIBNwMgIAFBMGoiACABQSBqQaiDwAAQkgEgAUEIaiAAEGpFBEAgASgCICABKAIoEOgBIAEoAiQEQCABKAIgECYLIAFB4ABqJAAPC0HAg8AAQTcgAUHYAGpB+IPAAEHUhMAAEGQAC9qtAQMyfip/AXwjAEEQayJPJAAgASE0IwBBgANrIkQkAEHM5sAAKAIAQQNHBEAgREEBOgAAIEQgRDYCuAEgREG4AWohPSMAQSBrIkUkACBFQQhqQQJyITtBzObAACgCACEBA0ACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIAEiNQ4EAAMCAQILQczmwABBAkHM5sAAKAIAIgEgASA1RiI4GzYCACA4RQ0NIEUgNUEBRjoADCBFQQM2AgggPSBFQQhqQbSOwAAoAgARAwBBzObAACgCACE1QczmwAAgRSgCCDYCACBFIDVBA3EiATYCACABQQJHDQggNUECayIBRQ0AA0AgASgCACE+IAFBADYCACA+RQ0KIAEoAgQgAUEBOgAIQQAhQyMAQSBrIj0kACA+QRhqIjsoAgAhASA7QQI2AgACQAJAAkAgAQ4DAgECAAsgPUEcakEANgIAID1B2KHAADYCGCA9QgE3AgwgPUHQrMAANgIIID1BCGpB2KzAABCJAQALIDstAAQhASA7QQE6AAQgPSABQQFxIgE6AAcCQAJAIAFFBEAgO0EEaiE4AkBBhOfAACgCAEH/////B3EEQBDqASEBIDstAAUEQCABQQFzIUMMAgsgAUUNBAwDCyA7LQAFRQ0CCyA9IEM6AAwgPSA4NgIIQceiwABBKyA9QQhqQfiqwABB6KzAABBkAAsgPUEANgIcID1B2KHAADYCGCA9QgE3AgwgPUHkqMAANgIIID1BB2ogPUEIahBsAAtBhOfAACgCAEH/////B3FFDQAQ6gENACA7QQE6AAULIDhBADoAAAsgPUEgaiQAID4gPigCACIBQQFrNgIAIAFBAUYEQCA+EH0LIgENAAsLIEVBIGokAAwLCyA1QQNxQQJGBEADQEHU6sAAKAIADQNB1OrAAEF/NgIAQdjqwAAoAgAiAUUEQEEgQQgQuAEiAUUNBSABQoGAgIAQNwMAIAFBEGpBADYCAEGI58AAKQMAIQIDQCACQgF8IgRQDQdBiOfAACAEQYjnwAApAwAiAyACIANRIjgbNwMAIAMhAiA4RQ0ACyABQQA7ARwgASAENwMIQdjqwAAgATYCACABQRhqQQA2AgALIAEgASgCACI4QQFqNgIAIDhBAEgNBiA1IThB1OrAAEHU6sAAKAIAQQFqNgIAQczmwAAgO0HM5sAAKAIAIjUgNSA4RiI+GzYCACBFQQA6ABAgRSABNgIIIEUgOEF8cTYCDCA+BEAgRS0AEEUNCAwLCwJAIEUoAggiAUUNACABIAEoAgAiAUEBazYCACABQQFHDQAgRSgCCBB9CyA1QQNxQQJGDQAMCwsAC0G0qcAAQcAAQcCQwAAQgwEACyBFQRxqQQA2AgAgRUHYocAANgIYIEVCATcCDCBFQaCqwAA2AgggRUEIakHAkMAAEIkBAAtB2KHAAEEQIEVB6KHAAEGMpcAAEGQAC0EgQQgQ2wEACxCHAQALAAsDQCMAQSBrIj4kAAJAAkACQAJAAkACQAJ/IwBBEGsiOCQAAkACQAJAQdTqwAAoAgBFBEBB1OrAAEF/NgIAQdjqwAAoAgAiNUUEQEEgQQgQuAEiNUUNAiA1QoGAgIAQNwMAIDVBEGpBADYCAEGI58AAKQMAIQIDQCACQgF8IgRQDQRBiOfAACAEQYjnwAApAwAiAyACIANRIgEbNwMAIAMhAiABRQ0ACyA1QQA7ARwgNSAENwMIQdjqwAAgNTYCACA1QRhqQQA2AgALIDUgNSgCACIBQQFqNgIAIAFBAEgNA0HU6sAAQdTqwAAoAgBBAWo2AgAgOEEQaiQAIDUMBAtB2KHAAEEQIDhBCGpB6KHAAEGMpcAAEGQAC0EgQQgQ2wEACxCHAQALAAsiOARAIDhBGGoiAUEAIAEoAgAiASABQQJGIgEbNgIAIAFFBEAgOEEcaiI1LQAAIQEgNUEBOgAAID4gAUEBcSIBOgAEIAENAkEAIUNBhOfAACgCAEH/////B3EEQBDqAUEBcyFDCyA4LQAdDQMgOCA4KAIYIgFBASABGzYCGCABRQ0GIAFBAkcNBCA4KAIYIQEgOEEANgIYID4gATYCBCABQQJHDQUCQCBDDQBBhOfAACgCAEH/////B3FFDQAQ6gENACA4QQE6AB0LIDVBADoAAAsgOCA4KAIAIgFBAWs2AgAgAUEBRgRAIDgQfQsgPkEgaiQADAYLIwBBEGsiACQAIABB3gA2AgwgAEH9osAANgIIIwBBIGsiASQAIAFBFGpBATYCACABQgE3AgQgAUGUycAANgIAIAFB+gA2AhwgASAAQQhqNgIYIAEgAUEYajYCECABQfijwAAQiQEACyA+QQA2AhwgPkHYocAANgIYID5CATcCDCA+QeSowAA2AgggPkEEaiA+QQhqEGwACyA+IEM6AAwgPiA1NgIIQceiwABBKyA+QQhqQfiqwABBvKvAABBkAAsgPkEcakEANgIAID5B2KHAADYCGCA+QgE3AgwgPkHkq8AANgIIID5BCGpB7KvAABCJAQALID5BADYCHCA+QdihwAA2AhggPkIBNwIMID5BnKzAADYCCCA+QQRqID5BCGpBpKzAABBtAAsgPkEcakEANgIAID5B2KHAADYCGCA+QgE3AgwgPkH0p8AANgIIID5BCGpBtKjAABCJAQALIEUtABBFDQALDAILIEVBADYCCCBFIEVBCGpB2KrAABBtAAtBnKLAAEErQeiqwAAQgwEACyBFKAIIIgFFDQAgASABKAIAIgFBAWs2AgAgAUEBRw0AIEUoAggQfUHM5sAAKAIAIQEMAgtBzObAACgCACEBDAELCwsgREG4AWohP0EAITVBACE+QQAhOEEAIUVBACE9IwBBsAJrIjYkACA2IDQ2AiwCQAJAAkACQAJAAkACQAJAAkACQAJAAn8CQAJAIDQQAkEBRgRAIDZBCDYCOCA2QdiLwAA2AjQgNiA0NgIwIDZBqAFqIU0gNkGgAWpBAXIhXUECIUMDQCA0IQEgNigCNCI6KAIAITsgNkEgaiI0IDooAgQ2AgQgNCA7NgIAIDZBoAFqITsgNigCICE0An8CQAJAAkACQAJAAkACQAJAAkAgNigCJEEFaw4GBgcBBwIABwsgNEGEi8AAQQoQ3wENA0EADAgLIDRBjovAAEEHEN8BDQFBAQwHCyA0QZWLwABBCRDfAQ0EQQIMBgsgNEGei8AAQQcQ3wENAUEDDAULIDRBpYvAAEEKEN8BDQNBBAwECyA0Qa+LwABBBxDfAQ0BQQUMAwtBCEEGIDRBtovAAEEFEN8BGwwCC0EIDAELQQhBByA0QbuLwABBChDfARsLITQgO0EAOgAAIDsgNDoAAQJAAkACfwJAIDYtAKABBEAgNigCpAEhNCA/QQI6AFAgPyA0NgIADAELAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAIDYtAKEBDggIBwYFBAMCAQALIDYoAjgiNEUNIyA2KAI0IjtFDSMgNiA0QQFrNgI4IDYgO0EIajYCNCA2QTBqIDsoAgAgOygCBBCMARDTASI0QSRJDRMgNBAADBMLIAinDQkgNigCOCI8RQ0iIDYoAjQiNEUNIiA2IDxBAWs2AjggNiA0QQhqNgI0IDYgNkEwaiA0KAIAIDQoAgQQjAEQ0wE2AqABIDZBEGohO0IAIQJCACEIIwBBEGsiOiQAIDogNkGgAWoiNCgCABAHAkAgOigCAEUNACA6KwMIIV4gNCgCABAYRQ0AIF5EAAAAAAAA4MNmITRCAEL///////////8AAn4gXplEAAAAAAAA4ENjBEAgXrAMAQtCgICAgICAgICAfwtCgICAgICAgICAfyA0GyBeRP///////99DZBsgXiBeYhshCEIBIQILIDsgCDcDCCA7IAI3AwAgOkEQaiQAAkAgNikDEEL/////D4MiAlAEQCA2QaABaiA2QagCakG8gcAAEDQhPAwBCyA2KQMYIQkLIDYoAqABIjRBJE8EQCA0EAALQgEhCCACUEUNEiA/QQI6AFAgPyA8NgIADBALIEkNBiA2KAI4IjRFDSEgNigCNCI7RQ0hIDYgNEEBazYCOCA2IDtBCGo2AjQgNiA2QTBqIDsoAgAgOygCBBCMARDTATYChAIgNkGIAmogNkGEAmoQXQJAIDYoAogCBEAgNkGgAmogNkGQAmooAgA2AgAgNiA2KQOIAjcDmAIgNkGgAWohUSMAQUBqIkkkACA2QZgCaiJCKAIAITwCQCBCQQhqKAIAIjtBIEYEQCBRQQA6AAAgUSA8KQAANwABIFFBGWogPEEYaikAADcAACBRQRFqIDxBEGopAAA3AAAgUUEJaiA8QQhqKQAANwAADAELIElBHGpBDjYCACBJQR82AhQgSUHEjMAANgIQIEkgOzYCJCBJIElBJGo2AhggSUECNgI8IElCAzcCLCBJQayMwAA2AiggSSBJQRBqIjo2AjggSSBJQShqIjQQNSBJQTBqIDs2AgAgSSA8NgIsIElBBjoAKCBJIEkoAgg2AhQgSSBJKAIAIjs2AhAgNCA6QciMwAAQZiE0IFFBAToAACBRIDQ2AgQgSSgCBEUNACA7ECYLIEJBBGooAgAEQCA8ECYLIElBQGskAAwBCyA2QYQCaiA2QagCakHsgMAAEDQhNCA2QQE6AKABIDYgNDYCpAELIDYoAoQCIjRBJE8EQCA0EAALIDYtAKABRQRAIDZBngFqIF1BAmotAAA6AAAgNkH4AWogTUEQaikCACICNwMAIDZBiAFqIE1BCGopAgA3AwAgNkGQAWogAjcDACA2QZgBaiBNQRhqLQAAOgAAIDYgXS8AADsBnAEgNiBNKQIANwOAASA2KAKkASFRQQEhSQwSCyA2KAKkASE0ID9BAjoAUCA/IDQ2AgAMDwsgUEUNDUH3gcAAQQcQfCE0ID9BAjoAUCA/IDQ2AgAMDgsgQ0ECRg0LQe2BwABBChB8ITQgP0ECOgBQID8gNDYCAAwNCyBORQ0IQeaBwABBBxB8ITQgP0ECOgBQID8gNDYCAAwMCyBUDQMgNigCOCI0RQ0dIDYoAjQiO0UNHSA2IDRBAWs2AjggNiA7QQhqNgI0IDYgNkEwaiA7KAIAIDsoAgQQjAEQ0wEiPDYCoAEgNiA8EAECQCA2KAIAIjQEQCA2NQIEQoGAgIAQfiECDAELIDZBoAFqIDZBqAJqQbyAwAAQNK0hAkEAITQgNigCoAEhPAsgPEEkTwRAIDwQAAsgNARAIFZFIFRFIAFFcnJFBEAgARAmCyACQiCIpyFaIAKnIVZBASFUDA8LID9BAjoAUCA/IAI+AgAMCwsgSEUNBUHWgcAAQQcQfCE0ID9BAjoAUCA/IDQ2AgAMCgsgNUUNA0HMgcAAQQoQfCE0ID9BAjoAUCA/IDQ2AgAMCQtB/oHAAEEFEHwhNCA/QQI6AFAgPyA0NgIADAgLQd2BwABBCRB8ITQgP0ECOgBQID8gNDYCAEEAIUJBASFUQQEhPiA1DAgLQYOCwABBChB8ITQgP0ECOgBQID8gNDYCAAwGCwJAIDYoAjgiNUUNACA2KAI0IjRFDQAgNiA1QQFrNgI4IDYgNEEIajYCNCA2IDZBMGogNCgCACA0KAIEEIwBENMBNgKIAiA2QegBaiA2QYgCahBdAkAgNigC6AEEQCBNIDZB8AFqKAIANgIAIDYgNikD6AE3A6ABIDZBmAJqIDZBoAFqEDYMAQsgNkGIAmogNkGoAmpBzIDAABA0ITUgNkEANgKYAiA2IDU2ApwCCyA2KAKIAiI1QSRPBEAgNRAACyA2KAKcAiE7IDYoApgCIjUEQCA2KAKgAiFbIAEhNCA7IUUMCgsgP0ECOgBQID8gOzYCAAwNCwwXCwJAIDYoAjgiNEUNACA2KAI0IjtFDQAgNiA0QQFrNgI4IDYgO0EIajYCNCA2QaABaiFSIDZBMGogOygCACA7KAIEEIwBENMBITQjAEHgAGsiQCQAIEAgNDYCJAJAAkAgQEEkaigCABAUBEAgQEEkaigCABAWITsgQEEYaiI0QQA6AAQgNCA7NgIAIEAtABwhNCBAKAIYIUgMAQsgQEHQAGohTCMAQRBrIjwkABAQITogQEEkaigCACI7IDoQESE0IDxBCGoQlQEgPCgCDCA0IDwoAggiNBshSwJAAkACQAJAIDRFBEAgSxALQQFGDQEgTEECOgAEIEtBJEkNAiBLEAAMAgsgTEEDOgAEIEwgSzYCAAwBCyBLIDsQEiE0IDwQlQEgPCgCBCA0IDwoAgAiNBshQgJAAkACQAJAIDRFBEAgQhACQQFHDQMgQhAMIjsQCyE0IDtBJEkNASA7EAAgNEEBRg0CDAMLIExBAzoABCBMIEI2AgAMAwsgNEEBRw0BCyBMQQA6AAQgTCBCNgIAIEtBJE8EQCBLEAALIDpBI0sNAwwECyBMQQI6AAQgQkEkSQ0AIEIQAAsgS0EkSQ0AIEsQAAsgOkEjTQ0BCyA6EAALIDxBEGokACBAKAJQIUgCfwJAAkAgQC0AVCI0QQJrDgIBAAMLIEgMAQsgQEEkaiBAQdAAakH8gMAAEDQLITQgUkEANgIAIFIgNDYCBAwBCyBAIEg2AiggQCA0QQFxOgAsIEBBEGogQEEoahBhIEAoAhQhSAJAAkACQAJAAkACQAJAIEAoAhBBAWsOAgMBAAsgQCBINgI8IEBBQGsgQEE8ahBdAkAgQCgCQARAIEBB2ABqIEBByABqKAIANgIAIEAgQCkDQDcDUCBAQTBqIUgjAEHQAGsiRiQAIEBB0ABqIjwoAgAhQgJAAkACQAJAAkAgPEEIaigCACJBQVhGBEAQYyE0IEhBADYCACBIIDQ2AgQMAQsgQUUNAyBBQQBIDQEgQUEBELgBIjRFDQIgNCBCIEEQ4AEhTCBBQQJNDQMgRkEoaiFKIwBBIGsiSyQAIEtBEGoiNEEDNgIEIDRB2pjAADYCAAJAAkACQAJAAkAgSygCFEEDRgRAIEwgSygCEEEDEN8BRQ0BCyBLQQhqIjRBBzYCBCA0Qd2YwAA2AgAgSygCCCE0AkAgSygCDCI6RQRAQQEhOwwBCyA6QQBIDQMgOkEBELgBIjtFDQQLIDsgNCA6EOABITQgSiA6NgIMIEogOjYCCCBKIDQ2AgQgSkEDOgAAIEogTC8AADsAASBKQQNqIExBAmotAAA6AAAMAQsgSkEGOgAACyBLQSBqJAAMAgsQiAEACyA6QQEQ2wEACyBGLQAoIjpBBkYEQCBIIEE2AgggSCBBNgIEIEggTDYCAAwBCyBGQQZqIjsgRi0AKzoAACBGIEYvACk7AQQgRikCLCECIEYoAjQhNCBMECYgRiA6OgAIIEYgRi8BBDsACSBGIDstAAA6AAsgRiA0NgIUIEYgAjcCDCBGQRo2AkQgRiBGQQhqNgJAIEZBATYCPCBGQgE3AiwgRkGcicAANgIoIEYgRkFAayI7NgI4IEZBGGogRkEoaiI0EDUgRkHIAGogRkEgaigCADYCACBGIEYpAxg3A0AgNCA7EHQgRigCKCI7IEYoAjAQ6AEhNCBGKAIsBEAgOxAmCyBGKAJEBEAgRigCQBAmCwJAIEYtAAhBA0cNACBGKAIQRQ0AIEYoAgwQJgsgSEEANgIAIEggNDYCBAsgPEEEaigCAARAIEIQJgsgRkHQAGokAAwDCxCIAQALIEFBARDbAQALQQMgQUG8jcAAEMoBAAsMAQsgQEE8aiBAQdAAakGcgcAAEDQhNCBAQQA2AjAgQCA0NgI0CyBAKAI8IjRBJE8EQCA0EAALIEAoAjAiOw0BIEAoAjQhSAwCC0EAEGIhSAwBCyBAKQI0IQIgQEEIaiBAQShqEGEgQCgCDCE0AkACQAJAAkAgQCgCCEEBaw4CAwEACyBAIDQ2AjwgQEFAayBAQTxqEF0CQCBAKAJABEAgQEHYAGogQEHIAGooAgA2AgAgQCBAKQNANwNQIEBBMGogQEHQAGoQNgwBCyBAQTxqIEBB0ABqQcyAwAAQNCE0IEBBADYCMCBAIDQ2AjQLIEAoAjwiNEEkTwRAIDQQAAsgQCgCMCI0DQEgQCgCNCE0DAILQQEQYiE0DAELIFIgQCkCNDcCECBSIDQ2AgwgUiACNwIEIFIgOzYCACBAKAIoIjxBJEkNBAwDCyBSQQA2AgAgUiA0NgIEIAKnRQ0BIDsQJgwBCyBSQQA2AgAgUiBINgIECyBAKAIoIjxBI00NAQsgPBAACwsgQCgCJCI0QSNLBEAgNBAACyBAQeAAaiQAIDYoAqQBITsgNigCoAEiSARAIDYoArQBIUsgNigCsAEhVyA2KAKsASFYIDYoAqgBIUwgASE0IDshRwwJCyA/QQI6AFAgPyA7NgIAQQAhSAwCCwwWCyA2KAI4IjRFDRUgNigCNCI+RQ0VIDYgNEEBazYCOCA2ID5BCGo2AjQgNiA2QTBqID4oAgAgPigCBBCMARDTASI0NgKgASA2QQhqIDQQAQJAIDYoAggiTgRAIDYoAgwhPgwBCyA2QaABaiA2QagCakG8gMAAEDQhPkEAIU4gNigCoAEhNAsgNEEkTwRAIDQQAAsgTgRAID4hPQwGCyA/QQI6AFAgPyA+NgIAQQAhTgsgNSE4QQEMCgsCQCA2KAI4IjRFDQAgNigCNCI7RQ0AIDYgNEEBazYCOCA2IDtBCGo2AjQgNkGgAWohSiA2QTBqIDsoAgAgOygCBBCMARDTASE0IwBB4AFrIkEkACBBIDQ2AgQCQCBBQQRqKAIAIjQQBEEBRwR/IDQQBUEBRgVBAQtFBEAgQSBBKAIENgLMASBBQdABaiBBQcwBahBdAkAgQSgC0AEEQCBBQRBqIEFB2AFqKAIANgIAIEEgQSkD0AE3AwggQUGIAWohPCMAQUBqIjkkACBBQQhqIjooAgAhQgJAIDpBCGooAgAiO0HAAEcEQCA5QRxqQQ42AgAgOUEONgIUIDlB+I3AADYCECA5IDs2AiQgOSA5QSRqNgIYIDlBAjYCPCA5QgM3AiwgOUHgjcAANgIoIDkgOUEQaiJDNgI4IDkgOUEoaiI0EDUgOUEwaiA7NgIAIDkgQjYCLCA5QQY6ACggOSA5KAIINgIUIDkgOSgCACI7NgIQIDQgQ0H8jcAAEGYhNCA8QQE6AAAgPCA0NgIEIDkoAgRFDQEgOxAmDAELIDxBADoAACA8IEIpAAA3AAEgPEE5aiBCQThqKQAANwAAIDxBMWogQkEwaikAADcAACA8QSlqIEJBKGopAAA3AAAgPEEhaiBCQSBqKQAANwAAIDxBGWogQkEYaikAADcAACA8QRFqIEJBEGopAAA3AAAgPEEJaiBCQQhqKQAANwAACyA6QQRqKAIABEAgQhAmCyA5QUBrJAAMAQsgQUHMAWogQUEIakGsgcAAEDQhNCBBQQE6AIgBIEEgNDYCjAELIEEoAswBIjRBJE8EQCA0EAALIEoCfyBBLQCIAUUEQCBKQQRqIEEtAIsBOgAAIEpBAmogQS8AiQE7AAAgQUHQAGoiNyBBQZgBaikDADcDACBBQdgAaiI5IEFBoAFqKQMANwMAIEFB4ABqIjwgQUGoAWopAwA3AwAgQUHoAGoiQiBBQbABaikDADcDACBBQfAAaiI6IEFBuAFqKQMANwMAIEFB+ABqIjQgQUHAAWopAwA3AwAgQUGAAWoiQyBBQcgBai0AADoAACBBIEFBkAFqKQMANwNIIEEoAowBITsgQUEQaiA3KQMAIgo3AwAgQUEYaiA5KQMAIgY3AwAgQUEgaiA8KQMAIgc3AwAgQUEoaiBCKQMAIgU3AwAgQUEwaiA6KQMAIgQ3AwAgQUE4aiA0KQMAIgM3AwAgQUFAayI0IEMtAAA6AAAgQSBBKQNIIgI3AwggSkEFaiA7NgAAIEpBCWogAjcAACBKQRFqIAo3AAAgSkEZaiAGNwAAIEpBIWogBzcAACBKQSlqIAU3AAAgSkExaiAENwAAIEpBOWogAzcAACBKQcEAaiA0LQAAOgAAIEpBAToAAUEADAELIEogQSgCjAE2AgRBAQs6AAAMAQsgSkEAOwEAIEEoAgQiNEEkSQ0AIDQQAAsgQUHgAWokACA2LQCgAUUEQCA2QcgAaiBNQQhqKQAANwMAIDZB0ABqIE1BEGopAAA3AwAgNkHYAGogTUEYaikAADcDACA2QeAAaiBNQSBqKQAANwMAIDZB6ABqIE1BKGopAAA3AwAgNkHwAGogTUEwaikAADcDACA2QfgAaiBNQThqLwAAOwEAIDYgTSkAADcDQCA2KAKkASE3IDYvAaIBITkgNi0AoQEhQwwFCyA/QQI6AFAgPyA2KAKkATYCAAwCCwwTCwJAIDYoAjgiNEUNACA2KAI0IjtFDQAgNiA0QQFrNgI4IDYgO0EIajYCNCA2IDZBMGogOygCACA7KAIEEIwBENMBNgKYAiA2QaABaiA2QZgCahBdAn8gNigCoAEiOwRAIDYoAqgBIVAgNigCpAEMAQsgNkGYAmogNkGoAmpBjIHAABA0CyFVIDYoApgCIjRBJE8EQCA0EAALAkAgO0UNACA2IFA2AqgBIDYgVTYCpAEgNiA7NgKgASA2QegBaiI7IDZBoAFqIjQpAgA3AgAgO0EIaiA0QQhqKAIANgIAIDYoAuwBIVUgNigC6AEiUEUNACA2KALwASFcDAQLID9BAjoAUCA/IFU2AgBBASFDQQAhQkEBITpBASE8DBALDBILQQAhQkEBIT4gNQshOEEBITxBASE6QQEhQwwMCyABITQLIDYoAjgNAAsMAQsgNkEsaiA2QagCakHcgMAAEDQhASA/QQI6AFAgPyABNgIAIDYoAiwiAUEkSQ0LIAEQAAwLCyA1RQRAIDQhAUHMgcAAQQoQeyE1ID9BAjoAUCA/IDU2AgAMAQsCQAJAAkACQAJAIEgEQCBURQ0BIE5FDQJBACEBIENBAkcEQCA2QdgBaiA2QfgAai8BADsBACA2QdABaiA2QfAAaikDADcDACA2QcgBaiA2QegAaikDADcDACA2QcABaiA2QeAAaikDADcDACA2QbgBaiA2QdgAaikDADcDACA2QbABaiA2QdAAaikDADcDACA2QagBaiA2QcgAaikDADcDACA2IDYpA0A3A6ABIEMhAQsgUEUNAyBJRQ0EIAhQDQUgPyA3NgBTID8gOTsAUSA/ID42AkAgPyA9NgI8ID8gTjYCOCA/IFs2AhAgPyBFNgIMID8gNTYCCCA/IDYpA6ABNwBXID9B3wBqIDZBqAFqKQMANwAAID9B5wBqIDZBsAFqKQMANwAAID9B7wBqIDZBuAFqKQMANwAAID9B9wBqIDZBwAFqKQMANwAAID9B/wBqIDZByAFqKQMANwAAID9BhwFqIDZB0AFqKQMANwAAID9BjwFqIDZB2AFqLwEAOwAAID8gUTYAlAEgPyAJNwMAID8gSDYCFCA/IEc2AhggPyBMNgIcID8gWDYCICA/IFc2AiQgPyBLNgIoID8gNDYCLCA/IFY2AjAgPyBaNgI0ID8gUDYCRCA/IFU2AkggPyBcNgJMID8gAToAUCA/QZMBaiA2QZ4Bai0AADoAACA/IDYvAZwBOwCRASA/IDYpA4ABNwCYASA/QaABaiA2QYgBaikDADcAACA/QagBaiA2QZABaikDADcAACA/QbABaiA2QZgBai0AADoAAAwPC0HWgcAAQQcQeyEBID9BAjoAUCA/IAE2AgBBASE+QQEhPEEBIToMCwtB3YHAAEEJEHshASA/QQI6AFAgPyABNgIAQQEhPkEBITwMCQtB5oHAAEEHEHshASA/QQI6AFAgPyABNgIAQQEhPgwHC0H3gcAAQQcQeyEBID9BAjoAUCA/IAE2AgAMBQtB/oHAAEEFEHshAQwDC0GDgsAAQQoQeyEBDAILQQELIT5BASE8QQEhOkEBIUNBACFCDAULID9BAjoAUCA/IAE2AgAgVUUNACBQECYLIFBFIT4gPUUNACBOECYLIE5FITwgNEUgVkVyDQAgNBAmCyBHBEAgSBAmCyBURSE6IFdFDQAgWBAmCyBIRSFDQQEhQgJAIEVFBEBBACFFDAELIDUQJgsgNCEBIDUhOAsgUEUEQCA4ITUMAQsgPkUEQCA4ITUMAQsgVUUEQCA4ITUMAQsgUBAmIDghNQsgPUUgTkUgPEVyckUEQCBOECYLIFZFIDogVHFFIAFFcnJFBEAgARAmCwJAIEhFIENBAXNyDQAgRwRAIEgQJgsgV0UNACBYECYLIEVFIEIgNUVyckUEQCA1ECYLCyA2KAIwIgFBI00NACABEAALIDZBsAJqJAAMAQtBjYLAAEErQZiDwAAQgwEACyBEKAK4ASE1AkACQAJAIEQtAIgCIgFBAkcEQCBEQQRyIERBuAFqQQRyQcwAEOABGiBEQdEAaiBEQYkCakHnABDgARogRCABOgBQIEQgNTYCACBEQfACaiFFIwBBgAFrIjwkAAJAAkACQEGAAUEBELgBIgEEQCA8QYAINgIUIDxCgAE3AgwgPCABNgIIIwBBMGsiOSQAIwBBIGsiNSQAIDVBmRA7AQggNUEIahBKIQEgPEEIaiI3KAIIIjggNygCBEYEQCA3IDhBARBSIDcoAgghOAsgPEEYaiFDIDcgOEEBajYCCCA3KAIAIDhqIAE6AAAgOUEgaiIBQRk6AAQgAUECNgIAIAFBBWpBCDoAACA1QSBqJAACQAJAAkACQAJAAkACQAJAAkAgOSgCICI+QQJHBEAgOUEcaiA5QSpqIjgvAQAiNDsBACA5IDkoASYiNTYCGCA5LwEkIQEgOCA0OwEAIDkgATsBJCA5ID42AiAgOSA1NgEmIDlBCGogOUEgahCcASA5KAIIIjVBBUcNAQsgOUEIaiA3QYSLwABBCiBEQQhqEEsgOSgCCEEFRw0BIDlBIGogN0GOi8AAQQcQLgJAIDkoAiAiAUECRgRAIwBBMGsiOiQAIDpBlgQ7AQggOkEIahBKIQEgOUEIaiE9IDcoAggiOCA3KAIERgRAIDcgOEEBEFIgNygCCCE4CyA3IDhBAWo2AgggNygCACA4aiABOgAAIERBFGoiOygCACEBIDpBIGogNyA7QQhqKAIAIjUQMwJAAkACQAJAAkACQCA6KAIgIj5BAkYEQCA1IDcoAgQgNygCCCJHa0sEQCA3IEcgNRBSIDcoAgghRwsgNygCACBHaiABIDUQ4AEaIDcgNSBHajYCCAwBCyA6QRxqIDpBKmoiOC8BACI0OwEAIDogOigBJiI1NgIYIDovASQhASA4IDQ7AQAgOiABOwEkIDogPjYCICA6IDU2ASYgOkEIaiA6QSBqEJwBIDooAghBBUcNAQsgO0EMaigCACEBIDpBIGogNyA7QRRqKAIAIjUQMyA6KAIgIj5BAkcNASA1IDcoAgQgNygCCCI4a0sEQCA3IDggNRBSIDcoAgghOAsgNygCACA4aiABIDUQ4AEaIDcgNSA4ajYCCAwCCyA9IDopAwg3AgAgPUEIaiA6QRBqKQMANwIADAMLIDpBHGogOkEqaiI4LwEAIjQ7AQAgOiA6KAEmIjU2AhggOi8BJCEBIDggNDsBACA6IAE7ASQgOiA+NgIgIDogNTYBJiA6QQhqIDpBIGoQnAEgOigCCEEFRw0BCyA9QQU2AgAMAQsgPSA6KQMINwIAID1BCGogOkEQaikDADcCAAsgOkEwaiQADAELIDkgOSkCJDcCJCA5IAE2AiAgOUEIaiA5QSBqEJwBCyA5KAIIQQVHDQIgOUEgaiA3QZWLwABBCRAuAkAgOSgCICI4QQJGBEAgOUEgaiA3IERBLGooAgAiASBEQTBqKAIAIAEbIERBNGooAgAQLiA5KAIgIjhBAkYNAQsgOSA5KQIkNwIkIDkgODYCICA5QQhqIDlBIGoQnAEgOSgCCEEFRw0ECyA5QSBqIDdBnovAAEEHEC4CQCA5KAIgIjhBAkYEQCA5QSBqIDcgREE4aigCACBEQUBrKAIAEC4gOSgCICI4QQJGDQELIDkgOSkCJDcCJCA5IDg2AiAgOUEIaiA5QSBqEJwBIDkoAghBBUcNBQsgOUEIaiE7IERB0ABqITUjAEEgayI9JAAgPUEQaiA3QaWLwABBChAuAkAgPSgCECIBQQJGBEAgNS0AAEUEQCA9QQI7ARAgPUEQahBKIQEgNygCCCI1IDcoAgRGBH8gNyA1QQEQUiA3KAIIBSA1CyA3KAIAaiABOgAAIDcgNygCCEEBajYCCCA7QQU2AgAMAgsgPUEQaiA3QcAAEDMgPSgCECI+QQJGBEAgNygCBCA3KAIIIgFrQT9NBH8gNyABQcAAEFIgNygCCAUgAQsgNygCAGoiNCA1QQFqIgEpAAA3AAAgNEE4aiABQThqKQAANwAAIDRBMGogAUEwaikAADcAACA0QShqIAFBKGopAAA3AAAgNEEgaiABQSBqKQAANwAAIDRBGGogAUEYaikAADcAACA0QRBqIAFBEGopAAA3AAAgNEEIaiABQQhqKQAANwAAIDcgNygCCEFAazYCCCA7QQU2AgAMAgsgPUEMaiA9QRpqIjgvAQAiNDsBACA9ID0oARYiNTYCCCA9LwEUIQEgOCA0OwEAID0gATsBFCA9ID42AhAgPSA1NgEWIDsgPUEQahCcAQwBCyA9ID0pAhQ3AhQgPSABNgIQIDsgPUEQahCcAQsgPUEgaiQAIDkoAghBBUcNBSA5QQhqIDdBr4vAAEEHIERBxABqEEsgOSgCCEEFRw0GIDlBCGohOyBEQZEBaiE1IwBBIGsiPSQAID1BEGogN0G2i8AAQQUQLgJAID0oAhAiAUECRgRAID1BEGogN0EgEDMgPSgCECI+QQJGBEAgNygCBCA3KAIIIgFrQR9NBH8gNyABQSAQUiA3KAIIBSABCyA3KAIAaiIBIDUpAAA3AAAgAUEYaiA1QRhqKQAANwAAIAFBEGogNUEQaikAADcAACABQQhqIDVBCGopAAA3AAAgO0EFNgIAIDcgNygCCEEgajYCCAwCCyA9QQxqID1BGmoiOC8BACI0OwEAID0gPSgBFiI1NgIIID0vARQhASA4IDQ7AQAgPSABOwEUID0gPjYCECA9IDU2ARYgOyA9QRBqEJwBDAELID0gPSkCFDcCFCA9IAE2AhAgOyA9QRBqEJwBCyA9QSBqJAAgOSgCCEEFRw0HIDlBCGohOyMAQSBrIkckACBHQRBqIDdBu4vAAEEKEC4CQCBHKAIQIgFBAkYEQCBHQRBqIT0gRCkDACECIwBBMGsiOiQAAkAgAkJgWgRAIDogAqdBCHRBAXIiNDsBICA6QSBqEEohASA3KAIIIjUgNygCBEYEQCA3IDVBARBSIDcoAgghNQsgNyA1QQFqNgIIIDcoAgAgNWogAToAACA9QQI2AgAgPSA0OwEEDAELIAJCgAF8Qt8AWARAIDpBCTsBICA6QSBqEEohASA3KAIIIjggNygCBEYEQCA3IDhBARBSIDcoAgghOAsgNyA4QQFqIjU2AgggNygCACA4aiABOgAAIDUgNygCBEYEQCA3IDVBARBSIDcoAgghNQsgPUEJOgAEID1BAjYCACA3IDVBAWo2AgggNygCACA1aiACPAAADAELIAJCgIACfEL//gFYBEAgOkEKOwEgIDpBIGoQSiEBIDcoAggiOCA3KAIERgRAIDcgOEEBEFIgNygCCCE4CyA3IDhBAWoiNTYCCCA3KAIAIDhqIAE6AAAgNygCBCA1a0EBTQRAIDcgNUECEFIgNygCCCE1CyA9QQo6AAQgPUECNgIAIDcgNUECajYCCCA3KAIAIDVqIAKnIgFBCHQgAUGA/gNxQQh2cjsAAAwBCyACQoCAgIAIfEL///3/B1gEQCA6QQs7ASAgOkEgahBKIQEgNygCCCI1IDcoAgRGBEAgNyA1QQEQUiA3KAIIITULIDcgNUEBaiI4NgIIIDcoAgAgNWogAToAACA3KAIEIDhrQQNNBEAgNyA4QQQQUiA3KAIIITgLID1BCzoABCA9QQI2AgAgNyA4QQRqNgIIIDcoAgAgOGogAqciAUEIdEGAgPwHcSABQRh0ciABQQh2QYD+A3EgAUEYdnJyNgAADAELAkACQCACQoCAgIB4WQRAIAJCgAFaDQIjAEEQayI4JAAgOCACpyI0QQh0OwEIIDhBCGoQSiEBIDcoAggiNSA3KAIERgRAIDcgNUEBEFIgNygCCCE1CyA3IDVBAWo2AgggNygCACA1aiABOgAAIDpBEGoiAUEEOgAAIDhBEGokACA6IDQ6ACIgOkEEOwEgIDpBCGogOkEgaiI1IAEgAS0AACIBQQRGGykCADcCAAJAIAFBBEYNACA1LQAAQQNHDQAgNSgCBCI1KAIAIDUoAgQoAgARBAAgNSgCBCIBQQRqKAIABEAgAUEIaigCABogNSgCABAmCyA1ECYLIDotAAhBBEcNASA9IDovAAk7AQQgPUECNgIADAMLIDpBDDsBICA6QSBqEEohASA3KAIIIjggNygCBEYEQCA3IDhBARBSIDcoAgghOAsgNyA4QQFqIjU2AgggNygCACA4aiABOgAAIDcoAgQgNWtBB00EQCA3IDVBCBBSIDcoAgghNQsgPUEMOgAEID1BAjYCACA3IDVBCGo2AgggNygCACA1aiACQiiGQoCAgICAgMD/AIMgAkI4hoQgAkIYhkKAgICAgOA/gyACQgiGQoCAgIDwH4OEhCACQgiIQoCAgPgPgyACQhiIQoCA/AeDhCACQiiIQoD+A4MgAkI4iISEhDcAAAwCCyA9IDopAwg3AgQgPUEANgIADAELAkAgAkKAAloEQCACQoCABFQNASACQoCAgIAQWgRAIwBBEGsiNCQAIDRBCDsBCCA0QQhqEEohASA3KAIEIkIgNygCCCI1RgRAIDcgNUEBEFIgNygCBCFCIDcoAgghNQsgNyA1QQFqIjg2AgggNSA3KAIAIjVqIAE6AAAgQiA4a0EHTQRAIDcgOEEIEFIgNygCCCE4IDcoAgAhNQsgOkEQaiIBQQI2AgAgNyA4QQhqNgIIIDUgOGogAkIohkKAgICAgIDA/wCDIAJCOIaEIAJCGIZCgICAgIDgP4MgAkIIhkKAgICA8B+DhIQgAkIIiEKAgID4D4MgAkIYiEKAgPwHg4QgAkIoiEKA/gODIAJCOIiEhIQ3AAAgNEEQaiQAIDpBAjYCICA6QQg6ACQgPSABIDpBIGoQUQwDCyMAQRBrIjQkACA0QQc7AQggNEEIahBKIQEgNygCBCJCIDcoAggiNUYEQCA3IDVBARBSIDcoAgQhQiA3KAIIITULIDcgNUEBaiI4NgIIIDUgNygCACI1aiABOgAAIEIgOGtBA00EQCA3IDhBBBBSIDcoAgghOCA3KAIAITULIDpBEGoiAUECNgIAIDcgOEEEajYCCCA1IDhqIAKnIjVBCHRBgID8B3EgNUEYdHIgNUEIdkGA/gNxIDVBGHZycjYAACA0QRBqJAAgOkECNgIgIDpBBzoAJCA9IAEgOkEgahBRDAILIwBBEGsiNCQAIDRBBTsBCCA0QQhqEEohASA3KAIEIkIgNygCCCI1RgRAIDcgNUEBEFIgNygCBCFCIDcoAgghNQsgNyA1QQFqIjg2AgggNSA3KAIAIjVqIAE6AAAgOCBCRgRAIDcgQkEBEFIgNygCCCE4IDcoAgAhNQsgOkEQaiIBQQI2AgAgNyA4QQFqNgIIIDUgOGogAjwAACA0QRBqJAAgOkECNgIgIDpBBToAJCA9IAEgOkEgahBRDAELIwBBEGsiPiQAID5BBjsBCCA+QQhqEEohASA3KAIEIkIgNygCCCI1RgRAIDcgNUEBEFIgNygCBCFCIDcoAgghNQsgNyA1QQFqIjg2AgggNSA3KAIAIjVqIAE6AAAgQiA4a0EBTQRAIDcgOEECEFIgNygCCCE4IDcoAgAhNQsgOkEQaiI0QQI2AgAgNyA4QQJqNgIIIDUgOGogAqciAUEIdCABQYD+A3FBCHZyOwAAID5BEGokACA6QQI2AiAgOkEGOgAkID0gNCA6QSBqEFELIDpBMGokACBHKAIQIj5BAkYEQCA7QQU2AgAMAgsgR0EMaiBHQRpqIjgvAQAiNDsBACBHIEcoARYiNTYCCCBHLwEUIQEgOCA0OwEAIEcgATsBFCBHID42AhAgRyA1NgEWIDsgR0EQahCcAQwBCyBHIEcpAhQ3AhQgRyABNgIQIDsgR0EQahCcAQsgR0EgaiQAIDkoAghBBUYEQCBDQQU2AgAMCQsgQyA5KQMINwIAIENBCGogOUEQaikDADcCAAwICyA5KAIMIQEgQyA5KQMQNwIIIEMgATYCBCBDIDU2AgAMBwsgQyA5KQMINwIAIENBCGogOUEQaikDADcCAAwGCyBDIDkpAwg3AgAgQ0EIaiA5QRBqKQMANwIADAULIEMgOSkDCDcCACBDQQhqIDlBEGopAwA3AgAMBAsgQyA5KQMINwIAIENBCGogOUEQaikDADcCAAwDCyBDIDkpAwg3AgAgQ0EIaiA5QRBqKQMANwIADAILIEMgOSkDCDcCACBDQQhqIDlBEGopAwA3AgAMAQsgQyA5KQMINwIAIENBCGogOUEQaikDADcCAAsgOUEwaiQAIDwoAhhBBUYNAiA8QUBrIDxBIGopAwA3AwAgPCA8KQMYNwM4IDxBADYCUCA8QgE3A0ggPEHYAGoiNSA8QcgAakHIicAAEJIBIwBBMGsiNCQAAn8CQAJAAkACQAJAIDxBOGoiASgCAEEBaw4EAQIDBAALIDQgAUEEajYCCCA0QSRqQQE2AgAgNEIBNwIUIDRBoJ7AADYCECA0QdkANgIsIDQgNEEoajYCICA0IDRBCGo2AiggNSA0QRBqEGsMBAsgNUHIncAAQcAAEK0BDAMLIDQgASkCBDcDCCA0QSRqQQE2AgAgNEIBNwIUIDRBwJ3AADYCECA0QdoANgIsIDQgNEEoajYCICA0IDRBCGo2AiggNSA0QRBqEGsMAgsgNUGLncAAQRQQrQEMAQsgNSABQQRqKAIAIAFBDGooAgAQrQELIDRBMGokAA0BIDxBMGogPEHQAGooAgA2AgAgPCA8KQNINwMoAkACQAJAIDwoAjgOBAECAgIACyA8QUBrKAIARQ0BIDwoAjwQJgwBCyA8QUBrLQAAIQECQAJAIDwoAjxFBEAgAUEDRw0DIDxBxABqKAIAIgEoAgAgASgCBCgCABEEACABKAIEIjRBBGooAgANAQwCCyABQQNHDQIgPEHEAGooAgAiASgCACABKAIEKAIAEQQAIAEoAgQiNEEEaigCAEUNAQsgNEEIaigCABogASgCABAmCyA8KAJEECYLIEUgPCkDKDcCBCBFQQxqIDxBMGooAgA2AgAgRUEANgIAIDwoAgxFDQMgPCgCCBAmDAMLQYABQQEQ2wEAC0HgicAAQTcgPEEoakGYisAAQfSKwAAQZAALIEUgPCkDCDcCBCBFQQI2AgAgRUEMaiA8QRBqKAIANgIACyA8QYABaiQAIEQoAvACQQJHBEAgREHAAWogREH4AmopAwA3AwAgRCBEKQPwAjcDuAECfyMAQUBqIjQkACA0QQA2AgggNEIBNwMAIDRBEGoiASA0QfSFwAAQkgEjAEEwayI4JAAgOCBEQbgBaiI1NgIMIDhBJGpBATYCACA4QgE3AhQgOEHUnMAANgIQIDhB1gA2AiwgOCA4QShqNgIgIDggOEEMajYCKCABIDhBEGoQayA4QTBqJABFBEAgNCgCACA0KAIIEAMgNCgCBARAIDQoAgAQJgsgNUEIaigCAARAIDUoAgQQJgsgNEFAayQADAELQYyGwABBNyA0QThqQcSGwABBoIfAABBkAAshNAwCCyBEQfgCaigCACE0IEQoAvQCIkdFDQEgREH8AmooAgAhQyMAQSBrIkIkACMAQdACayI5JAAgOUHmAGpBAEGgARDeARogOUEAOgBlIDlBADYCYEEBITogOUEBOgCKAiA5QYECNgGGAiA5QgA3A1ggOUEgOgBkIDlC+cL4m5Gjs/DbADcDyAIgOULr+obav7X2wR83A8ACIDlCn9j52cKR2oKbfzcDuAIgOULRhZrv+s+Uh9EANwOwAiA5QvHt9Pilp/2npX83A6gCIDlCq/DT9K/uvLc8NwOgAiA5QrvOqqbY0Ouzu383A5gCIDlCqJL3lf/M+YTqADcDkAIjAEGAAWsiASQAIDlBkAJqIjwpAzghKiA8KQMwISsgPCkDKCEsIDwpAyAhLSA8KQMYIS8gPCkDECEwIDwpAwghMSA8KQMAITIgAUEAQYABEN4BIT0gR0EAIENBAWsiASABIENLG0GAf3EiRSBDIEMgRUsbIgFqITUCQCBDIAFrIjhB/wBLBEBBgAEhOAwBCyA9IDUgOBDgASE1CyBFQYABaiE7AkACQAJAA0BCfyEJIDghPiA1IQEgRSBTRwRAIFNBgH9GDQIgU0GAAWogQ0sNA0IAIQlBgAEhPiBHIFNqIQELIC0gASkAKCIaIAEpACAiGyArIDB8fCICfCACIAmFQuv6htq/tfbBH4VCIIkiBEKr8NP0r+68tzx8IgMgK4VCKIkiAnwiFiAEhUIwiSITIAN8Ig8gAoVCAYkiCyABKQBQIhwgASkAGCIdIAEpABAiHiAsIDF8fCICfCACIDMgLiAuID6tfCIuVq18IjOFQp/Y+dnCkdqCm3+FQiCJIgZCxbHV2aevlMzEAH0iCiAshUIoiSIHfCIFfHwiAyABKQBYIh98IAsgAyABKQAIIiAgASkAACIhIC0gMnx8IgJ8IC0gAiAuhULRhZrv+s+Uh9EAhUIgiSICQoiS853/zPmE6gB8Ig6FQiiJIhB8IgQgAoVCMIkiDIVCIIkiFyABKQA4IiIgASkAMCIjICogL3x8IgJ8IAJC+cL4m5Gjs/DbAIVCIIkiA0KPkouH2tiC2NoAfSICICqFQiiJIg18IgggA4VCMIkiAyACfCIJfCIYhUIoiSIUfCIRIBt8IAcgCiAFIAaFQjCJIgZ8IgqFQgGJIgUgASkAQCIkIAR8fCICIAEpAEgiJXwgBSAPIAIgA4VCIIkiBHwiA4VCKIkiAnwiEiAEhUIwiSIVIAN8IgsgAoVCAYkiB3wiBSAkfCAHIAUgCSANhUIBiSIEIBYgASkAYCImfHwiAiABKQBoIid8IAQgAiAGhUIgiSIDIAwgDnwiAnwiDoVCKIkiD3wiBiADhUIwiSIMhUIgiSIZIAEpAHAiKCAIIAIgEIVCAYkiBHx8IgIgASkAeCIpfCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiFoVCKIkiE3wiECAhfCARIBeFQjCJIgcgGHwiCiAUhUIBiSIFIAYgJXx8IgIgKXwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiESAEhUIwiSIUIAN8IgsgAoVCAYkiBnwiBSAefCAGIAUgCSANhUIBiSIEIBIgKHx8IgIgHHwgBCACIAeFQiCJIgMgDCAOfCICfCIOhUIoiSISfCIHIAOFQjCJIgyFQiCJIhcgAiAPhUIBiSIEIAggJ3x8IgIgI3wgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhiFQiiJIhV8Ig8gJnwgEyAWIBAgGYVCMIkiBnwiCoVCAYkiBSAHICB8fCICICZ8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhAgBIVCMIkiEyADfCILIAKFQgGJIgd8IgUgIXwgByAFIAkgDYVCAYkiBCARIB98fCICICJ8IAQgAiAGhUIgiSIDIAwgDnwiAnwiDoVCKIkiEXwiBiADhUIwiSIMhUIgiSIZIAIgEoVCAYkiBCAIIBp8fCICIB18IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIWhUIoiSIUfCISIB18IBUgGCAPIBeFQjCJIgd8IgqFQgGJIgUgBiAafHwiAiAefCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIPIASFQjCJIhUgA3wiCyAChUIBiSIGfCIFICN8IAYgBSAJIA2FQgGJIgQgECAffHwiAiAkfCAEIAIgB4VCIIkiAyAMIA58IgJ8Ig6FQiiJIhB8IgcgA4VCMIkiDIVCIIkiFyACIBGFQgGJIgQgCCApfHwiAiAnfCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiGIVCKIkiE3wiESAdfCAUIBYgEiAZhUIwiSIGfCIKhUIBiSIFIAcgHHx8IgIgKHwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiEiAEhUIwiSIUIAN8IgsgAoVCAYkiB3wiBSAgfCAHIAUgCSANhUIBiSIEIA8gInx8IgIgIHwgBCACIAaFQiCJIgMgDCAOfCICfCIOhUIoiSIPfCIGIAOFQjCJIgyFQiCJIhkgAiAQhUIBiSIEIAggJXx8IgIgG3wgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhaFQiiJIhV8IhAgGnwgEyAYIBEgF4VCMIkiB3wiCoVCAYkiBSAGICd8fCICICZ8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhEgBIVCMIkiEyADfCILIAKFQgGJIgZ8IgUgHHwgBiAFIAkgDYVCAYkiBCASICJ8fCICICV8IAQgAiAHhUIgiSIDIAwgDnwiAnwiDoVCKIkiEnwiByADhUIwiSIMhUIgiSIXIAIgD4VCAYkiBCAIIB98fCICICh8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIYhUIoiSIUfCIPIBp8IBUgFiAQIBmFQjCJIgZ8IgqFQgGJIgUgByAefHwiAiAjfCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIQIASFQjCJIhUgA3wiCyAChUIBiSIHfCIFICJ8IAcgBSAJIA2FQgGJIgQgESAbfHwiAiAhfCAEIAIgBoVCIIkiAyAMIA58IgJ8Ig6FQiiJIhF8IgYgA4VCMIkiDIVCIIkiGSACIBKFQgGJIgQgCCApfHwiAiAkfCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiFoVCKIkiE3wiEiAffCAUIBggDyAXhUIwiSIHfCIKhUIBiSIFIAYgHnx8IgIgG3wgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiDyAEhUIwiSIUIAN8IgsgAoVCAYkiBnwiBSAmfCAGIAUgCSANhUIBiSIEIBAgJXx8IgIgIXwgBCACIAeFQiCJIgMgDCAOfCICfCIOhUIoiSIQfCIHIAOFQjCJIgyFQiCJIhcgAiARhUIBiSIEIAggHHx8IgIgKXwgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhiFQiiJIhV8IhEgI3wgEyAWIBIgGYVCMIkiBnwiCoVCAYkiBSAHICh8fCICICB8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhIgBIVCMIkiEyADfCILIAKFQgGJIgd8IgUgHHwgByAFIAkgDYVCAYkiBCAPICN8fCICICR8IAQgAiAGhUIgiSIDIAwgDnwiAnwiDoVCKIkiD3wiBiADhUIwiSIMhUIgiSIZIAIgEIVCAYkiBCAIIB18fCICICd8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIWhUIoiSIUfCIQICJ8IBUgGCARIBeFQjCJIgd8IgqFQgGJIgUgBiAhfHwiAiAffCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIRIASFQjCJIhUgA3wiCyAChUIBiSIGfCIFIBp8IAYgBSAJIA2FQgGJIgQgEiAefHwiAiAmfCAEIAIgB4VCIIkiAyAMIA58IgJ8Ig6FQiiJIhJ8IgcgA4VCMIkiDIVCIIkiFyACIA+FQgGJIgQgCCAkfHwiAiAdfCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiGIVCKIkiE3wiDyAgfCAUIBYgECAZhUIwiSIGfCIKhUIBiSIFIAcgG3x8IgIgJ3wgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiECAEhUIwiSIUIAN8IgsgAoVCAYkiB3wiBSApfCAHIAUgCSANhUIBiSIEIBEgKXx8IgIgKHwgBCACIAaFQiCJIgMgDCAOfCICfCIOhUIoiSIRfCIGIAOFQjCJIgyFQiCJIhkgAiAShUIBiSIEIAggIHx8IgIgJXwgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhaFQiiJIhV8IhIgI3wgEyAPIBeFQjCJIgcgGHwiCoVCAYkiBSAGICh8fCICICd8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8Ig8gBIVCMIkiEyADfCILIAKFQgGJIgZ8IgUgHXwgBiAFIAkgDYVCAYkiBCAQICZ8fCICIBp8IAQgAiAHhUIgiSIDIAwgDnwiAnwiDoVCKIkiEHwiByADhUIwiSIMhUIgiSIXIAIgEYVCAYkiBCAIIBt8fCICIBx8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIYhUIoiSIUfCIRICJ8IBUgEiAZhUIwiSIGIBZ8IgqFQgGJIgUgByAhfHwiAiAifCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCISIASFQjCJIhUgA3wiCyAChUIBiSIHfCIFICh8IAcgBSAJIA2FQgGJIgQgDyAlfHwiAiAefCAEIAIgBoVCIIkiAyAMIA58IgJ8Ig6FQiiJIg98IgYgA4VCMIkiDIVCIIkiGSACIBCFQgGJIgQgCCAkfHwiAiAffCAEIAIgE4VCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiFoVCKIkiE3wiECApfCAUIBEgF4VCMIkiByAYfCIKhUIBiSIFIAYgJnx8IgIgIHwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiESAEhUIwiSIUIAN8IgsgAoVCAYkiBnwiBSAbfCAGIAUgCSANhUIBiSIEIBIgJ3x8IgIgH3wgBCACIAeFQiCJIgMgDCAOfCICfCIOhUIoiSISfCIHIAOFQjCJIgyFQiCJIhcgAiAPhUIBiSIEIAggHXx8IgIgJXwgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhiFQiiJIhV8Ig8gKHwgEyAQIBmFQjCJIgYgFnwiCoVCAYkiBSAHIBp8fCICICF8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhMgBIVCMIkiECADfCILIAKFQgGJIgd8IgUgJXwgByAFIAkgDYVCAYkiBCARICR8fCICICN8IAQgAiAGhUIgiSIDIAwgDnwiAnwiDoVCKIkiEXwiBiADhUIwiSIMhUIgiSIZIAIgEoVCAYkiBCAIIB58fCICIBx8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIWhUIoiSIUfCISICd8IBUgDyAXhUIwiSIHIBh8IgqFQgGJIgUgBiAffHwiAiAdfCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIPIASFQjCJIhUgA3wiCyAChUIBiSIGfCIFICJ8IAYgBSAJIA2FQgGJIgQgEyAjfHwiAiApfCAEIAIgB4VCIIkiAyAMIA58IgJ8Ig6FQiiJIhN8IgcgA4VCMIkiDIVCIIkiFyACIBGFQgGJIgQgCCAhfHwiAiAkfCAEIAIgEIVCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiGIVCKIkiEHwiESAkfCAUIBIgGYVCMIkiBiAWfCIKhUIBiSIFIAcgJnx8IgIgHnwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiEiAEhUIwiSIUIAN8IgsgAoVCAYkiB3wiBSAbfCAHIAUgCSANhUIBiSIEIA8gIHx8IgIgG3wgBCACIAaFQiCJIgMgDCAOfCICfCIOhUIoiSIPfCIGIAOFQjCJIgyFQiCJIhkgAiAThUIBiSIEIAggHHx8IgIgGnwgBCACIBWFQiCJIgMgCnwiAoVCKIkiDXwiCCADhUIwiSIDIAJ8Igl8IhaFQiiJIhV8IhMgJXwgECARIBeFQjCJIgcgGHwiCoVCAYkiBSAGICJ8fCICICN8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhAgBIVCMIkiESADfCILIAKFQgGJIgZ8IgUgKHwgBiAFIAkgDYVCAYkiBCASIBx8fCICIB58IAQgAiAHhUIgiSIDIAwgDnwiAnwiDoVCKIkiEnwiByADhUIwiSIMhUIgiSIXIAIgD4VCAYkiBCAIICB8fCICIBp8IAQgAiAUhUIgiSIDIAp8IgKFQiiJIg18IgggA4VCMIkiAyACfCIJfCIYhUIoiSIUfCIPIB58IBUgEyAZhUIwiSIGIBZ8IgqFQgGJIgUgByApfHwiAiAffCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIVIASFQjCJIhMgA3wiCyAChUIBiSIHfCIFIB18IAcgBSAJIA2FQgGJIgQgECAdfHwiAiAmfCAEIAIgBoVCIIkiAyAMIA58IgJ8Ig6FQiiJIhB8IgYgA4VCMIkiDIVCIIkiGSACIBKFQgGJIgQgCCAnfHwiAiAhfCAEIAIgEYVCIIkiAyAKfCIChUIoiSINfCIIIAOFQjCJIgMgAnwiCXwiFoVCKIkiEXwiEiAcfCAUIA8gF4VCMIkiByAYfCIKhUIBiSIFIAYgG3x8IgIgGnwgBSACIAOFQiCJIgQgC3wiA4VCKIkiAnwiDyAEhUIwiSIXIAN8IgsgAoVCAYkiBnwiBSAffCAGIAUgCSANhUIBiSIEIBUgIXx8IgIgIHwgBCACIAeFQiCJIgMgDCAOfCICfCIOhUIoiSIYfCIHIAOFQjCJIgyFQiCJIhQgAiAQhUIBiSIEIAggI3x8IgIgInwgBCACIBOFQiCJIgMgCnwiAoVCKIkiDXwiFSADhUIwiSIDIAJ8Igh8IhOFQiiJIhB8IgkgG3wgESASIBmFQjCJIgogFnwiBoVCAYkiBSAHICR8fCICICV8IAUgAiADhUIgiSIEIAt8IgOFQiiJIgJ8IhEgBIVCMIkiEiADfCILIAKFQgGJIgd8IgUgJHwgByAFIAggDYVCAYkiBCAPICZ8fCICICd8IAQgAiAKhUIgiSIDIAwgDnwiAnwiD4VCKIkiDnwiDCADhUIwiSINhUIgiSIZIAIgGIVCAYkiBCAVICh8fCICICl8IAQgAiAXhUIgiSIDIAZ8IgKFQiiJIgp8IgggA4VCMIkiAyACfCIGfCIWhUIoiSIXfCIYICF8ICkgECAJIBSFQjCJIgcgE3wiCYVCAYkiBSAMICV8fCICfCAFIAIgA4VCIIkiBCALfCIDhUIoiSICfCIUIASFQjCJIgsgA3wiFSAChUIBiSIMfCIFIB58IAwgBSAcIAYgCoVCAYkiBCARICh8fCICfCAEIAIgB4VCIIkiAyANIA98IgJ8IgqFQiiJIg18IhMgA4VCMIkiBoVCIIkiByAjIAIgDoVCAYkiBSAIICd8fCICfCAFIAIgEoVCIIkiBCAJfCIDhUIoiSIIfCICIASFQjCJIhAgA3wiCXwiEYVCKIkiEnwiDyAHhUIwiSIOhSAdIA0gBiAKfCIKhUIBiSIGIAIgGnx8IgJ8IAYgAiALhUIgiSIHIBggGYVCMIkiBSAWfCIEfCIDhUIoiSICfCILIAeFQjCJIgwgA3wiDSAChUIBiYUhLSAIIAmFQgGJIgMgFCAffHwiAiAifCADIAogAiAFhUIgiSICfCIIhUIoiSIJfCIKIAKFQjCJIgYgLIUgBCAXhUIBiSIFIBMgIHx8IgIgJnwgBSACIBCFQiCJIgQgFXwiA4VCKIkiAnwiByAEhUIwiSIFIAN8IgQgAoVCAYmFISwgDiARfCIDIC+FIAuFIS8gDyAxhSANhSExIAYgCHwiAiAHIDKFhSEyIAUgKoUgAiAJhUIBiYUhKiADIBKFQgGJICuFIAyFISsgCiAwhSAEhSEwIDsgU0GAAWoiU0cNAAsgPCAqNwM4IDwgKzcDMCA8ICw3AyggPCAtNwMgIDwgLzcDGCA8IDA3AxAgPCAxNwMIIDwgMjcDACA9QYABaiQADAILQYB/IFNBgAFqQdibwAAQywEACyBTQYABaiBDQdibwAAQygEACyA5IDktAGQ6AFAgOSA5KQPIAjcDSCA5IDkpA8ACNwNAIDkgOSkDuAI3AzggOSA5KQOwAjcDMCA5IDkpA6gCNwMoIDkgOSkDoAI3AyAgOSA5KQOYAjcDGCA5IDkpA5ACNwMQIDlBEGoiNS0AQCI4QcEATwRAIDhBwABBxJzAABDKAQALIDlBCGoiASA4NgIEIAEgNTYCACA5KAIIIQECQAJAAkAgOSgCDCI4BEAgOEEATiI1RQ0BIDggNRC4ASI6RQ0CCyA6IAEgOBDgASEBIEJBDGogODYCACBCQQhqIDg2AgAgQiABNgIEIEJBBjoAACA5QdACaiQADAILEIgBAAsgOCA1ENsBAAsCQCBCLQAAQQZGBEAgTyBCKQIENwIAIE9BCGogQkEMaigCADYCACBCQSBqJAAMAQsgQkEYaiBCQQhqKQMANwMAIEIgQikDADcDEEHHmcAAQSsgQkEQakH0mcAAQYSawAAQZAALIDRFDQIgRxAmDAILAn8jAEHQAGsiPiQAID4gNTYCDCA+QQA2AhggPkIBNwMQID5BIGoiASA+QRBqQfSFwAAQkgEjAEEQayI4JAAgOEEIaiA+QQxqKAIAEAggOCgCCCI0IDgoAgwiNSABENwBIDUEQCA0ECYLIDhBEGokAEUEQCA+KAIQID4oAhgQAyA+KAIUBEAgPigCEBAmCyA+KAIMIgFBJE8EQCABEAALID5B0ABqJAAMAQtBjIbAAEE3ID5ByABqQcSGwABBoIfAABBkAAshASBPQQA2AgAgTyABNgIEDAILIE9BADYCACBPIDQ2AgQLIERBDGooAgAEQCBEKAIIECYLIERBGGooAgAEQCBEKAIUECYLIERBJGooAgAEQCBEQSBqKAIAECYLAkAgRCgCLCIBRQ0AIERBMGooAgBFDQAgARAmCyBEQTxqKAIABEAgRCgCOBAmCyBEQcgAaigCAARAIEQoAkQQJgsLIERBgANqJAAgTygCCCE0IE8oAgQhAQJAIAACfyBPKAIAIjUEQAJAIAEgNE0EQCA1IVkMAQsgNEUEQEEBIVkgNRAmDAELIDUgAUEBIDQQsAEiWUUNAwtBACEBQQAMAQtBAQs2AgwgACABNgIIIAAgNDYCBCAAIFk2AgAgT0EQaiQADwsgNEEBENsBAAuTAQEBfyMAQRBrIgYkAAJAIAEEQCAGIAEgAyAEIAUgAigCEBEHACAGKAIAIQECQCAGKAIEIgMgBigCCCICTQRAIAEhBAwBCyACRQRAQQQhBCABECYMAQsgASADQQJ0QQQgAkECdCIBELABIgRFDQILIAAgAjYCBCAAIAQ2AgAgBkEQaiQADwsQ1AEACyABQQQQ2wEAC5gBAQF/IwBBIGsiAiQAAkACQCABEMIBRQRAIAEQwQENASAAQQA2AgAMAgsgAkEQaiABEF8gAEEIaiACQRhqKAIANgIAIAAgAikDEDcCAAwBCyACIAEQ6QE2AgwgAkEQaiACQQxqEF8gAEEIaiACQRhqKAIANgIAIAAgAikDEDcCACACKAIMIgBBJEkNACAAEAALIAJBIGokAAuXAQEBfyMAQUBqIgIkACAAKAIAIQAgAkIANwM4IAJBOGogABAhIAJBHGpBATYCACACIAIoAjwiADYCMCACIAA2AiwgAiACKAI4NgIoIAJBzwA2AiQgAkICNwIMIAJByJfAADYCCCACIAJBKGo2AiAgAiACQSBqNgIYIAEgAkEIahBrIAIoAiwEQCACKAIoECYLIAJBQGskAAuUAQEEfwJAAkACQCABKAIAIgQQHCIBRQRAQQEhAwwBCyABQQBOIgJFDQEgASACELgBIgNFDQILIAAgATYCBCAAIAM2AgAQIyICEBkiBRAaIQEgBUEkTwRAIAUQAAsgASAEIAMQGyABQSRPBEAgARAACyACQSRPBEAgAhAACyAAIAQQHDYCCA8LEIgBAAsgASACENsBAAvyAgEDfyMAQRBrIgIkAAJ/AkACQAJAAkACQAJAIAAtAABBAWsOBQECAwQFAAsgAUH0msAAQQMQrQEMBQsgAUHrmsAAQQkQrQEMBAsgAUHkmsAAQQcQrQEMAwsgAiAAQQRqNgIIIAIgAEEBajYCDCMAQRBrIgAkACAAIAEoAhhBuprAAEEJIAFBHGooAgAoAgwRAQA6AAggACABNgIAIABBADoACSAAQQA2AgQgACACQQhqQcSawAAQRCACQQxqQdSawAAQRCEBAn8gAC0ACCIDIAAoAgQiBEUNABpBASADDQAaIAEoAgAhAQJAIARBAUcNACAALQAJRQ0AIAEtAABBBHENAEEBIAEoAhhBgsvAAEEBIAFBHGooAgAoAgwRAQANARoLIAEoAhhB7MfAAEEBIAFBHGooAgAoAgwRAQALIABBEGokAEH/AXFBAEcMAgsgAUGvmsAAQQsQrQEMAQsgAUGkmsAAQQsQrQELIAJBEGokAAuMAQEEfyMAQRBrIgIkAAJAIAEtAAQEQEECIQQMAQsgASgCABANIQMgAkEIahCVASACKAIIRQRAAn8gAxAORQRAIAMQDyEFQQAMAQsgAUEBOgAEQQILIQQgA0EkSQ0BIAMQAAwBCyACKAIMIQVBASEEIAFBAToABAsgACAFNgIEIAAgBDYCACACQRBqJAALgAEBAX8jAEFAaiIBJAAgAUGsgMAANgIUIAFBpIDAADYCECABIAA2AgwgAUEsakECNgIAIAFBPGpBCzYCACABQgI3AhwgAUHAhcAANgIYIAFBDjYCNCABIAFBMGo2AiggASABQRBqNgI4IAEgAUEMajYCMCABQRhqEFogAUFAayQAC3kBAn8jAEFAaiIAJAAgAEEANgIIIABCATcDACAAQRBqIgEgAEGog8AAEJIBQdCIwABBOyABENwBRQRAIAAoAgAgACgCCBDoASAAKAIEBEAgACgCABAmCyAAQUBrJAAPC0HAg8AAQTcgAEE4akH4g8AAQdSEwAAQZAALgAEBAX8jAEFAaiIFJAAgBSABNgIMIAUgADYCCCAFIAM2AhQgBSACNgIQIAVBLGpBAjYCACAFQTxqQfsANgIAIAVCAjcCHCAFQbzKwAA2AhggBUH6ADYCNCAFIAVBMGo2AiggBSAFQRBqNgI4IAUgBUEIajYCMCAFQRhqIAQQiQEAC64BAQJ/IwBBEGsiAiQAIAAoAgAhACABKAIYQYTLwABBASABQRxqKAIAKAIMEQEAIQMgAkEAOgAFIAIgAzoABCACIAE2AgAgAiAANgIMIAIgAkEMaiIBEM0BIAIgAEEBajYCDCACIAEQzQEgAiAAQQJqNgIMIAIgARDNASACLQAEBH9BAQUgAigCACIAQRhqKAIAQYXLwABBASAAQRxqKAIAKAIMEQEACyACQRBqJAALbQEBfyMAQTBrIgMkACADIAI2AgQgAyABNgIAIANBHGpBAjYCACADQSxqQQs2AgAgA0ICNwIMIANBgIXAADYCCCADQQw2AiQgAyAANgIgIAMgA0EgajYCGCADIAM2AiggA0EIahBaIANBMGokAAtbAQJ/IwBBIGsiAiQAIAFBHGooAgAhAyABKAIYIAJBGGogACgCACIAQRBqKQIANwMAIAJBEGogAEEIaikCADcDACACIAApAgA3AwggAyACQQhqEDAgAkEgaiQAC2wBBH8jAEEgayICJABBASEDAkAgACABEEMNACABQRxqKAIAIQQgASgCGCACQQA2AhwgAkHIr8AANgIYIAJCATcCDCACQfDHwAA2AgggBCACQQhqEDANACAAQQRqIAEQQyEDCyACQSBqJAAgAwttAQF/IwBBMGsiAyQAIAMgATYCBCADIAA2AgAgA0EcakECNgIAIANBLGpBDjYCACADQgI3AgwgA0G4yMAANgIIIANBDjYCJCADIANBIGo2AhggAyADNgIoIAMgA0EEajYCICADQQhqIAIQiQEAC1YBAn8jAEEgayICJAAgAUEcaigCACEDIAEoAhggAkEYaiAAQRBqKQIANwMAIAJBEGogAEEIaikCADcDACACIAApAgA3AwggAyACQQhqEDAgAkEgaiQAC1YBAn8jAEEgayICJAAgAEEcaigCACEDIAAoAhggAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAyACQQhqEDAgAkEgaiQAC2YBAX8jAEEgayICJAAgAkH4ocAANgIEIAIgADYCACACQRhqIAFBEGopAgA3AwAgAkEQaiABQQhqKQIANwMAIAIgASkCADcDCCACQYyiwAAgAkEEakGMosAAIAJBCGpBpKnAABA8AAtjAQF/IwBBIGsiAyQAIANBqKrAADYCBCADIAA2AgAgA0EYaiABQRBqKQIANwMAIANBEGogAUEIaikCADcDACADIAEpAgA3AwggA0H8ocAAIANBBGpB/KHAACADQQhqIAIQPAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHAj8AAIAJBCGoQMCACQSBqJAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHYkMAAIAJBCGoQMCACQSBqJAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHglcAAIAJBCGoQMCACQSBqJAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHAocAAIAJBCGoQMCACQSBqJAALaAAjAEEwayIBJABBsObAAC0AAARAIAFBHGpBATYCACABQgI3AgwgAUHApcAANgIIIAFBDjYCJCABIAA2AiwgASABQSBqNgIYIAEgAUEsajYCICABQQhqQeilwAAQiQEACyABQTBqJAALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakH8rcAAIAJBCGoQMCACQSBqJAALaAECfyABKAIAIQMCQAJAAkAgAUEIaigCACIBRQRAQQEhAgwBCyABQQBIDQEgAUEBELgBIgJFDQILIAIgAyABEOABIQIgACABNgIIIAAgATYCBCAAIAI2AgAPCxCIAQALIAFBARDbAQALWQEBfyMAQSBrIgIkACACIAAoAgA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakGAzcAAIAJBCGoQMCACQSBqJAALVgEBfyMAQSBrIgIkACACIAA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHAj8AAIAJBCGoQMCACQSBqJAALVgEBfyMAQSBrIgIkACACIAA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHYkMAAIAJBCGoQMCACQSBqJAALVgEBfyMAQSBrIgIkACACIAA2AgQgAkEYaiABQRBqKQIANwMAIAJBEGogAUEIaikCADcDACACIAEpAgA3AwggAkEEakHglcAAIAJBCGoQMCACQSBqJAALWwEBfyMAQRBrIgIkAAJ/IAAoAgAiACgCAEUEQCACIABBBGo2AgggAUH4nMAAQQkgAkEIahBVDAELIAIgAEEEajYCDCABQdycwABBCyACQQxqEFULIAJBEGokAAtWAQF/IwBBIGsiAiQAIAIgADYCBCACQRhqIAFBEGopAgA3AwAgAkEQaiABQQhqKQIANwMAIAIgASkCADcDCCACQQRqQYDNwAAgAkEIahAwIAJBIGokAAtfAQF/IwBBMGsiAiQAIAIgATYCDCACIAA2AgggAkEkakEBNgIAIAJCAjcCFCACQaCFwAA2AhAgAkENNgIsIAIgAkEoajYCICACIAJBCGo2AiggAkEQahBaIAJBMGokAAtfAQF/IwBBMGsiAiQAIAIgATYCDCACIAA2AgggAkEkakEBNgIAIAJCAjcCFCACQeSFwAA2AhAgAkENNgIsIAIgAkEoajYCICACIAJBCGo2AiggAkEQahBaIAJBMGokAAtRAQF/AkAgAEEQaigCACIBRQ0AIAFBADoAACAAQRRqKAIARQ0AIAAoAhAQJgsCQCAAQX9GDQAgACAAKAIEIgFBAWs2AgQgAUEBRw0AIAAQJgsLQAEBfyMAQSBrIgAkACAAQRxqQQA2AgAgAEH4rMAANgIYIABCATcCDCAAQZStwAA2AgggAEEIakHsrcAAEIkBAAtKAQF/IAIgACgCACIAQQRqKAIAIAAoAggiA2tLBEAgACADIAIQUyAAKAIIIQMLIAAoAgAgA2ogASACEOABGiAAIAIgA2o2AghBAAtKAQF/IAIgACgCACIAQQRqKAIAIAAoAggiA2tLBEAgACADIAIQUiAAKAIIIQMLIAAoAgAgA2ogASACEOABGiAAIAIgA2o2AghBAAtHAQF/IAIgACgCACIAKAIEIAAoAggiA2tLBEAgACADIAIQUiAAKAIIIQMLIAAoAgAgA2ogASACEOABGiAAIAIgA2o2AghBAAtCAQF/IAIgACgCBCAAKAIIIgNrSwRAIAAgAyACEFIgACgCCCEDCyAAKAIAIANqIAEgAhDgARogACACIANqNgIIQQALSAEBfyMAQSBrIgMkACADQRRqQQA2AgAgA0HIr8AANgIQIANCATcCBCADIAE2AhwgAyAANgIYIAMgA0EYajYCACADIAIQiQEAC0YBAn8gASgCBCECIAEoAgAhA0EIQQQQuAEiAUUEQEEIQQQQ2wEACyABIAI2AgQgASADNgIAIABBkKfAADYCBCAAIAE2AgALrHcDGH4rfwF8IAEoAgBBAXEhGiAAKwMAIUUCQAJAAkAgASgCEEEBRgRAAn8gASE8IAFBFGooAgAhNkEAIQEjAEHwCGsiIyQAIEW9IQYCQCBFIEViBEBBAiEADAELIAZC/////////weDIgNCgICAgICAgAiEIAZCAYZC/v///////w+DIAZCNIinQf8PcSIeGyIHQgGDIQVBAyEAAkACQAJAQQFBAkEEIAZCgICAgICAgPj/AIMiAlAiKBsgAkKAgICAgICA+P8AURtBA0EEICgbIANQG0ECaw4DAAECAwtBBCEADAILIB5BswhrIQEgBVAhAEIBIQQMAQtCgICAgICAgCAgB0IBhiAHQoCAgICAgIAIUSIBGyEHQgJCASABGyEEIAVQIQBBy3dBzHcgARsgHmohAQsgIyABOwHoCCAjIAQ3A+AIICNCATcD2AggIyAHNwPQCCAjIAA6AOoIAkACfyAAQQJrQf8BcSIAQQMgAEEDSRsiKARAQavHwABBrMfAAEHIr8AAIBobIAZCAFMbIT1BASEAIAZCP4inIBpyIUECQAJAAkAgKEECaw4CAQACC0F0QQUgAUEQdEEQdSIAQQBIGyAAbCIAQb/9AEsNBCAjQZAIaiEfICNBEGohKSAAQQR2QRVqIjEhK0EAIDZrQYCAfiA2QYCAAkkbITICQAJAAkACQAJAAkACQCAjQdAIaiIAKQMAIgJQRQRAIAJC//////////8fVg0BICtFDQNBoH8gAC8BGCIAQSBrIAAgAkKAgICAEFQiARsiAEEQayAAIAJCIIYgAiABGyICQoCAgICAgMAAVCIBGyIAQQhrIAAgAkIQhiACIAEbIgJCgICAgICAgIABVCIBGyIAQQRrIAAgAkIIhiACIAEbIgJCgICAgICAgIAQVCIBGyIAQQJrIAAgAkIEhiACIAEbIgJCgICAgICAgIDAAFQiABsgAkIChiACIAAbIgJCP4enQX9zaiIAa0EQdEEQdUHQAGxBsKcFakHOEG0iAUHRAE8NAiABQQR0IgFBwrfAAGovAQAhKAJ/AkACQCABQbi3wABqKQMAIgZC/////w+DIgcgAiACQn+FQj+IhiIDQiCIIgJ+IgVCIIggAiAGQiCIIgJ+fCACIANC/////w+DIgN+IgJCIIh8IAVC/////w+DIAMgB35CIIh8IAJC/////w+DfEKAgICACHxCIIh8IgJBQCAAIAFBwLfAAGovAQBqayIaQT9xrSIGiKciAEGQzgBPBEAgAEHAhD1JDQEgAEGAwtcvSQ0CQQhBCSAAQYCU69wDSSIBGyEeQYDC1y9BgJTr3AMgARsMAwsgAEHkAE8EQEECQQMgAEHoB0kiARshHkHkAEHoByABGwwDCyAAQQlLIR5BAUEKIABBCkkbDAILQQRBBSAAQaCNBkkiARshHkGQzgBBoI0GIAEbDAELQQZBByAAQYCt4gRJIgEbIR5BwIQ9QYCt4gQgARsLISBCASAGhiEHAkAgHiAoa0EQdEGAgARqQRB1IiQgMkEQdEEQdSIBSgRAIAIgB0IBfSIFgyECIBpB//8DcSEcICQgMmtBEHRBEHUgKyAkIAFrICtJGyIbQQFrIShBACEBA0AgACAgbiEaIAEgK0YNByAAIBogIGxrIQAgASApaiAaQTBqOgAAIAEgKEYNCCABIB5GDQIgAUEBaiEBICBBCkkgIEEKbiEgRQ0AC0HAw8AAQRlBrMXAABCDAQALIB8gKSArQQAgJCAyIAJCCoAgIK0gBoYgBxA5DAgLIAFBAWohASAcQQFrQT9xrSEDQgEhBANAIAQgA4hQRQRAIB9BADYCAAwJCyABICtPDQcgASApaiACQgp+IgIgBoinQTBqOgAAIARCCn4hBCACIAWDIQIgGyABQQFqIgFHDQALIB8gKSArIBsgJCAyIAIgByAEEDkMBwtB/7LAAEEcQdjEwAAQgwEAC0HoxMAAQSRBjMXAABCDAQALIAFB0QBB+MHAABBpAAtBjMTAAEEhQZzFwAAQgwEACyArICtBvMXAABBpAAsgHyApICsgGyAkIDIgAK0gBoYgAnwgIK0gBoYgBxA5DAELIAEgK0HMxcAAEGkACyAyQRB0QRB1IToCQCAjKAKQCEUEQCAjQcAIaiE7ICNBEGohOSMAQdAGayIhJAACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQCAjQdAIaiIAKQMAIgVQRQRAIAApAwgiA1ANASAAKQMQIgJQDQIgAiAFfCAFVA0DIAUgA30gBVYNBCAALwEYIRogISAFPgIMICFBEGpBACAFQiCIpyAFQoCAgIAQVCIAGzYCACAhQQFBAiAAGzYCCCAhQRRqQQBBmAEQ3gEaICFBuAFqQQBBnAEQ3gEaICFCgYCAgBA3A7ABIBqtQjCGQjCHIAVCAX15fULCmsHoBH5CgKHNoLQCfEIgiKciAUEQdEEQdSEzAkAgGkEQdEEQdSIAQQBOBEAgIUEIaiAaECUaDAELICFBsAFqQQAgAGtBEHRBEHUQJRoLICFBsAFqQQRyISwCQCAzQQBIBEAgIUEIakEAIDNrQRB0QRB1ECsMAQsgIUGwAWogAUH//wNxECsLICEoArABIRwgIUGoBWpBBHIgLEGgARDgASEqICEgHDYCqAUCQCAxIiJBCkkNAAJAIBxBKEsEQCAcIQAMAQsgIUGkBWohHiAcIQADQAJAIABFDQAgAEECdCEaIABBAWtB/////wNxIgFBAWoiAEEBcQJ/IAFFBEBCACEEIBogKmoMAQsgAEH+////B3EhASAaIB5qIQBCACEEA0AgAEEEaiIaIBo1AgAgBEIghoQiA0KAlOvcA4AiAj4CACAAIAA1AgAgAyACQoCU69wDfn1CIIaEIgNCgJTr3AOAIgI+AgAgAyACQoCU69wDfn0hBCAAQQhrIQAgAUECayIBDQALIABBCGoLIQBFDQAgAEEEayIAIAA1AgAgBEIghoRCgJTr3AOAPgIACyAiQQlrIiJBCU0NAiAhKAKoBSIAQSlJDQALCwwRCwJ/An8CQCAiQQJ0QdCwwABqKAIAIhoEQCAhKAKoBSIAQSlPDRRBACAARQ0DGiAAQQJ0IR4gAEEBa0H/////A3EiAUEBaiIAQQFxISggGq0hBSABDQFCACEEIB4gKmoMAgtB+97AAEEbQbTewAAQgwEACyAAQf7///8HcSEBIB4gIWpBpAVqIQBCACEEA0AgAEEEaiIaIBo1AgAgBEIghoQiAyAFgCICPgIAIAAgADUCACADIAIgBX59QiCGhCIDIAWAIgI+AgAgAyACIAV+fSEEIABBCGshACABQQJrIgENAAsgAEEIagshACAoBEAgAEEEayIAIAA1AgAgBEIghoQgBYA+AgALICEoAqgFCyIAICEoAggiHiAAIB5LGyIbQSlPDR0gIUEIakEEciEoIBtFBEBBACEbDAcLIBtBAXEhKSAbQQFGBEBBACEiDAYLIBtBfnEhJCAhQRBqIQEgIUGwBWohAEEAISIDQCAAQQRrIhogGigCACIfIAFBBGsoAgBqIisgIkEBcWoiGjYCACAAIAAoAgAiICABKAIAaiIyIBogK0kgHyArS3JqIho2AgAgGiAySSAgIDJLciEiIAFBCGohASAAQQhqIQAgJCAlQQJqIiVHDQALDAULQf+ywABBHEGYtsAAEIMBAAtBrLPAAEEdQai2wAAQgwEAC0Hcs8AAQRxBuLbAABCDAQALQYi0wABBNkHItsAAEIMBAAtB0LTAAEE3Qdi2wAAQgwEACyApBH8gKiAlQQJ0IhpqIgAgACgCACIBIBogKGooAgBqIhogImoiADYCACAAIBpJIAEgGktyBSAiC0EBcUUNACAbQSdLDRggG0ECdCAhakGsBWpBATYCACAbQQFqIRsLICEgGzYCqAUgGyAcIBsgHEsbIgBBKU8NCSAAQQJ0IQACQANAIAAEQCAhQagFaiAAaiEgICFBsAFqIABqIQEgAEEEayEAQX8gASgCACIaICAoAgAiAUcgASAaSRsiAUUNAQwCCwtBf0EAIAAbIQELIAFBAU0EQCAzQQFqITMMAwsgHkEpTw0KIB5FBEBBACEeDAILIB5BAWtB/////wNxIhpBAWoiAEEDcSEBIBpBA0kEQEIAIQQgKCEADAELIABB/P///wdxIRtCACEEICghAANAIAAgADUCAEIKfiAEfCICPgIAIABBBGoiGiAaNQIAQgp+IAJCIIh8IgI+AgAgAEEIaiIaIBo1AgBCCn4gAkIgiHwiAj4CACAAQQxqIhogGjUCAEIKfiACQiCIfCICPgIAIAJCIIghBCAAQRBqIQAgG0EEayIbDQALDAALIAEEQANAIAAgADUCAEIKfiAEfCICPgIAIABBBGohACACQiCIIQQgAUEBayIBDQALCyAEpyIARQ0AIB5BJ0sNAiAeQQJ0ICFqQQxqIAA2AgAgHkEBaiEeCyAhIB42AggLQQEhJQJAIDogM0EQdEEQdSIATARAIDMgOmtBEHRBEHUgMSAAIDprIDFJGyIiDQELQQAhIgwFCyAhQdgCaiIAQQRyICxBoAEQ4AEhQiAhIBw2AtgCIABBARAlICEoArABIQEgIUGABGoiAEEEciAsQaABEOABIUMgISABNgKABCAAQQIQJSEeICEoArABIQEgIUGoBWoiAEEEciAsQaABEOABIUQgISABNgKoBSAhQbgBaiEyICFB4AJqISkgIUGIBGohJCAhQbAFaiEfICFBEGohGiAAQQMQJSEAKAIAIT4gHigCACE/IAAoAgAhQCAhKAIIISAgISgCsAEhHEEAISsCQANAICshKiAgQSlPDQogKkEBaiErICBBAnQhHkEAIQACQAJAAkADQCAAIB5GDQEgIUEIaiAAaiAAQQRqIQBBBGooAgBFDQALICAgQCAgIEBLGyIeQSlPDQwgHkECdCEAAkADQCAABEAgIUEIaiAAaiElICFBqAVqIABqIQEgAEEEayEAQX8gASgCACIbICUoAgAiAUcgASAbSRsiAUUNAQwCCwtBf0EAIAAbIQELQQAhNCABQQJJBEAgHgRAQQEhJUEAISAgHkEBRwRAIB5BfnEhLyAfIQEgGiEAA0AgAEEEayIbIBsoAgAiMCABQQRrKAIAQX9zaiImICVBAXFqIhs2AgAgACAAKAIAIiUgASgCAEF/c2oiNSAmIDBJIBsgJklyaiIbNgIAIBsgNUkgJSA1S3IhJSABQQhqIQEgAEEIaiEAIC8gIEECaiIgRw0ACwsgHkEBcQR/ICggIEECdCIgaiIAIAAoAgAiASAgIERqKAIAQX9zaiIgICVqIgA2AgAgACAgSSABICBLcgUgJQtBAXFFDRALICEgHjYCCEEIITQgHiEgCyAgID8gICA/SxsiG0EpTw0YIBtBAnQhAANAIABFDQIgIUEIaiAAaiElICFBgARqIABqIQEgAEEEayEAQX8gASgCACIeICUoAgAiAUcgASAeSRsiAUUNAAsMAgsgIiAqSQ0FICIgMUsNBiAiICpGDQkgKiA5akEwICIgKmsQ3gEaDAkLQX9BACAAGyEBCwJAIAFBAUsEQCAgIRsMAQsgGwRAQQEhJUEAISAgG0EBRwRAIBtBfnEhLyAkIQEgGiEAA0AgAEEEayIeIB4oAgAiMCABQQRrKAIAQX9zaiImICVBAXFqIh42AgAgACAAKAIAIiUgASgCAEF/c2oiNSAmIDBJIB4gJklyaiIeNgIAIB4gNUkgJSA1S3IhJSABQQhqIQEgAEEIaiEAIC8gIEECaiIgRw0ACwsgG0EBcQR/ICggIEECdCIeaiIAIAAoAgAiASAeIENqKAIAQX9zaiIeICVqIgA2AgAgACAeSSABIB5LcgUgJQtBAXFFDQ0LICEgGzYCCCA0QQRyITQLIBsgPiAbID5LGyIeQSlPDQkgHkECdCEAAkADQCAABEAgIUEIaiAAaiElICFB2AJqIABqIQEgAEEEayEAQX8gASgCACIgICUoAgAiAUcgASAgSRsiAUUNAQwCCwtBf0EAIAAbIQELAkAgAUEBSwRAIBshHgwBCyAeBEBBASElQQAhICAeQQFHBEAgHkF+cSEvICkhASAaIQADQCAAQQRrIhsgGygCACIwIAFBBGsoAgBBf3NqIiYgJUEBcWoiGzYCACAAIAAoAgAiJSABKAIAQX9zaiI1ICYgMEkgGyAmSXJqIhs2AgAgGyA1SSAlIDVLciElIAFBCGohASAAQQhqIQAgLyAgQQJqIiBHDQALCyAeQQFxBH8gKCAgQQJ0IiBqIgAgACgCACIBICAgQmooAgBBf3NqIiAgJWoiADYCACAAICBJIAEgIEtyBSAlC0EBcUUNDQsgISAeNgIIIDRBAmohNAsgHiAcIBwgHkkbIiBBKU8NCiAgQQJ0IQACQANAIAAEQCAhQQhqIABqISUgIUGwAWogAGohASAAQQRrIQBBfyABKAIAIhsgJSgCACIBRyABIBtJGyIBRQ0BDAILC0F/QQAgABshAQsCQCABQQFLBEAgHiEgDAELICAEQEEBISVBACEeICBBAUcEQCAgQX5xIS8gMiEBIBohAANAIABBBGsiGyAbKAIAIjAgAUEEaygCAEF/c2oiJiAlQQFxaiIbNgIAIAAgACgCACIlIAEoAgBBf3NqIjUgJiAwSSAbICZJcmoiGzYCACAbIDVJICUgNUtyISUgAUEIaiEBIABBCGohACAvIB5BAmoiHkcNAAsLICBBAXEEfyAoIB5BAnQiHmoiACAAKAIAIgEgHiAsaigCAEF/c2oiHiAlaiIANgIAIAAgHkkgASAeS3IFICULQQFxRQ0NCyAhICA2AgggNEEBaiE0CyAqIDFGDQEgKiA5aiA0QTBqOgAAICBBKU8NCgJAICBFBEBBACEgDAELICBBAWtB/////wNxIhtBAWoiHkEDcSEBQgAhBCAoIQAgG0EDTwRAIB5B/P///wdxIRsDQCAAIAA1AgBCCn4gBHwiAj4CACAAQQRqIh4gHjUCAEIKfiACQiCIfCICPgIAIABBCGoiHiAeNQIAQgp+IAJCIIh8IgI+AgAgAEEMaiIeIB41AgBCCn4gAkIgiHwiAj4CACACQiCIIQQgAEEQaiEAIBtBBGsiGw0ACwsgAQRAA0AgACAANQIAQgp+IAR8IgI+AgAgAEEEaiEAIAJCIIghBCABQQFrIgENAAsLIASnIgBFDQAgIEEnSw0GICBBAnQgIWpBDGogADYCACAgQQFqISALICEgIDYCCCAiICtHDQALQQAhJQwFCyAxIDFB+LbAABBpAAsgHkEoQbTewAAQaQALICogIkHotsAAEMsBAAsgIiAxQei2wAAQygEACyAgQShBtN7AABBpAAsCQAJAAkACQAJAAkAgHEEpSQRAIBxFBEBBACEcDAMLIBxBAWtB/////wNxIhpBAWoiAUEDcSEAIBpBA0kEQEIAIQQMAgsgAUH8////B3EhAUIAIQQDQCAsICw1AgBCBX4gBHwiAj4CACAsQQRqIhogGjUCAEIFfiACQiCIfCICPgIAICxBCGoiGiAaNQIAQgV+IAJCIIh8IgI+AgAgLEEMaiIaIBo1AgBCBX4gAkIgiHwiAj4CACACQiCIIQQgLEEQaiEsIAFBBGsiAQ0ACwwBCwwWCyAABEADQCAsICw1AgBCBX4gBHwiAj4CACAsQQRqISwgAkIgiCEEIABBAWsiAA0ACwsgBKciAEUNACAcQSdLDQEgHEECdCAhakG0AWogADYCACAcQQFqIRwLICEgHDYCsAEgISgCCCIAIBwgACAcSxsiAEEpTw0FIABBAnQhAAJAA0AgAARAICFBCGogAGohKCAhQbABaiAAaiEBIABBBGshAEF/IAEoAgAiGiAoKAIAIgFHIAEgGkkbIgFFDQEMAgsLQX9BACAAGyEBCwJAAkAgAUH/AXEOAgABBQsgJQ0AICJBAWsiACAxTw0CIAAgOWotAABBAXFFDQQLICIgMUsNAkEAIQAgOSEBAkADQCAAICJGDQEgAEEBaiEAIAFBAWsiASAiaiIaLQAAQTlGDQALIBogGi0AAEEBajoAACAiIABrQQFqICJPDQQgGkEBakEwIABBAWsQ3gEaDAQLAn9BMSAlDQAaIDlBMToAAEEwICJBAUYNABogOUEBakEwICJBAWsQ3gEaQTALIQAgM0EQdEGAgARqQRB1IjMgOkwgIiAxT3INAyAiIDlqIAA6AAAgIkEBaiEiDAMLIBxBKEG03sAAEGkACyAAIDFBiLfAABBpAAsgIiAxQZi3wAAQygEACyAiIDFNDQAgIiAxQai3wAAQygEACyA7IDM7AQggOyAiNgIEIDsgOTYCACAhQdAGaiQADAULIABBKEG03sAAEMoBAAsgHkEoQbTewAAQygEACyAgQShBtN7AABDKAQALQcTewABBGkG03sAAEIMBAAsgI0HICGogI0GYCGooAgA2AgAgIyAjKQOQCDcDwAgLIDogIy4ByAgiAEgEQCAjQQhqICMoAsAIICMoAsQIIAAgNiAjQZAIahA6ICMoAgwhACAjKAIIDAQLQQIhACAjQQI7AZAIIDYEQCAjQaAIaiA2NgIAICNBADsBnAggI0ECNgKYCCAjQajHwAA2ApQIICNBkAhqDAQLQQEhACAjQQE2ApgIICNBrcfAADYClAggI0GQCGoMAwtBAiEAICNBAjsBkAggNgRAICNBoAhqIDY2AgAgI0EAOwGcCCAjQQI2ApgIICNBqMfAADYClAggI0GQCGoMAwtBASEAICNBATYCmAggI0Gtx8AANgKUCCAjQZAIagwCCyAjQQM2ApgIICNBrsfAADYClAggI0ECOwGQCCAjQZAIagwBCyAjQQM2ApgIICNBscfAADYClAggI0ECOwGQCEEBIQBByK/AACE9ICNBkAhqCyEBICNBzAhqIAA2AgAgIyABNgLICCAjIEE2AsQIICMgPTYCwAggPCAjQcAIahAxICNB8AhqJAAMAQtBtMfAAEElQdzHwAAQgwEACw8LIAEgGiEBIwBBgAFrIickACBFvSEEAkAgRSBFYgRAQQIhAAwBCyAEQv////////8HgyIFQoCAgICAgIAIhCAEQgGGQv7///////8PgyAEQjSIp0H/D3EiKBsiA0IBgyEHQQMhAAJAAkACQEEBQQJBBCAEQoCAgICAgID4/wCDIgJQIhobIAJCgICAgICAgPj/AFEbQQNBBCAaGyAFUBtBAmsOAwABAgMLQQQhAAwCCyAoQbMIayEsIAdQIQBCASEGDAELQoCAgICAgIAgIANCAYYgA0KAgICAgICACFEiGhshA0ICQgEgGhshBiAHUCEAQct3Qcx3IBobIChqISwLICcgLDsBeCAnIAY3A3AgJ0IBNwNoICcgAzcDYCAnIAA6AHoCfyAAQQJrQf8BcSIAQQMgAEEDSRsiGgRAQavHwABBrMfAAEHIr8AAIAEbIARCAFMbISxBASEAQQEgBEI/iKcgARshPQJAAkACQCAaQQJrDgIBAAILICdBIGohJCAnQQ9qIR8jAEEwayIpJAACQAJAAkACQAJAAkACQCAnQeAAaiIAKQMAIgVQRQRAIAApAwgiA1BFBEAgACkDECICUEUEQCAFIAIgBXwiAlgEQCAFIAUgA30iBloEQAJAAkAgAkL//////////x9YBEAgKSAALwEYIho7AQggKSAGNwMAIBogGkEgayAaIAJCgICAgBBUIgEbIgBBEGsgACACQiCGIAIgARsiAkKAgICAgIDAAFQiARsiAEEIayAAIAJCEIYgAiABGyICQoCAgICAgICAAVQiARsiAEEEayAAIAJCCIYgAiABGyICQoCAgICAgICAEFQiARsiAEECayAAIAJCBIYgAiABGyICQoCAgICAgICAwABUIgAbIAJCAoYgAiAAGyIEQj+Hp0F/c2oiAWtBEHRBEHUiAEEASA0CIClCfyAArSICiCIDIAaDNwMQIAMgBlQNDSApIBo7AQggKSAFNwMAICkgAyAFgzcDECADIAVUDQ1BoH8gAWtBEHRBEHVB0ABsQbCnBWpBzhBtIgBB0QBPDQEgAEEEdCIAQbi3wABqKQMAIgNC/////w+DIg0gBSACQj+DIgeGIgJCIIgiFX4iBUIgiCIJIANCIIgiDyAVfnwgDyACQv////8PgyIDfiICQiCIIhB8IAVC/////w+DIAMgDX5CIIh8IAJC/////w+DfEKAgICACHxCIIghFkIBQQAgASAAQcC3wABqLwEAamtBP3GtIgiGIgxCAX0hDiANIAYgB4YiAkIgiCIFfiIDQv////8PgyANIAJC/////w+DIgJ+QiCIfCACIA9+IgJC/////w+DfEKAgICACHxCIIghESAFIA9+IQsgAkIgiCEGIANCIIghByAAQcK3wABqLwEAIRoCfwJAAkAgDyAEIARCf4VCP4iGIgJCIIgiF34iBCANIBd+IgVCIIgiGHwgDyACQv////8PgyIDfiICQiCIIhl8IAVC/////w+DIAMgDX5CIIh8IAJC/////w+DfEKAgICACHxCIIgiDXxCAXwiEyAIiKciAUGQzgBPBEAgAUHAhD1JDQEgAUGAwtcvSQ0CQQhBCSABQYCU69wDSSIAGyEcQYDC1y9BgJTr3AMgABsMAwsgAUHkAE8EQEECQQMgAUHoB0kiABshHEHkAEHoByAAGwwDCyABQQlLIRxBAUEKIAFBCkkbDAILQQRBBSABQaCNBkkiABshHEGQzgBBoI0GIAAbDAELQQZBByABQYCt4gRJIgAbIRxBwIQ9QYCt4gQgABsLIRsgFnwhFCAOIBODIQMgHCAaa0EBaiEgIBMgByALfCAGfCARfCILfUIBfCIKIA6DIQZBACEAA0AgASAbbiEeAkACQCAAQRFHBEAgACAfaiIaIB5BMGoiKDoAACAKIAEgGyAebGsiAa0gCIYiEiADfCICVg0MIAAgHEcNAiAAQQFqIQBCASECA0AgAiEHIAYhBSAAQRFPDQIgACAfaiADQgp+IgMgCIinQTBqIhs6AAAgAEEBaiEAIAdCCn4hAiAFQgp+IgYgAyAOgyIDWA0ACyAGIAN9IgsgDFohASACIBMgFH1+IgQgAnwhECALIAxUIAQgAn0iCiADWHINDSAAIB9qQQFrIRogBUIKfiADIAx8fSERIAwgCn0hCyAKIAN9IQRCACEJA0AgAyAMfCICIApUIAQgCXwgAyALfFpyRQRAQQEhAQwPCyAaIBtBAWsiGzoAACAJIBF8IgUgDFohASACIApaDQ8gCSAMfSEJIAIhAyAFIAxaDQALDA4LQRFBEUHcw8AAEGkACyAAQRFB/MPAABBpAAsgAEEBaiEAIBtBCkkgG0EKbiEbRQ0AC0HAw8AAQRlBqMPAABCDAQALQejCwABBLUGYw8AAEIMBAAsgAEHRAEH4wcAAEGkAC0HIr8AAQR1BiLDAABCDAQALQdC0wABBN0HIwsAAEIMBAAtBiLTAAEE2QbjCwAAQgwEAC0Hcs8AAQRxBqMLAABCDAQALQayzwABBHUGYwsAAEIMBAAtB/7LAAEEcQYjCwAAQgwEACyAAQQFqIQECQCAAQRFJBEAgCiACfSIHIButIAiGIghaIQAgEyAUfSIFQgF8IQ4gByAIVCAFQgF9IhEgAlhyDQEgAyAIfCICIAl8IBB8IBZ8IA8gFSAXfX58IBh9IBl9IA19IQkgGCAZfCANfCAEfCEGQgAgFCADIBJ8fH0hBEICIAsgAiASfHx9IQcDQCACIBJ8IgUgEVQgBCAGfCAJIBJ8WnJFBEAgAyASfCECQQEhAAwDCyAaIChBAWsiKDoAACADIAh8IQMgBiAHfCELIAUgEVQEQCACIAh8IQIgCCAJfCEJIAYgCH0hBiAIIAtYDQELCyAIIAtYIQAgAyASfCECDAELIAFBEUHsw8AAEMoBAAsCQAJAIABFIAIgDlpyRQRAIAIgCHwiAyAOVCAOIAJ9IAMgDn1acg0BCyACIApCBH1YIAJCAlpxDQEgJEEANgIADAULICRBADYCAAwECyAkICA7AQggJCABNgIEDAILIAMhAgsCQAJAIAFFIAIgEFpyRQRAIAIgDHwiAyAQVCAQIAJ9IAMgEH1acg0BCyACIAdCWH4gBnxYIAIgB0IUflpxDQEgJEEANgIADAMLICRBADYCAAwCCyAkICA7AQggJCAANgIECyAkIB82AgALIClBMGokAAwBCyApQQA2AhgjAEEgayIBJAAgASApNgIEIAEgKUEQajYCACABQRhqIClBGGoiAEEQaikCADcDACABQRBqIABBCGopAgA3AwAgASAAKQIANwMIIAFBnMnAACABQQRqQZzJwAAgAUEIakGYsMAAEDwACwJAICcoAiBFBEAgJ0HQAGohOiAnQQ9qISEjAEHACmsiHSQAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAgJ0HgAGoiACkDACIHUEUEQCAAKQMIIgVQDQEgACkDECIDUA0CIAMgB3wiAiAHVA0DIAcgBX0gB1YNBCAALAAaITMgAC8BGCEaIB0gBz4CBCAdQQhqQQAgB0IgiKcgB0KAgICAEFQiABs2AgAgHUEBQQIgABs2AgAgHUEMakEAQZgBEN4BGiAdIAU+AqwBIB1BsAFqQQAgBUIgiKcgBUKAgICAEFQiABs2AgAgHUEBQQIgABs2AqgBIB1BtAFqQQBBmAEQ3gEaIB0gAz4C1AIgHUHYAmpBACADQiCIpyADQoCAgIAQVCIAGzYCACAdQQFBAiAAGzYC0AIgHUHcAmpBAEGYARDeARogHUGABGpBAEGcARDeARogHUKBgICAEDcD+AMgGq1CMIZCMIcgAkIBfXl9QsKawegEfkKAoc2gtAJ8QiCIpyIBQRB0QRB1ISMCQCAaQRB0QRB1IgBBAE4EQCAdIBoQJRogHUGoAWogGhAlGiAdQdACaiAaECUaDAELIB1B+ANqQQAgAGtBEHRBEHUQJRoLIB1BBHIhIAJAICNBAEgEQCAdQQAgI2tBEHRBEHUiABArIB1BqAFqIAAQKyAdQdACaiAAECsMAQsgHUH4A2ogAUH//wNxECsLIB0oAgAhHCAdQZgJakEEciAgQaABEOABITIgHSAcNgKYCSAcIB0oAtACIiogHCAqSxsiH0EpTw0aIB1B0AJqQQRyIR4gH0UEQEEAIR8MBwsgH0EBcSEpIB9BAUYNBSAfQX5xISQgHUHYAmohASAdQaAJaiEAA0AgAEEEayIaIBooAgAiGyABQQRrKAIAaiIrICZqIho2AgAgACAAKAIAIiggASgCAGoiPCAaICtJIBsgK0tyaiIaNgIAIBogPEkgKCA8S3IhJiABQQhqIQEgAEEIaiEAICQgLUECaiItRw0ACwwFC0H/ssAAQRxBnLPAABCDAQALQayzwABBHUHMs8AAEIMBAAtB3LPAAEEcQfizwAAQgwEAC0GItMAAQTZBwLTAABCDAQALQdC0wABBN0GItcAAEIMBAAsgKQR/IDIgLUECdCIaaiIAIAAoAgAiASAaIB5qKAIAaiIaICZqIgA2AgAgACAaSSABIBpLcgUgJgtFDQAgH0EnSw0BIB9BAnQgHWpBnAlqQQE2AgAgH0EBaiEfCyAdIB82ApgJIB0oAvgDIiQgHyAfICRJGyIAQSlPDRQgHUH4A2pBBHIhNCAdQagBakEEciEoIABBAnQhAAJAA0AgAARAIB1B+ANqIABqIRsgHUGYCWogAGohASAAQQRrIQBBfyABKAIAIhogGygCACIBRyABIBpJGyIBRQ0BDAILC0F/QQAgABshAQsgASAzTgRAIBxBKU8NHyAcRQRAQQAhHAwECyAcQQFrQf////8DcSIaQQFqIgBBA3EhASAaQQNJBEBCACECICAhAAwDCyAAQfz///8HcSEfQgAhAiAgIQADQCAAIAA1AgBCCn4gAnwiAj4CACAAQQRqIhogGjUCAEIKfiACQiCIfCICPgIAIABBCGoiGiAaNQIAQgp+IAJCIIh8IgI+AgAgAEEMaiIaIBo1AgBCCn4gAkIgiHwiAj4CACACQiCIIQIgAEEQaiEAIB9BBGsiHw0ACwwCCyAjQQFqISMMCAsgH0EoQbTewAAQaQALIAEEQANAIAAgADUCAEIKfiACfCICPgIAIABBBGohACACQiCIIQIgAUEBayIBDQALCyACpyIARQ0AIBxBJ0sNASAdIBxBAnRqQQRqIAA2AgAgHEEBaiEcCyAdIBw2AgAgHSgCqAEiG0EpTw0ZIBtFBEBBACEbDAMLIBtBAWtB/////wNxIhpBAWoiAEEDcSEBIBpBA0kEQEIAIQIgKCEADAILIABB/P///wdxIR9CACECICghAANAIAAgADUCAEIKfiACfCICPgIAIABBBGoiGiAaNQIAQgp+IAJCIIh8IgI+AgAgAEEIaiIaIBo1AgBCCn4gAkIgiHwiAj4CACAAQQxqIhogGjUCAEIKfiACQiCIfCICPgIAIAJCIIghAiAAQRBqIQAgH0EEayIfDQALDAELIBxBKEG03sAAEGkACyABBEADQCAAIAA1AgBCCn4gAnwiAj4CACAAQQRqIQAgAkIgiCECIAFBAWsiAQ0ACwsgAqciAEUNACAbQSdLDRggG0ECdCAdakGsAWogADYCACAbQQFqIRsLIB0gGzYCqAEgKkEpTw0AICpFBEAgHUEANgLQAgwDCyAqQQFrQf////8DcSIaQQFqIgBBA3EhASAaQQNJBEBCACECIB4hAAwCCyAAQfz///8HcSEfQgAhAiAeIQADQCAAIAA1AgBCCn4gAnwiAj4CACAAQQRqIhogGjUCAEIKfiACQiCIfCICPgIAIABBCGoiGiAaNQIAQgp+IAJCIIh8IgI+AgAgAEEMaiIaIBo1AgBCCn4gAkIgiHwiAj4CACACQiCIIQIgAEEQaiEAIB9BBGsiHw0ACwwBCyAqQShBtN7AABDKAQALIAEEQANAIAAgADUCAEIKfiACfCICPgIAIABBBGohACACQiCIIQIgAUEBayIBDQALCyAdIAKnIgAEfyAqQSdLDQIgKkECdCAdakHUAmogADYCACAqQQFqBSAqCzYC0AILIB1BoAVqIgBBBHIgNEGgARDgASE1IB0gJDYCoAUgAEEBECUhJCAdKAL4AyEBIB1ByAZqIgBBBHIgNEGgARDgASFBIB0gATYCyAYgAEECECUhHCAdKAL4AyEBIB1B8AdqIgBBBHIgNEGgARDgASFCIB0gATYC8AcgAEEDECUhAAJAIB0oAgAiGyAAKAIAIjsgGyA7SxsiH0EoTQRAIB1B2AJqITkgHUGgCWohKiAdQYAEaiErIB1BqAVqITwgHUHQBmohMiAdQfgHaiEpIB1BCGohGiAdQZgJakEEciFDICQoAgAhPiAcKAIAIT8gHSgC+AMhNkEAIRwDQCAcISQgH0ECdCEAAkADQCAABEAgACAdaiEiIB1B8AdqIABqIQEgAEEEayEAQX8gASgCACIcICIoAgAiAUcgASAcSRsiAUUNAQwCCwtBf0EAIAAbIQELQQAhLiABQQFNBEAgHwRAQQEhJkEAIS0gH0EBRwRAIB9BfnEhJSApIQEgGiEAA0AgAEEEayIcICYgHCgCACIiIAFBBGsoAgBBf3NqIi9qIhw2AgAgACAAKAIAIhsgASgCAEF/c2oiMCAcIC9JICIgL0tyaiIcNgIAIBwgMEkgGyAwS3IhJiABQQhqIQEgAEEIaiEAICUgLUECaiItRw0ACwsgH0EBcQR/ICAgLUECdCIcaiIAIAAoAgAiASAcIEJqKAIAQX9zaiIcICZqIgA2AgAgACAcSSABIBxLcgUgJgtFDRELIB0gHzYCAEEIIS4gHyEbCyAbID8gGyA/SxsiH0EpTw0NIB9BAnQhAAJAA0AgAARAIAAgHWohIiAdQcgGaiAAaiEBIABBBGshAEF/IAEoAgAiHCAiKAIAIgFHIAEgHEkbIgFFDQEMAgsLQX9BACAAGyEBCwJAIAFBAUsEQCAbIR8MAQsgHwRAQQEhJkEAIS0gH0EBRwRAIB9BfnEhJSAyIQEgGiEAA0AgAEEEayIcICYgHCgCACIiIAFBBGsoAgBBf3NqIi9qIhw2AgAgACAAKAIAIhsgASgCAEF/c2oiMCAcIC9JICIgL0tyaiIcNgIAIBwgMEkgGyAwS3IhJiABQQhqIQEgAEEIaiEAICUgLUECaiItRw0ACwsgH0EBcQR/ICAgLUECdCIcaiIAIAAoAgAiASAcIEFqKAIAQX9zaiIcICZqIgA2AgAgACAcSSABIBxLcgUgJgtFDRELIB0gHzYCACAuQQRyIS4LIB8gPiAfID5LGyIcQSlPDRggHEECdCEAAkADQCAABEAgACAdaiEiIB1BoAVqIABqIQEgAEEEayEAQX8gASgCACIbICIoAgAiAUcgASAbSRsiAUUNAQwCCwtBf0EAIAAbIQELAkAgAUEBSwRAIB8hHAwBCyAcBEBBASEmQQAhLSAcQQFHBEAgHEF+cSElIDwhASAaIQADQCAAQQRrIhsgJiAbKAIAIiIgAUEEaygCAEF/c2oiL2oiGzYCACAAIAAoAgAiHyABKAIAQX9zaiIwIBsgL0kgIiAvS3JqIhs2AgAgGyAwSSAfIDBLciEmIAFBCGohASAAQQhqIQAgJSAtQQJqIi1HDQALCyAcQQFxBH8gICAtQQJ0IhtqIgAgACgCACIBIBsgNWooAgBBf3NqIhsgJmoiADYCACAAIBtJIAEgG0tyBSAmC0UNEQsgHSAcNgIAIC5BAmohLgsgHCA2IBwgNksbIhtBKU8NFiAbQQJ0IQACQANAIAAEQCAAIB1qISIgHUH4A2ogAGohASAAQQRrIQBBfyABKAIAIh8gIigCACIBRyABIB9JGyIBRQ0BDAILC0F/QQAgABshAQsCQCABQQFLBEAgHCEbDAELIBsEQEEBISZBACEtIBtBAUcEQCAbQX5xISUgKyEBIBohAANAIABBBGsiHCAmIBwoAgAiIiABQQRrKAIAQX9zaiIvaiIcNgIAIAAgACgCACIfIAEoAgBBf3NqIjAgHCAvSSAiIC9LcmoiHDYCACAcIDBJIB8gMEtyISYgAUEIaiEBIABBCGohACAlIC1BAmoiLUcNAAsLIBtBAXEEfyAgIC1BAnQiHGoiACAAKAIAIgEgHCA0aigCAEF/c2oiHCAmaiIANgIAIAAgHEkgASAcS3IFICYLRQ0RCyAdIBs2AgAgLkEBaiEuCyAkQRFGDQYgISAkaiAuQTBqOgAAIBsgHSgCqAEiNyAbIDdLGyIAQSlPDQ4gJEEBaiEcIABBAnQhAAJAA0AgAARAIAAgHWohIiAdQagBaiAAaiEBIABBBGshAEF/IAEoAgAiHyAiKAIAIgFHIAEgH0kbIh9FDQEMAgsLQX9BACAAGyEfCyBDICBBoAEQ4AEhRCAdIBs2ApgJIBsgHSgC0AIiOCAbIDhLGyIuQSlPDQQCQCAuRQRAQQAhLgwBC0EAISZBACEtIC5BAUcEQCAuQX5xIS8gOSEBICohAANAIABBBGsiIiAmICIoAgAiMCABQQRrKAIAaiJAaiIiNgIAIAAgACgCACIlIAEoAgBqIiYgIiBASSAwIEBLcmoiIjYCACAiICZJICUgJktyISYgAUEIaiEBIABBCGohACAvIC1BAmoiLUcNAAsLIC5BAXEEfyBEIC1BAnQiImoiACAAKAIAIgEgHiAiaigCAGoiIiAmaiIANgIAIAAgIkkgASAiS3IFICYLRQ0AIC5BJ0sNBiAuQQJ0IB1qQZwJakEBNgIAIC5BAWohLgsgHSAuNgKYCSA2IC4gLiA2SRsiAEEpTw0OIABBAnQhAAJAA0AgAARAIB1B+ANqIABqISUgHUGYCWogAGohASAAQQRrIQBBfyABKAIAIiIgJSgCACIBRyABICJJGyIBRQ0BDAILC0F/QQAgABshAQsgHyAzSCABIDNIcg0CIBtBKU8NFgJAIBtFBEBBACEbDAELIBtBAWtB/////wNxIiRBAWoiH0EDcSEBQgAhAiAgIQAgJEEDTwRAIB9B/P///wdxIR8DQCAAIAA1AgBCCn4gAnwiAj4CACAAQQRqIiQgJDUCAEIKfiACQiCIfCICPgIAIABBCGoiJCAkNQIAQgp+IAJCIIh8IgI+AgAgAEEMaiIkICQ1AgBCCn4gAkIgiHwiAj4CACACQiCIIQIgAEEQaiEAIB9BBGsiHw0ACwsgAQRAA0AgACAANQIAQgp+IAJ8IgI+AgAgAEEEaiEAIAJCIIghAiABQQFrIgENAAsLIAKnIgBFDQAgG0EnSw0YIB0gG0ECdGpBBGogADYCACAbQQFqIRsLIB0gGzYCACA3QSlPDQcCQCA3RQRAQQAhNwwBCyA3QQFrQf////8DcSIkQQFqIh9BA3EhAUIAIQIgKCEAICRBA08EQCAfQfz///8HcSEfA0AgACAANQIAQgp+IAJ8IgI+AgAgAEEEaiIkICQ1AgBCCn4gAkIgiHwiAj4CACAAQQhqIiQgJDUCAEIKfiACQiCIfCICPgIAIABBDGoiJCAkNQIAQgp+IAJCIIh8IgI+AgAgAkIgiCECIABBEGohACAfQQRrIh8NAAsLIAEEQANAIAAgADUCAEIKfiACfCICPgIAIABBBGohACACQiCIIQIgAUEBayIBDQALCyACpyIARQ0AIDdBJ0sNCSA3QQJ0IB1qQawBaiAANgIAIDdBAWohNwsgHSA3NgKoASA4QSlPDQkCQCA4RQRAQQAhOAwBCyA4QQFrQf////8DcSIkQQFqIh9BA3EhAUIAIQIgHiEAICRBA08EQCAfQfz///8HcSEfA0AgACAANQIAQgp+IAJ8IgI+AgAgAEEEaiIkICQ1AgBCCn4gAkIgiHwiAj4CACAAQQhqIiQgJDUCAEIKfiACQiCIfCICPgIAIABBDGoiJCAkNQIAQgp+IAJCIIh8IgI+AgAgAkIgiCECIABBEGohACAfQQRrIh8NAAsLIAEEQANAIAAgADUCAEIKfiACfCICPgIAIABBBGohACACQiCIIQIgAUEBayIBDQALCyACpyIARQ0AIDhBJ0sNCyA4QQJ0IB1qQdQCaiAANgIAIDhBAWohOAsgHSA4NgLQAiAbIDsgGyA7SxsiH0EoTQ0ACwsMCwsgASAzTg0JIB8gM0gEQCAdQQEQJSgCACIBIB0oAvgDIgAgACABSRsiAEEpTw0MIABBAnQhAAJAA0AgAARAIAAgHWohKCAdQfgDaiAAaiEBIABBBGshAEF/IAEoAgAiGiAoKAIAIgFHIAEgGkkbIgFFDQEMAgsLQX9BACAAGyEBCyABQQJPDQoLICRBEU8NCCAkIQBBfyEBAkADQCAAQX9GDQEgAUEBaiEBIAAgIWogAEEBayEALQAAQTlGDQALIAAgIWoiKEEBaiIaIBotAABBAWo6AAAgAEECaiAkSw0KIChBAmpBMCABEN4BGgwKCyAhQTE6AAAgJARAICFBAWpBMCAkEN4BGgsgHCAhaiEAIBxBEUkEQCAAQTA6AAAgI0EBaiEjICRBAmohHAwKCyAcQRFB+LXAABBpAAsgKkEoQbTewAAQaQALIC5BKEG03sAAEMoBAAsgLkEoQbTewAAQaQALQRFBEUHYtcAAEGkACyA3QShBtN7AABDKAQALIDdBKEG03sAAEGkACyA4QShBtN7AABDKAQALIDhBKEG03sAAEGkACyAcQRFB6LXAABDKAQALIBxBEU0EQCA6ICM7AQggOiAcNgIEIDogITYCACAdQcAKaiQADAULIBxBEUGItsAAEMoBAAsgH0EoQbTewAAQygEACyAAQShBtN7AABDKAQALQcTewABBGkG03sAAEIMBAAsgJ0HYAGogJ0EoaigCADYCACAnICcpAyA3A1ALICcgJygCUCAnKAJUICcvAVhBACAnQSBqEDogJygCBCEAICcoAgAMAwsgJ0ECOwEgICdBATYCKCAnQa3HwAA2AiQgJ0EgagwCCyAnQQM2AiggJ0Gux8AANgIkICdBAjsBICAnQSBqDAELICdBAzYCKCAnQbHHwAA2AiQgJ0ECOwEgQQEhAEHIr8AAISwgJ0EgagshASAnQdwAaiAANgIAICcgATYCWCAnID02AlQgJyAsNgJQICdB0ABqEDEgJ0GAAWokAA8LIBtBKEG03sAAEMoBAAsgG0EoQbTewAAQaQALIBxBKEG03sAAEMoBAAs5AAJAAn8gAkGAgMQARwRAQQEgACACIAEoAhARAAANARoLIAMNAUEACw8LIAAgAyAEIAEoAgwRAQALQAEBfyMAQSBrIgAkACAAQRxqQQA2AgAgAEHYocAANgIYIABCATcCDCAAQcCkwAA2AgggAEEIakHIpMAAEIkBAAtAAQF/IwBBIGsiACQAIABBHGpBADYCACAAQZSuwAA2AhggAEIBNwIMIABBxK7AADYCCCAAQQhqQcyuwAAQiQEAC98CAQJ/IwBBIGsiAiQAIAJBAToAGCACIAE2AhQgAiAANgIQIAJBhMnAADYCDCACQcivwAA2AggjAEEQayIBJAACQCACQQhqIgAoAgwiAgRAIAAoAggiA0UNASABIAI2AgggASAANgIEIAEgAzYCACMAQRBrIgAkACAAQQhqIAFBCGooAgA2AgAgACABKQIANwMAIwBBEGsiASQAIAAoAgAiAkEUaigCACEDAkACfwJAAkAgAigCBA4CAAEDCyADDQJBACECQdihwAAMAQsgAw0BIAIoAgAiAygCBCECIAMoAgALIQMgASACNgIEIAEgAzYCACABQbSnwAAgACgCBCIBKAIIIAAoAgggAS0AEBBWAAsgAUEANgIEIAEgAjYCACABQaCnwAAgACgCBCIBKAIIIAAoAgggAS0AEBBWAAtBnKLAAEErQfCmwAAQgwEAC0GcosAAQStB4KbAABCDAQALMwACQCAAQfz///8HSw0AIABFBEBBBA8LIAAgAEH9////B0lBAnQQuAEiAEUNACAADwsACz0BAX8gACgCACEBAkAgAEEEai0AAA0AQYTnwAAoAgBB/////wdxRQ0AEOoBDQAgAUEBOgABCyABQQA6AAALjB0CFH8EfiMAQRBrIhMkACATIAE2AgwgEyAANgIIAn8jAEEgayIJJAAgE0EIaiIAQQRqKAIAIQ0gACgCACELAkBBAEHYksAAKAIAEQIAIhEEQCARKAIADQEgEUF/NgIAIBFBBGoiCEEEaigCACICQQxrIQMgDQR+IA1BB3EhAQJAIA1BAWtBB0kEQEKlxoihyJyn+UshFiALIQAMAQsgDUF4cSEEQqXGiKHInKf5SyEWIAshAANAIAAxAAcgADEABiAAMQAFIAAxAAQgADEAAyAAMQACIAAxAAEgFiAAMQAAhUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+hUKzg4CAgCB+IRYgAEEIaiEAIARBCGsiBA0ACwsgAQRAA0AgFiAAMQAAhUKzg4CAgCB+IRYgAEEBaiEAIAFBAWsiAQ0ACwsgFkL/AYVCs4OAgIAgfgVC7taLsMjJnLKvfwsiGEIZiEL/AINCgYKEiJCgwIABfiEZIBinIQAgCCgCACEBAkADQAJAIAIgACABcSIAaikAACIXIBmFIhZCf4UgFkKBgoSIkKDAgAF9g0KAgYKEiJCgwIB/gyIWUA0AA0ACQCANIANBACAWeqdBA3YgAGogAXFrIgRBDGxqIgdBBGooAgBGBEAgBygCACALIA0Q3wFFDQELIBZCAX0gFoMiFlBFDQEMAgsLIAkgCzYCBCAJQRBqIAg2AgAgCUEIaiANNgIAIAlBDGogAiAEQQxsajYCACAJQQA2AgAMAgsgFyAXQgGGg0KAgYKEiJCgwIB/g1AEQCAAIAVBCGoiBWohAAwBCwsgCCgCCEUEQEEAIQAjAEEwayIPJAACQCAIQQxqKAIAIhBBAWoiASAQSQRAEH4gDygCDBoMAQsCQAJAAn8CQCAIKAIAIgwgDEEBaiIHQQN2QQdsIAxBCEkbIhVBAXYgAUkEQCABIBVBAWoiACAAIAFJGyIAQQhJDQFBfyAAQQN0QQduQQFrZ3ZBAWogACAAQf////8BcUYNAhoQfiAPKAIsQYGAgIB4Rw0FIA8oAigMAgsgCEEEaigCACEEQQAhAQNAAkACfyAAQQFxBEAgAUEHaiIAIAFJIAAgB09yDQIgAUEIagwBCyABIAdJIgJFDQEgAiABIgBqCyEBIAAgBGoiACAAKQMAIhZCf4VCB4hCgYKEiJCgwIABgyAWQv/+/fv379+//wCEfDcDAEEBIQAMAQsLAkACQCAHQQhPBEAgBCAHaiAEKQAANwAADAELAkACQAJ/AkAgByIDIARBCGoiAiAEIgBrSwRAIAAgA2ohBSACIANqIQEgA0EPSw0BIAIMAgsgA0EPTQRAIAIhAQwDCyACQQAgAmtBA3EiBWohBiAFBEAgAiEBIAAhAgNAIAEgAi0AADoAACACQQFqIQIgAUEBaiIBIAZJDQALCyAGIAMgBWsiA0F8cSIKaiEBAkAgACAFaiIFQQNxIgIEQCAKQQBMDQEgBUF8cSIOQQRqIQBBACACQQN0IhJrQRhxIRQgDigCACECA0AgBiACIBJ2IAAoAgAiAiAUdHI2AgAgAEEEaiEAIAZBBGoiBiABSQ0ACwwBCyAKQQBMDQAgBSEAA0AgBiAAKAIANgIAIABBBGohACAGQQRqIgYgAUkNAAsLIANBA3EhAyAFIApqIQAMAgsgAUF8cSECQQAgAUEDcSIKayEOIAoEQCAAIANqQQFrIQYDQCABQQFrIgEgBi0AADoAACAGQQFrIQYgASACSw0ACwsgAiADIAprIgpBfHEiA2shAUEAIANrIQMCQCAFIA5qIgVBA3EiBgRAIANBAE4NASAFQXxxIg5BBGshAEEAIAZBA3QiEmtBGHEhFCAOKAIAIQYDQCACQQRrIgIgBiAUdCAAKAIAIgYgEnZyNgIAIABBBGshACABIAJJDQALDAELIANBAE4NACAAIApqQQRrIQADQCACQQRrIgIgACgCADYCACAAQQRrIQAgASACSQ0ACwsgCkEDcSIARQ0CIAMgBWohBSABIABrCyECIAVBAWshAANAIAFBAWsiASAALQAAOgAAIABBAWshACABIAJLDQALDAELIANFDQAgASADaiECA0AgASAALQAAOgAAIABBAWohACABQQFqIgEgAkkNAAsLIAdFDQELIARBDGshDkEAIQEDQAJAIAQgASICaiIFLQAAQYABRw0AIA4gAkF0bGohBiAEIAJBf3NBDGxqIQcCQANAIAwgBkEEaigCACIABH4gBigCACEBIABBB3EhA0KlxoihyJyn+UshFgJAIABBAWtBB0kEQCABIQAMAQsgAEF4cSEKA0AgATEAByABMQAGIAExAAUgATEABCABMQADIAExAAIgATEAASAWIAExAACFQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH4hFiABQQhqIgAhASAKQQhrIgoNAAsLIAMEQANAIBYgADEAAIVCs4OAgIAgfiEWIABBAWohACADQQFrIgMNAAsLIBZC/wGFQrODgICAIH4FQu7Wi7DIyZyyr38LpyIKcSIDIQAgAyAEaikAAEKAgYKEiJCgwIB/gyIWUARAQQghASADIQADQCAAIAFqIQAgAUEIaiEBIAQgACAMcSIAaikAAEKAgYKEiJCgwIB/gyIWUA0ACwsgBCAWeqdBA3YgAGogDHEiAGosAABBAE4EQCAEKQMAQoCBgoSIkKDAgH+DeqdBA3YhAAsgACADayACIANrcyAMcUEITwRAIAQgAEF/c0EMbGohASAAIARqIgMtAAAgAyAKQRl2IgM6AAAgAEEIayAMcSAEakEIaiADOgAAQf8BRg0CIAcoAAAhACAHIAEoAAA2AAAgASAANgAAIAEoAAQhACABIAcoAAQ2AAQgByAANgAEIActAAohACAHIAEtAAo6AAogASAAOgAKIActAAshACAHIAEtAAs6AAsgASAAOgALIAcvAAghACAHIAEvAAg7AAggASAAOwAIDAELCyAFIApBGXYiADoAACACQQhrIAxxIARqQQhqIAA6AAAMAQsgBUH/AToAACACQQhrIAxxIARqQQhqQf8BOgAAIAFBCGogB0EIaigAADYAACABIAcpAAA3AAALIAJBAWohASACIAxHDQALCyAIIBUgEGs2AggMBAtBBEEIIABBBEkbCyIBrUIMfiIWQiCIpw0AIBanIgBBB2oiAiAASQ0AIAJBeHEiAiABQQhqIgRqIgAgAk8NAQsQfiAPKAIUGgwBCwJAAkAgAEEATgRAQQghAwJAIABFDQAgAEEIELgBIgMNACAAQQgQ2wEACyACIANqQf8BIAQQ3gEhBCABQQFrIgUgAUEDdkEHbCAFQQhJGyAQa60gEK1CIIaEIRcgB0UEQCAIIBc3AgggCCAFNgIAIAgoAgQhAiAIIAQ2AgQMAwsgCEEEaigCACICQQxrIRADQCACIAZqLAAAQQBOBEAgBCAFIBAgBkF0bGoiAUEEaigCACIABH4gASgCACEBIABBB3EhCkKlxoihyJyn+UshFgJAIABBAWtBB0kEQCABIQAMAQsgAEF4cSEDA0AgATEAByABMQAGIAExAAUgATEABCABMQADIAExAAIgATEAASAWIAExAACFQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH6FQrODgICAIH4hFiABQQhqIgAhASADQQhrIgMNAAsLIAoEQANAIBYgADEAAIVCs4OAgIAgfiEWIABBAWohACAKQQFrIgoNAAsLIBZC/wGFQrODgICAIH4FQu7Wi7DIyZyyr38LpyIDcSIAaikAAEKAgYKEiJCgwIB/gyIWUARAQQghAQNAIAAgAWohACABQQhqIQEgBCAAIAVxIgBqKQAAQoCBgoSIkKDAgH+DIhZQDQALCyAEIBZ6p0EDdiAAaiAFcSIBaiwAAEEATgRAIAQpAwBCgIGChIiQoMCAf4N6p0EDdiEBCyABIARqIANBGXYiADoAACABQQhrIAVxIARqQQhqIAA6AAAgBCABQX9zQQxsaiIAQQhqIAIgBkF/c0EMbGoiAUEIaigAADYAACAAIAEpAAA3AAALIAYgDEYgBkEBaiEGRQ0ACwwBCxB+IA8oAhwaDAILIAggFzcCCCAIIAU2AgAgCEEEaiAENgIAIAwNAAwBCyAMIAetQgx+p0EHakF4cSIAakF3Rg0AIAIgAGsQJgsgD0EwaiQACyAJIBg3AwggCUEYaiAINgIAIAlBFGogDTYCACAJQRBqIAs2AgAgCUEBNgIACwJAIAkoAgBFBEAgCUEMaigCACEADAELIAlBFGooAgAhAyAJQRBqKAIAIQcgCUEYaigCACECIAkoAgghCCALIA0QEyEFIAJBBGooAgAiASAIIAIoAgAiBHEiC2opAABCgIGChIiQoMCAf4MiFlAEQEEIIQADQCAAIAtqIQsgAEEIaiEAIAEgBCALcSILaikAAEKAgYKEiJCgwIB/gyIWUA0ACwsgASAWeqdBA3YgC2ogBHEiAGosAAAiC0EATgRAIAEgASkDAEKAgYKEiJCgwIB/g3qnQQN2IgBqLQAAIQsLIAAgAWogCEEZdiIIOgAAIABBCGsgBHEgAWpBCGogCDoAACACIAIoAgggC0EBcWs2AgggAiACKAIMQQFqNgIMIAEgAEF0bGoiAEEMayIBIAU2AgggASADNgIEIAEgBzYCAAsgAEEEaygCABAKIBEgESgCAEEBajYCACAJQSBqJAAMAgtB6JLAAEHGACAJQbCTwABBkJTAABBkAAtBoJTAAEEQIAlBsJTAAEGglcAAEGQACyATQRBqJAALvQIBA38gACgCACEAIAEQvwFFBEAgARDAAUUEQCAAMQAAQQEgARBCDwsjAEGAAWsiAyQAIAAtAAAhAANAIAIgA2pB/wBqQTBBNyAAQQ9xIgRBCkkbIARqOgAAIAJBAWshAiAAIgRBBHYhACAEQQ9LDQALIAJBgAFqIgBBgQFPBEAgAEGAAUGky8AAEMkBAAsgAUEBQbTLwABBAiACIANqQYABakEAIAJrEC0gA0GAAWokAA8LIwBBgAFrIgMkACAALQAAIQADQCACIANqQf8AakEwQdcAIABBD3EiBEEKSRsgBGo6AAAgAkEBayECIAAiBEEEdiEAIARBD0sNAAsgAkGAAWoiAEGBAU8EQCAAQYABQaTLwAAQyQEACyABQQFBtMvAAEECIAIgA2pBgAFqQQAgAmsQLSADQYABaiQAC70CAQN/IAAoAgAhAiABEL8BRQRAIAEQwAFFBEAgAiABEMwBDwtBACEAIwBBgAFrIgMkACACKAIAIQIDQCAAIANqQf8AakEwQTcgAkEPcSIEQQpJGyAEajoAACAAQQFrIQAgAkEPSyACQQR2IQINAAsgAEGAAWoiAkGBAU8EQCACQYABQaTLwAAQyQEACyABQQFBtMvAAEECIAAgA2pBgAFqQQAgAGsQLSADQYABaiQADwtBACEAIwBBgAFrIgMkACACKAIAIQIDQCAAIANqQf8AakEwQdcAIAJBD3EiBEEKSRsgBGo6AAAgAEEBayEAIAJBD0sgAkEEdiECDQALIABBgAFqIgJBgQFPBEAgAkGAAUGky8AAEMkBAAsgAUEBQbTLwABBAiAAIANqQYABakEAIABrEC0gA0GAAWokAAuZAQEBfyMAQRBrIgAkACAAQQhqIgIgAUHyosAAEJMBIAItAAQhASACLQAFBEAgAgJ/QQEgAUH/AXENABogAigCACIBLQAAQQRxRQRAIAEoAhhB/crAAEECIAFBHGooAgAoAgwRAQAMAQsgASgCGEHvysAAQQEgAUEcaigCACgCDBEBAAsiAToABAsgAUH/AXFBAEcgAEEQaiQAC+QBAQJ/IwBBEGsiACQAIABBCGoiAyABQdikwAAQkwEjAEEQayICJAAgAwJ/QQEgAy0ABA0AGiADKAIAIQEgA0EFai0AAEUEQCABKAIYQfbKwABBByABQRxqKAIAKAIMEQEADAELIAEtAABBBHFFBEAgASgCGEHwysAAQQYgAUEcaigCACgCDBEBAAwBCyACQQE6AA8gAiABKQIYNwMAIAIgAkEPajYCCEEBIAJB7MrAAEEDEDcNABogASgCGEHvysAAQQEgASgCHCgCDBEBAAsiAToABCACQRBqJAAgAEEQaiQAIAEL8wIBAn8gACgCACIALQAAIABBADoAAEEBcUUEQEG4jsAAQStBsI/AABCDAQALIwBBIGsiACQAAkACQAJAQYTnwAAoAgBB/////wdxBEAQ6gFFDQELQfTmwAAoAgBB9ObAAEF/NgIADQECQAJAQYTnwAAoAgBB/////wdxRQRAQYDnwAAoAgAhAUGA58AAQYyOwAA2AgBB/ObAACgCACECQfzmwABBATYCAAwBCxDqAUGA58AAKAIAIQFBgOfAAEGMjsAANgIAQfzmwAAoAgAhAkH85sAAQQE2AgBFDQELQYTnwAAoAgBB/////wdxRQ0AEOoBDQBB+ObAAEEBOgAAC0H05sAAQQA2AgACQCACRQ0AIAIgASgCABEEACABQQRqKAIARQ0AIAFBCGooAgAaIAIQJgsgAEEgaiQADAILIABBHGpBADYCACAAQdihwAA2AhggAEIBNwIMIABBrKbAADYCCCAAQQhqQdCmwAAQiQEACwALCzQAIABBAzoAICAAQoCAgICABDcCACAAIAE2AhggAEEANgIQIABBADYCCCAAQRxqIAI2AgALMAAgASgCGCACQQsgAUEcaigCACgCDBEBACECIABBADoABSAAIAI6AAQgACABNgIACycAIAAgACgCBEEBcSABckECcjYCBCAAIAFqIgAgACgCBEEBcjYCBAs6AQJ/QdDmwAAtAAAhAUHQ5sAAQQA6AABB1ObAACgCACECQdTmwABBADYCACAAIAI2AgQgACABNgIACyEAAkAgAC0AAEEDRw0AIABBCGooAgBFDQAgACgCBBAmCwsgAQF/AkAgACgCBCIBRQ0AIABBCGooAgBFDQAgARAmCwsjAAJAIAFB/P///wdNBEAgACABQQQgAhCwASIADQELAAsgAAsjACACIAIoAgRBfnE2AgQgACABQQFyNgIEIAAgAWogATYCAAseACAAKAIAIgCtQgAgAKx9IABBAE4iABsgACABEEILHgAgAEUEQBDUAQALIAAgAiADIAQgBSABKAIQEQ0ACyMAIABBADYCACAAIAEpAgA3AgQgAEEMaiABQQhqKAIANgIACx8BAn4gACkDACICIAJCP4ciA4UgA30gAkIAWSABEEILHAAgAEUEQBDUAQALIAAgAiADIAQgASgCEBETAAscACAARQRAENQBAAsgACACIAMgBCABKAIQERUACxwAIABFBEAQ1AEACyAAIAIgAyAEIAEoAhARCAALHAAgAEUEQBDUAQALIAAgAiADIAQgASgCEBEXAAscACAARQRAENQBAAsgACACIAMgBCABKAIQEQwACx4AIAAgAUEDcjYCBCAAIAFqIgAgACgCBEEBcjYCBAsUACAAQQRqKAIABEAgACgCABAmCwsaACAARQRAENQBAAsgACACIAMgASgCEBEFAAsiACAALQAARQRAIAFBmM7AAEEFECcPCyABQZTOwABBBBAnCxgAIABFBEAQ1AEACyAAIAIgASgCEBEAAAsZAQF/IAAoAhAiAQR/IAEFIABBFGooAgALCxgAIAAoAgAiACgCACAAQQhqKAIAIAEQKgsSAEEAQRkgAEEBdmsgAEEfRhsLFgAgACABQQFyNgIEIAAgAWogATYCAAscACABKAIYQfjHwABBDiABQRxqKAIAKAIMEQEACxkAIAAoAhggASACIABBHGooAgAoAgwRAQALHAAgASgCGEG538AAQQUgAUEcaigCACgCDBEBAAsQACAAIAFqQQFrQQAgAWtxC48GAQZ/An8gACEFAkACQAJAIAJBCU8EQCADIAIQOCIHDQFBAAwEC0EIQQgQrwEhAEEUQQgQrwEhAUEQQQgQrwEhAkEAQRBBCBCvAUECdGsiBEGAgHwgAiAAIAFqamtBd3FBA2siACAAIARLGyADTQ0BQRAgA0EEakEQQQgQrwFBBWsgA0sbQQgQrwEhAiAFEO4BIgAgABDXASIEEOsBIQECQAJAAkACQAJAAkACQCAAEMQBRQRAIAIgBE0NASABQazqwAAoAgBGDQIgAUGo6sAAKAIARg0DIAEQvQENByABENcBIgYgBGoiCCACSQ0HIAggAmshBCAGQYACSQ0EIAEQRgwFCyAAENcBIQEgAkGAAkkNBiABIAJrQYGACEkgAkEEaiABTXENBSABIAAoAgAiAWpBEGohBCACQR9qQYCABBCvASECDAYLQRBBCBCvASAEIAJrIgFLDQQgACACEOsBIQQgACACEJQBIAQgARCUASAEIAEQMgwEC0Gk6sAAKAIAIARqIgQgAk0NBCAAIAIQ6wEhASAAIAIQlAEgASAEIAJrIgJBAXI2AgRBpOrAACACNgIAQazqwAAgATYCAAwDC0Gg6sAAKAIAIARqIgQgAkkNAwJAQRBBCBCvASAEIAJrIgFLBEAgACAEEJQBQQAhAUEAIQQMAQsgACACEOsBIgQgARDrASEGIAAgAhCUASAEIAEQqwEgBiAGKAIEQX5xNgIEC0Go6sAAIAQ2AgBBoOrAACABNgIADAILIAFBDGooAgAiCSABQQhqKAIAIgFHBEAgASAJNgIMIAkgATYCCAwBC0GQ58AAQZDnwAAoAgBBfiAGQQN2d3E2AgALQRBBCBCvASAETQRAIAAgAhDrASEBIAAgAhCUASABIAQQlAEgASAEEDIMAQsgACAIEJQBCyAADQMLIAMQJCIBRQ0BIAEgBSAAENcBQXhBfCAAEMQBG2oiACADIAAgA0kbEOABIAUQJgwDCyAHIAUgASADIAEgA0kbEOABGiAFECYLIAcMAQsgABDEARogABDtAQsLFAAgACgCACAAQQhqKAIAIAEQ3AELCwAgAQRAIAAQJgsLDwAgAEEBdCIAQQAgAGtyCxUAIAEgACgCACIAKAIAIAAoAgQQJwsUACAAKAIAIAEgACgCBCgCDBEAAAuuCAEDfyMAQfAAayIFJAAgBSADNgIMIAUgAjYCCAJAAkACQAJAIAUCfwJAAkAgAUGBAk8EQANAIAAgBmogBkEBayEGQYACaiwAAEG/f0wNAAsgBkGBAmoiByABSQ0CIAFBgQJrIAZHDQQgBSAHNgIUDAELIAUgATYCFAsgBSAANgIQQcivwAAhBkEADAELIAAgBmpBgQJqLAAAQb9/TA0BIAUgBzYCFCAFIAA2AhBBjNDAACEGQQULNgIcIAUgBjYCGAJAIAEgAkkiBiABIANJckUEQAJ/AkACQCACIANNBEACQAJAIAJFDQAgASACTQRAIAEgAkYNAQwCCyAAIAJqLAAAQUBIDQELIAMhAgsgBSACNgIgIAIgASIGSQRAIAJBAWoiBkEAIAJBA2siAyACIANJGyIDSQ0GIAAgBmogACADamshBgNAIAZBAWshBiAAIAJqIAJBAWshAiwAAEFASA0ACyACQQFqIQYLAkAgBkUNACABIAZNBEAgASAGRg0BDAoLIAAgBmosAABBv39MDQkLIAEgBkYNBwJAIAAgBmoiAiwAACIDQQBIBEAgAi0AAUE/cSEAIANBH3EhASADQV9LDQEgAUEGdCAAciEADAQLIAUgA0H/AXE2AiRBAQwECyACLQACQT9xIABBBnRyIQAgA0FwTw0BIAAgAUEMdHIhAAwCCyAFQeQAakH6ADYCACAFQdwAakH6ADYCACAFQdQAakEONgIAIAVBxABqQQQ2AgAgBUIENwI0IAVB8NDAADYCMCAFQQ42AkwgBSAFQcgAajYCQCAFIAVBGGo2AmAgBSAFQRBqNgJYIAUgBUEMajYCUCAFIAVBCGo2AkgMCAsgAUESdEGAgPAAcSACLQADQT9xIABBBnRyciIAQYCAxABGDQULIAUgADYCJEEBIABBgAFJDQAaQQIgAEGAEEkNABpBA0EEIABBgIAESRsLIQAgBSAGNgIoIAUgACAGajYCLCAFQcQAakEFNgIAIAVB7ABqQfoANgIAIAVB5ABqQfoANgIAIAVB3ABqQf0ANgIAIAVB1ABqQf4ANgIAIAVCBTcCNCAFQcTRwAA2AjAgBUEONgJMIAUgBUHIAGo2AkAgBSAFQRhqNgJoIAUgBUEQajYCYCAFIAVBKGo2AlggBSAFQSRqNgJQIAUgBUEgajYCSAwFCyAFIAIgAyAGGzYCKCAFQcQAakEDNgIAIAVB3ABqQfoANgIAIAVB1ABqQfoANgIAIAVCAzcCNCAFQbTQwAA2AjAgBUEONgJMIAUgBUHIAGo2AkAgBSAFQRhqNgJYIAUgBUEQajYCUCAFIAVBKGo2AkgMBAsgAyAGQYjSwAAQywEACyAAIAFBACAHIAQQtgEAC0GtxMAAQSsgBBCDAQALIAAgASAGIAEgBBC2AQALIAVBMGogBBCJAQALEQAgACgCACAAKAIEIAEQ3AELCAAgACABEDgLFgBB1ObAACAANgIAQdDmwABBAToAAAsRACABIAAoAgAgACgCBBCtAQsQACAAKAIAIAAoAgQgARAqCxMAIABBkKfAADYCBCAAIAE2AgALDQAgAC0ABEECcUEBdgsQACABIAAoAgAgACgCBBAnCw0AIAAtAABBEHFBBHYLDQAgAC0AAEEgcUEFdgsMACAAKAIAEBVBAEcLDAAgACgCABAdQQBHCwoAQQAgAGsgAHELCwAgAC0ABEEDcUULDAAgACABQQNyNgIECw0AIAAoAgAgACgCBGoL1gIBAn8gACgCACEAIwBBEGsiAiQAAkACfwJAIAFBgAFPBEAgAkEANgIMIAFBgBBPDQEgAiABQT9xQYABcjoADSACIAFBBnZBwAFyOgAMQQIMAgsgACgCCCIDIAAoAgRGBEAgACADEFQgACgCCCEDCyAAIANBAWo2AgggACgCACADaiABOgAADAILIAFBgIAETwRAIAIgAUE/cUGAAXI6AA8gAiABQQZ2QT9xQYABcjoADiACIAFBDHZBP3FBgAFyOgANIAIgAUESdkEHcUHwAXI6AAxBBAwBCyACIAFBP3FBgAFyOgAOIAIgAUEMdkHgAXI6AAwgAiABQQZ2QT9xQYABcjoADUEDCyEBIAEgAEEEaigCACAAKAIIIgNrSwRAIAAgAyABEFIgACgCCCEDCyAAKAIAIANqIAJBDGogARDgARogACABIANqNgIICyACQRBqJABBAAsOACAAKAIAGgNADAALAAttAQF/IwBBMGsiAyQAIAMgATYCBCADIAA2AgAgA0EcakECNgIAIANBLGpBDjYCACADQgI3AgwgA0Goz8AANgIIIANBDjYCJCADIANBIGo2AhggAyADQQRqNgIoIAMgAzYCICADQQhqIAIQiQEAC20BAX8jAEEwayIDJAAgAyABNgIEIAMgADYCACADQRxqQQI2AgAgA0EsakEONgIAIANCAjcCDCADQcjPwAA2AgggA0EONgIkIAMgA0EgajYCGCADIANBBGo2AiggAyADNgIgIANBCGogAhCJAQALbQEBfyMAQTBrIgMkACADIAE2AgQgAyAANgIAIANBHGpBAjYCACADQSxqQQ42AgAgA0ICNwIMIANB/M/AADYCCCADQQ42AiQgAyADQSBqNgIYIAMgA0EEajYCKCADIAM2AiAgA0EIaiACEIkBAAsNACAANQIAQQEgARBCC9gCAgR/An4jAEFAaiICJABBASEEAkAgAC0ABA0AIAAtAAUhBAJAAkACQCAAKAIAIgMoAgAiBUEEcUUEQCAEDQEMAwsgBA0BQQEhBCADKAIYQYPLwABBASADQRxqKAIAKAIMEQEADQMgAygCACEFDAELQQEhBCADKAIYQerKwABBAiADQRxqKAIAKAIMEQEARQ0BDAILQQEhBCACQQE6ABcgAkE0akHMysAANgIAIAIgBTYCGCACIAMpAhg3AwggAiACQRdqNgIQIAMpAgghBiADKQIQIQcgAiADLQAgOgA4IAIgAygCBDYCHCACIAc3AyggAiAGNwMgIAIgAkEIajYCMCABIAJBGGpBoJrAACgCABEAAA0BIAIoAjBB6MrAAEECIAIoAjQoAgwRAQAhBAwBCyABIANBoJrAACgCABEAACEECyAAQQE6AAUgACAEOgAEIAJBQGskAAsNACAAKAIAIAEgAhA3Cw0AIAApAwBBASABEEILxwMCAX4EfyAAKAIAKQMAIQIjAEGAAWsiBSQAAkACQAJAAkAgASgCACIAQRBxRQRAIABBIHENASACQQEgARBCIQAMBAtBgAEhACAFQYABaiEEAkACQANAIABFBEBBACEADAMLIARBAWtBMEHXACACpyIDQQ9xIgZBCkkbIAZqOgAAIAJCEFoEQCAEQQJrIgRBMEHXACADQf8BcSIDQaABSRsgA0EEdmo6AAAgAEECayEAIAJCgAJUIAJCCIghAkUNAQwCCwsgAEEBayEACyAAQYEBTw0CCyABQQFBtMvAAEECIAAgBWpBgAEgAGsQLSEADAMLQYABIQAgBUGAAWohBAJAAkADQCAARQRAQQAhAAwDCyAEQQFrQTBBNyACpyIDQQ9xIgZBCkkbIAZqOgAAIAJCEFoEQCAEQQJrIgRBMEE3IANB/wFxIgNBoAFJGyADQQR2ajoAACAAQQJrIQAgAkKAAlQgAkIIiCECRQ0BDAILCyAAQQFrIQALIABBgQFPDQILIAFBAUG0y8AAQQIgACAFakGAASAAaxAtIQAMAgsgAEGAAUGky8AAEMkBAAsgAEGAAUGky8AAEMkBAAsgBUGAAWokACAACwsAIAAjAGokACMACw4AIAFBpInAAEEhEK0BCwsAIAAoAgAgARAJCwwAQbCVwABBMBAiAAsOACABQaiewABBMBCtAQsMACAAKAIAIAEQpgELCgAgACgCBEF4cQsKACAAKAIEQQFxCwoAIAAoAgxBAXELCgAgACgCDEEBdgsaACAAIAFB8ObAACgCACIAQeEAIAAbEQMAAAsKACACIAAgARAnCw0AIAFBwM7AAEECECcLrwEBA38gASEFAkAgAkEPTQRAIAAhAQwBCyAAQQAgAGtBA3EiA2ohBCADBEAgACEBA0AgASAFOgAAIAFBAWoiASAESQ0ACwsgBCACIANrIgJBfHEiA2ohASADQQBKBEAgBUH/AXFBgYKECGwhAwNAIAQgAzYCACAEQQRqIgQgAUkNAAsLIAJBA3EhAgsgAgRAIAEgAmohAgNAIAEgBToAACABQQFqIgEgAkkNAAsLIAALQwEDfwJAIAJFDQADQCAALQAAIgQgAS0AACIFRgRAIABBAWohACABQQFqIQEgAkEBayICDQEMAgsLIAQgBWshAwsgAwuzAgEHfwJAIAIiBEEPTQRAIAAhAgwBCyAAQQAgAGtBA3EiA2ohBSADBEAgACECIAEhBgNAIAIgBi0AADoAACAGQQFqIQYgAkEBaiICIAVJDQALCyAFIAQgA2siCEF8cSIHaiECAkAgASADaiIDQQNxIgQEQCAHQQBMDQEgA0F8cSIGQQRqIQFBACAEQQN0IglrQRhxIQQgBigCACEGA0AgBSAGIAl2IAEoAgAiBiAEdHI2AgAgAUEEaiEBIAVBBGoiBSACSQ0ACwwBCyAHQQBMDQAgAyEBA0AgBSABKAIANgIAIAFBBGohASAFQQRqIgUgAkkNAAsLIAhBA3EhBCADIAdqIQELIAQEQCACIARqIQMDQCACIAEtAAA6AAAgAUEBaiEBIAJBAWoiAiADSQ0ACwsgAAsOACABQYGdwABBChCtAQsOACABQbShwABBCBCtAQsOACABQbyhwABBAxCtAQttAQF/IwBBMGsiACQAIABBHzYCFCAAQfiXwAA2AhAgAEEBNgIsIABCATcCHCAAQfCXwAA2AhggACAAQRBqNgIoIAAgAEEYahA1IAEgACgCACIBIAAoAggQrQEgACgCBARAIAEQJgsgAEEwaiQACw4AIAFB/JfAAEEXEK0BC20BAX8jAEEwayIAJAAgAEEONgIUIABByJjAADYCECAAQQE2AiwgAEIBNwIcIABBwJjAADYCGCAAIABBEGo2AiggACAAQRhqEDUgASAAKAIAIgEgACgCCBCtASAAKAIEBEAgARAmCyAAQTBqJAALDgAgAUGTmMAAQRMQrQELCAAgACABEBcLCQAgACgCABAaCwsAQdzqwAAoAgBFCwcAIAAgAWoLBwAgACABawsHACAAQQhqCwcAIABBCGsLlQYBBX8CQCMAQdAAayICJAAgAkEANgIYIAJCATcDECACQSBqIgQgAkEQakH4lcAAEJIBIwBBQGoiACQAQQEhAwJAIAQoAhgiBUHkyMAAQQwgBEEcaigCACIEKAIMEQEADQACQCABKAIIIgMEQCAAIAM2AgwgAEH4ADYCFCAAIABBDGo2AhBBASEDIABBATYCPCAAQgI3AiwgAEH0yMAANgIoIAAgAEEQajYCOCAFIAQgAEEoahAwRQ0BDAILIAEoAgAiAyABKAIEQQxqKAIAEQoAQuuRk7X22LOi9ABSDQAgACADNgIMIABB+QA2AhQgACAAQQxqNgIQQQEhAyAAQQE2AjwgAEICNwIsIABB9MjAADYCKCAAIABBEGo2AjggBSAEIABBKGoQMA0BCyABKAIMIQEgAEEkakEONgIAIABBHGpBDjYCACAAIAFBDGo2AiAgACABQQhqNgIYIABB+gA2AhQgACABNgIQIABBAzYCPCAAQgM3AiwgAEHMyMAANgIoIAAgAEEQajYCOCAFIAQgAEEoahAwIQMLIABBQGskAAJAIANFBEAgAigCFCACKAIYIgBrQQlNBEAgAkEQaiAAQQoQUiACKAIYIQALIAIoAhAgAGoiAUG0l8AAKQAANwAAIAFBCGpBvJfAAC8AADsAACACIABBCmo2AhggAkEIahAeIgQQHyACKAIIIQYgAigCDCIFIAIoAhQgAigCGCIAa0sEQCACQRBqIAAgBRBSIAIoAhghAAsgAigCECAAaiAGIAUQ4AEaIAIgACAFaiIANgIYIAIoAhQgAGtBAU0EQCACQRBqIABBAhBSIAIoAhghAAsgAigCECAAakGKFDsAACACIABBAmoiAzYCGCACKAIQIQACQCADIAIoAhQiAU8EQCAAIQEMAQsgA0UEQEEBIQEgABAmDAELIAAgAUEBIAMQsAEiAUUNAgsgASADECAgBQRAIAYQJgsgBEEkTwRAIAQQAAsgAkHQAGokAAwCC0GQlsAAQTcgAkHIAGpByJbAAEGkl8AAEGQACyADQQEQ2wEACwsNAELrkZO19tizovQACw0AQo/oo8y3gau8un8LDABCsqH/yeyFlYdWCwMAAQsLi2YHAEGAgMAAC44xdHVwbGUgc3RydWN0IENlbGxJZCB3aXRoIDIgZWxlbWVudHMAAAAQACMAAAABAAAACAAAAAQAAAACAAAAAQAAAAAAAAABAAAAAwAAAAEAAAAAAAAAAQAAAAQAAAABAAAAAAAAAAEAAAAFAAAAAQAAAAAAAAABAAAABgAAAAEAAAAAAAAAAQAAAAcAAAABAAAAAAAAAAEAAAAIAAAAAQAAAAAAAAABAAAABAAAAAEAAAAAAAAAAQAAAAkAAAABAAAAAAAAAAEAAAAKAAAAcHJvdmVuYW5jZWNlbGxfaWR6b21lX25hbWVmbl9uYW1lY2FwX3NlY3JldHBheWxvYWRub25jZWV4cGlyZXNfYXRjYWxsZWQgYE9wdGlvbjo6dW53cmFwKClgIG9uIGEgYE5vbmVgIHZhbHVlL1VzZXJzL2pvc3QvLmNhcmdvL3JlZ2lzdHJ5L3NyYy9naXRodWIuY29tLTFlY2M2Mjk5ZGI5ZWM4MjMvc2VyZGUtd2FzbS1iaW5kZ2VuLTAuMy4xL3NyYy9kZS5ycwAAOAEQAF4AAABZAAAAHwAAAA8AAAAMAAAABAAAABAAAAARAAAAEgAAAGEgRGlzcGxheSBpbXBsZW1lbnRhdGlvbiByZXR1cm5lZCBhbiBlcnJvciB1bmV4cGVjdGVkbHkAEwAAAAAAAAABAAAAFAAAAC9ydXN0Yy82OWY5YzMzZDcxYzg3MWZjMTZhYzQ0NTIxMTI4MWM2ZTdhMzQwOTQzL2xpYnJhcnkvYWxsb2Mvc3JjL3N0cmluZy5ycwAIAhAASwAAAOgJAAAJAAAAaW52YWxpZCB2YWx1ZTogLCBleHBlY3RlZCAAAGQCEAAPAAAAcwIQAAsAAABtaXNzaW5nIGZpZWxkIGBgkAIQAA8AAACfAhAAAQAAAGludmFsaWQgbGVuZ3RoIACwAhAADwAAAHMCEAALAAAAZHVwbGljYXRlIGZpZWxkIGAAAADQAhAAEQAAAJ8CEAABAAAAFQAAAAwAAAAEAAAAFgAAABcAAAASAAAAYSBEaXNwbGF5IGltcGxlbWVudGF0aW9uIHJldHVybmVkIGFuIGVycm9yIHVuZXhwZWN0ZWRseQAYAAAAAAAAAAEAAAAUAAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9hbGxvYy9zcmMvc3RyaW5nLnJzAFQDEABLAAAA6AkAAAkAAAAzIGJ5dGUgcHJlZml4AAAAGAAAAAAAAAABAAAAGQAAAC9Vc2Vycy9qb3N0Ly5jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2hvbG9faGFzaC0wLjEuMC1iZXRhLXJjLjAvc3JjL2hhc2hfdHlwZS9wcmltaXRpdmUucnPQAxAAcAAAAE0AAAARAAAASG9sb0hhc2ggc2VyaWFsaXplZCByZXByZXNlbnRhdGlvbiBtdXN0IGJlIGV4YWN0bHkgMzkgYnl0ZXNIb2xvSGFzaCBlcnJvcjogAIsEEAAQAAAAYSBIb2xvSGFzaCBvZiBwcmltaXRpdmUgaGFzaF90eXBlAAAAGwAAAAwAAAAEAAAAHAAAAB0AAAASAAAAYSBEaXNwbGF5IGltcGxlbWVudGF0aW9uIHJldHVybmVkIGFuIGVycm9yIHVuZXhwZWN0ZWRseQAeAAAAAAAAAAEAAAAUAAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9hbGxvYy9zcmMvc3RyaW5nLnJzACgFEABLAAAA6AkAAAkAAABwcm92ZW5hbmNlY2VsbF9pZHpvbWVfbmFtZWZuX25hbWVjYXBfc2VjcmV0cGF5bG9hZG5vbmNlZXhwaXJlc19hdFpvbWVDYWxsVW5zaWduZWQAAACEBRAACgAAAI4FEAAHAAAAlQUQAAkAAACeBRAABwAAAKUFEAAKAAAArwUQAAcAAAC2BRAABQAAALsFEAAKAAAAIGJ5dGVzLCBnb3QgIGJ5dGVzAAAYBhAAAAAAABgGEAAMAAAAJAYQAAYAAAAgAAAAIAAAAAgAAAAEAAAAAgAAAC9Vc2Vycy9qb3N0Ly5jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2hvbG9faGFzaC0wLjEuMC1iZXRhLXJjLjAvc3JjL2hhc2gucnMAAABYBhAAYQAAAF8AAAAtAAAAIGJ5dGVzLCBnb3QgIGJ5dGVzAADMBhAAAAAAAMwGEAAMAAAA2AYQAAYAAABAAAAAIQAAAAgAAAAEAAAAAgAAACIAAAAAAAAAAQAAACMAAAAkAAAAJQAAACIAAAAEAAAABAAAACYAAAAnAAAAY2FsbGVkIGBPcHRpb246OnVud3JhcCgpYCBvbiBhIGBOb25lYCB2YWx1ZS9ydXN0Yy82OWY5YzMzZDcxYzg3MWZjMTZhYzQ0NTIxMTI4MWM2ZTdhMzQwOTQzL2xpYnJhcnkvc3RkL3NyYy9zeW5jL29uY2UucnMAYwcQAEwAAACPAAAAKQAAACIAAAAEAAAABAAAACgAAAApAAAAKgAAAC9Vc2Vycy9qb3N0Ly5jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2NvbnNvbGVfZXJyb3JfcGFuaWNfaG9vay0wLjEuNy9zcmMvbGliLnJzAAAA2AcQAGUAAACVAAAADgAAAFAIEAAAAAAALAAAAAQAAAAEAAAALQAAAC4AAAAvAAAAMQAAAAwAAAAEAAAAMgAAADMAAAA0AAAAYSBEaXNwbGF5IGltcGxlbWVudGF0aW9uIHJldHVybmVkIGFuIGVycm9yIHVuZXhwZWN0ZWRseQA1AAAAAAAAAAEAAAAUAAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9hbGxvYy9zcmMvc3RyaW5nLnJzANAIEABLAAAA6AkAAAkAAABpbnZhbGlkIHR5cGU6ICwgZXhwZWN0ZWQgAAAALAkQAA4AAAA6CRAACwAAADYAAAAAAAAA//////////9jYW5ub3QgYWNjZXNzIGEgVGhyZWFkIExvY2FsIFN0b3JhZ2UgdmFsdWUgZHVyaW5nIG9yIGFmdGVyIGRlc3RydWN0aW9uAAA3AAAAAAAAAAEAAAA4AAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9zdGQvc3JjL3RocmVhZC9sb2NhbC5ycwDACRAATwAAAKYBAAAJAAAAYWxyZWFkeSBib3Jyb3dlZDcAAAAAAAAAAQAAADkAAAAvVXNlcnMvam9zdC8uY2FyZ28vcmVnaXN0cnkvc3JjL2dpdGh1Yi5jb20tMWVjYzYyOTlkYjllYzgyMy9zZXJkZS13YXNtLWJpbmRnZW4tMC4zLjEvc3JjL2xpYi5ycwBAChAAXwAAABgAAAAOAAAAY2xvc3VyZSBpbnZva2VkIHJlY3Vyc2l2ZWx5IG9yIGRlc3Ryb3llZCBhbHJlYWR5RgAAAAQAAAAEAAAARwAAAEgAAABJAAAASgAAAAwAAAAEAAAASwAAAEwAAABNAAAAYSBEaXNwbGF5IGltcGxlbWVudGF0aW9uIHJldHVybmVkIGFuIGVycm9yIHVuZXhwZWN0ZWRseQBOAAAAAAAAAAEAAAAUAAAAL3J1c3RjLzY5ZjljMzNkNzFjODcxZmMxNmFjNDQ1MjExMjgxYzZlN2EzNDA5NDMvbGlicmFyeS9hbGxvYy9zcmMvc3RyaW5nLnJzAFgLEABLAAAA6AkAAAkAAAAKClN0YWNrOgoKSnNWYWx1ZSgpAL4LEAAIAAAAxgsQAAEAAABhIGJ5dGUgYXJyYXkgb2YgbGVuZ3RoIADYCxAAFwAAACAAAABzdHJ1Y3QgWm9tZUNhbGxVbnNpZ25lZHR1cGxlIHN0cnVjdCBDZWxsSWRhIGJ5dGUgYXJyYXkgb2YgbGVuZ3RoIAAAACYMEAAXAAAAQAAAAIQgJEFnZW50UHViS2V5hC0kRG5hSGFzaC9Vc2Vycy9qb3N0Ly5jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2hvbG9faGFzaC0wLjEuMC1iZXRhLXJjLjAvc3JjL2VuY29kZS5yc2NhbGxlZCBgUmVzdWx0Ojp1bndyYXAoKWAgb24gYW4gYEVycmAgdmFsdWUAAFAAAAAQAAAABAAAABoAAABkDBAAYwAAAIMAAAAFAAAAUQAAAAQAAAAEAAAAUgAAAEJhZEhhc2hTaXplQmFkQ2hlY2tzdW1CYWRQcmVmaXgAUwAAAAQAAAAEAAAAVAAAAFMAAAAEAAAABAAAAFUAAABCYWRTaXplQmFkQmFzZTY0Tm9VL1VzZXJzL2pvc3QvLmNhcmdvL3JlZ2lzdHJ5L3NyYy9naXRodWIuY29tLTFlY2M2Mjk5ZGI5ZWM4MjMvYmxha2UyYl9zaW1kLTAuNS4xMS9zcmMvcG9ydGFibGUucnMAAHcNEABfAAAAlgAAABUAAAAvVXNlcnMvam9zdC8uY2FyZ28vcmVnaXN0cnkvc3JjL2dpdGh1Yi5jb20tMWVjYzYyOTlkYjllYzgyMy9ibGFrZTJiX3NpbWQtMC41LjExL3NyYy9saWIucnMAAOgNEABaAAAATgIAAAoAAABUDhAAAAAAAERlc2VyaWFsaXplAFcAAAAEAAAABAAAAFgAAABTZXJpYWxpemVieXRlIGFycmF5ZGVwdGggbGltaXQgZXhjZWVkZWRzZXJpYWxpemUgZGF0YSBtb2RlbCBpcyBpbnZhbGlkOiCfDhAAIQAAAGF0dGVtcHQgdG8gc2VyaWFsaXplIHN0cnVjdCwgc2VxdWVuY2Ugb3IgbWFwIHdpdGggdW5rbm93biBsZW5ndGhpbnZhbGlkIHZhbHVlIHdyaXRlOiAAAAAIDxAAFQAAAGVycm9yIHdoaWxlIHdyaXRpbmcgbXVsdGktYnl0ZSBNZXNzYWdlUGFjayB2YWx1ZXN0cnVjdCB2YXJpYW50AABYDxAADgAAAHR1cGxlIHZhcmlhbnQAAABwDxAADQAAAG5ld3R5cGUgdmFyaWFudACIDxAADwAAAHVuaXQgdmFyaWFudKAPEAAMAAAAZW51bbQPEAAEAAAAbWFwAMAPEAADAAAAc2VxdWVuY2XMDxAACAAAAG5ld3R5cGUgc3RydWN0AADcDxAADgAAAE9wdGlvbiB2YWx1ZfQPEAAMAAAAdW5pdCB2YWx1ZQAACBAQAAoAAABieXRlIGFycmF5AAAcEBAACgAAAHN0cmluZyAAMBAQAAcAAABjaGFyYWN0ZXIgYGBAEBAACwAAAEsQEAABAAAAZmxvYXRpbmcgcG9pbnQgYFwQEAAQAAAASxAQAAEAAABpbnRlZ2VyIGAAAAB8EBAACQAAAEsQEAABAAAAYm9vbGVhbiBgAAAAmBAQAAkAAABLEBAAAQAAAGEgc3RyaW5naTY0AGIAAAAEAAAABAAAAGMAAABkAAAAZQAAAGFscmVhZHkgYm9ycm93ZWRiAAAAAAAAAAEAAAA5AAAAAAAAAGIAAAAEAAAABAAAAGYAAABiAAAABAAAAAQAAABnAAAAY2FsbGVkIGBPcHRpb246OnVud3JhcCgpYCBvbiBhIGBOb25lYCB2YWx1ZWNhbGxlZCBgUmVzdWx0Ojp1bndyYXAoKWAgb24gYW4gYEVycmAgdmFsdWVBY2Nlc3NFcnJvcnVzZSBvZiBzdGQ6OnRocmVhZDo6Y3VycmVudCgpIGlzIG5vdCBwb3NzaWJsZSBhZnRlciB0aGUgdGhyZWFkJ3MgbG9jYWwgZGF0YSBoYXMgYmVlbiBkZXN0cm95ZWRsaWJyYXJ5L3N0ZC9zcmMvdGhyZWFkL21vZC5yc9sREAAdAAAA3QIAAAUAAABmYWlsZWQgdG8gZ2VuZXJhdGUgdW5pcXVlIHRocmVhZCBJRDogYml0c3BhY2UgZXhoYXVzdGVkAAgSEAA3AAAA2xEQAB0AAABWBAAADQAAAFBvaXNvbkVycm9ybGlicmFyeS9zdGQvc3JjL3N5c19jb21tb24vdGhyZWFkX2luZm8ucnNjEhAAKQAAABYAAAAzAAAAbWVtb3J5IGFsbG9jYXRpb24gb2YgIGJ5dGVzIGZhaWxlZAoAnBIQABUAAACxEhAADgAAAGxpYnJhcnkvc3RkL3NyYy9hbGxvYy5yc9ASEAAYAAAAVQEAAAkAAABjYW5ub3QgbW9kaWZ5IHRoZSBwYW5pYyBob29rIGZyb20gYSBwYW5pY2tpbmcgdGhyZWFk+BIQADQAAABsaWJyYXJ5L3N0ZC9zcmMvcGFuaWNraW5nLnJzNBMQABwAAACGAAAACQAAADQTEAAcAAAAPgIAAA8AAAA0ExAAHAAAAD0CAAAPAAAAaAAAAAwAAAAEAAAAaQAAAGIAAAAIAAAABAAAAGoAAABrAAAAEAAAAAQAAABsAAAAbQAAAGIAAAAIAAAABAAAAG4AAABvAAAAYgAAAAAAAAABAAAAcAAAAGNvbmR2YXIgd2FpdCBub3Qgc3VwcG9ydGVkAADYExAAGgAAAGxpYnJhcnkvc3RkL3NyYy9zeXMvd2FzbS8uLi91bnN1cHBvcnRlZC9sb2Nrcy9jb25kdmFyLnJz/BMQADgAAAAWAAAACQAAAGNhbm5vdCByZWN1cnNpdmVseSBhY3F1aXJlIG11dGV4RBQQACAAAABsaWJyYXJ5L3N0ZC9zcmMvc3lzL3dhc20vLi4vdW5zdXBwb3J0ZWQvbG9ja3MvbXV0ZXgucnMAAGwUEAA2AAAAFgAAAAkAAABhc3NlcnRpb24gZmFpbGVkOiBzdGF0ZV9hbmRfcXVldWUuYWRkcigpICYgU1RBVEVfTUFTSyA9PSBSVU5OSU5HT25jZSBpbnN0YW5jZSBoYXMgcHJldmlvdXNseSBiZWVuIHBvaXNvbmVkAAD0FBAAKgAAAAIAAABsaWJyYXJ5L3N0ZC9zcmMvc3lzX2NvbW1vbi9vbmNlL2dlbmVyaWMucnMAACwVEAAqAAAA+AAAAAkAAAAsFRAAKgAAAAUBAAAeAAAAcQAAAAgAAAAEAAAAcgAAAGxpYnJhcnkvc3RkL3NyYy9zeXNfY29tbW9uL3RocmVhZF9wYXJrZXIvZ2VuZXJpYy5ycwCIFRAAMwAAACcAAAAVAAAAaW5jb25zaXN0ZW50IHBhcmsgc3RhdGUAzBUQABcAAACIFRAAMwAAADUAAAAXAAAAcGFyayBzdGF0ZSBjaGFuZ2VkIHVuZXhwZWN0ZWRseQD8FRAAHwAAAIgVEAAzAAAAMgAAABEAAABpbmNvbnNpc3RlbnQgc3RhdGUgaW4gdW5wYXJrNBYQABwAAACIFRAAMwAAAGwAAAASAAAAiBUQADMAAAB6AAAADgAAAEhhc2ggdGFibGUgY2FwYWNpdHkgb3ZlcmZsb3d4FhAAHAAAAC9jYXJnby9yZWdpc3RyeS9zcmMvZ2l0aHViLmNvbS0xZWNjNjI5OWRiOWVjODIzL2hhc2hicm93bi0wLjEyLjMvc3JjL3Jhdy9tb2QucnMAnBYQAE8AAABaAAAAKAAAAHMAAAAEAAAABAAAAHQAAAB1AAAAdgAAAGxpYnJhcnkvYWxsb2Mvc3JjL3Jhd192ZWMucnNjYXBhY2l0eSBvdmVyZmxvdwAAADAXEAARAAAAFBcQABwAAAAGAgAABQAAAGEgZm9ybWF0dGluZyB0cmFpdCBpbXBsZW1lbnRhdGlvbiByZXR1cm5lZCBhbiBlcnJvcgBzAAAAAAAAAAEAAAAUAAAAbGlicmFyeS9hbGxvYy9zcmMvZm10LnJzoBcQABgAAABkAgAACQAAAGFzc2VydGlvbiBmYWlsZWQ6IGVkZWx0YSA+PSAwbGlicmFyeS9jb3JlL3NyYy9udW0vZGl5X2Zsb2F0LnJzAADlFxAAIQAAAEwAAAAJAAAA5RcQACEAAABOAAAACQAAAAEAAAAKAAAAZAAAAOgDAAAQJwAAoIYBAEBCDwCAlpgAAOH1BQDKmjsCAAAAFAAAAMgAAADQBwAAIE4AAEANAwCAhB4AAC0xAQDC6wsAlDV3AADBb/KGIwAAAAAAge+shVtBbS3uBABBmLHAAAsTAR9qv2TtOG7tl6fa9Pk/6QNPGABBvLHAAAsmAT6VLgmZ3wP9OBUPL+R0I+z1z9MI3ATE2rDNvBl/M6YDJh/pTgIAQYSywAALoAoBfC6YW4fTvnKf2diHLxUSxlDea3BuSs8P2JXVbnGyJrBmxq0kNhUdWtNCPA5U/2PAc1XMF+/5ZfIovFX3x9yA3O1u9M7v3F/3UwUAbGlicmFyeS9jb3JlL3NyYy9udW0vZmx0MmRlYy9zdHJhdGVneS9kcmFnb24ucnNhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQgPiAwAFAZEAAvAAAAdQAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1pbnVzID4gMAAAAFAZEAAvAAAAdgAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLnBsdXMgPiAwUBkQAC8AAAB3AAAABQAAAGFzc2VydGlvbiBmYWlsZWQ6IGQubWFudC5jaGVja2VkX2FkZChkLnBsdXMpLmlzX3NvbWUoKQAAUBkQAC8AAAB4AAAABQAAAGFzc2VydGlvbiBmYWlsZWQ6IGQubWFudC5jaGVja2VkX3N1YihkLm1pbnVzKS5pc19zb21lKCkAUBkQAC8AAAB5AAAABQAAAGFzc2VydGlvbiBmYWlsZWQ6IGJ1Zi5sZW4oKSA+PSBNQVhfU0lHX0RJR0lUUwAAAFAZEAAvAAAAegAAAAUAAABQGRAALwAAAMEAAAAJAAAAUBkQAC8AAAD5AAAAVAAAAFAZEAAvAAAA+gAAAA0AAABQGRAALwAAAAEBAAAzAAAAUBkQAC8AAAAKAQAABQAAAFAZEAAvAAAACwEAAAUAAABQGRAALwAAAAwBAAAFAAAAUBkQAC8AAAANAQAABQAAAFAZEAAvAAAADgEAAAUAAABQGRAALwAAAEsBAAAfAAAAUBkQAC8AAABlAQAADQAAAFAZEAAvAAAAcQEAACYAAABQGRAALwAAAHYBAABUAAAAUBkQAC8AAACDAQAAMwAAAN9FGj0DzxrmwfvM/gAAAADKxprHF/5wq9z71P4AAAAAT9y8vvyxd//2+9z+AAAAAAzWa0HvkVa+Efzk/gAAAAA8/H+QrR/QjSz87P4AAAAAg5pVMShcUdNG/PT+AAAAALXJpq2PrHGdYfz8/gAAAADLi+4jdyKc6nv8BP8AAAAAbVN4QJFJzK6W/Az/AAAAAFfOtl15EjyCsfwU/wAAAAA3VvtNNpQQwsv8HP8AAAAAT5hIOG/qlpDm/CT/AAAAAMc6giXLhXTXAP0s/wAAAAD0l7+Xzc+GoBv9NP8AAAAA5awqF5gKNO81/Tz/AAAAAI6yNSr7ZziyUP1E/wAAAAA7P8bS39TIhGv9TP8AAAAAus3TGidE3cWF/VT/AAAAAJbJJbvOn2uToP1c/wAAAACEpWJ9JGys27r9ZP8AAAAA9tpfDVhmq6PV/Wz/AAAAACbxw96T+OLz7/10/wAAAAC4gP+qqK21tQr+fP8AAAAAi0p8bAVfYocl/oT/AAAAAFMwwTRg/7zJP/6M/wAAAABVJrqRjIVOllr+lP8AAAAAvX4pcCR3+d90/pz/AAAAAI+45bifvd+mj/6k/wAAAACUfXSIz1+p+Kn+rP8AAAAAz5uoj5NwRLnE/rT/AAAAAGsVD7/48AiK3/68/wAAAAC2MTFlVSWwzfn+xP8AAAAArH970MbiP5kU/8z/AAAAAAY7KyrEEFzkLv/U/wAAAADTknNpmSQkqkn/3P8AAAAADsoAg/K1h/1j/+T/AAAAAOsaEZJkCOW8fv/s/wAAAADMiFBvCcy8jJn/9P8AAAAALGUZ4lgXt9Gz//z/AEGuvMAACwVAnM7/BABBvLzAAAv5BhCl1Ojo/wwAAAAAAAAAYqzF63itAwAUAAAAAACECZT4eDk/gR4AHAAAAAAAsxUHyXvOl8A4ACQAAAAAAHBc6nvOMn6PUwAsAAAAAABogOmrpDjS1W0ANAAAAAAARSKaFyYnT5+IADwAAAAAACf7xNQxomPtogBEAAAAAACorciMOGXesL0ATAAAAAAA22WrGo4Ix4PYAFQAAAAAAJodcUL5HV3E8gBcAAAAAABY5xumLGlNkg0BZAAAAAAA6o1wGmTuAdonAWwAAAAAAEp375qZo22iQgF0AAAAAACFa320e3gJ8lwBfAAAAAAAdxjdeaHkVLR3AYQAAAAAAMLFm1uShluGkgGMAAAAAAA9XZbIxVM1yKwBlAAAAAAAs6CX+ly0KpXHAZwAAAAAAONfoJm9n0be4QGkAAAAAAAljDnbNMKbpfwBrAAAAAAAXJ+Yo3KaxvYWArQAAAAAAM6+6VRTv9y3MQK8AAAAAADiQSLyF/P8iEwCxAAAAAAApXhc05vOIMxmAswAAAAAAN9TIXvzWhaYgQLUAAAAAAA6MB+X3LWg4psC3AAAAAAAlrPjXFPR2ai2AuQAAAAAADxEp6TZfJv70ALsAAAAAAAQRKSnTEx2u+sC9AAAAAAAGpxAtu+Oq4sGA/wAAAAAACyEV6YQ7x/QIAMEAQAAAAApMZHp5aQQmzsDDAEAAAAAnQycofubEOdVAxQBAAAAACn0O2LZICiscAMcAQAAAACFz6d6XktEgIsDJAEAAAAALd2sA0DkIb+lAywBAAAAAI//RF4vnGeOwAM0AQAAAABBuIycnRcz1NoDPAEAAAAAqRvjtJLbGZ71A0QBAAAAANl337puv5brDwRMAQAAAABsaWJyYXJ5L2NvcmUvc3JjL251bS9mbHQyZGVjL3N0cmF0ZWd5L2dyaXN1LnJzAADIIBAALgAAAH0AAAAVAAAAyCAQAC4AAACpAAAABQAAAMggEAAuAAAAqgAAAAUAAADIIBAALgAAAKsAAAAFAAAAyCAQAC4AAACsAAAABQAAAMggEAAuAAAArQAAAAUAAADIIBAALgAAAK4AAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogZC5tYW50ICsgZC5wbHVzIDwgKDEgPDwgNjEpAAAAyCAQAC4AAACvAAAABQAAAMggEAAuAAAACgEAABEAQcDDwAAL6SJhdHRlbXB0IHRvIGRpdmlkZSBieSB6ZXJvAAAAyCAQAC4AAAANAQAACQAAAMggEAAuAAAAFgEAAEIAAADIIBAALgAAAEABAAAJAAAAYXNzZXJ0aW9uIGZhaWxlZDogIWJ1Zi5pc19lbXB0eSgpY2FsbGVkIGBPcHRpb246OnVud3JhcCgpYCBvbiBhIGBOb25lYCB2YWx1ZcggEAAuAAAA3AEAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBkLm1hbnQgPCAoMSA8PCA2MSnIIBAALgAAAN0BAAAFAAAAyCAQAC4AAADeAQAABQAAAMggEAAuAAAAIwIAABEAAADIIBAALgAAACYCAAAJAAAAyCAQAC4AAABcAgAACQAAAMggEAAuAAAAvAIAAEcAAADIIBAALgAAANMCAABLAAAAyCAQAC4AAADfAgAARwAAAGxpYnJhcnkvY29yZS9zcmMvbnVtL2ZsdDJkZWMvbW9kLnJzAAwjEAAjAAAAvAAAAAUAAABhc3NlcnRpb24gZmFpbGVkOiBidWZbMF0gPiBiXCcwXCcAAAAMIxAAIwAAAL0AAAAFAAAAYXNzZXJ0aW9uIGZhaWxlZDogcGFydHMubGVuKCkgPj0gNAAADCMQACMAAAC+AAAABQAAADAuLi0rMGluZk5hTmFzc2VydGlvbiBmYWlsZWQ6IGJ1Zi5sZW4oKSA+PSBtYXhsZW4AAAAMIxAAIwAAAH8CAAANAAAAKS4uAO0jEAACAAAAQm9ycm93TXV0RXJyb3JpbmRleCBvdXQgb2YgYm91bmRzOiB0aGUgbGVuIGlzICBidXQgdGhlIGluZGV4IGlzIAYkEAAgAAAAJiQQABIAAAA6AAAAyBcQAAAAAABIJBAAAQAAAEgkEAABAAAAcGFuaWNrZWQgYXQgJycsIHAkEAABAAAAcSQQAAMAAAB/AAAAAAAAAAEAAACAAAAAyBcQAAAAAAB/AAAABAAAAAQAAACBAAAAbWF0Y2hlcyE9PT1hc3NlcnRpb24gZmFpbGVkOiBgKGxlZnQgIHJpZ2h0KWAKICBsZWZ0OiBgYCwKIHJpZ2h0OiBgYDogAAAAtyQQABkAAADQJBAAEgAAAOIkEAAMAAAA7iQQAAMAAABgAAAAtyQQABkAAADQJBAAEgAAAOIkEAAMAAAAFCUQAAEAAAA6IAAAyBcQAAAAAAA4JRAAAgAAAH8AAAAMAAAABAAAAIIAAACDAAAAhAAAACAgICAsCiwgLi4KfSwgLi4gfSB7IC4uIH0gfSgKKCwKW11saWJyYXJ5L2NvcmUvc3JjL2ZtdC9udW0ucnMAAACGJRAAGwAAAGUAAAAUAAAAMHgwMDAxMDIwMzA0MDUwNjA3MDgwOTEwMTExMjEzMTQxNTE2MTcxODE5MjAyMTIyMjMyNDI1MjYyNzI4MjkzMDMxMzIzMzM0MzUzNjM3MzgzOTQwNDE0MjQzNDQ0NTQ2NDc0ODQ5NTA1MTUyNTM1NDU1NTY1NzU4NTk2MDYxNjI2MzY0NjU2NjY3Njg2OTcwNzE3MjczNzQ3NTc2Nzc3ODc5ODA4MTgyODM4NDg1ODY4Nzg4ODk5MDkxOTI5Mzk0OTU5Njk3OTg5OQAAfwAAAAQAAAAEAAAAhQAAAIYAAACHAAAAbGlicmFyeS9jb3JlL3NyYy9mbXQvbW9kLnJzAJgmEAAbAAAAQwYAAB4AAAAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwmCYQABsAAAA9BgAALQAAAHRydWVmYWxzZQAAAJgmEAAbAAAAewkAAB4AAACYJhAAGwAAAIIJAAAWAAAAKClsaWJyYXJ5L2NvcmUvc3JjL3NsaWNlL21lbWNoci5ycwAAQicQACAAAABoAAAAJwAAAHJhbmdlIHN0YXJ0IGluZGV4ICBvdXQgb2YgcmFuZ2UgZm9yIHNsaWNlIG9mIGxlbmd0aCB0JxAAEgAAAIYnEAAiAAAAcmFuZ2UgZW5kIGluZGV4ILgnEAAQAAAAhicQACIAAABzbGljZSBpbmRleCBzdGFydHMgYXQgIGJ1dCBlbmRzIGF0IADYJxAAFgAAAO4nEAANAAAAWy4uLl1ieXRlIGluZGV4ICBpcyBvdXQgb2YgYm91bmRzIG9mIGAAABEoEAALAAAAHCgQABYAAAAUJRAAAQAAAGJlZ2luIDw9IGVuZCAoIDw9ICkgd2hlbiBzbGljaW5nIGAAAEwoEAAOAAAAWigQAAQAAABeKBAAEAAAABQlEAABAAAAIGlzIG5vdCBhIGNoYXIgYm91bmRhcnk7IGl0IGlzIGluc2lkZSAgKGJ5dGVzICkgb2YgYBEoEAALAAAAkCgQACYAAAC2KBAACAAAAL4oEAAGAAAAFCUQAAEAAABsaWJyYXJ5L2NvcmUvc3JjL3N0ci9tb2QucnMA7CgQABsAAAAHAQAAHQAAAGxpYnJhcnkvY29yZS9zcmMvdW5pY29kZS9wcmludGFibGUucnMAAAAYKRAAJQAAAAoAAAAcAAAAGCkQACUAAAAaAAAAKAAAAAABAwUFBgYCBwYIBwkRChwLGQwaDRAODA8EEAMSEhMJFgEXBBgBGQMaBxsBHAIfFiADKwMtCy4BMAMxAjIBpwKpAqoEqwj6AvsF/QL+A/8JrXh5i42iMFdYi4yQHN0OD0tM+/wuLz9cXV/ihI2OkZKpsbq7xcbJyt7k5f8ABBESKTE0Nzo7PUlKXYSOkqmxtLq7xsrOz+TlAAQNDhESKTE0OjtFRklKXmRlhJGbncnOzw0RKTo7RUlXW1xeX2RljZGptLq7xcnf5OXwDRFFSWRlgISyvL6/1dfw8YOFi6Smvr/Fx8/a20iYvc3Gzs9JTk9XWV5fiY6Psba3v8HGx9cRFhdbXPb3/v+AbXHe3w4fbm8cHV99fq6vf7u8FhceH0ZHTk9YWlxefn+1xdTV3PDx9XJzj3R1liYuL6evt7/Hz9ffmkCXmDCPH9LUzv9OT1pbBwgPECcv7u9ubzc9P0JFkJFTZ3XIydDR2Nnn/v8AIF8igt8EgkQIGwQGEYGsDoCrBR8JgRsDGQgBBC8ENAQHAwEHBgcRClAPEgdVBwMEHAoJAwgDBwMCAwMDDAQFAwsGAQ4VBU4HGwdXBwIGFwxQBEMDLQMBBBEGDww6BB0lXyBtBGolgMgFgrADGgaC/QNZBxYJGAkUDBQMagYKBhoGWQcrBUYKLAQMBAEDMQssBBoGCwOArAYKBi8xTQOApAg8Aw8DPAc4CCsFgv8RGAgvES0DIQ8hD4CMBIKXGQsViJQFLwU7BwIOGAmAviJ0DIDWGgwFgP8FgN8M8p0DNwmBXBSAuAiAywUKGDsDCgY4CEYIDAZ0Cx4DWgRZCYCDGBwKFglMBICKBqukDBcEMaEEgdomBwwFBYCmEIH1BwEgKgZMBICNBIC+AxsDDw0ABgEBAwEEAgUHBwIICAkCCgULAg4EEAERAhIFExEUARUCFwIZDRwFHQgfASQBagRrAq8DsQK8As8C0QLUDNUJ1gLXAtoB4AXhAucE6ALuIPAE+AL6A/sBDCc7Pk5Pj56en3uLk5aisrqGsQYHCTY9Plbz0NEEFBg2N1ZXf6qur7014BKHiY6eBA0OERIpMTQ6RUZJSk5PZGVctrcbHAcICgsUFzY5Oqip2NkJN5CRqAcKOz5maY+SEW9fv+7vWmL0/P9TVJqbLi8nKFWdoKGjpKeorbq8xAYLDBUdOj9FUaanzM2gBxkaIiU+P+fs7//FxgQgIyUmKDM4OkhKTFBTVVZYWlxeYGNlZmtzeH1/iqSqr7DA0K6vbm++k14iewUDBC0DZgMBLy6Agh0DMQ8cBCQJHgUrBUQEDiqAqgYkBCQEKAg0C05DgTcJFgoIGDtFOQNjCAkwFgUhAxsFAUA4BEsFLwQKBwkHQCAnBAwJNgM6BRoHBAwHUEk3Mw0zBy4ICoEmUksrCCoWGiYcFBcJTgQkCUQNGQcKBkgIJwl1C0I+KgY7BQoGUQYBBRADBYCLYh5ICAqApl4iRQsKBg0TOgYKNiwEF4C5PGRTDEgJCkZFG0gIUw1JBwqA9kYKHQNHSTcDDggKBjkHCoE2GQc7AxxWAQ8yDYObZnULgMSKTGMNhDAQFo+qgkehuYI5ByoEXAYmCkYKKAUTgrBbZUsEOQcRQAULAg6X+AiE1ioJoueBMw8BHQYOBAiBjIkEawUNAwkHEJJgRwl0PID2CnMIcBVGehQMFAxXCRmAh4FHA4VCDxWEUB8GBoDVKwU+IQFwLQMaBAKBQB8ROgUBgdAqguaA9ylMBAoEAoMRREw9gMI8BgEEVQUbNAKBDiwEZAxWCoCuOB0NLAQJBwIOBoCag9gEEQMNA3cEXwYMBAEPDAQ4CAoGKAgiToFUDB0DCQc2CA4ECQcJB4DLJQqEBmxpYnJhcnkvY29yZS9zcmMvdW5pY29kZS91bmljb2RlX2RhdGEucnPcLhAAKAAAAFcAAAA+AAAAbGlicmFyeS9jb3JlL3NyYy9udW0vYmlnbnVtLnJzAAAULxAAHgAAAKwBAAABAAAAYXNzZXJ0aW9uIGZhaWxlZDogbm9ib3Jyb3dhc3NlcnRpb24gZmFpbGVkOiBkaWdpdHMgPCA0MGFzc2VydGlvbiBmYWlsZWQ6IG90aGVyID4gMAAAfwAAAAQAAAAEAAAAiAAAAFRyeUZyb21TbGljZUVycm9yRXJyb3IAAAADAACDBCAAkQVgAF0ToAASFyAfDCBgH+8soCsqMCAsb6bgLAKoYC0e+2AuAP4gNp7/YDb9AeE2AQohNyQN4TerDmE5LxihOTAcYUjzHqFMQDRhUPBqoVFPbyFSnbyhUgDPYVNl0aFTANohVADg4VWu4mFX7OQhWdDooVkgAO5Z8AF/WgBwAAcALQEBAQIBAgEBSAswFRABZQcCBgICAQQjAR4bWws6CQkBGAQBCQEDAQUrAzwIKhgBIDcBAQEECAQBAwcKAh0BOgEBAQIECAEJAQoCGgECAjkBBAIEAgIDAwEeAgMBCwI5AQQFAQIEARQCFgYBAToBAQIBBAgBBwMKAh4BOwEBAQwBCQEoAQMBNwEBAwUDAQQHAgsCHQE6AQIBAgEDAQUCBwILAhwCOQIBAQIECAEJAQoCHQFIAQQBAgMBAQgBUQECBwwIYgECCQsHSQIbAQEBAQE3DgEFAQIFCwEkCQFmBAEGAQICAhkCBAMQBA0BAgIGAQ8BAAMAAx0CHgIeAkACAQcIAQILCQEtAwEBdQIiAXYDBAIJAQYD2wICAToBAQcBAQEBAggGCgIBMB8xBDAHAQEFASgJDAIgBAICAQM4AQECAwEBAzoIAgKYAwENAQcEAQYBAwLGQAABwyEAA40BYCAABmkCAAQBCiACUAIAAQMBBAEZAgUBlwIaEg0BJggZCy4DMAECBAICJwFDBgICAgIMAQgBLwEzAQEDAgIFAgEBKgIIAe4BAgEEAQABABAQEAACAAHiAZUFAAMBAgUEKAMEAaUCAAQAAlADRgsxBHsBNg8pAQICCgMxBAICBwE9AyQFAQg+AQwCNAkKBAIBXwMCAQECBgECAZ0BAwgVAjkCAQEBARYBDgcDBcMIAgMBARcBUQECBgEBAgEBAgEC6wECBAYCAQIbAlUIAgEBAmoBAQECBgEBZQMCBAEFAAkBAvUBCgIBAQQBkAQCAgQBIAooBgIECAEJBgIDLg0BAgAHAQYBAVIWAgcBAgECegYDAQECAQcBAUgCAwEBAQACCwI0BQUBAQEAAQYPAAU7BwABPwRRAQACAC4CFwABAQMEBQgIAgceBJQDADcEMggBDgEWBQEPAAcBEQIHAQIBBWQBoAcAAT0EAAQAB20HAGCA8AAA3C4QACgAAAA/AQAACQB7CXByb2R1Y2VycwIIbGFuZ3VhZ2UBBFJ1c3QADHByb2Nlc3NlZC1ieQMFcnVzdGMdMS42Ni4wICg2OWY5YzMzZDcgMjAyMi0xMi0xMikGd2FscnVzBjAuMTkuMAx3YXNtLWJpbmRnZW4SMC4yLjgzIChlYmE2OTFmMzgp");
var at;
(function(e) {
  e.Provisioned = "provisioned", e.Cloned = "cloned", e.Stem = "stem";
})(at || (at = {}));
var ya;
(function(e) {
  e.Create = "create", e.UseExisting = "use_existing", e.CreateIfNoExists = "create_if_no_exists";
})(ya || (ya = {}));
var va;
(function(e) {
  e.Enabled = "enabled", e.Disabled = "disabled", e.Running = "running", e.Stopped = "stopped", e.Paused = "paused";
})(va || (va = {}));
var Je = 4294967295;
function qd(e, t, A) {
  var i = Math.floor(A / 4294967296), s = A;
  e.setUint32(t, i), e.setUint32(t + 4, s);
}
function mg(e, t) {
  var A = e.getInt32(t), i = e.getUint32(t + 4);
  return A * 4294967296 + i;
}
function Vd(e, t) {
  var A = e.getUint32(t), i = e.getUint32(t + 4);
  return A * 4294967296 + i;
}
var Uo, Go, Mo, Xs = (typeof process > "u" || ((Uo = process == null ? void 0 : process.env) === null || Uo === void 0 ? void 0 : Uo.TEXT_ENCODING) !== "never") && typeof TextEncoder < "u" && typeof TextDecoder < "u", ai = Xs ? new TextEncoder() : void 0;
Xs && typeof process < "u" && ((Go = process == null ? void 0 : process.env) === null || Go === void 0 || Go.TEXT_ENCODING);
function zd(e, t, A) {
  t.set(ai.encode(e), A);
}
function Kd(e, t, A) {
  ai.encodeInto(e, t.subarray(A));
}
ai?.encodeInto;
var jd = 4096;
function bg(e, t, A) {
  for (var i = t, s = i + A, o = [], r = ""; i < s; ) {
    var n = e[i++];
    if (!(n & 128))
      o.push(n);
    else if ((n & 224) === 192) {
      var l = e[i++] & 63;
      o.push((n & 31) << 6 | l);
    } else if ((n & 240) === 224) {
      var l = e[i++] & 63, a = e[i++] & 63;
      o.push((n & 31) << 12 | l << 6 | a);
    } else if ((n & 248) === 240) {
      var l = e[i++] & 63, a = e[i++] & 63, c = e[i++] & 63, g = (n & 7) << 18 | l << 12 | a << 6 | c;
      g > 65535 && (g -= 65536, o.push(g >>> 10 & 1023 | 55296), g = 56320 | g & 1023), o.push(g);
    } else
      o.push(n);
    o.length >= jd && (r += String.fromCharCode.apply(String, o), o.length = 0);
  }
  return o.length > 0 && (r += String.fromCharCode.apply(String, o)), r;
}
var Zd = Xs ? new TextDecoder() : null, Wd = Xs ? typeof process < "u" && ((Mo = process == null ? void 0 : process.env) === null || Mo === void 0 ? void 0 : Mo.TEXT_DECODER) !== "force" ? 200 : 0 : Je;
function Xd(e, t, A) {
  var i = e.subarray(t, t + A);
  return Zd.decode(i);
}
var Pi = (
  /** @class */
  function() {
    function e(t, A) {
      this.type = t, this.data = A;
    }
    return e;
  }()
), tC = globalThis && globalThis.__extends || function() {
  var e = function(t, A) {
    return e = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, s) {
      i.__proto__ = s;
    } || function(i, s) {
      for (var o in s)
        Object.prototype.hasOwnProperty.call(s, o) && (i[o] = s[o]);
    }, e(t, A);
  };
  return function(t, A) {
    if (typeof A != "function" && A !== null)
      throw new TypeError("Class extends value " + String(A) + " is not a constructor or null");
    e(t, A);
    function i() {
      this.constructor = t;
    }
    t.prototype = A === null ? Object.create(A) : (i.prototype = A.prototype, new i());
  };
}(), Pt = (
  /** @class */
  function(e) {
    tC(t, e);
    function t(A) {
      var i = e.call(this, A) || this, s = Object.create(t.prototype);
      return Object.setPrototypeOf(i, s), Object.defineProperty(i, "name", {
        configurable: !0,
        enumerable: !1,
        value: t.name
      }), i;
    }
    return t;
  }(Error)
), eC = -1, AC = 4294967296 - 1, iC = 17179869184 - 1;
function sC(e) {
  var t = e.sec, A = e.nsec;
  if (t >= 0 && A >= 0 && t <= iC)
    if (A === 0 && t <= AC) {
      var i = new Uint8Array(4), s = new DataView(i.buffer);
      return s.setUint32(0, t), i;
    } else {
      var o = t / 4294967296, r = t & 4294967295, i = new Uint8Array(8), s = new DataView(i.buffer);
      return s.setUint32(0, A << 2 | o & 3), s.setUint32(4, r), i;
    }
  else {
    var i = new Uint8Array(12), s = new DataView(i.buffer);
    return s.setUint32(0, A), qd(s, 4, t), i;
  }
}
function oC(e) {
  var t = e.getTime(), A = Math.floor(t / 1e3), i = (t - A * 1e3) * 1e6, s = Math.floor(i / 1e9);
  return {
    sec: A + s,
    nsec: i - s * 1e9
  };
}
function rC(e) {
  if (e instanceof Date) {
    var t = oC(e);
    return sC(t);
  } else
    return null;
}
function nC(e) {
  var t = new DataView(e.buffer, e.byteOffset, e.byteLength);
  switch (e.byteLength) {
    case 4: {
      var A = t.getUint32(0), i = 0;
      return { sec: A, nsec: i };
    }
    case 8: {
      var s = t.getUint32(0), o = t.getUint32(4), A = (s & 3) * 4294967296 + o, i = s >>> 2;
      return { sec: A, nsec: i };
    }
    case 12: {
      var A = mg(t, 4), i = t.getUint32(0);
      return { sec: A, nsec: i };
    }
    default:
      throw new Pt("Unrecognized data size for timestamp (expected 4, 8, or 12): ".concat(e.length));
  }
}
function aC(e) {
  var t = nC(e);
  return new Date(t.sec * 1e3 + t.nsec / 1e6);
}
var lC = {
  type: eC,
  encode: rC,
  decode: aC
}, gC = (
  /** @class */
  function() {
    function e() {
      this.builtInEncoders = [], this.builtInDecoders = [], this.encoders = [], this.decoders = [], this.register(lC);
    }
    return e.prototype.register = function(t) {
      var A = t.type, i = t.encode, s = t.decode;
      if (A >= 0)
        this.encoders[A] = i, this.decoders[A] = s;
      else {
        var o = 1 + A;
        this.builtInEncoders[o] = i, this.builtInDecoders[o] = s;
      }
    }, e.prototype.tryToEncode = function(t, A) {
      for (var i = 0; i < this.builtInEncoders.length; i++) {
        var s = this.builtInEncoders[i];
        if (s != null) {
          var o = s(t, A);
          if (o != null) {
            var r = -1 - i;
            return new Pi(r, o);
          }
        }
      }
      for (var i = 0; i < this.encoders.length; i++) {
        var s = this.encoders[i];
        if (s != null) {
          var o = s(t, A);
          if (o != null) {
            var r = i;
            return new Pi(r, o);
          }
        }
      }
      return t instanceof Pi ? t : null;
    }, e.prototype.decode = function(t, A, i) {
      var s = A < 0 ? this.builtInDecoders[-1 - A] : this.decoders[A];
      return s ? s(t, A, i) : new Pi(A, t);
    }, e.defaultCodec = new e(), e;
  }()
);
function vr(e) {
  return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : e instanceof ArrayBuffer ? new Uint8Array(e) : Uint8Array.from(e);
}
function cC(e) {
  if (e instanceof ArrayBuffer)
    return new DataView(e);
  var t = vr(e);
  return new DataView(t.buffer, t.byteOffset, t.byteLength);
}
function Lo(e) {
  return "".concat(e < 0 ? "-" : "", "0x").concat(Math.abs(e).toString(16).padStart(2, "0"));
}
var hC = 16, IC = 16, uC = (
  /** @class */
  function() {
    function e(t, A) {
      t === void 0 && (t = hC), A === void 0 && (A = IC), this.maxKeyLength = t, this.maxLengthPerKey = A, this.hit = 0, this.miss = 0, this.caches = [];
      for (var i = 0; i < this.maxKeyLength; i++)
        this.caches.push([]);
    }
    return e.prototype.canBeCached = function(t) {
      return t > 0 && t <= this.maxKeyLength;
    }, e.prototype.find = function(t, A, i) {
      var s = this.caches[i - 1];
      t:
        for (var o = 0, r = s; o < r.length; o++) {
          for (var n = r[o], l = n.bytes, a = 0; a < i; a++)
            if (l[a] !== t[A + a])
              continue t;
          return n.str;
        }
      return null;
    }, e.prototype.store = function(t, A) {
      var i = this.caches[t.length - 1], s = { bytes: t, str: A };
      i.length >= this.maxLengthPerKey ? i[Math.random() * i.length | 0] = s : i.push(s);
    }, e.prototype.decode = function(t, A, i) {
      var s = this.find(t, A, i);
      if (s != null)
        return this.hit++, s;
      this.miss++;
      var o = bg(t, A, i), r = Uint8Array.prototype.slice.call(t, A, A + i);
      return this.store(r, o), o;
    }, e;
  }()
), dC = globalThis && globalThis.__awaiter || function(e, t, A, i) {
  function s(o) {
    return o instanceof A ? o : new A(function(r) {
      r(o);
    });
  }
  return new (A || (A = Promise))(function(o, r) {
    function n(c) {
      try {
        a(i.next(c));
      } catch (g) {
        r(g);
      }
    }
    function l(c) {
      try {
        a(i.throw(c));
      } catch (g) {
        r(g);
      }
    }
    function a(c) {
      c.done ? o(c.value) : s(c.value).then(n, l);
    }
    a((i = i.apply(e, t || [])).next());
  });
}, Jo = globalThis && globalThis.__generator || function(e, t) {
  var A = { label: 0, sent: function() {
    if (o[0] & 1)
      throw o[1];
    return o[1];
  }, trys: [], ops: [] }, i, s, o, r;
  return r = { next: n(0), throw: n(1), return: n(2) }, typeof Symbol == "function" && (r[Symbol.iterator] = function() {
    return this;
  }), r;
  function n(a) {
    return function(c) {
      return l([a, c]);
    };
  }
  function l(a) {
    if (i)
      throw new TypeError("Generator is already executing.");
    for (; A; )
      try {
        if (i = 1, s && (o = a[0] & 2 ? s.return : a[0] ? s.throw || ((o = s.return) && o.call(s), 0) : s.next) && !(o = o.call(s, a[1])).done)
          return o;
        switch (s = 0, o && (a = [a[0] & 2, o.value]), a[0]) {
          case 0:
          case 1:
            o = a;
            break;
          case 4:
            return A.label++, { value: a[1], done: !1 };
          case 5:
            A.label++, s = a[1], a = [0];
            continue;
          case 7:
            a = A.ops.pop(), A.trys.pop();
            continue;
          default:
            if (o = A.trys, !(o = o.length > 0 && o[o.length - 1]) && (a[0] === 6 || a[0] === 2)) {
              A = 0;
              continue;
            }
            if (a[0] === 3 && (!o || a[1] > o[0] && a[1] < o[3])) {
              A.label = a[1];
              break;
            }
            if (a[0] === 6 && A.label < o[1]) {
              A.label = o[1], o = a;
              break;
            }
            if (o && A.label < o[2]) {
              A.label = o[2], A.ops.push(a);
              break;
            }
            o[2] && A.ops.pop(), A.trys.pop();
            continue;
        }
        a = t.call(e, A);
      } catch (c) {
        a = [6, c], s = 0;
      } finally {
        i = o = 0;
      }
    if (a[0] & 5)
      throw a[1];
    return { value: a[0] ? a[1] : void 0, done: !0 };
  }
}, ma = globalThis && globalThis.__asyncValues || function(e) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var t = e[Symbol.asyncIterator], A;
  return t ? t.call(e) : (e = typeof __values == "function" ? __values(e) : e[Symbol.iterator](), A = {}, i("next"), i("throw"), i("return"), A[Symbol.asyncIterator] = function() {
    return this;
  }, A);
  function i(o) {
    A[o] = e[o] && function(r) {
      return new Promise(function(n, l) {
        r = e[o](r), s(n, l, r.done, r.value);
      });
    };
  }
  function s(o, r, n, l) {
    Promise.resolve(l).then(function(a) {
      o({ value: a, done: n });
    }, r);
  }
}, lA = globalThis && globalThis.__await || function(e) {
  return this instanceof lA ? (this.v = e, this) : new lA(e);
}, CC = globalThis && globalThis.__asyncGenerator || function(e, t, A) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var i = A.apply(e, t || []), s, o = [];
  return s = {}, r("next"), r("throw"), r("return"), s[Symbol.asyncIterator] = function() {
    return this;
  }, s;
  function r(h) {
    i[h] && (s[h] = function(u) {
      return new Promise(function(C, B) {
        o.push([h, u, C, B]) > 1 || n(h, u);
      });
    });
  }
  function n(h, u) {
    try {
      l(i[h](u));
    } catch (C) {
      g(o[0][3], C);
    }
  }
  function l(h) {
    h.value instanceof lA ? Promise.resolve(h.value.v).then(a, c) : g(o[0][2], h);
  }
  function a(h) {
    n("next", h);
  }
  function c(h) {
    n("throw", h);
  }
  function g(h, u) {
    h(u), o.shift(), o.length && n(o[0][0], o[0][1]);
  }
}, BC = function(e) {
  var t = typeof e;
  return t === "string" || t === "number";
}, qA = -1, cn = new DataView(new ArrayBuffer(0)), QC = new Uint8Array(cn.buffer), mr = function() {
  try {
    cn.getInt8(0);
  } catch (e) {
    return e.constructor;
  }
  throw new Error("never reached");
}(), ba = new mr("Insufficient data"), EC = new uC(), fC = (
  /** @class */
  function() {
    function e(t, A, i, s, o, r, n, l) {
      t === void 0 && (t = gC.defaultCodec), A === void 0 && (A = void 0), i === void 0 && (i = Je), s === void 0 && (s = Je), o === void 0 && (o = Je), r === void 0 && (r = Je), n === void 0 && (n = Je), l === void 0 && (l = EC), this.extensionCodec = t, this.context = A, this.maxStrLength = i, this.maxBinLength = s, this.maxArrayLength = o, this.maxMapLength = r, this.maxExtLength = n, this.keyDecoder = l, this.totalPos = 0, this.pos = 0, this.view = cn, this.bytes = QC, this.headByte = qA, this.stack = [];
    }
    return e.prototype.reinitializeState = function() {
      this.totalPos = 0, this.headByte = qA, this.stack.length = 0;
    }, e.prototype.setBuffer = function(t) {
      this.bytes = vr(t), this.view = cC(this.bytes), this.pos = 0;
    }, e.prototype.appendBuffer = function(t) {
      if (this.headByte === qA && !this.hasRemaining(1))
        this.setBuffer(t);
      else {
        var A = this.bytes.subarray(this.pos), i = vr(t), s = new Uint8Array(A.length + i.length);
        s.set(A), s.set(i, A.length), this.setBuffer(s);
      }
    }, e.prototype.hasRemaining = function(t) {
      return this.view.byteLength - this.pos >= t;
    }, e.prototype.createExtraByteError = function(t) {
      var A = this, i = A.view, s = A.pos;
      return new RangeError("Extra ".concat(i.byteLength - s, " of ").concat(i.byteLength, " byte(s) found at buffer[").concat(t, "]"));
    }, e.prototype.decode = function(t) {
      this.reinitializeState(), this.setBuffer(t);
      var A = this.doDecodeSync();
      if (this.hasRemaining(1))
        throw this.createExtraByteError(this.pos);
      return A;
    }, e.prototype.decodeMulti = function(t) {
      return Jo(this, function(A) {
        switch (A.label) {
          case 0:
            this.reinitializeState(), this.setBuffer(t), A.label = 1;
          case 1:
            return this.hasRemaining(1) ? [4, this.doDecodeSync()] : [3, 3];
          case 2:
            return A.sent(), [3, 1];
          case 3:
            return [
              2
              /*return*/
            ];
        }
      });
    }, e.prototype.decodeAsync = function(t) {
      var A, i, s, o;
      return dC(this, void 0, void 0, function() {
        var r, n, l, a, c, g, h, u;
        return Jo(this, function(C) {
          switch (C.label) {
            case 0:
              r = !1, C.label = 1;
            case 1:
              C.trys.push([1, 6, 7, 12]), A = ma(t), C.label = 2;
            case 2:
              return [4, A.next()];
            case 3:
              if (i = C.sent(), !!i.done)
                return [3, 5];
              if (l = i.value, r)
                throw this.createExtraByteError(this.totalPos);
              this.appendBuffer(l);
              try {
                n = this.doDecodeSync(), r = !0;
              } catch (B) {
                if (!(B instanceof mr))
                  throw B;
              }
              this.totalPos += this.pos, C.label = 4;
            case 4:
              return [3, 2];
            case 5:
              return [3, 12];
            case 6:
              return a = C.sent(), s = { error: a }, [3, 12];
            case 7:
              return C.trys.push([7, , 10, 11]), i && !i.done && (o = A.return) ? [4, o.call(A)] : [3, 9];
            case 8:
              C.sent(), C.label = 9;
            case 9:
              return [3, 11];
            case 10:
              if (s)
                throw s.error;
              return [
                7
                /*endfinally*/
              ];
            case 11:
              return [
                7
                /*endfinally*/
              ];
            case 12:
              if (r) {
                if (this.hasRemaining(1))
                  throw this.createExtraByteError(this.totalPos);
                return [2, n];
              }
              throw c = this, g = c.headByte, h = c.pos, u = c.totalPos, new RangeError("Insufficient data in parsing ".concat(Lo(g), " at ").concat(u, " (").concat(h, " in the current buffer)"));
          }
        });
      });
    }, e.prototype.decodeArrayStream = function(t) {
      return this.decodeMultiAsync(t, !0);
    }, e.prototype.decodeStream = function(t) {
      return this.decodeMultiAsync(t, !1);
    }, e.prototype.decodeMultiAsync = function(t, A) {
      return CC(this, arguments, function() {
        var s, o, r, n, l, a, c, g, h;
        return Jo(this, function(u) {
          switch (u.label) {
            case 0:
              s = A, o = -1, u.label = 1;
            case 1:
              u.trys.push([1, 13, 14, 19]), r = ma(t), u.label = 2;
            case 2:
              return [4, lA(r.next())];
            case 3:
              if (n = u.sent(), !!n.done)
                return [3, 12];
              if (l = n.value, A && o === 0)
                throw this.createExtraByteError(this.totalPos);
              this.appendBuffer(l), s && (o = this.readArraySize(), s = !1, this.complete()), u.label = 4;
            case 4:
              u.trys.push([4, 9, , 10]), u.label = 5;
            case 5:
              return [4, lA(this.doDecodeSync())];
            case 6:
              return [4, u.sent()];
            case 7:
              return u.sent(), --o === 0 ? [3, 8] : [3, 5];
            case 8:
              return [3, 10];
            case 9:
              if (a = u.sent(), !(a instanceof mr))
                throw a;
              return [3, 10];
            case 10:
              this.totalPos += this.pos, u.label = 11;
            case 11:
              return [3, 2];
            case 12:
              return [3, 19];
            case 13:
              return c = u.sent(), g = { error: c }, [3, 19];
            case 14:
              return u.trys.push([14, , 17, 18]), n && !n.done && (h = r.return) ? [4, lA(h.call(r))] : [3, 16];
            case 15:
              u.sent(), u.label = 16;
            case 16:
              return [3, 18];
            case 17:
              if (g)
                throw g.error;
              return [
                7
                /*endfinally*/
              ];
            case 18:
              return [
                7
                /*endfinally*/
              ];
            case 19:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    }, e.prototype.doDecodeSync = function() {
      t:
        for (; ; ) {
          var t = this.readHeadByte(), A = void 0;
          if (t >= 224)
            A = t - 256;
          else if (t < 192)
            if (t < 128)
              A = t;
            else if (t < 144) {
              var i = t - 128;
              if (i !== 0) {
                this.pushMapState(i), this.complete();
                continue t;
              } else
                A = {};
            } else if (t < 160) {
              var i = t - 144;
              if (i !== 0) {
                this.pushArrayState(i), this.complete();
                continue t;
              } else
                A = [];
            } else {
              var s = t - 160;
              A = this.decodeUtf8String(s, 0);
            }
          else if (t === 192)
            A = null;
          else if (t === 194)
            A = !1;
          else if (t === 195)
            A = !0;
          else if (t === 202)
            A = this.readF32();
          else if (t === 203)
            A = this.readF64();
          else if (t === 204)
            A = this.readU8();
          else if (t === 205)
            A = this.readU16();
          else if (t === 206)
            A = this.readU32();
          else if (t === 207)
            A = this.readU64();
          else if (t === 208)
            A = this.readI8();
          else if (t === 209)
            A = this.readI16();
          else if (t === 210)
            A = this.readI32();
          else if (t === 211)
            A = this.readI64();
          else if (t === 217) {
            var s = this.lookU8();
            A = this.decodeUtf8String(s, 1);
          } else if (t === 218) {
            var s = this.lookU16();
            A = this.decodeUtf8String(s, 2);
          } else if (t === 219) {
            var s = this.lookU32();
            A = this.decodeUtf8String(s, 4);
          } else if (t === 220) {
            var i = this.readU16();
            if (i !== 0) {
              this.pushArrayState(i), this.complete();
              continue t;
            } else
              A = [];
          } else if (t === 221) {
            var i = this.readU32();
            if (i !== 0) {
              this.pushArrayState(i), this.complete();
              continue t;
            } else
              A = [];
          } else if (t === 222) {
            var i = this.readU16();
            if (i !== 0) {
              this.pushMapState(i), this.complete();
              continue t;
            } else
              A = {};
          } else if (t === 223) {
            var i = this.readU32();
            if (i !== 0) {
              this.pushMapState(i), this.complete();
              continue t;
            } else
              A = {};
          } else if (t === 196) {
            var i = this.lookU8();
            A = this.decodeBinary(i, 1);
          } else if (t === 197) {
            var i = this.lookU16();
            A = this.decodeBinary(i, 2);
          } else if (t === 198) {
            var i = this.lookU32();
            A = this.decodeBinary(i, 4);
          } else if (t === 212)
            A = this.decodeExtension(1, 0);
          else if (t === 213)
            A = this.decodeExtension(2, 0);
          else if (t === 214)
            A = this.decodeExtension(4, 0);
          else if (t === 215)
            A = this.decodeExtension(8, 0);
          else if (t === 216)
            A = this.decodeExtension(16, 0);
          else if (t === 199) {
            var i = this.lookU8();
            A = this.decodeExtension(i, 1);
          } else if (t === 200) {
            var i = this.lookU16();
            A = this.decodeExtension(i, 2);
          } else if (t === 201) {
            var i = this.lookU32();
            A = this.decodeExtension(i, 4);
          } else
            throw new Pt("Unrecognized type byte: ".concat(Lo(t)));
          this.complete();
          for (var o = this.stack; o.length > 0; ) {
            var r = o[o.length - 1];
            if (r.type === 0)
              if (r.array[r.position] = A, r.position++, r.position === r.size)
                o.pop(), A = r.array;
              else
                continue t;
            else if (r.type === 1) {
              if (!BC(A))
                throw new Pt("The type of key must be string or number but " + typeof A);
              if (A === "__proto__")
                throw new Pt("The key __proto__ is not allowed");
              r.key = A, r.type = 2;
              continue t;
            } else if (r.map[r.key] = A, r.readCount++, r.readCount === r.size)
              o.pop(), A = r.map;
            else {
              r.key = null, r.type = 1;
              continue t;
            }
          }
          return A;
        }
    }, e.prototype.readHeadByte = function() {
      return this.headByte === qA && (this.headByte = this.readU8()), this.headByte;
    }, e.prototype.complete = function() {
      this.headByte = qA;
    }, e.prototype.readArraySize = function() {
      var t = this.readHeadByte();
      switch (t) {
        case 220:
          return this.readU16();
        case 221:
          return this.readU32();
        default: {
          if (t < 160)
            return t - 144;
          throw new Pt("Unrecognized array type byte: ".concat(Lo(t)));
        }
      }
    }, e.prototype.pushMapState = function(t) {
      if (t > this.maxMapLength)
        throw new Pt("Max length exceeded: map length (".concat(t, ") > maxMapLengthLength (").concat(this.maxMapLength, ")"));
      this.stack.push({
        type: 1,
        size: t,
        key: null,
        readCount: 0,
        map: {}
      });
    }, e.prototype.pushArrayState = function(t) {
      if (t > this.maxArrayLength)
        throw new Pt("Max length exceeded: array length (".concat(t, ") > maxArrayLength (").concat(this.maxArrayLength, ")"));
      this.stack.push({
        type: 0,
        size: t,
        array: new Array(t),
        position: 0
      });
    }, e.prototype.decodeUtf8String = function(t, A) {
      var i;
      if (t > this.maxStrLength)
        throw new Pt("Max length exceeded: UTF-8 byte length (".concat(t, ") > maxStrLength (").concat(this.maxStrLength, ")"));
      if (this.bytes.byteLength < this.pos + A + t)
        throw ba;
      var s = this.pos + A, o;
      return this.stateIsMapKey() && (!((i = this.keyDecoder) === null || i === void 0) && i.canBeCached(t)) ? o = this.keyDecoder.decode(this.bytes, s, t) : t > Wd ? o = Xd(this.bytes, s, t) : o = bg(this.bytes, s, t), this.pos += A + t, o;
    }, e.prototype.stateIsMapKey = function() {
      if (this.stack.length > 0) {
        var t = this.stack[this.stack.length - 1];
        return t.type === 1;
      }
      return !1;
    }, e.prototype.decodeBinary = function(t, A) {
      if (t > this.maxBinLength)
        throw new Pt("Max length exceeded: bin length (".concat(t, ") > maxBinLength (").concat(this.maxBinLength, ")"));
      if (!this.hasRemaining(t + A))
        throw ba;
      var i = this.pos + A, s = this.bytes.subarray(i, i + t);
      return this.pos += A + t, s;
    }, e.prototype.decodeExtension = function(t, A) {
      if (t > this.maxExtLength)
        throw new Pt("Max length exceeded: ext length (".concat(t, ") > maxExtLength (").concat(this.maxExtLength, ")"));
      var i = this.view.getInt8(this.pos + A), s = this.decodeBinary(
        t,
        A + 1
        /* extType */
      );
      return this.extensionCodec.decode(s, i, this.context);
    }, e.prototype.lookU8 = function() {
      return this.view.getUint8(this.pos);
    }, e.prototype.lookU16 = function() {
      return this.view.getUint16(this.pos);
    }, e.prototype.lookU32 = function() {
      return this.view.getUint32(this.pos);
    }, e.prototype.readU8 = function() {
      var t = this.view.getUint8(this.pos);
      return this.pos++, t;
    }, e.prototype.readI8 = function() {
      var t = this.view.getInt8(this.pos);
      return this.pos++, t;
    }, e.prototype.readU16 = function() {
      var t = this.view.getUint16(this.pos);
      return this.pos += 2, t;
    }, e.prototype.readI16 = function() {
      var t = this.view.getInt16(this.pos);
      return this.pos += 2, t;
    }, e.prototype.readU32 = function() {
      var t = this.view.getUint32(this.pos);
      return this.pos += 4, t;
    }, e.prototype.readI32 = function() {
      var t = this.view.getInt32(this.pos);
      return this.pos += 4, t;
    }, e.prototype.readU64 = function() {
      var t = Vd(this.view, this.pos);
      return this.pos += 8, t;
    }, e.prototype.readI64 = function() {
      var t = mg(this.view, this.pos);
      return this.pos += 8, t;
    }, e.prototype.readF32 = function() {
      var t = this.view.getFloat32(this.pos);
      return this.pos += 4, t;
    }, e.prototype.readF64 = function() {
      var t = this.view.getFloat64(this.pos);
      return this.pos += 8, t;
    }, e;
  }()
), pC = {};
function wC(e, t) {
  t === void 0 && (t = pC);
  var A = new fC(t.extensionCodec, t.context, t.maxStrLength, t.maxBinLength, t.maxArrayLength, t.maxMapLength, t.maxExtLength);
  return A.decode(e);
}
var yC = Object.defineProperty, vC = (e, t) => {
  for (var A in t)
    yC(e, A, { get: t[A], enumerable: !0 });
}, mC = {};
vC(mC, { convertFileSrc: () => kC, invoke: () => DC, transformCallback: () => br });
function bC() {
  return window.crypto.getRandomValues(new Uint32Array(1))[0];
}
function br(e, t = !1) {
  let A = bC(), i = `_${A}`;
  return Object.defineProperty(window, i, { value: (s) => (t && Reflect.deleteProperty(window, i), e?.(s)), writable: !1, configurable: !0 }), A;
}
async function DC(e, t = {}) {
  return new Promise((A, i) => {
    let s = br((r) => {
      A(r), Reflect.deleteProperty(window, `_${o}`);
    }, !0), o = br((r) => {
      i(r), Reflect.deleteProperty(window, `_${s}`);
    }, !0);
    window.__TAURI_IPC__({ cmd: e, callback: s, error: o, ...t });
  });
}
function kC(e, t = "asset") {
  let A = encodeURIComponent(e);
  return navigator.userAgent.includes("Windows") ? `https://${t}.localhost/${A}` : `${t}://localhost/${A}`;
}
/*! noble-ed25519 - MIT License (c) 2019 Paul Miller (paulmillr.com) */
const rt = 2n ** 255n - 19n, as = 2n ** 252n + 27742317777372353535851937790883648493n, Dr = 0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51an, kr = 0x6666666666666666666666666666666666666666666666666666666666666658n, qi = {
  a: -1n,
  d: 37095705934669439343138083508754565189542113879843219016388785533085940283555n,
  p: rt,
  n: as,
  h: 8,
  Gx: Dr,
  Gy: kr
  // field prime, curve (group) order, cofactor
}, St = (e = "") => {
  throw new Error(e);
}, Dg = (e) => typeof e == "string", kg = (e, t) => (
  // is Uint8Array (of specific length)
  !(e instanceof Uint8Array) || typeof t == "number" && t > 0 && e.length !== t ? St("Uint8Array expected") : e
), hn = (e) => new Uint8Array(e), SC = (e, t) => kg(Dg(e) ? Ng(e) : hn(e), t), y = (e, t = rt) => {
  let A = e % t;
  return A >= 0n ? A : t + A;
}, Da = (e) => e instanceof Nt ? e : St("Point expected");
let ka;
class Nt {
  constructor(t, A, i, s) {
    this.ex = t, this.ey = A, this.ez = i, this.et = s;
  }
  static fromAffine(t) {
    return new Nt(t.x, t.y, 1n, y(t.x * t.y));
  }
  static fromHex(t, A = !0) {
    const { d: i } = qi;
    t = SC(t, 32);
    const s = t.slice();
    s[31] = t[31] & -129;
    const o = NC(s);
    o === 0n || (A && !(0n < o && o < rt) && St("bad y coord 1"), !A && !(0n < o && o < 2n ** 256n) && St("bad y coord 2"));
    const r = y(o * o), n = y(r - 1n), l = y(i * r + 1n);
    let { isValid: a, value: c } = UC(n, l);
    a || St("bad y coordinate 3");
    const g = (c & 1n) === 1n;
    return (t[31] & 128) !== 0 !== g && (c = y(-c)), new Nt(c, o, 1n, y(c * o));
  }
  get x() {
    return this.toAffine().x;
  }
  // .x, .y will call expensive toAffine.
  get y() {
    return this.toAffine().y;
  }
  // Should be used with care.
  equals(t) {
    const { ex: A, ey: i, ez: s } = this, { ex: o, ey: r, ez: n } = Da(t), l = y(A * n), a = y(o * s), c = y(i * n), g = y(r * s);
    return l === a && c === g;
  }
  is0() {
    return this.equals(ls);
  }
  negate() {
    return new Nt(y(-this.ex), this.ey, this.ez, y(-this.et));
  }
  double() {
    const { ex: t, ey: A, ez: i } = this, { a: s } = qi, o = y(t * t), r = y(A * A), n = y(2n * y(i * i)), l = y(s * o), a = t + A, c = y(y(a * a) - o - r), g = l + r, h = g - n, u = l - r, C = y(c * h), B = y(g * u), E = y(c * u), f = y(h * g);
    return new Nt(C, B, f, E);
  }
  add(t) {
    const { ex: A, ey: i, ez: s, et: o } = this, { ex: r, ey: n, ez: l, et: a } = Da(t), { a: c, d: g } = qi, h = y(A * r), u = y(i * n), C = y(o * g * a), B = y(s * l), E = y((A + i) * (r + n) - h - u), f = y(B - C), p = y(B + C), D = y(u - c * h), N = y(E * f), M = y(p * D), Mt = y(E * D), ot = y(f * p);
    return new Nt(N, M, ot, Mt);
  }
  mul(t, A = !0) {
    if (t === 0n)
      return A === !0 ? St("cannot multiply by 0") : ls;
    if (typeof t == "bigint" && 0n < t && t < as || St("invalid scalar, must be < L"), !A && this.is0() || t === 1n)
      return this;
    if (this.equals(ys))
      return MC(t).p;
    let i = ls, s = ys;
    for (let o = this; t > 0n; o = o.double(), t >>= 1n)
      t & 1n ? i = i.add(o) : A && (s = s.add(o));
    return i;
  }
  multiply(t) {
    return this.mul(t);
  }
  // Aliases for compatibilty
  clearCofactor() {
    return this.mul(BigInt(qi.h), !1);
  }
  // multiply by cofactor
  isSmallOrder() {
    return this.clearCofactor().is0();
  }
  // check if P is small order
  isTorsionFree() {
    let t = this.mul(as / 2n, !1).double();
    return as % 2n && (t = t.add(this)), t.is0();
  }
  toAffine() {
    const { ex: t, ey: A, ez: i } = this;
    if (this.is0())
      return { x: 0n, y: 0n };
    const s = FC(i);
    return y(i * s) !== 1n && St("invalid inverse"), { x: y(t * s), y: y(A * s) };
  }
  toRawBytes() {
    const { x: t, y: A } = this.toAffine(), i = xC(A);
    return i[31] |= t & 1n ? 128 : 0, i;
  }
  toHex() {
    return xg(this.toRawBytes());
  }
  // encode to hex string
}
Nt.BASE = new Nt(Dr, kr, 1n, y(Dr * kr));
Nt.ZERO = new Nt(0n, 1n, 1n, 0n);
const { BASE: ys, ZERO: ls } = Nt, Sg = (e, t) => e.toString(16).padStart(t, "0"), xg = (e) => Array.from(e).map((t) => Sg(t, 2)).join(""), Ng = (e) => {
  const t = e.length;
  (!Dg(e) || t % 2) && St("hex invalid 1");
  const A = hn(t / 2);
  for (let i = 0; i < A.length; i++) {
    const s = i * 2, o = e.slice(s, s + 2), r = Number.parseInt(o, 16);
    (Number.isNaN(r) || r < 0) && St("hex invalid 2"), A[i] = r;
  }
  return A;
}, xC = (e) => Ng(Sg(e, 32 * 2)).reverse(), NC = (e) => BigInt("0x" + xg(hn(kg(e)).reverse())), FC = (e, t = rt) => {
  (e === 0n || t <= 0n) && St("no inverse n=" + e + " mod=" + t);
  let A = y(e, t), i = t, s = 0n, o = 1n;
  for (; A !== 0n; ) {
    const r = i / A, n = i % A, l = s - o * r;
    i = A, A = n, s = o, o = l;
  }
  return i === 1n ? y(s, t) : St("no inverse");
}, $t = (e, t) => {
  let A = e;
  for (; t-- > 0n; )
    A *= A, A %= rt;
  return A;
}, RC = (e) => {
  const A = e * e % rt * e % rt, i = $t(A, 2n) * A % rt, s = $t(i, 1n) * e % rt, o = $t(s, 5n) * s % rt, r = $t(o, 10n) * o % rt, n = $t(r, 20n) * r % rt, l = $t(n, 40n) * n % rt, a = $t(l, 80n) * l % rt, c = $t(a, 80n) * l % rt, g = $t(c, 10n) * o % rt;
  return { pow_p_5_8: $t(g, 2n) * e % rt, b2: A };
}, Sa = 19681161376707505956807079304988542015446066515923890162744021073123829784752n, UC = (e, t) => {
  const A = y(t * t * t), i = y(A * A * t), s = RC(e * i).pow_p_5_8;
  let o = y(e * A * s);
  const r = y(t * o * o), n = o, l = y(o * Sa), a = r === e, c = r === y(-e), g = r === y(-e * Sa);
  return a && (o = n), (c || g) && (o = l), (y(o) & 1n) === 1n && (o = y(-o)), { isValid: a || c, value: o };
}, Ye = 8, GC = () => {
  const e = [], t = 256 / Ye + 1;
  let A = ys, i = A;
  for (let s = 0; s < t; s++) {
    i = A, e.push(i);
    for (let o = 1; o < 2 ** (Ye - 1); o++)
      i = i.add(A), e.push(i);
    A = i.double();
  }
  return e;
}, MC = (e) => {
  const t = ka || (ka = GC()), A = (c, g) => {
    let h = g.negate();
    return c ? h : g;
  };
  let i = ls, s = ys;
  const o = 1 + 256 / Ye, r = 2 ** (Ye - 1), n = BigInt(2 ** Ye - 1), l = 2 ** Ye, a = BigInt(Ye);
  for (let c = 0; c < o; c++) {
    const g = c * r;
    let h = Number(e & n);
    e >>= a, h > r && (h -= l, e += 1n);
    const u = g, C = g + Math.abs(h) - 1, B = c % 2 !== 0, E = h < 0;
    h === 0 ? s = s.add(A(B, t[u])) : i = i.add(A(E, t[C]));
  }
  return { p: i, f: s };
}, Fg = "3.7.5", LC = Fg, JC = typeof atob == "function", YC = typeof btoa == "function", xA = typeof Buffer == "function", xa = typeof TextDecoder == "function" ? new TextDecoder() : void 0, Na = typeof TextEncoder == "function" ? new TextEncoder() : void 0, HC = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", oi = Array.prototype.slice.call(HC), Vi = ((e) => {
  let t = {};
  return e.forEach((A, i) => t[A] = i), t;
})(oi), _C = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/, nt = String.fromCharCode.bind(String), Fa = typeof Uint8Array.from == "function" ? Uint8Array.from.bind(Uint8Array) : (e) => new Uint8Array(Array.prototype.slice.call(e, 0)), Rg = (e) => e.replace(/=/g, "").replace(/[+\/]/g, (t) => t == "+" ? "-" : "_"), Ug = (e) => e.replace(/[^A-Za-z0-9\+\/]/g, ""), Gg = (e) => {
  let t, A, i, s, o = "";
  const r = e.length % 3;
  for (let n = 0; n < e.length; ) {
    if ((A = e.charCodeAt(n++)) > 255 || (i = e.charCodeAt(n++)) > 255 || (s = e.charCodeAt(n++)) > 255)
      throw new TypeError("invalid character found");
    t = A << 16 | i << 8 | s, o += oi[t >> 18 & 63] + oi[t >> 12 & 63] + oi[t >> 6 & 63] + oi[t & 63];
  }
  return r ? o.slice(0, r - 3) + "===".substring(r) : o;
}, In = YC ? (e) => btoa(e) : xA ? (e) => Buffer.from(e, "binary").toString("base64") : Gg, Sr = xA ? (e) => Buffer.from(e).toString("base64") : (e) => {
  let A = [];
  for (let i = 0, s = e.length; i < s; i += 4096)
    A.push(nt.apply(null, e.subarray(i, i + 4096)));
  return In(A.join(""));
}, gs = (e, t = !1) => t ? Rg(Sr(e)) : Sr(e), TC = (e) => {
  if (e.length < 2) {
    var t = e.charCodeAt(0);
    return t < 128 ? e : t < 2048 ? nt(192 | t >>> 6) + nt(128 | t & 63) : nt(224 | t >>> 12 & 15) + nt(128 | t >>> 6 & 63) + nt(128 | t & 63);
  } else {
    var t = 65536 + (e.charCodeAt(0) - 55296) * 1024 + (e.charCodeAt(1) - 56320);
    return nt(240 | t >>> 18 & 7) + nt(128 | t >>> 12 & 63) + nt(128 | t >>> 6 & 63) + nt(128 | t & 63);
  }
}, OC = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, Mg = (e) => e.replace(OC, TC), Ra = xA ? (e) => Buffer.from(e, "utf8").toString("base64") : Na ? (e) => Sr(Na.encode(e)) : (e) => In(Mg(e)), gA = (e, t = !1) => t ? Rg(Ra(e)) : Ra(e), Ua = (e) => gA(e, !0), $C = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g, PC = (e) => {
  switch (e.length) {
    case 4:
      var t = (7 & e.charCodeAt(0)) << 18 | (63 & e.charCodeAt(1)) << 12 | (63 & e.charCodeAt(2)) << 6 | 63 & e.charCodeAt(3), A = t - 65536;
      return nt((A >>> 10) + 55296) + nt((A & 1023) + 56320);
    case 3:
      return nt((15 & e.charCodeAt(0)) << 12 | (63 & e.charCodeAt(1)) << 6 | 63 & e.charCodeAt(2));
    default:
      return nt((31 & e.charCodeAt(0)) << 6 | 63 & e.charCodeAt(1));
  }
}, Lg = (e) => e.replace($C, PC), Jg = (e) => {
  if (e = e.replace(/\s+/g, ""), !_C.test(e))
    throw new TypeError("malformed base64.");
  e += "==".slice(2 - (e.length & 3));
  let t, A = "", i, s;
  for (let o = 0; o < e.length; )
    t = Vi[e.charAt(o++)] << 18 | Vi[e.charAt(o++)] << 12 | (i = Vi[e.charAt(o++)]) << 6 | (s = Vi[e.charAt(o++)]), A += i === 64 ? nt(t >> 16 & 255) : s === 64 ? nt(t >> 16 & 255, t >> 8 & 255) : nt(t >> 16 & 255, t >> 8 & 255, t & 255);
  return A;
}, un = JC ? (e) => atob(Ug(e)) : xA ? (e) => Buffer.from(e, "base64").toString("binary") : Jg, Yg = xA ? (e) => Fa(Buffer.from(e, "base64")) : (e) => Fa(un(e).split("").map((t) => t.charCodeAt(0))), Hg = (e) => Yg(_g(e)), qC = xA ? (e) => Buffer.from(e, "base64").toString("utf8") : xa ? (e) => xa.decode(Yg(e)) : (e) => Lg(un(e)), _g = (e) => Ug(e.replace(/[-_]/g, (t) => t == "-" ? "+" : "/")), xr = (e) => qC(_g(e)), VC = (e) => {
  if (typeof e != "string")
    return !1;
  const t = e.replace(/\s+/g, "").replace(/={0,2}$/, "");
  return !/[^\s0-9a-zA-Z\+/]/.test(t) || !/[^\s0-9a-zA-Z\-_]/.test(t);
}, Tg = (e) => ({
  value: e,
  enumerable: !1,
  writable: !0,
  configurable: !0
}), Og = function() {
  const e = (t, A) => Object.defineProperty(String.prototype, t, Tg(A));
  e("fromBase64", function() {
    return xr(this);
  }), e("toBase64", function(t) {
    return gA(this, t);
  }), e("toBase64URI", function() {
    return gA(this, !0);
  }), e("toBase64URL", function() {
    return gA(this, !0);
  }), e("toUint8Array", function() {
    return Hg(this);
  });
}, $g = function() {
  const e = (t, A) => Object.defineProperty(Uint8Array.prototype, t, Tg(A));
  e("toBase64", function(t) {
    return gs(this, t);
  }), e("toBase64URI", function() {
    return gs(this, !0);
  }), e("toBase64URL", function() {
    return gs(this, !0);
  });
}, zC = () => {
  Og(), $g();
}, Pg = {
  version: Fg,
  VERSION: LC,
  atob: un,
  atobPolyfill: Jg,
  btoa: In,
  btoaPolyfill: Gg,
  fromBase64: xr,
  toBase64: gA,
  encode: gA,
  encodeURI: Ua,
  encodeURL: Ua,
  utob: Mg,
  btou: Lg,
  decode: xr,
  isValid: VC,
  fromUint8Array: gs,
  toUint8Array: Hg,
  extendString: Og,
  extendUint8Array: $g,
  extendBuiltins: zC
};
function cs(e) {
  return Pg.toUint8Array(e.slice(1));
}
function sA(e) {
  return `u${Pg.fromUint8Array(e, !0)}`;
}
globalThis.crypto || import("./__vite-browser-external-2447137e.js").then((e) => globalThis.crypto = e);
var Ga;
(function(e) {
  e.All = "All", e.Listed = "Listed";
})(Ga || (Ga = {}));
const he = /* @__PURE__ */ new WeakMap(), Ge = /* @__PURE__ */ new WeakMap(), Ae = /* @__PURE__ */ new WeakMap(), vs = Symbol("anyProducer"), Ma = Promise.resolve(), ms = Symbol("listenerAdded"), bs = Symbol("listenerRemoved");
let Ds = !1, Yo = !1;
function We(e) {
  if (typeof e != "string" && typeof e != "symbol" && typeof e != "number")
    throw new TypeError("`eventName` must be a string, symbol, or number");
}
function zi(e) {
  if (typeof e != "function")
    throw new TypeError("listener must be a function");
}
function Xe(e, t) {
  const A = Ge.get(e);
  if (A.has(t))
    return A.get(t);
}
function li(e, t) {
  const A = typeof t == "string" || typeof t == "symbol" || typeof t == "number" ? t : vs, i = Ae.get(e);
  if (i.has(A))
    return i.get(A);
}
function KC(e, t, A) {
  const i = Ae.get(e);
  if (i.has(t))
    for (const s of i.get(t))
      s.enqueue(A);
  if (i.has(vs)) {
    const s = Promise.all([t, A]);
    for (const o of i.get(vs))
      o.enqueue(s);
  }
}
function La(e, t) {
  t = Array.isArray(t) ? t : [t];
  let A = !1, i = () => {
  }, s = [];
  const o = {
    enqueue(r) {
      s.push(r), i();
    },
    finish() {
      A = !0, i();
    }
  };
  for (const r of t) {
    let n = li(e, r);
    n || (n = /* @__PURE__ */ new Set(), Ae.get(e).set(r, n)), n.add(o);
  }
  return {
    async next() {
      return s ? s.length === 0 ? A ? (s = void 0, this.next()) : (await new Promise((r) => {
        i = r;
      }), this.next()) : {
        done: !1,
        value: await s.shift()
      } : { done: !0 };
    },
    async return(r) {
      s = void 0;
      for (const n of t) {
        const l = li(e, n);
        l && (l.delete(o), l.size === 0 && Ae.get(e).delete(n));
      }
      return i(), arguments.length > 0 ? { done: !0, value: await r } : { done: !0 };
    },
    [Symbol.asyncIterator]() {
      return this;
    }
  };
}
function Ja(e) {
  if (e === void 0)
    return Ya;
  if (!Array.isArray(e))
    throw new TypeError("`methodNames` must be an array of strings");
  for (const t of e)
    if (!Ya.includes(t))
      throw typeof t != "string" ? new TypeError("`methodNames` element must be a string") : new Error(`${t} is not Emittery method`);
  return e;
}
const AA = (e) => e === ms || e === bs;
function Ki(e, t, A) {
  if (AA(t))
    try {
      Ds = !0, e.emit(t, A);
    } finally {
      Ds = !1;
    }
}
class fA {
  static mixin(t, A) {
    return A = Ja(A), (i) => {
      if (typeof i != "function")
        throw new TypeError("`target` must be function");
      for (const r of A)
        if (i.prototype[r] !== void 0)
          throw new Error(`The property \`${r}\` already exists on \`target\``);
      function s() {
        return Object.defineProperty(this, t, {
          enumerable: !1,
          value: new fA()
        }), this[t];
      }
      Object.defineProperty(i.prototype, t, {
        enumerable: !1,
        get: s
      });
      const o = (r) => function(...n) {
        return this[t][r](...n);
      };
      for (const r of A)
        Object.defineProperty(i.prototype, r, {
          enumerable: !1,
          value: o(r)
        });
      return i;
    };
  }
  static get isDebugEnabled() {
    if (typeof globalThis.process?.env != "object")
      return Yo;
    const { env: t } = globalThis.process ?? { env: {} };
    return t.DEBUG === "emittery" || t.DEBUG === "*" || Yo;
  }
  static set isDebugEnabled(t) {
    Yo = t;
  }
  constructor(t = {}) {
    he.set(this, /* @__PURE__ */ new Set()), Ge.set(this, /* @__PURE__ */ new Map()), Ae.set(this, /* @__PURE__ */ new Map()), Ae.get(this).set(vs, /* @__PURE__ */ new Set()), this.debug = t.debug ?? {}, this.debug.enabled === void 0 && (this.debug.enabled = !1), this.debug.logger || (this.debug.logger = (A, i, s, o) => {
      try {
        o = JSON.stringify(o);
      } catch {
        o = `Object with the following keys failed to stringify: ${Object.keys(o).join(",")}`;
      }
      (typeof s == "symbol" || typeof s == "number") && (s = s.toString());
      const r = /* @__PURE__ */ new Date(), n = `${r.getHours()}:${r.getMinutes()}:${r.getSeconds()}.${r.getMilliseconds()}`;
      console.log(`[${n}][emittery:${A}][${i}] Event Name: ${s}
	data: ${o}`);
    });
  }
  logIfDebugEnabled(t, A, i) {
    (fA.isDebugEnabled || this.debug.enabled) && this.debug.logger(t, this.debug.name, A, i);
  }
  on(t, A) {
    zi(A), t = Array.isArray(t) ? t : [t];
    for (const i of t) {
      We(i);
      let s = Xe(this, i);
      s || (s = /* @__PURE__ */ new Set(), Ge.get(this).set(i, s)), s.add(A), this.logIfDebugEnabled("subscribe", i, void 0), AA(i) || Ki(this, ms, { eventName: i, listener: A });
    }
    return this.off.bind(this, t, A);
  }
  off(t, A) {
    zi(A), t = Array.isArray(t) ? t : [t];
    for (const i of t) {
      We(i);
      const s = Xe(this, i);
      s && (s.delete(A), s.size === 0 && Ge.get(this).delete(i)), this.logIfDebugEnabled("unsubscribe", i, void 0), AA(i) || Ki(this, bs, { eventName: i, listener: A });
    }
  }
  once(t) {
    let A;
    const i = new Promise((s) => {
      A = this.on(t, (o) => {
        A(), s(o);
      });
    });
    return i.off = A, i;
  }
  events(t) {
    t = Array.isArray(t) ? t : [t];
    for (const A of t)
      We(A);
    return La(this, t);
  }
  async emit(t, A) {
    if (We(t), AA(t) && !Ds)
      throw new TypeError("`eventName` cannot be meta event `listenerAdded` or `listenerRemoved`");
    this.logIfDebugEnabled("emit", t, A), KC(this, t, A);
    const i = Xe(this, t) ?? /* @__PURE__ */ new Set(), s = he.get(this), o = [...i], r = AA(t) ? [] : [...s];
    await Ma, await Promise.all([
      ...o.map(async (n) => {
        if (i.has(n))
          return n(A);
      }),
      ...r.map(async (n) => {
        if (s.has(n))
          return n(t, A);
      })
    ]);
  }
  async emitSerial(t, A) {
    if (We(t), AA(t) && !Ds)
      throw new TypeError("`eventName` cannot be meta event `listenerAdded` or `listenerRemoved`");
    this.logIfDebugEnabled("emitSerial", t, A);
    const i = Xe(this, t) ?? /* @__PURE__ */ new Set(), s = he.get(this), o = [...i], r = [...s];
    await Ma;
    for (const n of o)
      i.has(n) && await n(A);
    for (const n of r)
      s.has(n) && await n(t, A);
  }
  onAny(t) {
    return zi(t), this.logIfDebugEnabled("subscribeAny", void 0, void 0), he.get(this).add(t), Ki(this, ms, { listener: t }), this.offAny.bind(this, t);
  }
  anyEvent() {
    return La(this);
  }
  offAny(t) {
    zi(t), this.logIfDebugEnabled("unsubscribeAny", void 0, void 0), Ki(this, bs, { listener: t }), he.get(this).delete(t);
  }
  clearListeners(t) {
    t = Array.isArray(t) ? t : [t];
    for (const A of t)
      if (this.logIfDebugEnabled("clear", A, void 0), typeof A == "string" || typeof A == "symbol" || typeof A == "number") {
        const i = Xe(this, A);
        i && i.clear();
        const s = li(this, A);
        if (s) {
          for (const o of s)
            o.finish();
          s.clear();
        }
      } else {
        he.get(this).clear();
        for (const [i, s] of Ge.get(this).entries())
          s.clear(), Ge.get(this).delete(i);
        for (const [i, s] of Ae.get(this).entries()) {
          for (const o of s)
            o.finish();
          s.clear(), Ae.get(this).delete(i);
        }
      }
  }
  listenerCount(t) {
    t = Array.isArray(t) ? t : [t];
    let A = 0;
    for (const i of t) {
      if (typeof i == "string") {
        A += he.get(this).size + (Xe(this, i)?.size ?? 0) + (li(this, i)?.size ?? 0) + (li(this)?.size ?? 0);
        continue;
      }
      typeof i < "u" && We(i), A += he.get(this).size;
      for (const s of Ge.get(this).values())
        A += s.size;
      for (const s of Ae.get(this).values())
        A += s.size;
    }
    return A;
  }
  bindMethods(t, A) {
    if (typeof t != "object" || t === null)
      throw new TypeError("`target` must be an object");
    A = Ja(A);
    for (const i of A) {
      if (t[i] !== void 0)
        throw new Error(`The property \`${i}\` already exists on \`target\``);
      Object.defineProperty(t, i, {
        enumerable: !1,
        value: this[i].bind(this)
      });
    }
  }
}
const Ya = Object.getOwnPropertyNames(fA.prototype).filter((e) => e !== "constructor");
Object.defineProperty(fA, "listenerAdded", {
  value: ms,
  writable: !1,
  enumerable: !0,
  configurable: !1
});
Object.defineProperty(fA, "listenerRemoved", {
  value: bs,
  writable: !1,
  enumerable: !0,
  configurable: !1
});
var Ha;
(function(e) {
  e.Dna = "Dna", e.AgentValidationPkg = "AgentValidationPkg", e.InitZomesComplete = "InitZomesComplete", e.CreateLink = "CreateLink", e.DeleteLink = "DeleteLink", e.OpenChain = "OpenChain", e.CloseChain = "CloseChain", e.Create = "Create", e.Update = "Update", e.Delete = "Delete";
})(Ha || (Ha = {}));
var _a;
(function(e) {
  e.StoreRecord = "StoreRecord", e.StoreEntry = "StoreEntry", e.RegisterAgentActivity = "RegisterAgentActivity", e.RegisterUpdatedContent = "RegisterUpdatedContent", e.RegisterUpdatedRecord = "RegisterUpdatedRecord", e.RegisterDeletedBy = "RegisterDeletedBy", e.RegisterDeletedEntryAction = "RegisterDeletedEntryAction", e.RegisterAddLink = "RegisterAddLink", e.RegisterRemoveLink = "RegisterRemoveLink";
})(_a || (_a = {}));
var Ta;
(function(e) {
  e[e.AGENT = 0] = "AGENT", e[e.ENTRY = 1] = "ENTRY", e[e.DHTOP = 2] = "DHTOP", e[e.ACTION = 3] = "ACTION", e[e.DNA = 4] = "DNA";
})(Ta || (Ta = {}));
function jC(e, t) {
  for (const [A, i] of Object.entries(e.cell_info))
    for (const s of i)
      if (at.Provisioned in s) {
        if (s[at.Provisioned].cell_id.toString() === t.toString())
          return A;
      } else if (at.Cloned in s)
        return s[at.Cloned].clone_id ? s[at.Cloned].clone_id : A;
}
async function ZC(e, t, A) {
  const i = await e.appInfo(), s = jC(i, A.cell_id);
  return t === s;
}
class qg {
  constructor(t, A, i) {
    this.client = t, this.roleName = A, this.zomeName = i;
  }
  onSignal(t) {
    return this.client.on("signal", async (A) => {
      await ZC(this.client, this.roleName, A) && this.zomeName === A.zome_name && t(A.payload);
    });
  }
  callZome(t, A) {
    const i = {
      role_name: this.roleName,
      zome_name: this.zomeName,
      fn_name: t,
      payload: A
    };
    return this.client.callZome(i);
  }
}
globalThis && globalThis.__classPrivateFieldGet;
class ks {
  constructor(t) {
    if (this._map = /* @__PURE__ */ new Map(), t)
      for (const [A, i] of t)
        this.set(A, i);
  }
  has(t) {
    return this._map.has(sA(t));
  }
  get(t) {
    return this._map.get(sA(t));
  }
  set(t, A) {
    return this._map.set(sA(t), A), this;
  }
  delete(t) {
    return this._map.delete(sA(t));
  }
  keys() {
    return Array.from(this._map.keys()).map((t) => cs(t))[Symbol.iterator]();
  }
  values() {
    return this._map.values();
  }
  entries() {
    return Array.from(this._map.entries()).map(([t, A]) => [cs(t), A])[Symbol.iterator]();
  }
  clear() {
    return this._map.clear();
  }
  forEach(t, A) {
    return this._map.forEach((i, s) => {
      t(i, cs(s), this);
    }, A);
  }
  get size() {
    return this._map.size;
  }
  [Symbol.iterator]() {
    return this.entries();
  }
  get [Symbol.toStringTag]() {
    return this._map[Symbol.toStringTag];
  }
}
class Vg {
  constructor(t) {
    this.newValue = t, this.map = new ks();
  }
  get(t) {
    return this.map.has(t) || this.map.set(t, this.newValue(t)), this.map.get(t);
  }
}
function WC(e) {
  return Math.floor(e / 1e3);
}
function XC(e) {
  const t = e.entry?.Present?.entry;
  return wC(t);
}
class ji {
  constructor(t) {
    this.record = t;
  }
  get actionHash() {
    return this.record.signed_action.hashed.hash;
  }
  get action() {
    const t = this.record.signed_action.hashed.content;
    return {
      ...t,
      timestamp: WC(t.timestamp)
    };
  }
  get entry() {
    return XC(this.record);
  }
  get entryHash() {
    return this.record.signed_action.hashed.content.entry_hash;
  }
}
const zg = ".", Kg = (e) => e.includes(zg), tB = (e) => {
  if (!Kg(e))
    throw new Error("invalid clone id: no clone id delimiter found in role name");
  return e.split(zg)[0];
};
function eB(e, t) {
  if (Kg(e)) {
    const i = tB(e);
    if (!(i in t.cell_info))
      throw new Error(`No cell found with role_name ${e}`);
    const s = t.cell_info[i].find((o) => at.Cloned in o && o[at.Cloned].clone_id === e);
    if (!s || !(at.Cloned in s))
      throw new Error(`No clone cell found with clone id ${e}`);
    return s[at.Cloned].cell_id;
  }
  if (!(e in t.cell_info))
    throw new Error(`No cell found with role_name ${e}`);
  const A = t.cell_info[e].find((i) => at.Provisioned in i);
  if (!A || !(at.Provisioned in A))
    throw new Error(`No provisioned cell found with role_name ${e}`);
  return A[at.Provisioned].cell_id;
}
function dn(e) {
  return gg({ status: "pending" }, (t) => (e().then((A) => {
    t({ status: "complete", value: A });
  }).catch((A) => t({ status: "error", error: A })), () => {
  }));
}
function Nr(e, t) {
  return gg({ status: "pending" }, (A) => {
    let i, s, o = !0;
    async function r() {
      const n = await e();
      (o || !yg(n, s)) && (s = n, o = !1, A({ status: "complete", value: n }));
    }
    return r().then(() => {
      i = setInterval(() => r().catch(() => {
      }), t);
    }).catch((n) => {
      A({ status: "error", error: n });
    }), () => {
      i && clearInterval(i);
    };
  });
}
const Ut = [
  ae`
    .row {
      display: flex;
      flex-direction: row;
    }
    .column {
      display: flex;
      flex-direction: column;
    }
    .small-margin {
      margin-top: 6px;
    }
    .big-margin {
      margin-top: 23px;
    }

    .fill {
      flex: 1;
      height: 100%;
    }

    .title {
      font-size: 20px;
    }

    .center-content {
      align-items: center;
      justify-content: center;
    }

    .placeholder {
      color: var(--sl-color-gray-700);
    }

    .flex-scrollable-parent {
      position: relative;
      display: flex;
      flex: 1;
    }

    .flex-scrollable-container {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
    }

    .flex-scrollable-x {
      max-width: 100%;
      overflow-x: auto;
    }
    .flex-scrollable-y {
      max-height: 100%;
      overflow-y: auto;
    }
    :host {
      color: var(--sl-color-neutral-1000);
    }

    sl-card {
      display: flex;
    }
    sl-card::part(base) {
      flex: 1;
    }
    sl-card::part(body) {
      display: flex;
      flex: 1;
    }
    sl-drawer::part(body) {
      display: flex;
    }
  `
];
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const AB = (e) => (...t) => ({ _$litDirective$: e, values: t });
let iB = class {
  constructor(t) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(t, A, i) {
    this._$Ct = t, this._$AM = A, this._$Ci = i;
  }
  _$AS(t, A) {
    return this.update(t, A);
  }
  update(t, A) {
    return this.render(...A);
  }
};
function Ho(e) {
  return typeof e == "string" && e.split(",").length === 39 ? new Uint8Array(e.split(",").map((t) => parseInt(t, 10))) : e;
}
function Oa(e) {
  const t = new FormData(e), A = {};
  return t.forEach((i, s) => {
    if (Reflect.has(A, s)) {
      const o = A[s];
      Array.isArray(o) ? o.push(Ho(i)) : A[s] = [A[s], Ho(i)];
    } else
      A[s] = Ho(i);
  }), A;
}
class sB extends iB {
  constructor() {
    super(...arguments), this.initialized = !1;
  }
  update(t, A) {
    this.initialized || (this.initialized = !0, t.element.addEventListener("update-form", (s) => {
      this.listener && t.element.removeEventListener("submit", this.listener), this.listener = (o) => {
        o.preventDefault();
        const r = Oa(t.element);
        A[0](r);
      }, t.element.addEventListener("submit", this.listener);
    })), setTimeout(() => {
      this.listener && t.element.removeEventListener("submit", this.listener), this.listener = (i) => {
        i.preventDefault();
        const s = Oa(t.element);
        A[0](s);
      }, t.element.addEventListener("submit", this.listener);
    }, 100);
  }
  render(t) {
    return "";
  }
}
const jg = AB(sB);
function NA(e) {
  return {
    attribute: e,
    type: Object,
    hasChanged: (t, A) => t?.toString() !== A?.toString(),
    converter: (t) => t && t.length > 0 && cs(t)
  };
}
function fe(e) {
  return `data:image/svg+xml;utf8,${oB(e)}`;
}
function oB(e) {
  return `<svg style='fill: currentColor' viewBox='0 0 24 24'><path d='${e}'></path></svg>`;
}
var Zg = "M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z", rB = "M7.5 16.5H13.55C13.34 16.97 13.18 17.47 13.09 18H7.5C4.46 18 2 15.54 2 12.5S4.46 7 7.5 7H18C20.21 7 22 8.79 22 11C22 11.91 21.69 12.74 21.17 13.41C20.63 13.2 20.05 13.07 19.45 13.03C20.08 12.58 20.5 11.84 20.5 11C20.5 9.62 19.38 8.5 18 8.5H7.5C5.29 8.5 3.5 10.29 3.5 12.5S5.29 16.5 7.5 16.5M9.5 13.5C8.95 13.5 8.5 13.05 8.5 12.5S8.95 11.5 9.5 11.5H17V10H9.5C8.12 10 7 11.12 7 12.5S8.12 15 9.5 15H14.54C15.11 14.36 15.81 13.85 16.61 13.5H9.5M20 18V15H18V18H15V20H18V23H20V20H23V18H20Z", nB = "M16.61 13.5C15.81 13.85 15.11 14.36 14.54 15H9.5C8.12 15 7 13.88 7 12.5S8.12 10 9.5 10H17V11.5H9.5C8.95 11.5 8.5 11.95 8.5 12.5S8.95 13.5 9.5 13.5H16.61M3.5 12.5C3.5 10.29 5.29 8.5 7.5 8.5H18C19.38 8.5 20.5 9.62 20.5 11C20.5 11.84 20.08 12.58 19.45 13.03C20.05 13.07 20.63 13.2 21.17 13.41C21.69 12.74 22 11.91 22 11C22 8.79 20.21 7 18 7H7.5C4.46 7 2 9.46 2 12.5S4.46 18 7.5 18H13.09C13.18 17.47 13.34 16.97 13.55 16.5H7.5C5.29 16.5 3.5 14.71 3.5 12.5M22.54 16.88L21.12 15.47L19 17.59L16.88 15.47L15.47 16.88L17.59 19L15.47 21.12L16.88 22.54L19 20.41L21.12 22.54L22.54 21.12L20.41 19L22.54 16.88Z", aB = "M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z", Wg = "M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z", lB = "M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z", gB = "M3 3V21H21V3H3M18 18H6V17H18V18M18 16H6V15H18V16M18 12H6V6H18V12Z";
function cB(e) {
  const t = document.createElement("div");
  return t.textContent = e, t.innerHTML;
}
function hB(e, t = "primary", A = Wg, i = 3e3) {
  const s = Object.assign(document.createElement("sl-alert"), {
    variant: t,
    closable: !0,
    duration: i,
    innerHTML: `
        <sl-icon src="${fe(A)}" slot="icon"></sl-icon>
        ${cB(e)}
      `
  });
  return document.body.append(s), s.toast();
}
function Ji(e) {
  return hB(e, "danger", Zg);
}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let IB = class extends Event {
  constructor(t, A, i) {
    super("context-request", { bubbles: !0, composed: !0 }), this.context = t, this.callback = A, this.subscribe = i;
  }
};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let uB = class {
  constructor(t, A, i, s = !1) {
    this.host = t, this.context = A, this.callback = i, this.subscribe = s, this.provided = !1, this.value = void 0, this.host.addController(this);
  }
  hostConnected() {
    this.dispatchRequest();
  }
  hostDisconnected() {
    this.unsubscribe && (this.unsubscribe(), this.unsubscribe = void 0);
  }
  dispatchRequest() {
    this.host.dispatchEvent(new IB(this.context, (t, A) => {
      this.unsubscribe && (this.unsubscribe !== A && (this.provided = !1, this.unsubscribe()), this.subscribe || this.unsubscribe()), this.value = t, this.host.requestUpdate(), this.provided && !this.subscribe || (this.provided = !0, this.callback && this.callback(t, A)), this.unsubscribe = A;
    }, this.subscribe));
  }
};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let dB = class {
  constructor(t) {
    this.callbacks = /* @__PURE__ */ new Map(), this.updateObservers = () => {
      for (const [A, i] of this.callbacks)
        A(this.t, i);
    }, t !== void 0 && (this.value = t);
  }
  get value() {
    return this.t;
  }
  set value(t) {
    this.setValue(t);
  }
  setValue(t, A = !1) {
    const i = A || !Object.is(t, this.t);
    this.t = t, i && this.updateObservers();
  }
  addCallback(t, A) {
    A && (this.callbacks.has(t) || this.callbacks.set(t, () => {
      this.callbacks.delete(t);
    })), t(this.value);
  }
  clearCallbacks() {
    this.callbacks.clear();
  }
};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let CB = class extends Event {
  constructor(t) {
    super("context-provider", { bubbles: !0, composed: !0 }), this.context = t;
  }
}, BB = class extends dB {
  constructor(t, A, i) {
    super(i), this.host = t, this.context = A, this.onContextRequest = (s) => {
      s.context === this.context && s.composedPath()[0] !== this.host && (s.stopPropagation(), this.addCallback(s.callback, s.subscribe));
    }, this.attachListeners(), this.host.addController(this);
  }
  attachListeners() {
    this.host.addEventListener("context-request", this.onContextRequest);
  }
  hostConnected() {
    this.host.dispatchEvent(new CB(this.context));
  }
};
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function to({ context: e }) {
  return gn({ finisher: (t, A) => {
    const i = /* @__PURE__ */ new WeakMap();
    t.addInitializer((n) => {
      i.set(n, new BB(n, e));
    });
    const s = Object.getOwnPropertyDescriptor(t.prototype, A), o = s?.set, r = { ...s, set: function(n) {
      var l;
      (l = i.get(this)) === null || l === void 0 || l.setValue(n), o && o.call(this, n);
    } };
    Object.defineProperty(t.prototype, A, r);
  } });
}
/**
 * @license
 * Copyright 2022 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
function Tt({ context: e, subscribe: t }) {
  return gn({ finisher: (A, i) => {
    A.addInitializer((s) => {
      new uB(s, e, (o) => {
        s[i] = o;
      }, t);
    });
  } });
}
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const QB = (e) => typeof e != "string" && "strTag" in e, EB = (e, t, A) => {
  let i = e[0];
  for (let s = 1; s < e.length; s++)
    i += t[A ? A[s - 1] : s - 1], i += e[s];
  return i;
};
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const fB = (e) => QB(e) ? EB(e.strings, e.values) : e;
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const $a = "lit-localize-status";
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let pB = class {
  constructor(t) {
    this.__litLocalizeEventHandler = (A) => {
      A.detail.status === "ready" && this.host.requestUpdate();
    }, this.host = t;
  }
  hostConnected() {
    window.addEventListener($a, this.__litLocalizeEventHandler);
  }
  hostDisconnected() {
    window.removeEventListener($a, this.__litLocalizeEventHandler);
  }
};
const wB = (e) => e.addController(new pB(e)), Xg = wB;
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
const yB = () => (e) => typeof e == "function" ? mB(e) : vB(e), Xt = yB, vB = ({ kind: e, elements: t }) => ({
  kind: e,
  elements: t,
  finisher(A) {
    A.addInitializer(Xg);
  }
}), mB = (e) => (e.addInitializer(Xg), e);
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
class bB {
  constructor() {
    this.settled = !1, this.promise = new Promise((t, A) => {
      this._resolve = t, this._reject = A;
    });
  }
  resolve(t) {
    this.settled = !0, this._resolve(t);
  }
  reject(t) {
    this.settled = !0, this._reject(t);
  }
}
/**
 * @license
 * Copyright 2014 Travis Webb
 * SPDX-License-Identifier: MIT
 */
for (let e = 0; e < 256; e++)
  (e >> 4 & 15).toString(16) + (e & 15).toString(16);
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let DB = new bB();
DB.resolve();
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
let k = fB;
var hs = window, Cn = hs.ShadowRoot && (hs.ShadyCSS === void 0 || hs.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Bn = Symbol(), Pa = /* @__PURE__ */ new WeakMap(), tc = class {
  constructor(t, A, i) {
    if (this._$cssResult$ = !0, i !== Bn)
      throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = A;
  }
  get styleSheet() {
    let t = this.o;
    const A = this.t;
    if (Cn && t === void 0) {
      const i = A !== void 0 && A.length === 1;
      i && (t = Pa.get(A)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), i && Pa.set(A, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
}, kB = (e) => new tc(typeof e == "string" ? e : e + "", void 0, Bn), V = (e, ...t) => {
  const A = e.length === 1 ? e[0] : t.reduce((i, s, o) => i + ((r) => {
    if (r._$cssResult$ === !0)
      return r.cssText;
    if (typeof r == "number")
      return r;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + r + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(s) + e[o + 1], e[0]);
  return new tc(A, e, Bn);
}, SB = (e, t) => {
  Cn ? e.adoptedStyleSheets = t.map((A) => A instanceof CSSStyleSheet ? A : A.styleSheet) : t.forEach((A) => {
    const i = document.createElement("style"), s = hs.litNonce;
    s !== void 0 && i.setAttribute("nonce", s), i.textContent = A.cssText, e.appendChild(i);
  });
}, qa = Cn ? (e) => e : (e) => e instanceof CSSStyleSheet ? ((t) => {
  let A = "";
  for (const i of t.cssRules)
    A += i.cssText;
  return kB(A);
})(e) : e, _o, Ss = window, Va = Ss.trustedTypes, xB = Va ? Va.emptyScript : "", za = Ss.reactiveElementPolyfillSupport, pi = { toAttribute(e, t) {
  switch (t) {
    case Boolean:
      e = e ? xB : null;
      break;
    case Object:
    case Array:
      e = e == null ? e : JSON.stringify(e);
  }
  return e;
}, fromAttribute(e, t) {
  let A = e;
  switch (t) {
    case Boolean:
      A = e !== null;
      break;
    case Number:
      A = e === null ? null : Number(e);
      break;
    case Object:
    case Array:
      try {
        A = JSON.parse(e);
      } catch {
        A = null;
      }
  }
  return A;
} }, ec = (e, t) => t !== e && (t == t || e == e), To = { attribute: !0, type: String, converter: pi, reflect: !1, hasChanged: ec }, iA = class extends HTMLElement {
  constructor() {
    super(), this._$Ei = /* @__PURE__ */ new Map(), this.isUpdatePending = !1, this.hasUpdated = !1, this._$El = null, this.u();
  }
  static addInitializer(e) {
    var t;
    this.finalize(), ((t = this.h) !== null && t !== void 0 ? t : this.h = []).push(e);
  }
  static get observedAttributes() {
    this.finalize();
    const e = [];
    return this.elementProperties.forEach((t, A) => {
      const i = this._$Ep(A, t);
      i !== void 0 && (this._$Ev.set(i, A), e.push(i));
    }), e;
  }
  static createProperty(e, t = To) {
    if (t.state && (t.attribute = !1), this.finalize(), this.elementProperties.set(e, t), !t.noAccessor && !this.prototype.hasOwnProperty(e)) {
      const A = typeof e == "symbol" ? Symbol() : "__" + e, i = this.getPropertyDescriptor(e, A, t);
      i !== void 0 && Object.defineProperty(this.prototype, e, i);
    }
  }
  static getPropertyDescriptor(e, t, A) {
    return { get() {
      return this[t];
    }, set(i) {
      const s = this[e];
      this[t] = i, this.requestUpdate(e, s, A);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(e) {
    return this.elementProperties.get(e) || To;
  }
  static finalize() {
    if (this.hasOwnProperty("finalized"))
      return !1;
    this.finalized = !0;
    const e = Object.getPrototypeOf(this);
    if (e.finalize(), e.h !== void 0 && (this.h = [...e.h]), this.elementProperties = new Map(e.elementProperties), this._$Ev = /* @__PURE__ */ new Map(), this.hasOwnProperty("properties")) {
      const t = this.properties, A = [...Object.getOwnPropertyNames(t), ...Object.getOwnPropertySymbols(t)];
      for (const i of A)
        this.createProperty(i, t[i]);
    }
    return this.elementStyles = this.finalizeStyles(this.styles), !0;
  }
  static finalizeStyles(e) {
    const t = [];
    if (Array.isArray(e)) {
      const A = new Set(e.flat(1 / 0).reverse());
      for (const i of A)
        t.unshift(qa(i));
    } else
      e !== void 0 && t.push(qa(e));
    return t;
  }
  static _$Ep(e, t) {
    const A = t.attribute;
    return A === !1 ? void 0 : typeof A == "string" ? A : typeof e == "string" ? e.toLowerCase() : void 0;
  }
  u() {
    var e;
    this._$E_ = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$Eg(), this.requestUpdate(), (e = this.constructor.h) === null || e === void 0 || e.forEach((t) => t(this));
  }
  addController(e) {
    var t, A;
    ((t = this._$ES) !== null && t !== void 0 ? t : this._$ES = []).push(e), this.renderRoot !== void 0 && this.isConnected && ((A = e.hostConnected) === null || A === void 0 || A.call(e));
  }
  removeController(e) {
    var t;
    (t = this._$ES) === null || t === void 0 || t.splice(this._$ES.indexOf(e) >>> 0, 1);
  }
  _$Eg() {
    this.constructor.elementProperties.forEach((e, t) => {
      this.hasOwnProperty(t) && (this._$Ei.set(t, this[t]), delete this[t]);
    });
  }
  createRenderRoot() {
    var e;
    const t = (e = this.shadowRoot) !== null && e !== void 0 ? e : this.attachShadow(this.constructor.shadowRootOptions);
    return SB(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    var e;
    this.renderRoot === void 0 && (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), (e = this._$ES) === null || e === void 0 || e.forEach((t) => {
      var A;
      return (A = t.hostConnected) === null || A === void 0 ? void 0 : A.call(t);
    });
  }
  enableUpdating(e) {
  }
  disconnectedCallback() {
    var e;
    (e = this._$ES) === null || e === void 0 || e.forEach((t) => {
      var A;
      return (A = t.hostDisconnected) === null || A === void 0 ? void 0 : A.call(t);
    });
  }
  attributeChangedCallback(e, t, A) {
    this._$AK(e, A);
  }
  _$EO(e, t, A = To) {
    var i;
    const s = this.constructor._$Ep(e, A);
    if (s !== void 0 && A.reflect === !0) {
      const o = (((i = A.converter) === null || i === void 0 ? void 0 : i.toAttribute) !== void 0 ? A.converter : pi).toAttribute(t, A.type);
      this._$El = e, o == null ? this.removeAttribute(s) : this.setAttribute(s, o), this._$El = null;
    }
  }
  _$AK(e, t) {
    var A;
    const i = this.constructor, s = i._$Ev.get(e);
    if (s !== void 0 && this._$El !== s) {
      const o = i.getPropertyOptions(s), r = typeof o.converter == "function" ? { fromAttribute: o.converter } : ((A = o.converter) === null || A === void 0 ? void 0 : A.fromAttribute) !== void 0 ? o.converter : pi;
      this._$El = s, this[s] = r.fromAttribute(t, o.type), this._$El = null;
    }
  }
  requestUpdate(e, t, A) {
    let i = !0;
    e !== void 0 && (((A = A || this.constructor.getPropertyOptions(e)).hasChanged || ec)(this[e], t) ? (this._$AL.has(e) || this._$AL.set(e, t), A.reflect === !0 && this._$El !== e && (this._$EC === void 0 && (this._$EC = /* @__PURE__ */ new Map()), this._$EC.set(e, A))) : i = !1), !this.isUpdatePending && i && (this._$E_ = this._$Ej());
  }
  async _$Ej() {
    this.isUpdatePending = !0;
    try {
      await this._$E_;
    } catch (t) {
      Promise.reject(t);
    }
    const e = this.scheduleUpdate();
    return e != null && await e, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    var e;
    if (!this.isUpdatePending)
      return;
    this.hasUpdated, this._$Ei && (this._$Ei.forEach((i, s) => this[s] = i), this._$Ei = void 0);
    let t = !1;
    const A = this._$AL;
    try {
      t = this.shouldUpdate(A), t ? (this.willUpdate(A), (e = this._$ES) === null || e === void 0 || e.forEach((i) => {
        var s;
        return (s = i.hostUpdate) === null || s === void 0 ? void 0 : s.call(i);
      }), this.update(A)) : this._$Ek();
    } catch (i) {
      throw t = !1, this._$Ek(), i;
    }
    t && this._$AE(A);
  }
  willUpdate(e) {
  }
  _$AE(e) {
    var t;
    (t = this._$ES) === null || t === void 0 || t.forEach((A) => {
      var i;
      return (i = A.hostUpdated) === null || i === void 0 ? void 0 : i.call(A);
    }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(e)), this.updated(e);
  }
  _$Ek() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$E_;
  }
  shouldUpdate(e) {
    return !0;
  }
  update(e) {
    this._$EC !== void 0 && (this._$EC.forEach((t, A) => this._$EO(A, this[A], t)), this._$EC = void 0), this._$Ek();
  }
  updated(e) {
  }
  firstUpdated(e) {
  }
};
iA.finalized = !0, iA.elementProperties = /* @__PURE__ */ new Map(), iA.elementStyles = [], iA.shadowRootOptions = { mode: "open" }, za?.({ ReactiveElement: iA }), ((_o = Ss.reactiveElementVersions) !== null && _o !== void 0 ? _o : Ss.reactiveElementVersions = []).push("1.6.1");
var Oo, xs = window, pA = xs.trustedTypes, Ka = pA ? pA.createPolicy("lit-html", { createHTML: (e) => e }) : void 0, Ce = `lit$${(Math.random() + "").slice(9)}$`, Ac = "?" + Ce, NB = `<${Ac}>`, wA = document, wi = (e = "") => wA.createComment(e), yi = (e) => e === null || typeof e != "object" && typeof e != "function", ic = Array.isArray, FB = (e) => ic(e) || typeof e?.[Symbol.iterator] == "function", VA = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, ja = /-->/g, Za = />/g, Ne = RegExp(`>|[ 	
\f\r](?:([^\\s"'>=/]+)([ 	
\f\r]*=[ 	
\f\r]*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), Wa = /'/g, Xa = /"/g, sc = /^(?:script|style|textarea|title)$/i, RB = (e) => (t, ...A) => ({ _$litType$: e, strings: t, values: A }), _ = RB(1), Yt = Symbol.for("lit-noChange"), P = Symbol.for("lit-nothing"), tl = /* @__PURE__ */ new WeakMap(), cA = wA.createTreeWalker(wA, 129, null, !1), UB = (e, t) => {
  const A = e.length - 1, i = [];
  let s, o = t === 2 ? "<svg>" : "", r = VA;
  for (let l = 0; l < A; l++) {
    const a = e[l];
    let c, g, h = -1, u = 0;
    for (; u < a.length && (r.lastIndex = u, g = r.exec(a), g !== null); )
      u = r.lastIndex, r === VA ? g[1] === "!--" ? r = ja : g[1] !== void 0 ? r = Za : g[2] !== void 0 ? (sc.test(g[2]) && (s = RegExp("</" + g[2], "g")), r = Ne) : g[3] !== void 0 && (r = Ne) : r === Ne ? g[0] === ">" ? (r = s ?? VA, h = -1) : g[1] === void 0 ? h = -2 : (h = r.lastIndex - g[2].length, c = g[1], r = g[3] === void 0 ? Ne : g[3] === '"' ? Xa : Wa) : r === Xa || r === Wa ? r = Ne : r === ja || r === Za ? r = VA : (r = Ne, s = void 0);
    const C = r === Ne && e[l + 1].startsWith("/>") ? " " : "";
    o += r === VA ? a + NB : h >= 0 ? (i.push(c), a.slice(0, h) + "$lit$" + a.slice(h) + Ce + C) : a + Ce + (h === -2 ? (i.push(void 0), l) : C);
  }
  const n = o + (e[A] || "<?>") + (t === 2 ? "</svg>" : "");
  if (!Array.isArray(e) || !e.hasOwnProperty("raw"))
    throw Error("invalid template strings array");
  return [Ka !== void 0 ? Ka.createHTML(n) : n, i];
}, Ns = class {
  constructor({ strings: t, _$litType$: A }, i) {
    let s;
    this.parts = [];
    let o = 0, r = 0;
    const n = t.length - 1, l = this.parts, [a, c] = UB(t, A);
    if (this.el = Ns.createElement(a, i), cA.currentNode = this.el.content, A === 2) {
      const g = this.el.content, h = g.firstChild;
      h.remove(), g.append(...h.childNodes);
    }
    for (; (s = cA.nextNode()) !== null && l.length < n; ) {
      if (s.nodeType === 1) {
        if (s.hasAttributes()) {
          const g = [];
          for (const h of s.getAttributeNames())
            if (h.endsWith("$lit$") || h.startsWith(Ce)) {
              const u = c[r++];
              if (g.push(h), u !== void 0) {
                const C = s.getAttribute(u.toLowerCase() + "$lit$").split(Ce), B = /([.?@])?(.*)/.exec(u);
                l.push({ type: 1, index: o, name: B[2], strings: C, ctor: B[1] === "." ? MB : B[1] === "?" ? JB : B[1] === "@" ? YB : Ao });
              } else
                l.push({ type: 6, index: o });
            }
          for (const h of g)
            s.removeAttribute(h);
        }
        if (sc.test(s.tagName)) {
          const g = s.textContent.split(Ce), h = g.length - 1;
          if (h > 0) {
            s.textContent = pA ? pA.emptyScript : "";
            for (let u = 0; u < h; u++)
              s.append(g[u], wi()), cA.nextNode(), l.push({ type: 2, index: ++o });
            s.append(g[h], wi());
          }
        }
      } else if (s.nodeType === 8)
        if (s.data === Ac)
          l.push({ type: 2, index: o });
        else {
          let g = -1;
          for (; (g = s.data.indexOf(Ce, g + 1)) !== -1; )
            l.push({ type: 7, index: o }), g += Ce.length - 1;
        }
      o++;
    }
  }
  static createElement(t, A) {
    const i = wA.createElement("template");
    return i.innerHTML = t, i;
  }
};
function yA(e, t, A = e, i) {
  var s, o, r, n;
  if (t === Yt)
    return t;
  let l = i !== void 0 ? (s = A._$Co) === null || s === void 0 ? void 0 : s[i] : A._$Cl;
  const a = yi(t) ? void 0 : t._$litDirective$;
  return l?.constructor !== a && ((o = l?._$AO) === null || o === void 0 || o.call(l, !1), a === void 0 ? l = void 0 : (l = new a(e), l._$AT(e, A, i)), i !== void 0 ? ((r = (n = A)._$Co) !== null && r !== void 0 ? r : n._$Co = [])[i] = l : A._$Cl = l), l !== void 0 && (t = yA(e, l._$AS(e, t.values), l, i)), t;
}
var GB = class {
  constructor(t, A) {
    this.u = [], this._$AN = void 0, this._$AD = t, this._$AM = A;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  v(t) {
    var A;
    const { el: { content: i }, parts: s } = this._$AD, o = ((A = t?.creationScope) !== null && A !== void 0 ? A : wA).importNode(i, !0);
    cA.currentNode = o;
    let r = cA.nextNode(), n = 0, l = 0, a = s[0];
    for (; a !== void 0; ) {
      if (n === a.index) {
        let c;
        a.type === 2 ? c = new eo(r, r.nextSibling, this, t) : a.type === 1 ? c = new a.ctor(r, a.name, a.strings, this, t) : a.type === 6 && (c = new HB(r, this, t)), this.u.push(c), a = s[++l];
      }
      n !== a?.index && (r = cA.nextNode(), n++);
    }
    return o;
  }
  p(t) {
    let A = 0;
    for (const i of this.u)
      i !== void 0 && (i.strings !== void 0 ? (i._$AI(t, i, A), A += i.strings.length - 2) : i._$AI(t[A])), A++;
  }
}, eo = class {
  constructor(e, t, A, i) {
    var s;
    this.type = 2, this._$AH = P, this._$AN = void 0, this._$AA = e, this._$AB = t, this._$AM = A, this.options = i, this._$Cm = (s = i?.isConnected) === null || s === void 0 || s;
  }
  get _$AU() {
    var e, t;
    return (t = (e = this._$AM) === null || e === void 0 ? void 0 : e._$AU) !== null && t !== void 0 ? t : this._$Cm;
  }
  get parentNode() {
    let e = this._$AA.parentNode;
    const t = this._$AM;
    return t !== void 0 && e.nodeType === 11 && (e = t.parentNode), e;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(e, t = this) {
    e = yA(this, e, t), yi(e) ? e === P || e == null || e === "" ? (this._$AH !== P && this._$AR(), this._$AH = P) : e !== this._$AH && e !== Yt && this.g(e) : e._$litType$ !== void 0 ? this.$(e) : e.nodeType !== void 0 ? this.T(e) : FB(e) ? this.k(e) : this.g(e);
  }
  O(e, t = this._$AB) {
    return this._$AA.parentNode.insertBefore(e, t);
  }
  T(e) {
    this._$AH !== e && (this._$AR(), this._$AH = this.O(e));
  }
  g(e) {
    this._$AH !== P && yi(this._$AH) ? this._$AA.nextSibling.data = e : this.T(wA.createTextNode(e)), this._$AH = e;
  }
  $(e) {
    var t;
    const { values: A, _$litType$: i } = e, s = typeof i == "number" ? this._$AC(e) : (i.el === void 0 && (i.el = Ns.createElement(i.h, this.options)), i);
    if (((t = this._$AH) === null || t === void 0 ? void 0 : t._$AD) === s)
      this._$AH.p(A);
    else {
      const o = new GB(s, this), r = o.v(this.options);
      o.p(A), this.T(r), this._$AH = o;
    }
  }
  _$AC(e) {
    let t = tl.get(e.strings);
    return t === void 0 && tl.set(e.strings, t = new Ns(e)), t;
  }
  k(e) {
    ic(this._$AH) || (this._$AH = [], this._$AR());
    const t = this._$AH;
    let A, i = 0;
    for (const s of e)
      i === t.length ? t.push(A = new eo(this.O(wi()), this.O(wi()), this, this.options)) : A = t[i], A._$AI(s), i++;
    i < t.length && (this._$AR(A && A._$AB.nextSibling, i), t.length = i);
  }
  _$AR(e = this._$AA.nextSibling, t) {
    var A;
    for ((A = this._$AP) === null || A === void 0 || A.call(this, !1, !0, t); e && e !== this._$AB; ) {
      const i = e.nextSibling;
      e.remove(), e = i;
    }
  }
  setConnected(e) {
    var t;
    this._$AM === void 0 && (this._$Cm = e, (t = this._$AP) === null || t === void 0 || t.call(this, e));
  }
}, Ao = class {
  constructor(e, t, A, i, s) {
    this.type = 1, this._$AH = P, this._$AN = void 0, this.element = e, this.name = t, this._$AM = i, this.options = s, A.length > 2 || A[0] !== "" || A[1] !== "" ? (this._$AH = Array(A.length - 1).fill(new String()), this.strings = A) : this._$AH = P;
  }
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e, t = this, A, i) {
    const s = this.strings;
    let o = !1;
    if (s === void 0)
      e = yA(this, e, t, 0), o = !yi(e) || e !== this._$AH && e !== Yt, o && (this._$AH = e);
    else {
      const r = e;
      let n, l;
      for (e = s[0], n = 0; n < s.length - 1; n++)
        l = yA(this, r[A + n], t, n), l === Yt && (l = this._$AH[n]), o || (o = !yi(l) || l !== this._$AH[n]), l === P ? e = P : e !== P && (e += (l ?? "") + s[n + 1]), this._$AH[n] = l;
    }
    o && !i && this.j(e);
  }
  j(e) {
    e === P ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, e ?? "");
  }
}, MB = class extends Ao {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(e) {
    this.element[this.name] = e === P ? void 0 : e;
  }
}, LB = pA ? pA.emptyScript : "", JB = class extends Ao {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    t && t !== P ? this.element.setAttribute(this.name, LB) : this.element.removeAttribute(this.name);
  }
}, YB = class extends Ao {
  constructor(t, A, i, s, o) {
    super(t, A, i, s, o), this.type = 5;
  }
  _$AI(t, A = this) {
    var i;
    if ((t = (i = yA(this, t, A, 0)) !== null && i !== void 0 ? i : P) === Yt)
      return;
    const s = this._$AH, o = t === P && s !== P || t.capture !== s.capture || t.once !== s.once || t.passive !== s.passive, r = t !== P && (s === P || o);
    o && this.element.removeEventListener(this.name, this, s), r && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    var A, i;
    typeof this._$AH == "function" ? this._$AH.call((i = (A = this.options) === null || A === void 0 ? void 0 : A.host) !== null && i !== void 0 ? i : this.element, t) : this._$AH.handleEvent(t);
  }
}, HB = class {
  constructor(e, t, A) {
    this.element = e, this.type = 6, this._$AN = void 0, this._$AM = t, this.options = A;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(e) {
    yA(this, e);
  }
}, el = xs.litHtmlPolyfillSupport;
el?.(Ns, eo), ((Oo = xs.litHtmlVersions) !== null && Oo !== void 0 ? Oo : xs.litHtmlVersions = []).push("2.6.1");
var _B = (e, t, A) => {
  var i, s;
  const o = (i = A?.renderBefore) !== null && i !== void 0 ? i : t;
  let r = o._$litPart$;
  if (r === void 0) {
    const n = (s = A?.renderBefore) !== null && s !== void 0 ? s : null;
    o._$litPart$ = r = new eo(t.insertBefore(wi(), n), n, void 0, A ?? {});
  }
  return r._$AI(e), r;
}, $o, Po, gi = class extends iA {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Dt = void 0;
  }
  createRenderRoot() {
    var e, t;
    const A = super.createRenderRoot();
    return (e = (t = this.renderOptions).renderBefore) !== null && e !== void 0 || (t.renderBefore = A.firstChild), A;
  }
  update(e) {
    const t = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(e), this._$Dt = _B(t, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    var e;
    super.connectedCallback(), (e = this._$Dt) === null || e === void 0 || e.setConnected(!0);
  }
  disconnectedCallback() {
    var e;
    super.disconnectedCallback(), (e = this._$Dt) === null || e === void 0 || e.setConnected(!1);
  }
  render() {
    return Yt;
  }
};
gi.finalized = !0, gi._$litElement$ = !0, ($o = globalThis.litElementHydrateSupport) === null || $o === void 0 || $o.call(globalThis, { LitElement: gi });
var Al = globalThis.litElementPolyfillSupport;
Al?.({ LitElement: gi });
((Po = globalThis.litElementVersions) !== null && Po !== void 0 ? Po : globalThis.litElementVersions = []).push("3.2.0");
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/lit-html.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-element/lit-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var it = V`
  :host {
    box-sizing: border-box;
  }

  :host *,
  :host *::before,
  :host *::after {
    box-sizing: inherit;
  }

  [hidden] {
    display: none !important;
  }
`, TB = V`
  ${it}

  :host {
    --max-width: 20rem;
    --hide-delay: 0ms;
    --show-delay: 150ms;

    display: contents;
  }

  .tooltip {
    --arrow-size: var(--sl-tooltip-arrow-size);
    --arrow-color: var(--sl-tooltip-background-color);
  }

  .tooltip::part(popup) {
    pointer-events: none;
    z-index: var(--sl-z-index-tooltip);
  }

  .tooltip[placement^='top']::part(popup) {
    transform-origin: bottom;
  }

  .tooltip[placement^='bottom']::part(popup) {
    transform-origin: top;
  }

  .tooltip[placement^='left']::part(popup) {
    transform-origin: right;
  }

  .tooltip[placement^='right']::part(popup) {
    transform-origin: left;
  }

  .tooltip__body {
    display: block;
    width: max-content;
    max-width: var(--max-width);
    border-radius: var(--sl-tooltip-border-radius);
    background-color: var(--sl-tooltip-background-color);
    font-family: var(--sl-tooltip-font-family);
    font-size: var(--sl-tooltip-font-size);
    font-weight: var(--sl-tooltip-font-weight);
    line-height: var(--sl-tooltip-line-height);
    color: var(--sl-tooltip-color);
    padding: var(--sl-tooltip-padding);
    pointer-events: none;
  }
`, oc = Object.defineProperty, OB = Object.defineProperties, $B = Object.getOwnPropertyDescriptor, PB = Object.getOwnPropertyDescriptors, Fs = Object.getOwnPropertySymbols, rc = Object.prototype.hasOwnProperty, nc = Object.prototype.propertyIsEnumerable, il = (e, t, A) => t in e ? oc(e, t, { enumerable: !0, configurable: !0, writable: !0, value: A }) : e[t] = A, Y = (e, t) => {
  for (var A in t || (t = {}))
    rc.call(t, A) && il(e, A, t[A]);
  if (Fs)
    for (var A of Fs(t))
      nc.call(t, A) && il(e, A, t[A]);
  return e;
}, Bt = (e, t) => OB(e, PB(t)), Qn = (e, t) => {
  var A = {};
  for (var i in e)
    rc.call(e, i) && t.indexOf(i) < 0 && (A[i] = e[i]);
  if (e != null && Fs)
    for (var i of Fs(e))
      t.indexOf(i) < 0 && nc.call(e, i) && (A[i] = e[i]);
  return A;
}, I = (e, t, A, i) => {
  for (var s = i > 1 ? void 0 : i ? $B(t, A) : t, o = e.length - 1, r; o >= 0; o--)
    (r = e[o]) && (s = (i ? r(t, A, s) : r(s)) || s);
  return i && s && oc(t, A, s), s;
}, ac = /* @__PURE__ */ new Map(), qB = /* @__PURE__ */ new WeakMap();
function VB(e) {
  return e ?? { keyframes: [], options: { duration: 0 } };
}
function sl(e, t) {
  return t.toLowerCase() === "rtl" ? {
    keyframes: e.rtlKeyframes || e.keyframes,
    options: e.options
  } : e;
}
function Ot(e, t) {
  ac.set(e, VB(t));
}
function Lt(e, t, A) {
  const i = qB.get(e);
  if (i?.[t])
    return sl(i[t], A.dir);
  const s = ac.get(t);
  return s ? sl(s, A.dir) : {
    keyframes: [],
    options: { duration: 0 }
  };
}
function pe(e, t) {
  return new Promise((A) => {
    function i(s) {
      s.target === e && (e.removeEventListener(t, i), A());
    }
    e.addEventListener(t, i);
  });
}
function Jt(e, t, A) {
  return new Promise((i) => {
    if (A?.duration === 1 / 0)
      throw new Error("Promise-based animations must be finite.");
    const s = e.animate(t, Bt(Y({}, A), {
      duration: zB() ? 0 : A.duration
    }));
    s.addEventListener("cancel", i, { once: !0 }), s.addEventListener("finish", i, { once: !0 });
  });
}
function ol(e) {
  return e = e.toString().toLowerCase(), e.indexOf("ms") > -1 ? parseFloat(e) : e.indexOf("s") > -1 ? parseFloat(e) * 1e3 : parseFloat(e);
}
function zB() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function zt(e) {
  return Promise.all(
    e.getAnimations().map((t) => new Promise((A) => {
      const i = requestAnimationFrame(A);
      t.addEventListener("cancel", () => i, { once: !0 }), t.addEventListener("finish", () => i, { once: !0 }), t.cancel();
    }))
  );
}
var Fr = /* @__PURE__ */ new Set(), KB = new MutationObserver(cc), oA = /* @__PURE__ */ new Map(), lc = document.documentElement.dir || "ltr", gc = document.documentElement.lang || navigator.language, He;
KB.observe(document.documentElement, {
  attributes: !0,
  attributeFilter: ["dir", "lang"]
});
function jB(...e) {
  e.map((t) => {
    const A = t.$code.toLowerCase();
    oA.has(A) ? oA.set(A, Object.assign(Object.assign({}, oA.get(A)), t)) : oA.set(A, t), He || (He = t);
  }), cc();
}
function cc() {
  lc = document.documentElement.dir || "ltr", gc = document.documentElement.lang || navigator.language, [...Fr.keys()].map((e) => {
    typeof e.requestUpdate == "function" && e.requestUpdate();
  });
}
var ZB = class {
  constructor(e) {
    this.host = e, this.host.addController(this);
  }
  hostConnected() {
    Fr.add(this.host);
  }
  hostDisconnected() {
    Fr.delete(this.host);
  }
  dir() {
    return `${this.host.dir || lc}`.toLowerCase();
  }
  lang() {
    return `${this.host.lang || gc}`.toLowerCase();
  }
  getTranslationData(e) {
    var t, A;
    const i = new Intl.Locale(e), s = i?.language.toLowerCase(), o = (A = (t = i?.region) === null || t === void 0 ? void 0 : t.toLowerCase()) !== null && A !== void 0 ? A : "", r = oA.get(`${s}-${o}`), n = oA.get(s);
    return { locale: i, language: s, region: o, primary: r, secondary: n };
  }
  exists(e, t) {
    var A;
    const { primary: i, secondary: s } = this.getTranslationData((A = t.lang) !== null && A !== void 0 ? A : this.lang());
    return t = Object.assign({ includeFallback: !1 }, t), !!(i && i[e] || s && s[e] || t.includeFallback && He && He[e]);
  }
  term(e, ...t) {
    const { primary: A, secondary: i } = this.getTranslationData(this.lang());
    let s;
    if (A && A[e])
      s = A[e];
    else if (i && i[e])
      s = i[e];
    else if (He && He[e])
      s = He[e];
    else
      return console.error(`No translation found for: ${String(e)}`), String(e);
    return typeof s == "function" ? s(...t) : s;
  }
  date(e, t) {
    return e = new Date(e), new Intl.DateTimeFormat(this.lang(), t).format(e);
  }
  number(e, t) {
    return e = Number(e), isNaN(e) ? "" : new Intl.NumberFormat(this.lang(), t).format(e);
  }
  relativeTime(e, t, A) {
    return new Intl.RelativeTimeFormat(this.lang(), A).format(e, t);
  }
}, be = class extends ZB {
}, WB = {
  $code: "en",
  $name: "English",
  $dir: "ltr",
  carousel: "Carousel",
  clearEntry: "Clear entry",
  close: "Close",
  copy: "Copy",
  currentValue: "Current value",
  goToSlide: (e, t) => `Go to slide ${e} of ${t}`,
  hidePassword: "Hide password",
  loading: "Loading",
  nextSlide: "Next slide",
  numOptionsSelected: (e) => e === 0 ? "No options selected" : e === 1 ? "1 option selected" : `${e} options selected`,
  previousSlide: "Previous slide",
  progress: "Progress",
  remove: "Remove",
  resize: "Resize",
  scrollToEnd: "Scroll to end",
  scrollToStart: "Scroll to start",
  selectAColorFromTheScreen: "Select a color from the screen",
  showPassword: "Show password",
  slideNum: (e) => `Slide ${e}`,
  toggleColorFormat: "Toggle color format"
};
jB(WB);
function z(e, t) {
  const A = Y({
    waitUntilFirstUpdate: !1
  }, t);
  return (i, s) => {
    const { update: o } = i, r = Array.isArray(e) ? e : [e];
    i.update = function(n) {
      r.forEach((l) => {
        const a = l;
        if (n.has(a)) {
          const c = n.get(a), g = this[a];
          c !== g && (!A.waitUntilFirstUpdate || this.hasUpdated) && this[s](c, g);
        }
      }), o.call(this, n);
    };
  };
}
var Me = { ATTRIBUTE: 1, CHILD: 2, PROPERTY: 3, BOOLEAN_ATTRIBUTE: 4, EVENT: 5, ELEMENT: 6 }, hc = (e) => (...t) => ({ _$litDirective$: e, values: t }), Ic = class {
  constructor(t) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(t, A, i) {
    this._$Ct = t, this._$AM = A, this._$Ci = i;
  }
  _$AS(t, A) {
    return this.update(t, A);
  }
  update(t, A) {
    return this.render(...A);
  }
};
/*! Bundled license information:

lit-html/directive.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var Qt = hc(class extends Ic {
  constructor(e) {
    var t;
    if (super(e), e.type !== Me.ATTRIBUTE || e.name !== "class" || ((t = e.strings) === null || t === void 0 ? void 0 : t.length) > 2)
      throw Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.");
  }
  render(e) {
    return " " + Object.keys(e).filter((t) => e[t]).join(" ") + " ";
  }
  update(e, [t]) {
    var A, i;
    if (this.nt === void 0) {
      this.nt = /* @__PURE__ */ new Set(), e.strings !== void 0 && (this.st = new Set(e.strings.join(" ").split(/\s/).filter((o) => o !== "")));
      for (const o in t)
        t[o] && !(!((A = this.st) === null || A === void 0) && A.has(o)) && this.nt.add(o);
      return this.render(t);
    }
    const s = e.element.classList;
    this.nt.forEach((o) => {
      o in t || (s.remove(o), this.nt.delete(o));
    });
    for (const o in t) {
      const r = !!t[o];
      r === this.nt.has(o) || !((i = this.st) === null || i === void 0) && i.has(o) || (r ? (s.add(o), this.nt.add(o)) : (s.remove(o), this.nt.delete(o)));
    }
    return Yt;
  }
});
/*! Bundled license information:

lit-html/directives/class-map.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var st = (e) => (t) => typeof t == "function" ? ((A, i) => (customElements.define(A, i), i))(e, t) : ((A, i) => {
  const { kind: s, elements: o } = i;
  return { kind: s, elements: o, finisher(r) {
    customElements.define(A, r);
  } };
})(e, t), XB = (e, t) => t.kind === "method" && t.descriptor && !("value" in t.descriptor) ? Bt(Y({}, t), { finisher(A) {
  A.createProperty(t.key, e);
} }) : { kind: "field", key: Symbol(), placement: "own", descriptor: {}, originalKey: t.key, initializer() {
  typeof t.initializer == "function" && (this[t.key] = t.initializer.call(this));
}, finisher(A) {
  A.createProperty(t.key, e);
} };
function d(e) {
  return (t, A) => A !== void 0 ? ((i, s, o) => {
    s.constructor.createProperty(o, i);
  })(e, t, A) : XB(e, t);
}
function FA(e) {
  return d(Bt(Y({}, e), { state: !0 }));
}
var tQ = ({ finisher: e, descriptor: t }) => (A, i) => {
  var s;
  if (i === void 0) {
    const o = (s = A.originalKey) !== null && s !== void 0 ? s : A.key, r = t != null ? { kind: "method", placement: "prototype", key: o, descriptor: t(A.key) } : Bt(Y({}, A), { key: o });
    return e != null && (r.finisher = function(n) {
      e(n, o);
    }), r;
  }
  {
    const o = A.constructor;
    t !== void 0 && Object.defineProperty(A, i, t(i)), e?.(o, i);
  }
};
function X(e, t) {
  return tQ({ descriptor: (A) => {
    const i = { get() {
      var s, o;
      return (o = (s = this.renderRoot) === null || s === void 0 ? void 0 : s.querySelector(e)) !== null && o !== void 0 ? o : null;
    }, enumerable: !0, configurable: !0 };
    if (t) {
      const s = typeof A == "symbol" ? Symbol() : "__" + A;
      i.get = function() {
        var o, r;
        return this[s] === void 0 && (this[s] = (r = (o = this.renderRoot) === null || o === void 0 ? void 0 : o.querySelector(e)) !== null && r !== void 0 ? r : null), this[s];
      };
    }
    return i;
  } });
}
var qo;
((qo = window.HTMLSlotElement) === null || qo === void 0 ? void 0 : qo.prototype.assignedElements) != null;
var K = class extends gi {
  emit(e, t) {
    const A = new CustomEvent(e, Y({
      bubbles: !0,
      cancelable: !1,
      composed: !0,
      detail: {}
    }, t));
    return this.dispatchEvent(A), A;
  }
};
I([
  d()
], K.prototype, "dir", 2);
I([
  d()
], K.prototype, "lang", 2);
/*! Bundled license information:

@lit/reactive-element/decorators/custom-element.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/property.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/state.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/base.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/event-options.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-async.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-all.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-assigned-elements.js:
  (**
   * @license
   * Copyright 2021 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/decorators/query-assigned-nodes.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var gt = class extends K {
  constructor() {
    super(...arguments), this.localize = new be(this), this.content = "", this.placement = "top", this.disabled = !1, this.distance = 8, this.open = !1, this.skidding = 0, this.trigger = "hover focus", this.hoist = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.handleBlur = this.handleBlur.bind(this), this.handleClick = this.handleClick.bind(this), this.handleFocus = this.handleFocus.bind(this), this.handleKeyDown = this.handleKeyDown.bind(this), this.handleMouseOver = this.handleMouseOver.bind(this), this.handleMouseOut = this.handleMouseOut.bind(this), this.updateComplete.then(() => {
      this.addEventListener("blur", this.handleBlur, !0), this.addEventListener("focus", this.handleFocus, !0), this.addEventListener("click", this.handleClick), this.addEventListener("keydown", this.handleKeyDown), this.addEventListener("mouseover", this.handleMouseOver), this.addEventListener("mouseout", this.handleMouseOut);
    });
  }
  firstUpdated() {
    this.body.hidden = !this.open, this.open && (this.popup.active = !0, this.popup.reposition());
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("blur", this.handleBlur, !0), this.removeEventListener("focus", this.handleFocus, !0), this.removeEventListener("click", this.handleClick), this.removeEventListener("keydown", this.handleKeyDown), this.removeEventListener("mouseover", this.handleMouseOver), this.removeEventListener("mouseout", this.handleMouseOut);
  }
  handleBlur() {
    this.hasTrigger("focus") && this.hide();
  }
  handleClick() {
    this.hasTrigger("click") && (this.open ? this.hide() : this.show());
  }
  handleFocus() {
    this.hasTrigger("focus") && this.show();
  }
  handleKeyDown(e) {
    this.open && e.key === "Escape" && (e.stopPropagation(), this.hide());
  }
  handleMouseOver() {
    if (this.hasTrigger("hover")) {
      const e = ol(getComputedStyle(this).getPropertyValue("--show-delay"));
      clearTimeout(this.hoverTimeout), this.hoverTimeout = window.setTimeout(() => this.show(), e);
    }
  }
  handleMouseOut() {
    if (this.hasTrigger("hover")) {
      const e = ol(getComputedStyle(this).getPropertyValue("--hide-delay"));
      clearTimeout(this.hoverTimeout), this.hoverTimeout = window.setTimeout(() => this.hide(), e);
    }
  }
  hasTrigger(e) {
    return this.trigger.split(" ").includes(e);
  }
  async handleOpenChange() {
    if (this.open) {
      if (this.disabled)
        return;
      this.emit("sl-show"), await zt(this.body), this.body.hidden = !1, this.popup.active = !0;
      const { keyframes: e, options: t } = Lt(this, "tooltip.show", { dir: this.localize.dir() });
      await Jt(this.popup.popup, e, t), this.emit("sl-after-show");
    } else {
      this.emit("sl-hide"), await zt(this.body);
      const { keyframes: e, options: t } = Lt(this, "tooltip.hide", { dir: this.localize.dir() });
      await Jt(this.popup.popup, e, t), this.popup.active = !1, this.body.hidden = !0, this.emit("sl-after-hide");
    }
  }
  async handleOptionsChange() {
    this.hasUpdated && (await this.updateComplete, this.popup.reposition());
  }
  handleDisabledChange() {
    this.disabled && this.open && this.hide();
  }
  /** Shows the tooltip. */
  async show() {
    if (!this.open)
      return this.open = !0, pe(this, "sl-after-show");
  }
  /** Hides the tooltip */
  async hide() {
    if (this.open)
      return this.open = !1, pe(this, "sl-after-hide");
  }
  render() {
    return _`
      <sl-popup
        part="base"
        exportparts="
          popup:base__popup,
          arrow:base__arrow
        "
        class=${Qt({
      tooltip: !0,
      "tooltip--open": this.open
    })}
        placement=${this.placement}
        distance=${this.distance}
        skidding=${this.skidding}
        strategy=${this.hoist ? "fixed" : "absolute"}
        flip
        shift
        arrow
      >
        <slot slot="anchor" aria-describedby="tooltip"></slot>

        <slot
          name="content"
          part="body"
          id="tooltip"
          class="tooltip__body"
          role="tooltip"
          aria-live=${this.open ? "polite" : "off"}
        >
          ${this.content}
        </slot>
      </sl-popup>
    `;
  }
};
gt.styles = TB;
I([
  X("slot:not([name])")
], gt.prototype, "defaultSlot", 2);
I([
  X(".tooltip__body")
], gt.prototype, "body", 2);
I([
  X("sl-popup")
], gt.prototype, "popup", 2);
I([
  d()
], gt.prototype, "content", 2);
I([
  d()
], gt.prototype, "placement", 2);
I([
  d({ type: Boolean, reflect: !0 })
], gt.prototype, "disabled", 2);
I([
  d({ type: Number })
], gt.prototype, "distance", 2);
I([
  d({ type: Boolean, reflect: !0 })
], gt.prototype, "open", 2);
I([
  d({ type: Number })
], gt.prototype, "skidding", 2);
I([
  d()
], gt.prototype, "trigger", 2);
I([
  d({ type: Boolean })
], gt.prototype, "hoist", 2);
I([
  z("open", { waitUntilFirstUpdate: !0 })
], gt.prototype, "handleOpenChange", 1);
I([
  z(["content", "distance", "hoist", "placement", "skidding"])
], gt.prototype, "handleOptionsChange", 1);
I([
  z("disabled")
], gt.prototype, "handleDisabledChange", 1);
gt = I([
  st("sl-tooltip")
], gt);
Ot("tooltip.show", {
  keyframes: [
    { opacity: 0, scale: 0.8 },
    { opacity: 1, scale: 1 }
  ],
  options: { duration: 150, easing: "ease" }
});
Ot("tooltip.hide", {
  keyframes: [
    { opacity: 1, scale: 1 },
    { opacity: 0, scale: 0.8 }
  ],
  options: { duration: 150, easing: "ease" }
});
var eQ = V`
  ${it}

  :host {
    --arrow-color: var(--sl-color-neutral-1000);
    --arrow-size: 6px;

    /*
     * These properties are computed to account for the arrow's dimensions after being rotated 45º. The constant
     * 0.7071 is derived from sin(45), which is the diagonal size of the arrow's container after rotating.
     */
    --arrow-size-diagonal: calc(var(--arrow-size) * 0.7071);
    --arrow-padding-offset: calc(var(--arrow-size-diagonal) - var(--arrow-size));

    display: contents;
  }

  .popup {
    position: absolute;
    isolation: isolate;
    max-width: var(--auto-size-available-width, none);
    max-height: var(--auto-size-available-height, none);
  }

  .popup--fixed {
    position: fixed;
  }

  .popup:not(.popup--active) {
    display: none;
  }

  .popup__arrow {
    position: absolute;
    width: calc(var(--arrow-size-diagonal) * 2);
    height: calc(var(--arrow-size-diagonal) * 2);
    rotate: 45deg;
    background: var(--arrow-color);
    z-index: -1;
  }
`;
function RA(e) {
  return e.split("-")[1];
}
function En(e) {
  return e === "y" ? "height" : "width";
}
function Qe(e) {
  return e.split("-")[0];
}
function UA(e) {
  return ["top", "bottom"].includes(Qe(e)) ? "x" : "y";
}
function rl(e, t, A) {
  let { reference: i, floating: s } = e;
  const o = i.x + i.width / 2 - s.width / 2, r = i.y + i.height / 2 - s.height / 2, n = UA(t), l = En(n), a = i[l] / 2 - s[l] / 2, c = n === "x";
  let g;
  switch (Qe(t)) {
    case "top":
      g = { x: o, y: i.y - s.height };
      break;
    case "bottom":
      g = { x: o, y: i.y + i.height };
      break;
    case "right":
      g = { x: i.x + i.width, y: r };
      break;
    case "left":
      g = { x: i.x - s.width, y: r };
      break;
    default:
      g = { x: i.x, y: i.y };
  }
  switch (RA(t)) {
    case "start":
      g[n] -= a * (A && c ? -1 : 1);
      break;
    case "end":
      g[n] += a * (A && c ? -1 : 1);
  }
  return g;
}
var AQ = async (e, t, A) => {
  const { placement: i = "bottom", strategy: s = "absolute", middleware: o = [], platform: r } = A, n = o.filter(Boolean), l = await (r.isRTL == null ? void 0 : r.isRTL(t));
  let a = await r.getElementRects({ reference: e, floating: t, strategy: s }), { x: c, y: g } = rl(a, i, l), h = i, u = {}, C = 0;
  for (let B = 0; B < n.length; B++) {
    const { name: E, fn: f } = n[B], { x: p, y: D, data: N, reset: M } = await f({ x: c, y: g, initialPlacement: i, placement: h, strategy: s, middlewareData: u, rects: a, platform: r, elements: { reference: e, floating: t } });
    c = p ?? c, g = D ?? g, u = Bt(Y({}, u), { [E]: Y(Y({}, u[E]), N) }), M && C <= 50 && (C++, typeof M == "object" && (M.placement && (h = M.placement), M.rects && (a = M.rects === !0 ? await r.getElementRects({ reference: e, floating: t, strategy: s }) : M.rects), { x: c, y: g } = rl(a, h, l)), B = -1);
  }
  return { x: c, y: g, placement: h, strategy: s, middlewareData: u };
};
function uc(e) {
  return typeof e != "number" ? function(t) {
    return Y({ top: 0, right: 0, bottom: 0, left: 0 }, t);
  }(e) : { top: e, right: e, bottom: e, left: e };
}
function Rr(e) {
  return Bt(Y({}, e), { top: e.y, left: e.x, right: e.x + e.width, bottom: e.y + e.height });
}
async function fn(e, t) {
  var A;
  t === void 0 && (t = {});
  const { x: i, y: s, platform: o, rects: r, elements: n, strategy: l } = e, { boundary: a = "clippingAncestors", rootBoundary: c = "viewport", elementContext: g = "floating", altBoundary: h = !1, padding: u = 0 } = t, C = uc(u), B = n[h ? g === "floating" ? "reference" : "floating" : g], E = Rr(await o.getClippingRect({ element: (A = await (o.isElement == null ? void 0 : o.isElement(B))) == null || A ? B : B.contextElement || await (o.getDocumentElement == null ? void 0 : o.getDocumentElement(n.floating)), boundary: a, rootBoundary: c, strategy: l })), f = g === "floating" ? Bt(Y({}, r.floating), { x: i, y: s }) : r.reference, p = await (o.getOffsetParent == null ? void 0 : o.getOffsetParent(n.floating)), D = await (o.isElement == null ? void 0 : o.isElement(p)) && await (o.getScale == null ? void 0 : o.getScale(p)) || { x: 1, y: 1 }, N = Rr(o.convertOffsetParentRelativeRectToViewportRelativeRect ? await o.convertOffsetParentRelativeRectToViewportRelativeRect({ rect: f, offsetParent: p, strategy: l }) : f);
  return { top: (E.top - N.top + C.top) / D.y, bottom: (N.bottom - E.bottom + C.bottom) / D.y, left: (E.left - N.left + C.left) / D.x, right: (N.right - E.right + C.right) / D.x };
}
var Ur = Math.min, Le = Math.max;
function Gr(e, t, A) {
  return Le(e, Ur(t, A));
}
var iQ = (e) => ({ name: "arrow", options: e, async fn(t) {
  const { element: A, padding: i = 0 } = e || {}, { x: s, y: o, placement: r, rects: n, platform: l } = t;
  if (A == null)
    return {};
  const a = uc(i), c = { x: s, y: o }, g = UA(r), h = En(g), u = await l.getDimensions(A), C = g === "y" ? "top" : "left", B = g === "y" ? "bottom" : "right", E = n.reference[h] + n.reference[g] - c[g] - n.floating[h], f = c[g] - n.reference[g], p = await (l.getOffsetParent == null ? void 0 : l.getOffsetParent(A));
  let D = p ? g === "y" ? p.clientHeight || 0 : p.clientWidth || 0 : 0;
  D === 0 && (D = n.floating[h]);
  const N = E / 2 - f / 2, M = a[C], Mt = D - u[h] - a[B], ot = D / 2 - u[h] / 2 + N, bt = Gr(M, ot, Mt), ke = RA(r) != null && ot != bt && n.reference[h] / 2 - (ot < M ? a[C] : a[B]) - u[h] / 2 < 0;
  return { [g]: c[g] - (ke ? ot < M ? M - ot : Mt - ot : 0), data: { [g]: bt, centerOffset: ot - bt } };
} }), sQ = ["top", "right", "bottom", "left"];
sQ.reduce((e, t) => e.concat(t, t + "-start", t + "-end"), []);
var oQ = { left: "right", right: "left", bottom: "top", top: "bottom" };
function Rs(e) {
  return e.replace(/left|right|bottom|top/g, (t) => oQ[t]);
}
function rQ(e, t, A) {
  A === void 0 && (A = !1);
  const i = RA(e), s = UA(e), o = En(s);
  let r = s === "x" ? i === (A ? "end" : "start") ? "right" : "left" : i === "start" ? "bottom" : "top";
  return t.reference[o] > t.floating[o] && (r = Rs(r)), { main: r, cross: Rs(r) };
}
var nQ = { start: "end", end: "start" };
function Vo(e) {
  return e.replace(/start|end/g, (t) => nQ[t]);
}
var aQ = function(e) {
  return e === void 0 && (e = {}), { name: "flip", options: e, async fn(t) {
    var A;
    const { placement: i, middlewareData: s, rects: o, initialPlacement: r, platform: n, elements: l } = t, a = e, { mainAxis: c = !0, crossAxis: g = !0, fallbackPlacements: h, fallbackStrategy: u = "bestFit", fallbackAxisSideDirection: C = "none", flipAlignment: B = !0 } = a, E = Qn(a, ["mainAxis", "crossAxis", "fallbackPlacements", "fallbackStrategy", "fallbackAxisSideDirection", "flipAlignment"]), f = Qe(i), p = Qe(r) === r, D = await (n.isRTL == null ? void 0 : n.isRTL(l.floating)), N = h || (p || !B ? [Rs(r)] : function(Dt) {
      const te = Rs(Dt);
      return [Vo(Dt), te, Vo(te)];
    }(r));
    h || C === "none" || N.push(...function(Dt, te, Se, ce) {
      const ee = RA(Dt);
      let kt = function(OA, wo, dh) {
        const On = ["left", "right"], $n = ["right", "left"], Ch = ["top", "bottom"], Bh = ["bottom", "top"];
        switch (OA) {
          case "top":
          case "bottom":
            return dh ? wo ? $n : On : wo ? On : $n;
          case "left":
          case "right":
            return wo ? Ch : Bh;
          default:
            return [];
        }
      }(Qe(Dt), Se === "start", ce);
      return ee && (kt = kt.map((OA) => OA + "-" + ee), te && (kt = kt.concat(kt.map(Vo)))), kt;
    }(r, B, C, D));
    const M = [r, ...N], Mt = await fn(t, E), ot = [];
    let bt = ((A = s.flip) == null ? void 0 : A.overflows) || [];
    if (c && ot.push(Mt[f]), g) {
      const { main: Dt, cross: te } = rQ(i, o, D);
      ot.push(Mt[Dt], Mt[te]);
    }
    if (bt = [...bt, { placement: i, overflows: ot }], !ot.every((Dt) => Dt <= 0)) {
      var ke, _n;
      const Dt = (((ke = s.flip) == null ? void 0 : ke.index) || 0) + 1, te = M[Dt];
      if (te)
        return { data: { index: Dt, overflows: bt }, reset: { placement: te } };
      let Se = (_n = bt.filter((ce) => ce.overflows[0] <= 0).sort((ce, ee) => ce.overflows[1] - ee.overflows[1])[0]) == null ? void 0 : _n.placement;
      if (!Se)
        switch (u) {
          case "bestFit": {
            var Tn;
            const ce = (Tn = bt.map((ee) => [ee.placement, ee.overflows.filter((kt) => kt > 0).reduce((kt, OA) => kt + OA, 0)]).sort((ee, kt) => ee[1] - kt[1])[0]) == null ? void 0 : Tn[0];
            ce && (Se = ce);
            break;
          }
          case "initialPlacement":
            Se = r;
        }
      if (i !== Se)
        return { reset: { placement: Se } };
    }
    return {};
  } };
}, lQ = function(e) {
  return e === void 0 && (e = 0), { name: "offset", options: e, async fn(t) {
    const { x: A, y: i } = t, s = await async function(o, r) {
      const { placement: n, platform: l, elements: a } = o, c = await (l.isRTL == null ? void 0 : l.isRTL(a.floating)), g = Qe(n), h = RA(n), u = UA(n) === "x", C = ["left", "top"].includes(g) ? -1 : 1, B = c && u ? -1 : 1, E = typeof r == "function" ? r(o) : r;
      let { mainAxis: f, crossAxis: p, alignmentAxis: D } = typeof E == "number" ? { mainAxis: E, crossAxis: 0, alignmentAxis: null } : Y({ mainAxis: 0, crossAxis: 0, alignmentAxis: null }, E);
      return h && typeof D == "number" && (p = h === "end" ? -1 * D : D), u ? { x: p * B, y: f * C } : { x: f * C, y: p * B };
    }(t, e);
    return { x: A + s.x, y: i + s.y, data: s };
  } };
};
function gQ(e) {
  return e === "x" ? "y" : "x";
}
var cQ = function(e) {
  return e === void 0 && (e = {}), { name: "shift", options: e, async fn(t) {
    const { x: A, y: i, placement: s } = t, o = e, { mainAxis: r = !0, crossAxis: n = !1, limiter: l = { fn: (f) => {
      let { x: p, y: D } = f;
      return { x: p, y: D };
    } } } = o, a = Qn(o, ["mainAxis", "crossAxis", "limiter"]), c = { x: A, y: i }, g = await fn(t, a), h = UA(Qe(s)), u = gQ(h);
    let C = c[h], B = c[u];
    if (r) {
      const f = h === "y" ? "bottom" : "right";
      C = Gr(C + g[h === "y" ? "top" : "left"], C, C - g[f]);
    }
    if (n) {
      const f = u === "y" ? "bottom" : "right";
      B = Gr(B + g[u === "y" ? "top" : "left"], B, B - g[f]);
    }
    const E = l.fn(Bt(Y({}, t), { [h]: C, [u]: B }));
    return Bt(Y({}, E), { data: { x: E.x - A, y: E.y - i } });
  } };
}, nl = function(e) {
  return e === void 0 && (e = {}), { name: "size", options: e, async fn(t) {
    const { placement: A, rects: i, platform: s, elements: o } = t, r = e, { apply: n = () => {
    } } = r, l = Qn(r, ["apply"]), a = await fn(t, l), c = Qe(A), g = RA(A), h = UA(A) === "x", { width: u, height: C } = i.floating;
    let B, E;
    c === "top" || c === "bottom" ? (B = c, E = g === (await (s.isRTL == null ? void 0 : s.isRTL(o.floating)) ? "start" : "end") ? "left" : "right") : (E = c, B = g === "end" ? "top" : "bottom");
    const f = C - a[B], p = u - a[E];
    let D = f, N = p;
    if (h ? N = Ur(u - a.right - a.left, p) : D = Ur(C - a.bottom - a.top, f), !t.middlewareData.shift && !g) {
      const Mt = Le(a.left, 0), ot = Le(a.right, 0), bt = Le(a.top, 0), ke = Le(a.bottom, 0);
      h ? N = u - 2 * (Mt !== 0 || ot !== 0 ? Mt + ot : Le(a.left, a.right)) : D = C - 2 * (bt !== 0 || ke !== 0 ? bt + ke : Le(a.top, a.bottom));
    }
    await n(Bt(Y({}, t), { availableWidth: N, availableHeight: D }));
    const M = await s.getDimensions(o.floating);
    return u !== M.width || C !== M.height ? { reset: { rects: !0 } } : {};
  } };
};
function yt(e) {
  var t;
  return ((t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Kt(e) {
  return yt(e).getComputedStyle(e);
}
var al = Math.min, ci = Math.max, Us = Math.round;
function dc(e) {
  const t = Kt(e);
  let A = parseFloat(t.width), i = parseFloat(t.height);
  const s = e.offsetWidth, o = e.offsetHeight, r = Us(A) !== s || Us(i) !== o;
  return r && (A = s, i = o), { width: A, height: i, fallback: r };
}
function we(e) {
  return Bc(e) ? (e.nodeName || "").toLowerCase() : "";
}
var Zi;
function Cc() {
  if (Zi)
    return Zi;
  const e = navigator.userAgentData;
  return e && Array.isArray(e.brands) ? (Zi = e.brands.map((t) => t.brand + "/" + t.version).join(" "), Zi) : navigator.userAgent;
}
function jt(e) {
  return e instanceof yt(e).HTMLElement;
}
function Ht(e) {
  return e instanceof yt(e).Element;
}
function Bc(e) {
  return e instanceof yt(e).Node;
}
function ll(e) {
  return typeof ShadowRoot > "u" ? !1 : e instanceof yt(e).ShadowRoot || e instanceof ShadowRoot;
}
function io(e) {
  const { overflow: t, overflowX: A, overflowY: i, display: s } = Kt(e);
  return /auto|scroll|overlay|hidden|clip/.test(t + i + A) && !["inline", "contents"].includes(s);
}
function hQ(e) {
  return ["table", "td", "th"].includes(we(e));
}
function Mr(e) {
  const t = /firefox/i.test(Cc()), A = Kt(e), i = A.backdropFilter || A.WebkitBackdropFilter;
  return A.transform !== "none" || A.perspective !== "none" || !!i && i !== "none" || t && A.willChange === "filter" || t && !!A.filter && A.filter !== "none" || ["transform", "perspective"].some((s) => A.willChange.includes(s)) || ["paint", "layout", "strict", "content"].some((s) => {
    const o = A.contain;
    return o != null && o.includes(s);
  });
}
function Lr() {
  return /^((?!chrome|android).)*safari/i.test(Cc());
}
function pn(e) {
  return ["html", "body", "#document"].includes(we(e));
}
function Qc(e) {
  return Ht(e) ? e : e.contextElement;
}
var Ec = { x: 1, y: 1 };
function hA(e) {
  const t = Qc(e);
  if (!jt(t))
    return Ec;
  const A = t.getBoundingClientRect(), { width: i, height: s, fallback: o } = dc(t);
  let r = (o ? Us(A.width) : A.width) / i, n = (o ? Us(A.height) : A.height) / s;
  return r && Number.isFinite(r) || (r = 1), n && Number.isFinite(n) || (n = 1), { x: r, y: n };
}
function Te(e, t, A, i) {
  var s, o;
  t === void 0 && (t = !1), A === void 0 && (A = !1);
  const r = e.getBoundingClientRect(), n = Qc(e);
  let l = Ec;
  t && (i ? Ht(i) && (l = hA(i)) : l = hA(e));
  const a = n ? yt(n) : window, c = Lr() && A;
  let g = (r.left + (c && ((s = a.visualViewport) == null ? void 0 : s.offsetLeft) || 0)) / l.x, h = (r.top + (c && ((o = a.visualViewport) == null ? void 0 : o.offsetTop) || 0)) / l.y, u = r.width / l.x, C = r.height / l.y;
  if (n) {
    const B = yt(n), E = i && Ht(i) ? yt(i) : i;
    let f = B.frameElement;
    for (; f && i && E !== B; ) {
      const p = hA(f), D = f.getBoundingClientRect(), N = getComputedStyle(f);
      D.x += (f.clientLeft + parseFloat(N.paddingLeft)) * p.x, D.y += (f.clientTop + parseFloat(N.paddingTop)) * p.y, g *= p.x, h *= p.y, u *= p.x, C *= p.y, g += D.x, h += D.y, f = yt(f).frameElement;
    }
  }
  return { width: u, height: C, top: h, right: g + u, bottom: h + C, left: g, x: g, y: h };
}
function Ee(e) {
  return ((Bc(e) ? e.ownerDocument : e.document) || window.document).documentElement;
}
function so(e) {
  return Ht(e) ? { scrollLeft: e.scrollLeft, scrollTop: e.scrollTop } : { scrollLeft: e.pageXOffset, scrollTop: e.pageYOffset };
}
function fc(e) {
  return Te(Ee(e)).left + so(e).scrollLeft;
}
function vi(e) {
  if (we(e) === "html")
    return e;
  const t = e.assignedSlot || e.parentNode || ll(e) && e.host || Ee(e);
  return ll(t) ? t.host : t;
}
function pc(e) {
  const t = vi(e);
  return pn(t) ? t.ownerDocument.body : jt(t) && io(t) ? t : pc(t);
}
function hi(e, t) {
  var A;
  t === void 0 && (t = []);
  const i = pc(e), s = i === ((A = e.ownerDocument) == null ? void 0 : A.body), o = yt(i);
  return s ? t.concat(o, o.visualViewport || [], io(i) ? i : []) : t.concat(i, hi(i));
}
function gl(e, t, A) {
  let i;
  if (t === "viewport")
    i = function(r, n) {
      const l = yt(r), a = Ee(r), c = l.visualViewport;
      let g = a.clientWidth, h = a.clientHeight, u = 0, C = 0;
      if (c) {
        g = c.width, h = c.height;
        const B = Lr();
        (!B || B && n === "fixed") && (u = c.offsetLeft, C = c.offsetTop);
      }
      return { width: g, height: h, x: u, y: C };
    }(e, A);
  else if (t === "document")
    i = function(r) {
      const n = Ee(r), l = so(r), a = r.ownerDocument.body, c = ci(n.scrollWidth, n.clientWidth, a.scrollWidth, a.clientWidth), g = ci(n.scrollHeight, n.clientHeight, a.scrollHeight, a.clientHeight);
      let h = -l.scrollLeft + fc(r);
      const u = -l.scrollTop;
      return Kt(a).direction === "rtl" && (h += ci(n.clientWidth, a.clientWidth) - c), { width: c, height: g, x: h, y: u };
    }(Ee(e));
  else if (Ht(t))
    i = function(r, n) {
      const l = Te(r, !0, n === "fixed"), a = l.top + r.clientTop, c = l.left + r.clientLeft, g = jt(r) ? hA(r) : { x: 1, y: 1 };
      return { width: r.clientWidth * g.x, height: r.clientHeight * g.y, x: c * g.x, y: a * g.y };
    }(t, A);
  else {
    const r = Y({}, t);
    if (Lr()) {
      var s, o;
      const n = yt(e);
      r.x -= ((s = n.visualViewport) == null ? void 0 : s.offsetLeft) || 0, r.y -= ((o = n.visualViewport) == null ? void 0 : o.offsetTop) || 0;
    }
    i = r;
  }
  return Rr(i);
}
function cl(e, t) {
  return jt(e) && Kt(e).position !== "fixed" ? t ? t(e) : e.offsetParent : null;
}
function hl(e, t) {
  const A = yt(e);
  let i = cl(e, t);
  for (; i && hQ(i) && Kt(i).position === "static"; )
    i = cl(i, t);
  return i && (we(i) === "html" || we(i) === "body" && Kt(i).position === "static" && !Mr(i)) ? A : i || function(s) {
    let o = vi(s);
    for (; jt(o) && !pn(o); ) {
      if (Mr(o))
        return o;
      o = vi(o);
    }
    return null;
  }(e) || A;
}
function IQ(e, t, A) {
  const i = jt(t), s = Ee(t), o = Te(e, !0, A === "fixed", t);
  let r = { scrollLeft: 0, scrollTop: 0 };
  const n = { x: 0, y: 0 };
  if (i || !i && A !== "fixed")
    if ((we(t) !== "body" || io(s)) && (r = so(t)), jt(t)) {
      const l = Te(t, !0);
      n.x = l.x + t.clientLeft, n.y = l.y + t.clientTop;
    } else
      s && (n.x = fc(s));
  return { x: o.left + r.scrollLeft - n.x, y: o.top + r.scrollTop - n.y, width: o.width, height: o.height };
}
var Is = { getClippingRect: function(e) {
  let { element: t, boundary: A, rootBoundary: i, strategy: s } = e;
  const o = A === "clippingAncestors" ? function(a, c) {
    const g = c.get(a);
    if (g)
      return g;
    let h = hi(a).filter((E) => Ht(E) && we(E) !== "body"), u = null;
    const C = Kt(a).position === "fixed";
    let B = C ? vi(a) : a;
    for (; Ht(B) && !pn(B); ) {
      const E = Kt(B), f = Mr(B);
      E.position === "fixed" ? u = null : (C ? f || u : f || E.position !== "static" || !u || !["absolute", "fixed"].includes(u.position)) ? u = E : h = h.filter((p) => p !== B), B = vi(B);
    }
    return c.set(a, h), h;
  }(t, this._c) : [].concat(A), r = [...o, i], n = r[0], l = r.reduce((a, c) => {
    const g = gl(t, c, s);
    return a.top = ci(g.top, a.top), a.right = al(g.right, a.right), a.bottom = al(g.bottom, a.bottom), a.left = ci(g.left, a.left), a;
  }, gl(t, n, s));
  return { width: l.right - l.left, height: l.bottom - l.top, x: l.left, y: l.top };
}, convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
  let { rect: t, offsetParent: A, strategy: i } = e;
  const s = jt(A), o = Ee(A);
  if (A === o)
    return t;
  let r = { scrollLeft: 0, scrollTop: 0 }, n = { x: 1, y: 1 };
  const l = { x: 0, y: 0 };
  if ((s || !s && i !== "fixed") && ((we(A) !== "body" || io(o)) && (r = so(A)), jt(A))) {
    const a = Te(A);
    n = hA(A), l.x = a.x + A.clientLeft, l.y = a.y + A.clientTop;
  }
  return { width: t.width * n.x, height: t.height * n.y, x: t.x * n.x - r.scrollLeft * n.x + l.x, y: t.y * n.y - r.scrollTop * n.y + l.y };
}, isElement: Ht, getDimensions: function(e) {
  return jt(e) ? dc(e) : e.getBoundingClientRect();
}, getOffsetParent: hl, getDocumentElement: Ee, getScale: hA, async getElementRects(e) {
  let { reference: t, floating: A, strategy: i } = e;
  const s = this.getOffsetParent || hl, o = this.getDimensions;
  return { reference: IQ(t, await s(A), i), floating: Y({ x: 0, y: 0 }, await o(A)) };
}, getClientRects: (e) => Array.from(e.getClientRects()), isRTL: (e) => Kt(e).direction === "rtl" };
function uQ(e, t, A, i) {
  i === void 0 && (i = {});
  const { ancestorScroll: s = !0, ancestorResize: o = !0, elementResize: r = !0, animationFrame: n = !1 } = i, l = s && !n, a = l || o ? [...Ht(e) ? hi(e) : e.contextElement ? hi(e.contextElement) : [], ...hi(t)] : [];
  a.forEach((u) => {
    l && u.addEventListener("scroll", A, { passive: !0 }), o && u.addEventListener("resize", A);
  });
  let c, g = null;
  if (r) {
    let u = !0;
    g = new ResizeObserver(() => {
      u || A(), u = !1;
    }), Ht(e) && !n && g.observe(e), Ht(e) || !e.contextElement || n || g.observe(e.contextElement), g.observe(t);
  }
  let h = n ? Te(e) : null;
  return n && function u() {
    const C = Te(e);
    !h || C.x === h.x && C.y === h.y && C.width === h.width && C.height === h.height || A(), h = C, c = requestAnimationFrame(u);
  }(), A(), () => {
    var u;
    a.forEach((C) => {
      l && C.removeEventListener("scroll", A), o && C.removeEventListener("resize", A);
    }), (u = g) == null || u.disconnect(), g = null, n && cancelAnimationFrame(c);
  };
}
var dQ = (e, t, A) => {
  const i = /* @__PURE__ */ new Map(), s = Y({ platform: Is }, A), o = Bt(Y({}, s.platform), { _c: i });
  return AQ(e, t, Bt(Y({}, s), { platform: o }));
};
function CQ(e) {
  return BQ(e);
}
function zo(e) {
  return e.assignedSlot ? e.assignedSlot : e.parentNode instanceof ShadowRoot ? e.parentNode.host : e.parentNode;
}
function BQ(e) {
  for (let t = e; t; t = zo(t))
    if (t instanceof Element && getComputedStyle(t).display === "none")
      return null;
  for (let t = zo(e); t; t = zo(t)) {
    if (!(t instanceof Element))
      continue;
    const A = getComputedStyle(t);
    if (A.display !== "contents" && (A.position !== "static" || A.filter !== "none" || t.tagName === "BODY"))
      return t;
  }
  return null;
}
var L = class extends K {
  constructor() {
    super(...arguments), this.active = !1, this.placement = "top", this.strategy = "absolute", this.distance = 0, this.skidding = 0, this.arrow = !1, this.arrowPlacement = "anchor", this.arrowPadding = 10, this.flip = !1, this.flipFallbackPlacements = "", this.flipFallbackStrategy = "best-fit", this.flipPadding = 0, this.shift = !1, this.shiftPadding = 0, this.autoSizePadding = 0;
  }
  async connectedCallback() {
    super.connectedCallback(), await this.updateComplete, this.start();
  }
  disconnectedCallback() {
    this.stop();
  }
  async updated(e) {
    super.updated(e), e.has("active") && (this.active ? this.start() : this.stop()), e.has("anchor") && this.handleAnchorChange(), this.active && (await this.updateComplete, this.reposition());
  }
  async handleAnchorChange() {
    if (await this.stop(), this.anchor && typeof this.anchor == "string") {
      const e = this.getRootNode();
      this.anchorEl = e.getElementById(this.anchor);
    } else
      this.anchor instanceof Element ? this.anchorEl = this.anchor : this.anchorEl = this.querySelector('[slot="anchor"]');
    if (this.anchorEl instanceof HTMLSlotElement && (this.anchorEl = this.anchorEl.assignedElements({ flatten: !0 })[0]), !this.anchorEl)
      throw new Error(
        "Invalid anchor element: no anchor could be found using the anchor slot or the anchor attribute."
      );
    this.start();
  }
  start() {
    this.anchorEl && (this.cleanup = uQ(this.anchorEl, this.popup, () => {
      this.reposition();
    }));
  }
  async stop() {
    return new Promise((e) => {
      this.cleanup ? (this.cleanup(), this.cleanup = void 0, this.removeAttribute("data-current-placement"), this.style.removeProperty("--auto-size-available-width"), this.style.removeProperty("--auto-size-available-height"), requestAnimationFrame(() => e())) : e();
    });
  }
  /** Forces the popup to recalculate and reposition itself. */
  reposition() {
    if (!this.active || !this.anchorEl)
      return;
    const e = [
      // The offset middleware goes first
      lQ({ mainAxis: this.distance, crossAxis: this.skidding })
    ];
    this.sync ? e.push(
      nl({
        apply: ({ rects: A }) => {
          const i = this.sync === "width" || this.sync === "both", s = this.sync === "height" || this.sync === "both";
          this.popup.style.width = i ? `${A.reference.width}px` : "", this.popup.style.height = s ? `${A.reference.height}px` : "";
        }
      })
    ) : (this.popup.style.width = "", this.popup.style.height = ""), this.flip && e.push(
      aQ({
        boundary: this.flipBoundary,
        // @ts-expect-error - We're converting a string attribute to an array here
        fallbackPlacements: this.flipFallbackPlacements,
        fallbackStrategy: this.flipFallbackStrategy === "best-fit" ? "bestFit" : "initialPlacement",
        padding: this.flipPadding
      })
    ), this.shift && e.push(
      cQ({
        boundary: this.shiftBoundary,
        padding: this.shiftPadding
      })
    ), this.autoSize ? e.push(
      nl({
        boundary: this.autoSizeBoundary,
        padding: this.autoSizePadding,
        apply: ({ availableWidth: A, availableHeight: i }) => {
          this.autoSize === "vertical" || this.autoSize === "both" ? this.style.setProperty("--auto-size-available-height", `${i}px`) : this.style.removeProperty("--auto-size-available-height"), this.autoSize === "horizontal" || this.autoSize === "both" ? this.style.setProperty("--auto-size-available-width", `${A}px`) : this.style.removeProperty("--auto-size-available-width");
        }
      })
    ) : (this.style.removeProperty("--auto-size-available-width"), this.style.removeProperty("--auto-size-available-height")), this.arrow && e.push(
      iQ({
        element: this.arrowEl,
        padding: this.arrowPadding
      })
    );
    const t = this.strategy === "absolute" ? (A) => Is.getOffsetParent(A, CQ) : Is.getOffsetParent;
    dQ(this.anchorEl, this.popup, {
      placement: this.placement,
      middleware: e,
      strategy: this.strategy,
      platform: Bt(Y({}, Is), {
        getOffsetParent: t
      })
    }).then(({ x: A, y: i, middlewareData: s, placement: o }) => {
      const r = getComputedStyle(this).direction === "rtl", n = { top: "bottom", right: "left", bottom: "top", left: "right" }[o.split("-")[0]];
      if (this.setAttribute("data-current-placement", o), Object.assign(this.popup.style, {
        left: `${A}px`,
        top: `${i}px`
      }), this.arrow) {
        const l = s.arrow.x, a = s.arrow.y;
        let c = "", g = "", h = "", u = "";
        if (this.arrowPlacement === "start") {
          const C = typeof l == "number" ? `calc(${this.arrowPadding}px - var(--arrow-padding-offset))` : "";
          c = typeof a == "number" ? `calc(${this.arrowPadding}px - var(--arrow-padding-offset))` : "", g = r ? C : "", u = r ? "" : C;
        } else if (this.arrowPlacement === "end") {
          const C = typeof l == "number" ? `calc(${this.arrowPadding}px - var(--arrow-padding-offset))` : "";
          g = r ? "" : C, u = r ? C : "", h = typeof a == "number" ? `calc(${this.arrowPadding}px - var(--arrow-padding-offset))` : "";
        } else
          this.arrowPlacement === "center" ? (u = typeof l == "number" ? "calc(50% - var(--arrow-size-diagonal))" : "", c = typeof a == "number" ? "calc(50% - var(--arrow-size-diagonal))" : "") : (u = typeof l == "number" ? `${l}px` : "", c = typeof a == "number" ? `${a}px` : "");
        Object.assign(this.arrowEl.style, {
          top: c,
          right: g,
          bottom: h,
          left: u,
          [n]: "calc(var(--arrow-size-diagonal) * -1)"
        });
      }
    }), this.emit("sl-reposition");
  }
  render() {
    return _`
      <slot name="anchor" @slotchange=${this.handleAnchorChange}></slot>

      <div
        part="popup"
        class=${Qt({
      popup: !0,
      "popup--active": this.active,
      "popup--fixed": this.strategy === "fixed",
      "popup--has-arrow": this.arrow
    })}
      >
        <slot></slot>
        ${this.arrow ? _`<div part="arrow" class="popup__arrow" role="presentation"></div>` : ""}
      </div>
    `;
  }
};
L.styles = eQ;
I([
  X(".popup")
], L.prototype, "popup", 2);
I([
  X(".popup__arrow")
], L.prototype, "arrowEl", 2);
I([
  d()
], L.prototype, "anchor", 2);
I([
  d({ type: Boolean, reflect: !0 })
], L.prototype, "active", 2);
I([
  d({ reflect: !0 })
], L.prototype, "placement", 2);
I([
  d({ reflect: !0 })
], L.prototype, "strategy", 2);
I([
  d({ type: Number })
], L.prototype, "distance", 2);
I([
  d({ type: Number })
], L.prototype, "skidding", 2);
I([
  d({ type: Boolean })
], L.prototype, "arrow", 2);
I([
  d({ attribute: "arrow-placement" })
], L.prototype, "arrowPlacement", 2);
I([
  d({ attribute: "arrow-padding", type: Number })
], L.prototype, "arrowPadding", 2);
I([
  d({ type: Boolean })
], L.prototype, "flip", 2);
I([
  d({
    attribute: "flip-fallback-placements",
    converter: {
      fromAttribute: (e) => e.split(" ").map((t) => t.trim()).filter((t) => t !== ""),
      toAttribute: (e) => e.join(" ")
    }
  })
], L.prototype, "flipFallbackPlacements", 2);
I([
  d({ attribute: "flip-fallback-strategy" })
], L.prototype, "flipFallbackStrategy", 2);
I([
  d({ type: Object })
], L.prototype, "flipBoundary", 2);
I([
  d({ attribute: "flip-padding", type: Number })
], L.prototype, "flipPadding", 2);
I([
  d({ type: Boolean })
], L.prototype, "shift", 2);
I([
  d({ type: Object })
], L.prototype, "shiftBoundary", 2);
I([
  d({ attribute: "shift-padding", type: Number })
], L.prototype, "shiftPadding", 2);
I([
  d({ attribute: "auto-size" })
], L.prototype, "autoSize", 2);
I([
  d()
], L.prototype, "sync", 2);
I([
  d({ type: Object })
], L.prototype, "autoSizeBoundary", 2);
I([
  d({ attribute: "auto-size-padding", type: Number })
], L.prototype, "autoSizePadding", 2);
L = I([
  st("sl-popup")
], L);
var Jr = "";
function Il(e) {
  Jr = e;
}
function QQ(e = "") {
  if (!Jr) {
    const t = [...document.getElementsByTagName("script")], A = t.find((i) => i.hasAttribute("data-shoelace"));
    if (A)
      Il(A.getAttribute("data-shoelace"));
    else {
      const i = t.find((o) => /shoelace(\.min)?\.js($|\?)/.test(o.src) || /shoelace-autoloader(\.min)?\.js($|\?)/.test(o.src));
      let s = "";
      i && (s = i.getAttribute("src")), Il(s.split("/").slice(0, -1).join("/"));
    }
  }
  return Jr.replace(/\/$/, "") + (e ? `/${e.replace(/^\//, "")}` : "");
}
var EQ = {
  name: "default",
  resolver: (e) => QQ(`assets/icons/${e}.svg`)
}, fQ = EQ, ul = {
  caret: `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="6 9 12 15 18 9"></polyline>
    </svg>
  `,
  check: `
    <svg part="checked-icon" class="checkbox__icon" viewBox="0 0 16 16">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">
        <g stroke="currentColor" stroke-width="2">
          <g transform="translate(3.428571, 3.428571)">
            <path d="M0,5.71428571 L3.42857143,9.14285714"></path>
            <path d="M9.14285714,0 L3.42857143,9.14285714"></path>
          </g>
        </g>
      </g>
    </svg>
  `,
  "chevron-down": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-down" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
    </svg>
  `,
  "chevron-left": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-left" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
    </svg>
  `,
  "chevron-right": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chevron-right" viewBox="0 0 16 16">
      <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
    </svg>
  `,
  eye: `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
      <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
      <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
    </svg>
  `,
  "eye-slash": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-slash" viewBox="0 0 16 16">
      <path d="M13.359 11.238C15.06 9.72 16 8 16 8s-3-5.5-8-5.5a7.028 7.028 0 0 0-2.79.588l.77.771A5.944 5.944 0 0 1 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.134 13.134 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755-.165.165-.337.328-.517.486l.708.709z"/>
      <path d="M11.297 9.176a3.5 3.5 0 0 0-4.474-4.474l.823.823a2.5 2.5 0 0 1 2.829 2.829l.822.822zm-2.943 1.299.822.822a3.5 3.5 0 0 1-4.474-4.474l.823.823a2.5 2.5 0 0 0 2.829 2.829z"/>
      <path d="M3.35 5.47c-.18.16-.353.322-.518.487A13.134 13.134 0 0 0 1.172 8l.195.288c.335.48.83 1.12 1.465 1.755C4.121 11.332 5.881 12.5 8 12.5c.716 0 1.39-.133 2.02-.36l.77.772A7.029 7.029 0 0 1 8 13.5C3 13.5 0 8 0 8s.939-1.721 2.641-3.238l.708.709zm10.296 8.884-12-12 .708-.708 12 12-.708.708z"/>
    </svg>
  `,
  eyedropper: `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eyedropper" viewBox="0 0 16 16">
      <path d="M13.354.646a1.207 1.207 0 0 0-1.708 0L8.5 3.793l-.646-.647a.5.5 0 1 0-.708.708L8.293 5l-7.147 7.146A.5.5 0 0 0 1 12.5v1.793l-.854.853a.5.5 0 1 0 .708.707L1.707 15H3.5a.5.5 0 0 0 .354-.146L11 7.707l1.146 1.147a.5.5 0 0 0 .708-.708l-.647-.646 3.147-3.146a1.207 1.207 0 0 0 0-1.708l-2-2zM2 12.707l7-7L10.293 7l-7 7H2v-1.293z"></path>
    </svg>
  `,
  "grip-vertical": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
      <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"></path>
    </svg>
  `,
  indeterminate: `
    <svg part="indeterminate-icon" class="checkbox__icon" viewBox="0 0 16 16">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round">
        <g stroke="currentColor" stroke-width="2">
          <g transform="translate(2.285714, 6.857143)">
            <path d="M10.2857143,1.14285714 L1.14285714,1.14285714"></path>
          </g>
        </g>
      </g>
    </svg>
  `,
  "person-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
      <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
    </svg>
  `,
  "play-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-play-fill" viewBox="0 0 16 16">
      <path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393z"></path>
    </svg>
  `,
  "pause-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pause-fill" viewBox="0 0 16 16">
      <path d="M5.5 3.5A1.5 1.5 0 0 1 7 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5zm5 0A1.5 1.5 0 0 1 12 5v6a1.5 1.5 0 0 1-3 0V5a1.5 1.5 0 0 1 1.5-1.5z"></path>
    </svg>
  `,
  radio: `
    <svg part="checked-icon" class="radio__icon" viewBox="0 0 16 16">
      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g fill="currentColor">
          <circle cx="8" cy="8" r="3.42857143"></circle>
        </g>
      </g>
    </svg>
  `,
  "star-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
      <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"/>
    </svg>
  `,
  "x-lg": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
      <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"/>
    </svg>
  `,
  "x-circle-fill": `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"></path>
    </svg>
  `
}, pQ = {
  name: "system",
  resolver: (e) => e in ul ? `data:image/svg+xml,${encodeURIComponent(ul[e])}` : ""
}, wQ = pQ, yQ = [fQ, wQ], Yr = [];
function vQ(e) {
  Yr.push(e);
}
function mQ(e) {
  Yr = Yr.filter((t) => t !== e);
}
function dl(e) {
  return yQ.find((t) => t.name === e);
}
var bQ = V`
  ${it}

  :host {
    display: inline-block;
    width: 1em;
    height: 1em;
    box-sizing: content-box !important;
  }

  svg {
    display: block;
    height: 100%;
    width: 100%;
  }
`, zA = Symbol(), Wi = Symbol(), Ko, jo = /* @__PURE__ */ new Map(), _t = class extends K {
  constructor() {
    super(...arguments), this.svg = null, this.label = "", this.library = "default";
  }
  /** Given a URL, this function returns the resulting SVG element or an appropriate error symbol. */
  static async resolveIcon(e) {
    var t;
    let A;
    try {
      if (A = await fetch(e, { mode: "cors" }), !A.ok)
        return A.status === 410 ? zA : Wi;
    } catch {
      return Wi;
    }
    try {
      const i = document.createElement("div");
      i.innerHTML = await A.text();
      const s = i.firstElementChild;
      if (((t = s?.tagName) == null ? void 0 : t.toLowerCase()) !== "svg")
        return zA;
      Ko || (Ko = new DOMParser());
      const r = Ko.parseFromString(s.outerHTML, "text/html").body.querySelector("svg");
      return r ? (r.part.add("svg"), document.adoptNode(r)) : zA;
    } catch {
      return zA;
    }
  }
  connectedCallback() {
    super.connectedCallback(), vQ(this);
  }
  firstUpdated() {
    this.setIcon();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), mQ(this);
  }
  getUrl() {
    const e = dl(this.library);
    return this.name && e ? e.resolver(this.name) : this.src;
  }
  handleLabelChange() {
    typeof this.label == "string" && this.label.length > 0 ? (this.setAttribute("role", "img"), this.setAttribute("aria-label", this.label), this.removeAttribute("aria-hidden")) : (this.removeAttribute("role"), this.removeAttribute("aria-label"), this.setAttribute("aria-hidden", "true"));
  }
  async setIcon() {
    var e;
    const t = dl(this.library), A = this.getUrl();
    if (!A) {
      this.svg = null;
      return;
    }
    let i = jo.get(A);
    i || (i = _t.resolveIcon(A), jo.set(A, i));
    const s = await i;
    if (s === Wi && jo.delete(A), A === this.getUrl())
      switch (s) {
        case Wi:
        case zA:
          this.svg = null, this.emit("sl-error");
          break;
        default:
          this.svg = s.cloneNode(!0), (e = t?.mutator) == null || e.call(t, this.svg), this.emit("sl-load");
      }
  }
  render() {
    return this.svg;
  }
};
_t.styles = bQ;
I([
  FA()
], _t.prototype, "svg", 2);
I([
  d({ reflect: !0 })
], _t.prototype, "name", 2);
I([
  d()
], _t.prototype, "src", 2);
I([
  d()
], _t.prototype, "label", 2);
I([
  d({ reflect: !0 })
], _t.prototype, "library", 2);
I([
  z("label")
], _t.prototype, "handleLabelChange", 1);
I([
  z(["name", "src", "library"])
], _t.prototype, "setIcon", 1);
_t = I([
  st("sl-icon")
], _t);
var Yi = globalThis && globalThis.__decorate || function(e, t, A, i) {
  var s = arguments.length, o = s < 3 ? t : i === null ? i = Object.getOwnPropertyDescriptor(t, A) : i, r;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function")
    o = Reflect.decorate(e, t, A, i);
  else
    for (var n = e.length - 1; n >= 0; n--)
      (r = e[n]) && (o = (s < 3 ? r(o) : s > 3 ? r(t, A, o) : r(t, A)) || o);
  return s > 3 && o && Object.defineProperty(t, A, o), o;
};
let Oe = class extends q {
  constructor() {
    super(...arguments), this.tooltip = !1;
  }
  get _iconSize() {
    return this.iconSize ? this.iconSize : this.tooltip !== !1 ? "32px" : "64px";
  }
  renderIcon() {
    return w`
      <sl-icon
        style="color: red; height: ${this._iconSize}; width: ${this._iconSize}; margin-bottom: 8px;"
        src="${fe(Zg)}"
      ></sl-icon>
    `;
  }
  renderFull() {
    return w` <div class="column center-content" style="flex: 1">
      ${this.renderIcon()}
      <div style="width: 500px; text-align: center" class="column">
        ${this.headline ? w` <span style="margin-bottom: 8px">${this.headline} </span>` : w``}
        <span class="placeholder">${this.error} </span>
      </div>
    </div>`;
  }
  renderTooltip() {
    return w`
      <sl-tooltip hoist .content=${this.headline ? this.headline : this.error}>
        ${this.renderIcon()}</sl-tooltip
      >
    `;
  }
  render() {
    return this.tooltip !== !1 ? this.renderTooltip() : this.renderFull();
  }
};
Oe.styles = [
  Ut,
  ae`
      :host {
        display: flex;
        flex: 1;
      }
    `
];
Yi([
  W({ attribute: "tooltip" })
], Oe.prototype, "tooltip", void 0);
Yi([
  W()
], Oe.prototype, "headline", void 0);
Yi([
  W()
], Oe.prototype, "error", void 0);
Yi([
  W({ attribute: "icon-size" })
], Oe.prototype, "iconSize", void 0);
Oe = Yi([
  It("display-error")
], Oe);
var DQ = V`
  ${it}

  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.01em, 2.75em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.01em, 2.75em;
    }
  }
`, Hr = class extends K {
  constructor() {
    super(...arguments), this.localize = new be(this);
  }
  render() {
    return _`
      <svg part="base" class="spinner" role="progressbar" aria-valuetext=${this.localize.term("loading")}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `;
  }
};
Hr.styles = DQ;
Hr = I([
  st("sl-spinner")
], Hr);
var KA = /* @__PURE__ */ new WeakMap(), jA = /* @__PURE__ */ new WeakMap(), Zo = /* @__PURE__ */ new WeakSet(), Xi = /* @__PURE__ */ new WeakMap(), wn = class {
  constructor(e, t) {
    (this.host = e).addController(this), this.options = Y({
      form: (A) => {
        if (A.hasAttribute("form") && A.getAttribute("form") !== "") {
          const i = A.getRootNode(), s = A.getAttribute("form");
          if (s)
            return i.getElementById(s);
        }
        return A.closest("form");
      },
      name: (A) => A.name,
      value: (A) => A.value,
      defaultValue: (A) => A.defaultValue,
      disabled: (A) => {
        var i;
        return (i = A.disabled) != null ? i : !1;
      },
      reportValidity: (A) => typeof A.reportValidity == "function" ? A.reportValidity() : !0,
      setValue: (A, i) => A.value = i,
      assumeInteractionOn: ["sl-input"]
    }, t), this.handleFormData = this.handleFormData.bind(this), this.handleFormSubmit = this.handleFormSubmit.bind(this), this.handleFormReset = this.handleFormReset.bind(this), this.reportFormValidity = this.reportFormValidity.bind(this), this.handleInteraction = this.handleInteraction.bind(this);
  }
  hostConnected() {
    const e = this.options.form(this.host);
    e && this.attachForm(e), Xi.set(this.host, []), this.options.assumeInteractionOn.forEach((t) => {
      this.host.addEventListener(t, this.handleInteraction);
    });
  }
  hostDisconnected() {
    this.detachForm(), Xi.delete(this.host), this.options.assumeInteractionOn.forEach((e) => {
      this.host.removeEventListener(e, this.handleInteraction);
    });
  }
  hostUpdated() {
    const e = this.options.form(this.host);
    e || this.detachForm(), e && this.form !== e && (this.detachForm(), this.attachForm(e)), this.host.hasUpdated && this.setValidity(this.host.validity.valid);
  }
  attachForm(e) {
    e ? (this.form = e, KA.has(this.form) ? KA.get(this.form).add(this.host) : KA.set(this.form, /* @__PURE__ */ new Set([this.host])), this.form.addEventListener("formdata", this.handleFormData), this.form.addEventListener("submit", this.handleFormSubmit), this.form.addEventListener("reset", this.handleFormReset), jA.has(this.form) || (jA.set(this.form, this.form.reportValidity), this.form.reportValidity = () => this.reportFormValidity())) : this.form = void 0;
  }
  detachForm() {
    var e;
    this.form && ((e = KA.get(this.form)) == null || e.delete(this.host), this.form.removeEventListener("formdata", this.handleFormData), this.form.removeEventListener("submit", this.handleFormSubmit), this.form.removeEventListener("reset", this.handleFormReset), jA.has(this.form) && (this.form.reportValidity = jA.get(this.form), jA.delete(this.form))), this.form = void 0;
  }
  handleFormData(e) {
    const t = this.options.disabled(this.host), A = this.options.name(this.host), i = this.options.value(this.host), s = this.host.tagName.toLowerCase() === "sl-button";
    !t && !s && typeof A == "string" && A.length > 0 && typeof i < "u" && (Array.isArray(i) ? i.forEach((o) => {
      e.formData.append(A, o.toString());
    }) : e.formData.append(A, i.toString()));
  }
  handleFormSubmit(e) {
    var t;
    const A = this.options.disabled(this.host), i = this.options.reportValidity;
    this.form && !this.form.noValidate && ((t = KA.get(this.form)) == null || t.forEach((s) => {
      this.setUserInteracted(s, !0);
    })), this.form && !this.form.noValidate && !A && !i(this.host) && (e.preventDefault(), e.stopImmediatePropagation());
  }
  handleFormReset() {
    this.options.setValue(this.host, this.options.defaultValue(this.host)), this.setUserInteracted(this.host, !1), Xi.set(this.host, []);
  }
  handleInteraction(e) {
    const t = Xi.get(this.host);
    t.includes(e.type) || t.push(e.type), t.length === this.options.assumeInteractionOn.length && this.setUserInteracted(this.host, !0);
  }
  reportFormValidity() {
    if (this.form && !this.form.noValidate) {
      const e = this.form.querySelectorAll("*");
      for (const t of e)
        if (typeof t.reportValidity == "function" && !t.reportValidity())
          return !1;
    }
    return !0;
  }
  setUserInteracted(e, t) {
    t ? Zo.add(e) : Zo.delete(e), e.requestUpdate();
  }
  doAction(e, t) {
    if (this.form) {
      const A = document.createElement("button");
      A.type = e, A.style.position = "absolute", A.style.width = "0", A.style.height = "0", A.style.clipPath = "inset(50%)", A.style.overflow = "hidden", A.style.whiteSpace = "nowrap", t && (A.name = t.name, A.value = t.value, ["formaction", "formenctype", "formmethod", "formnovalidate", "formtarget"].forEach((i) => {
        t.hasAttribute(i) && A.setAttribute(i, t.getAttribute(i));
      })), this.form.append(A), A.click(), A.remove();
    }
  }
  /** Returns the associated `<form>` element, if one exists. */
  getForm() {
    var e;
    return (e = this.form) != null ? e : null;
  }
  /** Resets the form, restoring all the control to their default value */
  reset(e) {
    this.doAction("reset", e);
  }
  /** Submits the form, triggering validation and form data injection. */
  submit(e) {
    this.doAction("submit", e);
  }
  /**
   * Synchronously sets the form control's validity. Call this when you know the future validity but need to update
   * the host element immediately, i.e. before Lit updates the component in the next update.
   */
  setValidity(e) {
    const t = this.host, A = !!Zo.has(t), i = !!t.required;
    t.toggleAttribute("data-required", i), t.toggleAttribute("data-optional", !i), t.toggleAttribute("data-invalid", !e), t.toggleAttribute("data-valid", e), t.toggleAttribute("data-user-invalid", !e && A), t.toggleAttribute("data-user-valid", e && A);
  }
  /**
   * Updates the form control's validity based on the current value of `host.validity.valid`. Call this when anything
   * that affects constraint validation changes so the component receives the correct validity states.
   */
  updateValidity() {
    const e = this.host;
    this.setValidity(e.validity.valid);
  }
  /**
   * Dispatches a non-bubbling, cancelable custom event of type `sl-invalid`.
   * If the `sl-invalid` event will be cancelled then the original `invalid`
   * event (which may have been passed as argument) will also be cancelled.
   * If no original `invalid` event has been passed then the `sl-invalid`
   * event will be cancelled before being dispatched.
   */
  emitInvalidEvent(e) {
    const t = new CustomEvent("sl-invalid", {
      bubbles: !1,
      composed: !1,
      cancelable: !0,
      detail: {}
    });
    e || t.preventDefault(), this.host.dispatchEvent(t) || e?.preventDefault();
  }
}, yn = Object.freeze({
  badInput: !1,
  customError: !1,
  patternMismatch: !1,
  rangeOverflow: !1,
  rangeUnderflow: !1,
  stepMismatch: !1,
  tooLong: !1,
  tooShort: !1,
  typeMismatch: !1,
  valid: !0,
  valueMissing: !1
});
Object.freeze(Bt(Y({}, yn), {
  valid: !1,
  valueMissing: !0
}));
Object.freeze(Bt(Y({}, yn), {
  valid: !1,
  customError: !0
}));
var kQ = V`
  ${it}

  :host {
    display: inline-block;
    position: relative;
    width: auto;
    cursor: pointer;
  }

  .button {
    display: inline-flex;
    align-items: stretch;
    justify-content: center;
    width: 100%;
    border-style: solid;
    border-width: var(--sl-input-border-width);
    font-family: var(--sl-input-font-family);
    font-weight: var(--sl-font-weight-semibold);
    text-decoration: none;
    user-select: none;
    white-space: nowrap;
    vertical-align: middle;
    padding: 0;
    transition: var(--sl-transition-x-fast) background-color, var(--sl-transition-x-fast) color,
      var(--sl-transition-x-fast) border, var(--sl-transition-x-fast) box-shadow;
    cursor: inherit;
  }

  .button::-moz-focus-inner {
    border: 0;
  }

  .button:focus {
    outline: none;
  }

  .button:focus-visible {
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .button--disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* When disabled, prevent mouse events from bubbling up from children */
  .button--disabled * {
    pointer-events: none;
  }

  .button__prefix,
  .button__suffix {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    pointer-events: none;
  }

  .button__label {
    display: inline-block;
  }

  .button__label::slotted(sl-icon) {
    vertical-align: -2px;
  }

  /*
   * Standard buttons
   */

  /* Default */
  .button--standard.button--default {
    background-color: var(--sl-color-neutral-0);
    border-color: var(--sl-color-neutral-300);
    color: var(--sl-color-neutral-700);
  }

  .button--standard.button--default:hover:not(.button--disabled) {
    background-color: var(--sl-color-primary-50);
    border-color: var(--sl-color-primary-300);
    color: var(--sl-color-primary-700);
  }

  .button--standard.button--default:active:not(.button--disabled) {
    background-color: var(--sl-color-primary-100);
    border-color: var(--sl-color-primary-400);
    color: var(--sl-color-primary-700);
  }

  /* Primary */
  .button--standard.button--primary {
    background-color: var(--sl-color-primary-600);
    border-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--primary:hover:not(.button--disabled) {
    background-color: var(--sl-color-primary-500);
    border-color: var(--sl-color-primary-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--primary:active:not(.button--disabled) {
    background-color: var(--sl-color-primary-600);
    border-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  /* Success */
  .button--standard.button--success {
    background-color: var(--sl-color-success-600);
    border-color: var(--sl-color-success-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--success:hover:not(.button--disabled) {
    background-color: var(--sl-color-success-500);
    border-color: var(--sl-color-success-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--success:active:not(.button--disabled) {
    background-color: var(--sl-color-success-600);
    border-color: var(--sl-color-success-600);
    color: var(--sl-color-neutral-0);
  }

  /* Neutral */
  .button--standard.button--neutral {
    background-color: var(--sl-color-neutral-600);
    border-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--neutral:hover:not(.button--disabled) {
    background-color: var(--sl-color-neutral-500);
    border-color: var(--sl-color-neutral-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--neutral:active:not(.button--disabled) {
    background-color: var(--sl-color-neutral-600);
    border-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-0);
  }

  /* Warning */
  .button--standard.button--warning {
    background-color: var(--sl-color-warning-600);
    border-color: var(--sl-color-warning-600);
    color: var(--sl-color-neutral-0);
  }
  .button--standard.button--warning:hover:not(.button--disabled) {
    background-color: var(--sl-color-warning-500);
    border-color: var(--sl-color-warning-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--warning:active:not(.button--disabled) {
    background-color: var(--sl-color-warning-600);
    border-color: var(--sl-color-warning-600);
    color: var(--sl-color-neutral-0);
  }

  /* Danger */
  .button--standard.button--danger {
    background-color: var(--sl-color-danger-600);
    border-color: var(--sl-color-danger-600);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--danger:hover:not(.button--disabled) {
    background-color: var(--sl-color-danger-500);
    border-color: var(--sl-color-danger-500);
    color: var(--sl-color-neutral-0);
  }

  .button--standard.button--danger:active:not(.button--disabled) {
    background-color: var(--sl-color-danger-600);
    border-color: var(--sl-color-danger-600);
    color: var(--sl-color-neutral-0);
  }

  /*
   * Outline buttons
   */

  .button--outline {
    background: none;
    border: solid 1px;
  }

  /* Default */
  .button--outline.button--default {
    border-color: var(--sl-color-neutral-300);
    color: var(--sl-color-neutral-700);
  }

  .button--outline.button--default:hover:not(.button--disabled),
  .button--outline.button--default.button--checked:not(.button--disabled) {
    border-color: var(--sl-color-primary-600);
    background-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--default:active:not(.button--disabled) {
    border-color: var(--sl-color-primary-700);
    background-color: var(--sl-color-primary-700);
    color: var(--sl-color-neutral-0);
  }

  /* Primary */
  .button--outline.button--primary {
    border-color: var(--sl-color-primary-600);
    color: var(--sl-color-primary-600);
  }

  .button--outline.button--primary:hover:not(.button--disabled),
  .button--outline.button--primary.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--primary:active:not(.button--disabled) {
    border-color: var(--sl-color-primary-700);
    background-color: var(--sl-color-primary-700);
    color: var(--sl-color-neutral-0);
  }

  /* Success */
  .button--outline.button--success {
    border-color: var(--sl-color-success-600);
    color: var(--sl-color-success-600);
  }

  .button--outline.button--success:hover:not(.button--disabled),
  .button--outline.button--success.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-success-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--success:active:not(.button--disabled) {
    border-color: var(--sl-color-success-700);
    background-color: var(--sl-color-success-700);
    color: var(--sl-color-neutral-0);
  }

  /* Neutral */
  .button--outline.button--neutral {
    border-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-600);
  }

  .button--outline.button--neutral:hover:not(.button--disabled),
  .button--outline.button--neutral.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-neutral-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--neutral:active:not(.button--disabled) {
    border-color: var(--sl-color-neutral-700);
    background-color: var(--sl-color-neutral-700);
    color: var(--sl-color-neutral-0);
  }

  /* Warning */
  .button--outline.button--warning {
    border-color: var(--sl-color-warning-600);
    color: var(--sl-color-warning-600);
  }

  .button--outline.button--warning:hover:not(.button--disabled),
  .button--outline.button--warning.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-warning-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--warning:active:not(.button--disabled) {
    border-color: var(--sl-color-warning-700);
    background-color: var(--sl-color-warning-700);
    color: var(--sl-color-neutral-0);
  }

  /* Danger */
  .button--outline.button--danger {
    border-color: var(--sl-color-danger-600);
    color: var(--sl-color-danger-600);
  }

  .button--outline.button--danger:hover:not(.button--disabled),
  .button--outline.button--danger.button--checked:not(.button--disabled) {
    background-color: var(--sl-color-danger-600);
    color: var(--sl-color-neutral-0);
  }

  .button--outline.button--danger:active:not(.button--disabled) {
    border-color: var(--sl-color-danger-700);
    background-color: var(--sl-color-danger-700);
    color: var(--sl-color-neutral-0);
  }

  @media (forced-colors: active) {
    .button.button--outline.button--checked:not(.button--disabled) {
      outline: solid 2px transparent;
    }
  }

  /*
   * Text buttons
   */

  .button--text {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-600);
  }

  .button--text:hover:not(.button--disabled) {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-500);
  }

  .button--text:focus-visible:not(.button--disabled) {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-500);
  }

  .button--text:active:not(.button--disabled) {
    background-color: transparent;
    border-color: transparent;
    color: var(--sl-color-primary-700);
  }

  /*
   * Size modifiers
   */

  .button--small {
    font-size: var(--sl-button-font-size-small);
    height: var(--sl-input-height-small);
    line-height: calc(var(--sl-input-height-small) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-small);
  }

  .button--medium {
    font-size: var(--sl-button-font-size-medium);
    height: var(--sl-input-height-medium);
    line-height: calc(var(--sl-input-height-medium) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-medium);
  }

  .button--large {
    font-size: var(--sl-button-font-size-large);
    height: var(--sl-input-height-large);
    line-height: calc(var(--sl-input-height-large) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-large);
  }

  /*
   * Pill modifier
   */

  .button--pill.button--small {
    border-radius: var(--sl-input-height-small);
  }

  .button--pill.button--medium {
    border-radius: var(--sl-input-height-medium);
  }

  .button--pill.button--large {
    border-radius: var(--sl-input-height-large);
  }

  /*
   * Circle modifier
   */

  .button--circle {
    padding-left: 0;
    padding-right: 0;
  }

  .button--circle.button--small {
    width: var(--sl-input-height-small);
    border-radius: 50%;
  }

  .button--circle.button--medium {
    width: var(--sl-input-height-medium);
    border-radius: 50%;
  }

  .button--circle.button--large {
    width: var(--sl-input-height-large);
    border-radius: 50%;
  }

  .button--circle .button__prefix,
  .button--circle .button__suffix,
  .button--circle .button__caret {
    display: none;
  }

  /*
   * Caret modifier
   */

  .button--caret .button__suffix {
    display: none;
  }

  .button--caret .button__caret {
    height: auto;
  }

  /*
   * Loading modifier
   */

  .button--loading {
    position: relative;
    cursor: wait;
  }

  .button--loading .button__prefix,
  .button--loading .button__label,
  .button--loading .button__suffix,
  .button--loading .button__caret {
    visibility: hidden;
  }

  .button--loading sl-spinner {
    --indicator-color: currentColor;
    position: absolute;
    font-size: 1em;
    height: 1em;
    width: 1em;
    top: calc(50% - 0.5em);
    left: calc(50% - 0.5em);
  }

  /*
   * Badges
   */

  .button ::slotted(sl-badge) {
    position: absolute;
    top: 0;
    right: 0;
    translate: 50% -50%;
    pointer-events: none;
  }

  .button--rtl ::slotted(sl-badge) {
    right: auto;
    left: 0;
    translate: -50% -50%;
  }

  /*
   * Button spacing
   */

  .button--has-label.button--small .button__label {
    padding: 0 var(--sl-spacing-small);
  }

  .button--has-label.button--medium .button__label {
    padding: 0 var(--sl-spacing-medium);
  }

  .button--has-label.button--large .button__label {
    padding: 0 var(--sl-spacing-large);
  }

  .button--has-prefix.button--small {
    padding-inline-start: var(--sl-spacing-x-small);
  }

  .button--has-prefix.button--small .button__label {
    padding-inline-start: var(--sl-spacing-x-small);
  }

  .button--has-prefix.button--medium {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-prefix.button--medium .button__label {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-prefix.button--large {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-prefix.button--large .button__label {
    padding-inline-start: var(--sl-spacing-small);
  }

  .button--has-suffix.button--small,
  .button--caret.button--small {
    padding-inline-end: var(--sl-spacing-x-small);
  }

  .button--has-suffix.button--small .button__label,
  .button--caret.button--small .button__label {
    padding-inline-end: var(--sl-spacing-x-small);
  }

  .button--has-suffix.button--medium,
  .button--caret.button--medium {
    padding-inline-end: var(--sl-spacing-small);
  }

  .button--has-suffix.button--medium .button__label,
  .button--caret.button--medium .button__label {
    padding-inline-end: var(--sl-spacing-small);
  }

  .button--has-suffix.button--large,
  .button--caret.button--large {
    padding-inline-end: var(--sl-spacing-small);
  }

  .button--has-suffix.button--large .button__label,
  .button--caret.button--large .button__label {
    padding-inline-end: var(--sl-spacing-small);
  }

  /*
   * Button groups support a variety of button types (e.g. buttons with tooltips, buttons as dropdown triggers, etc.).
   * This means buttons aren't always direct descendants of the button group, thus we can't target them with the
   * ::slotted selector. To work around this, the button group component does some magic to add these special classes to
   * buttons and we style them here instead.
   */

  :host(.sl-button-group__button--first:not(.sl-button-group__button--last)) .button {
    border-start-end-radius: 0;
    border-end-end-radius: 0;
  }

  :host(.sl-button-group__button--inner) .button {
    border-radius: 0;
  }

  :host(.sl-button-group__button--last:not(.sl-button-group__button--first)) .button {
    border-start-start-radius: 0;
    border-end-start-radius: 0;
  }

  /* All except the first */
  :host(.sl-button-group__button:not(.sl-button-group__button--first)) {
    margin-inline-start: calc(-1 * var(--sl-input-border-width));
  }

  /* Add a visual separator between solid buttons */
  :host(
      .sl-button-group__button:not(
          .sl-button-group__button--first,
          .sl-button-group__button--radio,
          [variant='default']
        ):not(:hover)
    )
    .button:after {
    content: '';
    position: absolute;
    top: 0;
    inset-inline-start: 0;
    bottom: 0;
    border-left: solid 1px rgb(128 128 128 / 33%);
    mix-blend-mode: multiply;
  }

  /* Bump hovered, focused, and checked buttons up so their focus ring isn't clipped */
  :host(.sl-button-group__button--hover) {
    z-index: 1;
  }

  /* Focus and checked are always on top */
  :host(.sl-button-group__button--focus),
  :host(.sl-button-group__button[checked]) {
    z-index: 2;
  }
`, wc = Symbol.for(""), SQ = (e) => {
  if (e?.r === wc)
    return e?._$litStatic$;
}, Gs = (e, ...t) => ({ _$litStatic$: t.reduce((A, i, s) => A + ((o) => {
  if (o._$litStatic$ !== void 0)
    return o._$litStatic$;
  throw Error(`Value passed to 'literal' function must be a 'literal' result: ${o}. Use 'unsafeStatic' to pass non-literal values, but
            take care to ensure page security.`);
})(i) + e[s + 1], e[0]), r: wc }), Cl = /* @__PURE__ */ new Map(), xQ = (e) => (t, ...A) => {
  const i = A.length;
  let s, o;
  const r = [], n = [];
  let l, a = 0, c = !1;
  for (; a < i; ) {
    for (l = t[a]; a < i && (o = A[a], (s = SQ(o)) !== void 0); )
      l += s + t[++a], c = !0;
    n.push(o), r.push(l), a++;
  }
  if (a === i && r.push(t[i]), c) {
    const g = r.join("$$lit$$");
    (t = Cl.get(g)) === void 0 && (r.raw = r, Cl.set(g, t = r)), A = n;
  }
  return e(t, ...A);
}, us = xQ(_);
/*! Bundled license information:

lit-html/static.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var m = (e) => e ?? P;
/*! Bundled license information:

lit-html/directives/if-defined.js:
  (**
   * @license
   * Copyright 2018 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var GA = class {
  constructor(e, ...t) {
    this.slotNames = [], (this.host = e).addController(this), this.slotNames = t, this.handleSlotChange = this.handleSlotChange.bind(this);
  }
  hasDefaultSlot() {
    return [...this.host.childNodes].some((e) => {
      if (e.nodeType === e.TEXT_NODE && e.textContent.trim() !== "")
        return !0;
      if (e.nodeType === e.ELEMENT_NODE) {
        const t = e;
        if (t.tagName.toLowerCase() === "sl-visually-hidden")
          return !1;
        if (!t.hasAttribute("slot"))
          return !0;
      }
      return !1;
    });
  }
  hasNamedSlot(e) {
    return this.host.querySelector(`:scope > [slot="${e}"]`) !== null;
  }
  test(e) {
    return e === "[default]" ? this.hasDefaultSlot() : this.hasNamedSlot(e);
  }
  hostConnected() {
    this.host.shadowRoot.addEventListener("slotchange", this.handleSlotChange);
  }
  hostDisconnected() {
    this.host.shadowRoot.removeEventListener("slotchange", this.handleSlotChange);
  }
  handleSlotChange(e) {
    const t = e.target;
    (this.slotNames.includes("[default]") && !t.name || t.name && this.slotNames.includes(t.name)) && this.host.requestUpdate();
  }
};
function NQ(e) {
  if (!e)
    return "";
  const t = e.assignedNodes({ flatten: !0 });
  let A = "";
  return [...t].forEach((i) => {
    i.nodeType === Node.TEXT_NODE && (A += i.textContent);
  }), A;
}
var U = class extends K {
  constructor() {
    super(...arguments), this.formControlController = new wn(this, {
      form: (e) => {
        if (e.hasAttribute("form")) {
          const t = e.getRootNode(), A = e.getAttribute("form");
          return t.getElementById(A);
        }
        return e.closest("form");
      },
      assumeInteractionOn: ["click"]
    }), this.hasSlotController = new GA(this, "[default]", "prefix", "suffix"), this.localize = new be(this), this.hasFocus = !1, this.invalid = !1, this.title = "", this.variant = "default", this.size = "medium", this.caret = !1, this.disabled = !1, this.loading = !1, this.outline = !1, this.pill = !1, this.circle = !1, this.type = "button", this.name = "", this.value = "", this.href = "", this.rel = "noreferrer noopener";
  }
  /** Gets the validity state object */
  get validity() {
    return this.isButton() ? this.button.validity : yn;
  }
  /** Gets the validation message */
  get validationMessage() {
    return this.isButton() ? this.button.validationMessage : "";
  }
  connectedCallback() {
    super.connectedCallback(), this.handleHostClick = this.handleHostClick.bind(this), this.addEventListener("click", this.handleHostClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("click", this.handleHostClick);
  }
  firstUpdated() {
    this.isButton() && this.formControlController.updateValidity();
  }
  handleBlur() {
    this.hasFocus = !1, this.emit("sl-blur");
  }
  handleFocus() {
    this.hasFocus = !0, this.emit("sl-focus");
  }
  handleClick() {
    this.type === "submit" && this.formControlController.submit(this), this.type === "reset" && this.formControlController.reset(this);
  }
  handleHostClick(e) {
    (this.disabled || this.loading) && (e.preventDefault(), e.stopImmediatePropagation());
  }
  handleInvalid(e) {
    this.formControlController.setValidity(!1), this.formControlController.emitInvalidEvent(e);
  }
  isButton() {
    return !this.href;
  }
  isLink() {
    return !!this.href;
  }
  handleDisabledChange() {
    this.isButton() && this.formControlController.setValidity(this.disabled);
  }
  /** Simulates a click on the button. */
  click() {
    this.button.click();
  }
  /** Sets focus on the button. */
  focus(e) {
    this.button.focus(e);
  }
  /** Removes focus from the button. */
  blur() {
    this.button.blur();
  }
  /** Checks for validity but does not show a validation message. Returns `true` when valid and `false` when invalid. */
  checkValidity() {
    return this.isButton() ? this.button.checkValidity() : !0;
  }
  /** Gets the associated form, if one exists. */
  getForm() {
    return this.formControlController.getForm();
  }
  /** Checks for validity and shows the browser's validation message if the control is invalid. */
  reportValidity() {
    return this.isButton() ? this.button.reportValidity() : !0;
  }
  /** Sets a custom validation message. Pass an empty string to restore validity. */
  setCustomValidity(e) {
    this.isButton() && (this.button.setCustomValidity(e), this.formControlController.updateValidity());
  }
  render() {
    const e = this.isLink(), t = e ? Gs`a` : Gs`button`;
    return us`
      <${t}
        part="base"
        class=${Qt({
      button: !0,
      "button--default": this.variant === "default",
      "button--primary": this.variant === "primary",
      "button--success": this.variant === "success",
      "button--neutral": this.variant === "neutral",
      "button--warning": this.variant === "warning",
      "button--danger": this.variant === "danger",
      "button--text": this.variant === "text",
      "button--small": this.size === "small",
      "button--medium": this.size === "medium",
      "button--large": this.size === "large",
      "button--caret": this.caret,
      "button--circle": this.circle,
      "button--disabled": this.disabled,
      "button--focused": this.hasFocus,
      "button--loading": this.loading,
      "button--standard": !this.outline,
      "button--outline": this.outline,
      "button--pill": this.pill,
      "button--rtl": this.localize.dir() === "rtl",
      "button--has-label": this.hasSlotController.test("[default]"),
      "button--has-prefix": this.hasSlotController.test("prefix"),
      "button--has-suffix": this.hasSlotController.test("suffix")
    })}
        ?disabled=${m(e ? void 0 : this.disabled)}
        type=${m(e ? void 0 : this.type)}
        title=${this.title}
        name=${m(e ? void 0 : this.name)}
        value=${m(e ? void 0 : this.value)}
        href=${m(e ? this.href : void 0)}
        target=${m(e ? this.target : void 0)}
        download=${m(e ? this.download : void 0)}
        rel=${m(e ? this.rel : void 0)}
        role=${m(e ? void 0 : "button")}
        aria-disabled=${this.disabled ? "true" : "false"}
        tabindex=${this.disabled ? "-1" : "0"}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
        @invalid=${this.isButton() ? this.handleInvalid : null}
        @click=${this.handleClick}
      >
        <slot name="prefix" part="prefix" class="button__prefix"></slot>
        <slot part="label" class="button__label"></slot>
        <slot name="suffix" part="suffix" class="button__suffix"></slot>
        ${this.caret ? us` <sl-icon part="caret" class="button__caret" library="system" name="caret"></sl-icon> ` : ""}
        ${this.loading ? us`<sl-spinner></sl-spinner>` : ""}
      </${t}>
    `;
  }
};
U.styles = kQ;
I([
  X(".button")
], U.prototype, "button", 2);
I([
  FA()
], U.prototype, "hasFocus", 2);
I([
  FA()
], U.prototype, "invalid", 2);
I([
  d()
], U.prototype, "title", 2);
I([
  d({ reflect: !0 })
], U.prototype, "variant", 2);
I([
  d({ reflect: !0 })
], U.prototype, "size", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "caret", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "disabled", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "loading", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "outline", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "pill", 2);
I([
  d({ type: Boolean, reflect: !0 })
], U.prototype, "circle", 2);
I([
  d()
], U.prototype, "type", 2);
I([
  d()
], U.prototype, "name", 2);
I([
  d()
], U.prototype, "value", 2);
I([
  d()
], U.prototype, "href", 2);
I([
  d()
], U.prototype, "target", 2);
I([
  d()
], U.prototype, "rel", 2);
I([
  d()
], U.prototype, "download", 2);
I([
  d()
], U.prototype, "form", 2);
I([
  d({ attribute: "formaction" })
], U.prototype, "formAction", 2);
I([
  d({ attribute: "formenctype" })
], U.prototype, "formEnctype", 2);
I([
  d({ attribute: "formmethod" })
], U.prototype, "formMethod", 2);
I([
  d({ attribute: "formnovalidate", type: Boolean })
], U.prototype, "formNoValidate", 2);
I([
  d({ attribute: "formtarget" })
], U.prototype, "formTarget", 2);
I([
  z("disabled", { waitUntilFirstUpdate: !0 })
], U.prototype, "handleDisabledChange", 1);
U = I([
  st("sl-button")
], U);
var FQ = V`
  ${it}

  :host {
    display: contents;

    /* For better DX, we'll reset the margin here so the base part can inherit it */
    margin: 0;
  }

  .alert {
    position: relative;
    display: flex;
    align-items: stretch;
    background-color: var(--sl-panel-background-color);
    border: solid var(--sl-panel-border-width) var(--sl-panel-border-color);
    border-top-width: calc(var(--sl-panel-border-width) * 3);
    border-radius: var(--sl-border-radius-medium);
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-small);
    font-weight: var(--sl-font-weight-normal);
    line-height: 1.6;
    color: var(--sl-color-neutral-700);
    margin: inherit;
  }

  .alert:not(.alert--has-icon) .alert__icon,
  .alert:not(.alert--closable) .alert__close-button {
    display: none;
  }

  .alert__icon {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    font-size: var(--sl-font-size-large);
    padding-inline-start: var(--sl-spacing-large);
  }

  .alert--primary {
    border-top-color: var(--sl-color-primary-600);
  }

  .alert--primary .alert__icon {
    color: var(--sl-color-primary-600);
  }

  .alert--success {
    border-top-color: var(--sl-color-success-600);
  }

  .alert--success .alert__icon {
    color: var(--sl-color-success-600);
  }

  .alert--neutral {
    border-top-color: var(--sl-color-neutral-600);
  }

  .alert--neutral .alert__icon {
    color: var(--sl-color-neutral-600);
  }

  .alert--warning {
    border-top-color: var(--sl-color-warning-600);
  }

  .alert--warning .alert__icon {
    color: var(--sl-color-warning-600);
  }

  .alert--danger {
    border-top-color: var(--sl-color-danger-600);
  }

  .alert--danger .alert__icon {
    color: var(--sl-color-danger-600);
  }

  .alert__message {
    flex: 1 1 auto;
    display: block;
    padding: var(--sl-spacing-large);
    overflow: hidden;
  }

  .alert__close-button {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    font-size: var(--sl-font-size-medium);
    padding-inline-end: var(--sl-spacing-medium);
  }
`, tA = Object.assign(document.createElement("div"), { className: "sl-toast-stack" }), Zt = class extends K {
  constructor() {
    super(...arguments), this.hasSlotController = new GA(this, "icon", "suffix"), this.localize = new be(this), this.open = !1, this.closable = !1, this.variant = "primary", this.duration = 1 / 0;
  }
  firstUpdated() {
    this.base.hidden = !this.open;
  }
  restartAutoHide() {
    clearTimeout(this.autoHideTimeout), this.open && this.duration < 1 / 0 && (this.autoHideTimeout = window.setTimeout(() => this.hide(), this.duration));
  }
  handleCloseClick() {
    this.hide();
  }
  handleMouseMove() {
    this.restartAutoHide();
  }
  async handleOpenChange() {
    if (this.open) {
      this.emit("sl-show"), this.duration < 1 / 0 && this.restartAutoHide(), await zt(this.base), this.base.hidden = !1;
      const { keyframes: e, options: t } = Lt(this, "alert.show", { dir: this.localize.dir() });
      await Jt(this.base, e, t), this.emit("sl-after-show");
    } else {
      this.emit("sl-hide"), clearTimeout(this.autoHideTimeout), await zt(this.base);
      const { keyframes: e, options: t } = Lt(this, "alert.hide", { dir: this.localize.dir() });
      await Jt(this.base, e, t), this.base.hidden = !0, this.emit("sl-after-hide");
    }
  }
  handleDurationChange() {
    this.restartAutoHide();
  }
  /** Shows the alert. */
  async show() {
    if (!this.open)
      return this.open = !0, pe(this, "sl-after-show");
  }
  /** Hides the alert */
  async hide() {
    if (this.open)
      return this.open = !1, pe(this, "sl-after-hide");
  }
  /**
   * Displays the alert as a toast notification. This will move the alert out of its position in the DOM and, when
   * dismissed, it will be removed from the DOM completely. By storing a reference to the alert, you can reuse it by
   * calling this method again. The returned promise will resolve after the alert is hidden.
   */
  async toast() {
    return new Promise((e) => {
      tA.parentElement === null && document.body.append(tA), tA.appendChild(this), requestAnimationFrame(() => {
        this.clientWidth, this.show();
      }), this.addEventListener(
        "sl-after-hide",
        () => {
          tA.removeChild(this), e(), tA.querySelector("sl-alert") === null && tA.remove();
        },
        { once: !0 }
      );
    });
  }
  render() {
    return _`
      <div
        part="base"
        class=${Qt({
      alert: !0,
      "alert--open": this.open,
      "alert--closable": this.closable,
      "alert--has-icon": this.hasSlotController.test("icon"),
      "alert--primary": this.variant === "primary",
      "alert--success": this.variant === "success",
      "alert--neutral": this.variant === "neutral",
      "alert--warning": this.variant === "warning",
      "alert--danger": this.variant === "danger"
    })}
        role="alert"
        aria-hidden=${this.open ? "false" : "true"}
        @mousemove=${this.handleMouseMove}
      >
        <slot name="icon" part="icon" class="alert__icon"></slot>

        <slot part="message" class="alert__message" aria-live="polite"></slot>

        ${this.closable ? _`
              <sl-icon-button
                part="close-button"
                exportparts="base:close-button__base"
                class="alert__close-button"
                name="x-lg"
                library="system"
                label=${this.localize.term("close")}
                @click=${this.handleCloseClick}
              ></sl-icon-button>
            ` : ""}
      </div>
    `;
  }
};
Zt.styles = FQ;
I([
  X('[part~="base"]')
], Zt.prototype, "base", 2);
I([
  d({ type: Boolean, reflect: !0 })
], Zt.prototype, "open", 2);
I([
  d({ type: Boolean, reflect: !0 })
], Zt.prototype, "closable", 2);
I([
  d({ reflect: !0 })
], Zt.prototype, "variant", 2);
I([
  d({ type: Number })
], Zt.prototype, "duration", 2);
I([
  z("open", { waitUntilFirstUpdate: !0 })
], Zt.prototype, "handleOpenChange", 1);
I([
  z("duration")
], Zt.prototype, "handleDurationChange", 1);
Zt = I([
  st("sl-alert")
], Zt);
Ot("alert.show", {
  keyframes: [
    { opacity: 0, scale: 0.8 },
    { opacity: 1, scale: 1 }
  ],
  options: { duration: 250, easing: "ease" }
});
Ot("alert.hide", {
  keyframes: [
    { opacity: 1, scale: 1 },
    { opacity: 0, scale: 0.8 }
  ],
  options: { duration: 250, easing: "ease" }
});
var RQ = V`
  ${it}

  :host {
    display: inline-block;
    color: var(--sl-color-neutral-600);
  }

  .icon-button {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    background: none;
    border: none;
    border-radius: var(--sl-border-radius-medium);
    font-size: inherit;
    color: inherit;
    padding: var(--sl-spacing-x-small);
    cursor: pointer;
    transition: var(--sl-transition-x-fast) color;
    -webkit-appearance: none;
  }

  .icon-button:hover:not(.icon-button--disabled),
  .icon-button:focus-visible:not(.icon-button--disabled) {
    color: var(--sl-color-primary-600);
  }

  .icon-button:active:not(.icon-button--disabled) {
    color: var(--sl-color-primary-700);
  }

  .icon-button:focus {
    outline: none;
  }

  .icon-button--disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .icon-button:focus-visible {
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .icon-button__icon {
    pointer-events: none;
  }
`, vt = class extends K {
  constructor() {
    super(...arguments), this.hasFocus = !1, this.label = "", this.disabled = !1;
  }
  handleBlur() {
    this.hasFocus = !1, this.emit("sl-blur");
  }
  handleFocus() {
    this.hasFocus = !0, this.emit("sl-focus");
  }
  handleClick(e) {
    this.disabled && (e.preventDefault(), e.stopPropagation());
  }
  /** Simulates a click on the icon button. */
  click() {
    this.button.click();
  }
  /** Sets focus on the icon button. */
  focus(e) {
    this.button.focus(e);
  }
  /** Removes focus from the icon button. */
  blur() {
    this.button.blur();
  }
  render() {
    const e = !!this.href, t = e ? Gs`a` : Gs`button`;
    return us`
      <${t}
        part="base"
        class=${Qt({
      "icon-button": !0,
      "icon-button--disabled": !e && this.disabled,
      "icon-button--focused": this.hasFocus
    })}
        ?disabled=${m(e ? void 0 : this.disabled)}
        type=${m(e ? void 0 : "button")}
        href=${m(e ? this.href : void 0)}
        target=${m(e ? this.target : void 0)}
        download=${m(e ? this.download : void 0)}
        rel=${m(e && this.target ? "noreferrer noopener" : void 0)}
        role=${m(e ? void 0 : "button")}
        aria-disabled=${this.disabled ? "true" : "false"}
        aria-label="${this.label}"
        tabindex=${this.disabled ? "-1" : "0"}
        @blur=${this.handleBlur}
        @focus=${this.handleFocus}
        @click=${this.handleClick}
      >
        <sl-icon
          class="icon-button__icon"
          name=${m(this.name)}
          library=${m(this.library)}
          src=${m(this.src)}
          aria-hidden="true"
        ></sl-icon>
      </${t}>
    `;
  }
};
vt.styles = RQ;
I([
  X(".icon-button")
], vt.prototype, "button", 2);
I([
  FA()
], vt.prototype, "hasFocus", 2);
I([
  d()
], vt.prototype, "name", 2);
I([
  d()
], vt.prototype, "library", 2);
I([
  d()
], vt.prototype, "src", 2);
I([
  d()
], vt.prototype, "href", 2);
I([
  d()
], vt.prototype, "target", 2);
I([
  d()
], vt.prototype, "download", 2);
I([
  d()
], vt.prototype, "label", 2);
I([
  d({ type: Boolean, reflect: !0 })
], vt.prototype, "disabled", 2);
vt = I([
  st("sl-icon-button")
], vt);
var UQ = V`
  ${it}

  :host {
    --border-color: var(--sl-color-neutral-200);
    --border-radius: var(--sl-border-radius-medium);
    --border-width: 1px;
    --padding: var(--sl-spacing-large);

    display: inline-block;
  }

  .card {
    display: flex;
    flex-direction: column;
    background-color: var(--sl-panel-background-color);
    box-shadow: var(--sl-shadow-x-small);
    border: solid var(--border-width) var(--border-color);
    border-radius: var(--border-radius);
  }

  .card__image {
    display: flex;
    border-top-left-radius: var(--border-radius);
    border-top-right-radius: var(--border-radius);
    margin: calc(-1 * var(--border-width));
    overflow: hidden;
  }

  .card__image::slotted(img) {
    display: block;
    width: 100%;
  }

  .card:not(.card--has-image) .card__image {
    display: none;
  }

  .card__header {
    display: block;
    border-bottom: solid var(--border-width) var(--border-color);
    padding: calc(var(--padding) / 2) var(--padding);
  }

  .card:not(.card--has-header) .card__header {
    display: none;
  }

  .card:not(.card--has-image) .card__header {
    border-top-left-radius: var(--border-radius);
    border-top-right-radius: var(--border-radius);
  }

  .card__body {
    display: block;
    padding: var(--padding);
  }

  .card--has-footer .card__footer {
    display: block;
    border-top: solid var(--border-width) var(--border-color);
    padding: var(--padding);
  }

  .card:not(.card--has-footer) .card__footer {
    display: none;
  }
`, _r = class extends K {
  constructor() {
    super(...arguments), this.hasSlotController = new GA(this, "footer", "header", "image");
  }
  render() {
    return _`
      <div
        part="base"
        class=${Qt({
      card: !0,
      "card--has-footer": this.hasSlotController.test("footer"),
      "card--has-image": this.hasSlotController.test("image"),
      "card--has-header": this.hasSlotController.test("header")
    })}
      >
        <slot name="image" part="image" class="card__image"></slot>
        <slot name="header" part="header" class="card__header"></slot>
        <slot part="body" class="card__body"></slot>
        <slot name="footer" part="footer" class="card__footer"></slot>
      </div>
    `;
  }
};
_r.styles = UQ;
_r = I([
  st("sl-card")
], _r);
function T(e, t, A, i) {
  var s = arguments.length, o = s < 3 ? t : i === null ? i = Object.getOwnPropertyDescriptor(t, A) : i, r;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function")
    o = Reflect.decorate(e, t, A, i);
  else
    for (var n = e.length - 1; n >= 0; n--)
      (r = e[n]) && (o = (s < 3 ? r(o) : s > 3 ? r(t, A, o) : r(t, A)) || o);
  return s > 3 && o && Object.defineProperty(t, A, o), o;
}
var GQ = V`
  ${it}

  :host {
    --border-radius: var(--sl-border-radius-pill);
    --color: var(--sl-color-neutral-200);
    --sheen-color: var(--sl-color-neutral-300);

    display: block;
    position: relative;
  }

  .skeleton {
    display: flex;
    width: 100%;
    height: 100%;
    min-height: 1rem;
  }

  .skeleton__indicator {
    flex: 1 1 auto;
    background: var(--color);
    border-radius: var(--border-radius);
  }

  .skeleton--sheen .skeleton__indicator {
    background: linear-gradient(270deg, var(--sheen-color), var(--color), var(--color), var(--sheen-color));
    background-size: 400% 100%;
    background-size: 400% 100%;
    animation: sheen 8s ease-in-out infinite;
  }

  .skeleton--pulse .skeleton__indicator {
    animation: pulse 2s ease-in-out 0.5s infinite;
  }

  /* Forced colors mode */
  @media (forced-colors: active) {
    :host {
      --color: GrayText;
    }
  }

  @keyframes sheen {
    0% {
      background-position: 200% 0;
    }
    to {
      background-position: -200% 0;
    }
  }

  @keyframes pulse {
    0% {
      opacity: 1;
    }
    50% {
      opacity: 0.4;
    }
    100% {
      opacity: 1;
    }
  }
`, Ms = class extends K {
  constructor() {
    super(...arguments), this.effect = "none";
  }
  render() {
    return _`
      <div
        part="base"
        class=${Qt({
      skeleton: !0,
      "skeleton--pulse": this.effect === "pulse",
      "skeleton--sheen": this.effect === "sheen"
    })}
      >
        <div part="indicator" class="skeleton__indicator"></div>
      </div>
    `;
  }
};
Ms.styles = GQ;
I([
  d()
], Ms.prototype, "effect", 2);
Ms = I([
  st("sl-skeleton")
], Ms);
function Bl(e) {
  const t = e.tagName.toLowerCase();
  return e.getAttribute("tabindex") === "-1" || e.hasAttribute("disabled") || e.hasAttribute("aria-disabled") && e.getAttribute("aria-disabled") !== "false" || t === "input" && e.getAttribute("type") === "radio" && !e.hasAttribute("checked") || e.offsetParent === null || window.getComputedStyle(e).visibility === "hidden" ? !1 : (t === "audio" || t === "video") && e.hasAttribute("controls") || e.hasAttribute("tabindex") || e.hasAttribute("contenteditable") && e.getAttribute("contenteditable") !== "false" ? !0 : ["button", "input", "select", "textarea", "a", "audio", "video", "summary"].includes(t);
}
function yc(e) {
  var t, A;
  const i = [];
  function s(n) {
    n instanceof HTMLElement && (i.push(n), n.shadowRoot !== null && n.shadowRoot.mode === "open" && s(n.shadowRoot)), [...n.children].forEach((l) => s(l));
  }
  s(e);
  const o = (t = i.find((n) => Bl(n))) != null ? t : null, r = (A = i.reverse().find((n) => Bl(n))) != null ? A : null;
  return { start: o, end: r };
}
var ZA = [], MQ = class {
  constructor(e) {
    this.tabDirection = "forward", this.element = e, this.handleFocusIn = this.handleFocusIn.bind(this), this.handleKeyDown = this.handleKeyDown.bind(this), this.handleKeyUp = this.handleKeyUp.bind(this);
  }
  activate() {
    ZA.push(this.element), document.addEventListener("focusin", this.handleFocusIn), document.addEventListener("keydown", this.handleKeyDown), document.addEventListener("keyup", this.handleKeyUp);
  }
  deactivate() {
    ZA = ZA.filter((e) => e !== this.element), document.removeEventListener("focusin", this.handleFocusIn), document.removeEventListener("keydown", this.handleKeyDown), document.removeEventListener("keyup", this.handleKeyUp);
  }
  isActive() {
    return ZA[ZA.length - 1] === this.element;
  }
  checkFocus() {
    if (this.isActive() && !this.element.matches(":focus-within")) {
      const { start: e, end: t } = yc(this.element), A = this.tabDirection === "forward" ? e : t;
      typeof A?.focus == "function" && A.focus({ preventScroll: !0 });
    }
  }
  handleFocusIn() {
    this.checkFocus();
  }
  handleKeyDown(e) {
    e.key === "Tab" && e.shiftKey && (this.tabDirection = "backward", requestAnimationFrame(() => this.checkFocus()));
  }
  handleKeyUp() {
    this.tabDirection = "forward";
  }
}, Tr = /* @__PURE__ */ new Set();
function LQ() {
  const e = document.documentElement.clientWidth;
  return Math.abs(window.innerWidth - e);
}
function Ql(e) {
  if (Tr.add(e), !document.body.classList.contains("sl-scroll-lock")) {
    const t = LQ();
    document.body.classList.add("sl-scroll-lock"), document.body.style.setProperty("--sl-scroll-lock-size", `${t}px`);
  }
}
function El(e) {
  Tr.delete(e), Tr.size === 0 && (document.body.classList.remove("sl-scroll-lock"), document.body.style.removeProperty("--sl-scroll-lock-size"));
}
var JQ = V`
  ${it}

  :host {
    --width: 31rem;
    --header-spacing: var(--sl-spacing-large);
    --body-spacing: var(--sl-spacing-large);
    --footer-spacing: var(--sl-spacing-large);

    display: contents;
  }

  .dialog {
    display: flex;
    align-items: center;
    justify-content: center;
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: var(--sl-z-index-dialog);
  }

  .dialog__panel {
    display: flex;
    flex-direction: column;
    z-index: 2;
    width: var(--width);
    max-width: calc(100% - var(--sl-spacing-2x-large));
    max-height: calc(100% - var(--sl-spacing-2x-large));
    background-color: var(--sl-panel-background-color);
    border-radius: var(--sl-border-radius-medium);
    box-shadow: var(--sl-shadow-x-large);
  }

  .dialog__panel:focus {
    outline: none;
  }

  /* Ensure there's enough vertical padding for phones that don't update vh when chrome appears (e.g. iPhone) */
  @media screen and (max-width: 420px) {
    .dialog__panel {
      max-height: 80vh;
    }
  }

  .dialog--open .dialog__panel {
    display: flex;
    opacity: 1;
  }

  .dialog__header {
    flex: 0 0 auto;
    display: flex;
  }

  .dialog__title {
    flex: 1 1 auto;
    font: inherit;
    font-size: var(--sl-font-size-large);
    line-height: var(--sl-line-height-dense);
    padding: var(--header-spacing);
    margin: 0;
  }

  .dialog__header-actions {
    flex-shrink: 0;
    display: flex;
    flex-wrap: wrap;
    justify-content: end;
    gap: var(--sl-spacing-2x-small);
    padding: 0 var(--header-spacing);
  }

  .dialog__header-actions sl-icon-button,
  .dialog__header-actions ::slotted(sl-icon-button) {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    font-size: var(--sl-font-size-medium);
  }

  .dialog__body {
    flex: 1 1 auto;
    display: block;
    padding: var(--body-spacing);
    overflow: auto;
    -webkit-overflow-scrolling: touch;
  }

  .dialog__footer {
    flex: 0 0 auto;
    text-align: right;
    padding: var(--footer-spacing);
  }

  .dialog__footer ::slotted(sl-button:not(:first-of-type)) {
    margin-inline-start: var(--sl-spacing-x-small);
  }

  .dialog:not(.dialog--has-footer) .dialog__footer {
    display: none;
  }

  .dialog__overlay {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: var(--sl-overlay-background-color);
  }

  @media (forced-colors: active) {
    .dialog__panel {
      border: solid 1px var(--sl-color-neutral-0);
    }
  }
`, Wt = class extends K {
  constructor() {
    super(...arguments), this.hasSlotController = new GA(this, "footer"), this.localize = new be(this), this.open = !1, this.label = "", this.noHeader = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.handleDocumentKeyDown = this.handleDocumentKeyDown.bind(this), this.modal = new MQ(this);
  }
  firstUpdated() {
    this.dialog.hidden = !this.open, this.open && (this.addOpenListeners(), this.modal.activate(), Ql(this));
  }
  disconnectedCallback() {
    super.disconnectedCallback(), El(this);
  }
  requestClose(e) {
    if (this.emit("sl-request-close", {
      cancelable: !0,
      detail: { source: e }
    }).defaultPrevented) {
      const A = Lt(this, "dialog.denyClose", { dir: this.localize.dir() });
      Jt(this.panel, A.keyframes, A.options);
      return;
    }
    this.hide();
  }
  addOpenListeners() {
    document.addEventListener("keydown", this.handleDocumentKeyDown);
  }
  removeOpenListeners() {
    document.removeEventListener("keydown", this.handleDocumentKeyDown);
  }
  handleDocumentKeyDown(e) {
    this.open && e.key === "Escape" && (e.stopPropagation(), this.requestClose("keyboard"));
  }
  async handleOpenChange() {
    if (this.open) {
      this.emit("sl-show"), this.addOpenListeners(), this.originalTrigger = document.activeElement, this.modal.activate(), Ql(this);
      const e = this.querySelector("[autofocus]");
      e && e.removeAttribute("autofocus"), await Promise.all([zt(this.dialog), zt(this.overlay)]), this.dialog.hidden = !1, requestAnimationFrame(() => {
        this.emit("sl-initial-focus", { cancelable: !0 }).defaultPrevented || (e ? e.focus({ preventScroll: !0 }) : this.panel.focus({ preventScroll: !0 })), e && e.setAttribute("autofocus", "");
      });
      const t = Lt(this, "dialog.show", { dir: this.localize.dir() }), A = Lt(this, "dialog.overlay.show", { dir: this.localize.dir() });
      await Promise.all([
        Jt(this.panel, t.keyframes, t.options),
        Jt(this.overlay, A.keyframes, A.options)
      ]), this.emit("sl-after-show");
    } else {
      this.emit("sl-hide"), this.removeOpenListeners(), this.modal.deactivate(), await Promise.all([zt(this.dialog), zt(this.overlay)]);
      const e = Lt(this, "dialog.hide", { dir: this.localize.dir() }), t = Lt(this, "dialog.overlay.hide", { dir: this.localize.dir() });
      await Promise.all([
        Jt(this.overlay, t.keyframes, t.options).then(() => {
          this.overlay.hidden = !0;
        }),
        Jt(this.panel, e.keyframes, e.options).then(() => {
          this.panel.hidden = !0;
        })
      ]), this.dialog.hidden = !0, this.overlay.hidden = !1, this.panel.hidden = !1, El(this);
      const A = this.originalTrigger;
      typeof A?.focus == "function" && setTimeout(() => A.focus()), this.emit("sl-after-hide");
    }
  }
  /** Shows the dialog. */
  async show() {
    if (!this.open)
      return this.open = !0, pe(this, "sl-after-show");
  }
  /** Hides the dialog */
  async hide() {
    if (this.open)
      return this.open = !1, pe(this, "sl-after-hide");
  }
  render() {
    return _`
      <div
        part="base"
        class=${Qt({
      dialog: !0,
      "dialog--open": this.open,
      "dialog--has-footer": this.hasSlotController.test("footer")
    })}
      >
        <div part="overlay" class="dialog__overlay" @click=${() => this.requestClose("overlay")} tabindex="-1"></div>

        <div
          part="panel"
          class="dialog__panel"
          role="dialog"
          aria-modal="true"
          aria-hidden=${this.open ? "false" : "true"}
          aria-label=${m(this.noHeader ? this.label : void 0)}
          aria-labelledby=${m(this.noHeader ? void 0 : "title")}
          tabindex="0"
        >
          ${this.noHeader ? "" : _`
                <header part="header" class="dialog__header">
                  <h2 part="title" class="dialog__title" id="title">
                    <slot name="label"> ${this.label.length > 0 ? this.label : String.fromCharCode(65279)} </slot>
                  </h2>
                  <div part="header-actions" class="dialog__header-actions">
                    <slot name="header-actions"></slot>
                    <sl-icon-button
                      part="close-button"
                      exportparts="base:close-button__base"
                      class="dialog__close"
                      name="x-lg"
                      label=${this.localize.term("close")}
                      library="system"
                      @click="${() => this.requestClose("close-button")}"
                    ></sl-icon-button>
                  </div>
                </header>
              `}

          <slot part="body" class="dialog__body"></slot>

          <footer part="footer" class="dialog__footer">
            <slot name="footer"></slot>
          </footer>
        </div>
      </div>
    `;
  }
};
Wt.styles = JQ;
I([
  X(".dialog")
], Wt.prototype, "dialog", 2);
I([
  X(".dialog__panel")
], Wt.prototype, "panel", 2);
I([
  X(".dialog__overlay")
], Wt.prototype, "overlay", 2);
I([
  d({ type: Boolean, reflect: !0 })
], Wt.prototype, "open", 2);
I([
  d({ reflect: !0 })
], Wt.prototype, "label", 2);
I([
  d({ attribute: "no-header", type: Boolean, reflect: !0 })
], Wt.prototype, "noHeader", 2);
I([
  z("open", { waitUntilFirstUpdate: !0 })
], Wt.prototype, "handleOpenChange", 1);
Wt = I([
  st("sl-dialog")
], Wt);
Ot("dialog.show", {
  keyframes: [
    { opacity: 0, scale: 0.8 },
    { opacity: 1, scale: 1 }
  ],
  options: { duration: 250, easing: "ease" }
});
Ot("dialog.hide", {
  keyframes: [
    { opacity: 1, scale: 1 },
    { opacity: 0, scale: 0.8 }
  ],
  options: { duration: 250, easing: "ease" }
});
Ot("dialog.denyClose", {
  keyframes: [{ scale: 1 }, { scale: 1.02 }, { scale: 1 }],
  options: { duration: 250 }
});
Ot("dialog.overlay.show", {
  keyframes: [{ opacity: 0 }, { opacity: 1 }],
  options: { duration: 250 }
});
Ot("dialog.overlay.hide", {
  keyframes: [{ opacity: 1 }, { opacity: 0 }],
  options: { duration: 250 }
});
async function vn(e, t) {
  const A = new ks(), i = new ks();
  for (const s of t) {
    const o = await e.appletInfo(s);
    if (o) {
      i.set(s, o);
      for (const r of o.groupsIds)
        if (!A.has(r)) {
          const n = await e.groupProfile(r);
          n && A.set(r, n);
        }
    }
  }
  return {
    groupsProfiles: A,
    appletsInfos: i
  };
}
const Hi = "we_services";
var YQ = V`
  ${it}

  :host {
    display: inline-block;
  }

  .tag {
    display: flex;
    align-items: center;
    border: solid 1px;
    line-height: 1;
    white-space: nowrap;
    user-select: none;
  }

  .tag__remove::part(base) {
    color: inherit;
    padding: 0;
  }

  /*
   * Variant modifiers
   */

  .tag--primary {
    background-color: var(--sl-color-primary-50);
    border-color: var(--sl-color-primary-200);
    color: var(--sl-color-primary-800);
  }

  .tag--primary:active > sl-icon-button {
    color: var(--sl-color-primary-600);
  }

  .tag--success {
    background-color: var(--sl-color-success-50);
    border-color: var(--sl-color-success-200);
    color: var(--sl-color-success-800);
  }

  .tag--success:active > sl-icon-button {
    color: var(--sl-color-success-600);
  }

  .tag--neutral {
    background-color: var(--sl-color-neutral-50);
    border-color: var(--sl-color-neutral-200);
    color: var(--sl-color-neutral-800);
  }

  .tag--neutral:active > sl-icon-button {
    color: var(--sl-color-neutral-600);
  }

  .tag--warning {
    background-color: var(--sl-color-warning-50);
    border-color: var(--sl-color-warning-200);
    color: var(--sl-color-warning-800);
  }

  .tag--warning:active > sl-icon-button {
    color: var(--sl-color-warning-600);
  }

  .tag--danger {
    background-color: var(--sl-color-danger-50);
    border-color: var(--sl-color-danger-200);
    color: var(--sl-color-danger-800);
  }

  .tag--danger:active > sl-icon-button {
    color: var(--sl-color-danger-600);
  }

  /*
   * Size modifiers
   */

  .tag--small {
    font-size: var(--sl-button-font-size-small);
    height: calc(var(--sl-input-height-small) * 0.8);
    line-height: calc(var(--sl-input-height-small) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-small);
    padding: 0 var(--sl-spacing-x-small);
  }

  .tag--medium {
    font-size: var(--sl-button-font-size-medium);
    height: calc(var(--sl-input-height-medium) * 0.8);
    line-height: calc(var(--sl-input-height-medium) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-medium);
    padding: 0 var(--sl-spacing-small);
  }

  .tag--large {
    font-size: var(--sl-button-font-size-large);
    height: calc(var(--sl-input-height-large) * 0.8);
    line-height: calc(var(--sl-input-height-large) - var(--sl-input-border-width) * 2);
    border-radius: var(--sl-input-border-radius-large);
    padding: 0 var(--sl-spacing-medium);
  }

  .tag__remove {
    margin-inline-start: var(--sl-spacing-x-small);
  }

  /*
   * Pill modifier
   */

  .tag--pill {
    border-radius: var(--sl-border-radius-pill);
  }
`, $e = class extends K {
  constructor() {
    super(...arguments), this.localize = new be(this), this.variant = "neutral", this.size = "medium", this.pill = !1, this.removable = !1;
  }
  handleRemoveClick() {
    this.emit("sl-remove");
  }
  render() {
    return _`
      <span
        part="base"
        class=${Qt({
      tag: !0,
      // Types
      "tag--primary": this.variant === "primary",
      "tag--success": this.variant === "success",
      "tag--neutral": this.variant === "neutral",
      "tag--warning": this.variant === "warning",
      "tag--danger": this.variant === "danger",
      "tag--text": this.variant === "text",
      // Sizes
      "tag--small": this.size === "small",
      "tag--medium": this.size === "medium",
      "tag--large": this.size === "large",
      // Modifiers
      "tag--pill": this.pill,
      "tag--removable": this.removable
    })}
      >
        <slot part="content" class="tag__content"></slot>

        ${this.removable ? _`
              <sl-icon-button
                part="remove-button"
                exportparts="base:remove-button__base"
                name="x-lg"
                library="system"
                label=${this.localize.term("remove")}
                class="tag__remove"
                @click=${this.handleRemoveClick}
                tabindex="-1"
              ></sl-icon-button>
            ` : ""}
      </span>
    `;
  }
};
$e.styles = YQ;
I([
  d({ reflect: !0 })
], $e.prototype, "variant", 2);
I([
  d({ reflect: !0 })
], $e.prototype, "size", 2);
I([
  d({ type: Boolean, reflect: !0 })
], $e.prototype, "pill", 2);
I([
  d({ type: Boolean })
], $e.prototype, "removable", 2);
$e = I([
  st("sl-tag")
], $e);
let vA = class extends q {
  constructor() {
    super(...arguments), this.info = new Ke(this, () => dn(async () => {
      const t = await this.weServices.entryInfo(this.hrl);
      if (!t)
        return;
      const { groupsProfiles: A, appletsInfos: i } = await vn(this.weServices, [
        t.appletId
      ]);
      return {
        entryInfo: t,
        groupsProfiles: A,
        appletsInfos: i
      };
    }), () => [this.hrl]);
  }
  render() {
    var t, A;
    switch (this.info.value.status) {
      case "pending":
        return w`<sl-skeleton></sl-skeleton>`;
      case "complete":
        if (this.info.value.value === void 0)
          return w``;
        const { appletsInfos: i, groupsProfiles: s, entryInfo: o } = this.info.value.value;
        return w`
          <sl-tooltip
            ><div slot="content">
              <div slot="suffix" class="row" style="align-items: center">
                <span>
                  ${(t = i.get(o.appletId)) === null || t === void 0 ? void 0 : t.appletName}</span
                >
                <span class="placeholder" style="margin-right: 8px"
                  >${k(" in ")}</span
                >
                ${(A = i.get(o.appletId)) === null || A === void 0 ? void 0 : A.groupsIds.map((r) => {
          var n, l;
          return w`
                    <img
                      .src=${(n = s.get(r)) === null || n === void 0 ? void 0 : n.logo_src}
                      style="height: 16px; width: 16px; margin-right: 4px;"
                    />
                    <span>${(l = s.get(r)) === null || l === void 0 ? void 0 : l.name}</span>
                  `;
        })}
              </div>
            </div>
            <sl-tag
              pill
              @click=${() => this.weServices.openViews.openHrl(this.hrl, this.context)}
            >
              <div class="row">
                <sl-icon .src=${o.entryInfo.icon_src}></sl-icon>
                <span>${o.entryInfo.name}</span>
              </div>
            </sl-tag>
          </sl-tooltip>
        `;
      case "error":
        return w`<display-error
          tooltip
          .headline=${k("Error fetching the entry")}
          .error=${this.info.value.error.data.data}
        ></display-error>`;
    }
  }
};
vA.styles = [Ut];
T([
  W()
], vA.prototype, "hrl", void 0);
T([
  W()
], vA.prototype, "context", void 0);
T([
  Tt({ context: Hi, subscribe: !0 })
], vA.prototype, "weServices", void 0);
vA = T([
  Xt(),
  It("hrl-link")
], vA);
const mn = "attachments_store";
let ye = class extends q {
  constructor() {
    super(...arguments), this.attachments = new Ke(this, () => this.attachmentsStore.attachments.get(this.hash), () => [this.hash]), this.removing = !1;
  }
  async removeAttachment(t) {
    this.removing = !0;
    try {
      await this.attachmentsStore.client.removeAttachment(this.hash, t), this._attachmentToRemove = void 0;
    } catch (A) {
      Ji(k("Error removing the attachment")), console.error(A);
    }
    this.removing = !1;
  }
  renderAttachments(t) {
    return t.length === 0 ? w`<span class="placeholder"
        >${k("There are no attachments yet.")}</span
      >` : w`
      ${this._attachmentToRemove ? w`
            <sl-dialog
              open
              .label=${k("Remove Attachment")}
              @sl-hide=${() => {
      this._attachmentToRemove = void 0;
    }}
              @sl-request-close=${(A) => {
      this.removing && A.preventDefault();
    }}
            >
              <span>${k("Do you want to remove this attachment?")}</span>

              <sl-button
                slot="footer"
                @click=${() => {
      this._attachmentToRemove = void 0;
    }}
                >${k("Cancel")}</sl-button
              >

              <sl-button
                slot="footer"
                variant="primary"
                @click=${() => this.removeAttachment(this._attachmentToRemove)}
                .loading=${this.removing}
                >${k("Remove")}</sl-button
              >
            </sl-dialog>
          ` : w``}

      <div class="column">
        ${t.map((A) => w` <div class="row">
              <hrl-link
                style="flex:1"
                .hrl=${A.hrl}
                .context=${A.context}
              ></hrl-link>
              <sl-icon-button
                .src=${fe(nB)}
                @click=${() => this._attachmentToRemove = A}
              ></sl-icon-button>
            </div>`)}
      </div>
    `;
  }
  render() {
    switch (this.attachments.value.status) {
      case "pending":
        return w`<sl-skeleton></sl-skeleton><sl-skeleton></sl-skeleton
          ><sl-skeleton></sl-skeleton>`;
      case "complete":
        return this.renderAttachments(this.attachments.value.value);
      case "error":
        return w`<display-error
          tooltip
          .headline=${k("Error fetching the attachments")}
          .error=${this.attachments.value.error.data.data}
        ></display-error>`;
    }
  }
};
ye.styles = [Ut];
T([
  Tt({ context: mn, subscribe: !0 })
], ye.prototype, "attachmentsStore", void 0);
T([
  Tt({ context: Hi, subscribe: !0 })
], ye.prototype, "weServices", void 0);
T([
  W(NA("hash"))
], ye.prototype, "hash", void 0);
T([
  Mi()
], ye.prototype, "_attachmentToRemove", void 0);
T([
  Mi()
], ye.prototype, "removing", void 0);
ye = T([
  It("attachments-list")
], ye);
var HQ = V`
  ${it}

  :host {
    display: inline-block;
  }

  .dropdown::part(popup) {
    z-index: var(--sl-z-index-dropdown);
  }

  .dropdown[data-current-placement^='top']::part(popup) {
    transform-origin: bottom;
  }

  .dropdown[data-current-placement^='bottom']::part(popup) {
    transform-origin: top;
  }

  .dropdown[data-current-placement^='left']::part(popup) {
    transform-origin: right;
  }

  .dropdown[data-current-placement^='right']::part(popup) {
    transform-origin: left;
  }

  .dropdown__trigger {
    display: block;
  }

  .dropdown__panel {
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-medium);
    font-weight: var(--sl-font-weight-normal);
    box-shadow: var(--sl-shadow-large);
    border-radius: var(--sl-border-radius-medium);
    pointer-events: none;
  }

  .dropdown--open .dropdown__panel {
    display: block;
    pointer-events: all;
  }

  /* When users slot a menu, make sure it conforms to the popup's auto-size */
  ::slotted(sl-menu) {
    max-width: var(--auto-size-available-width) !important;
    max-height: var(--auto-size-available-height) !important;
  }
`, Et = class extends K {
  constructor() {
    super(...arguments), this.localize = new be(this), this.open = !1, this.placement = "bottom-start", this.disabled = !1, this.stayOpenOnSelect = !1, this.distance = 0, this.skidding = 0, this.hoist = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.handlePanelSelect = this.handlePanelSelect.bind(this), this.handleKeyDown = this.handleKeyDown.bind(this), this.handleDocumentKeyDown = this.handleDocumentKeyDown.bind(this), this.handleDocumentMouseDown = this.handleDocumentMouseDown.bind(this), this.containingElement || (this.containingElement = this);
  }
  firstUpdated() {
    this.panel.hidden = !this.open, this.open && (this.addOpenListeners(), this.popup.active = !0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeOpenListeners(), this.hide();
  }
  focusOnTrigger() {
    const e = this.trigger.assignedElements({ flatten: !0 })[0];
    typeof e?.focus == "function" && e.focus();
  }
  getMenu() {
    return this.panel.assignedElements({ flatten: !0 }).find((e) => e.tagName.toLowerCase() === "sl-menu");
  }
  handleKeyDown(e) {
    this.open && e.key === "Escape" && (e.stopPropagation(), this.hide(), this.focusOnTrigger());
  }
  handleDocumentKeyDown(e) {
    var t;
    if (e.key === "Escape" && this.open) {
      e.stopPropagation(), this.focusOnTrigger(), this.hide();
      return;
    }
    if (e.key === "Tab") {
      if (this.open && ((t = document.activeElement) == null ? void 0 : t.tagName.toLowerCase()) === "sl-menu-item") {
        e.preventDefault(), this.hide(), this.focusOnTrigger();
        return;
      }
      setTimeout(() => {
        var A, i, s;
        const o = ((A = this.containingElement) == null ? void 0 : A.getRootNode()) instanceof ShadowRoot ? (s = (i = document.activeElement) == null ? void 0 : i.shadowRoot) == null ? void 0 : s.activeElement : document.activeElement;
        (!this.containingElement || o?.closest(this.containingElement.tagName.toLowerCase()) !== this.containingElement) && this.hide();
      });
    }
  }
  handleDocumentMouseDown(e) {
    const t = e.composedPath();
    this.containingElement && !t.includes(this.containingElement) && this.hide();
  }
  handlePanelSelect(e) {
    const t = e.target;
    !this.stayOpenOnSelect && t.tagName.toLowerCase() === "sl-menu" && (this.hide(), this.focusOnTrigger());
  }
  handleTriggerClick() {
    this.open ? this.hide() : (this.show(), this.focusOnTrigger());
  }
  handleTriggerKeyDown(e) {
    if ([" ", "Enter"].includes(e.key)) {
      e.preventDefault(), this.handleTriggerClick();
      return;
    }
    const t = this.getMenu();
    if (t) {
      const A = t.getAllItems(), i = A[0], s = A[A.length - 1];
      ["ArrowDown", "ArrowUp", "Home", "End"].includes(e.key) && (e.preventDefault(), this.open || this.show(), A.length > 0 && this.updateComplete.then(() => {
        (e.key === "ArrowDown" || e.key === "Home") && (t.setCurrentItem(i), i.focus()), (e.key === "ArrowUp" || e.key === "End") && (t.setCurrentItem(s), s.focus());
      }));
    }
  }
  handleTriggerKeyUp(e) {
    e.key === " " && e.preventDefault();
  }
  handleTriggerSlotChange() {
    this.updateAccessibleTrigger();
  }
  //
  // Slotted triggers can be arbitrary content, but we need to link them to the dropdown panel with `aria-haspopup` and
  // `aria-expanded`. These must be applied to the "accessible trigger" (the tabbable portion of the trigger element
  // that gets slotted in) so screen readers will understand them. The accessible trigger could be the slotted element,
  // a child of the slotted element, or an element in the slotted element's shadow root.
  //
  // For example, the accessible trigger of an <sl-button> is a <button> located inside its shadow root.
  //
  // To determine this, we assume the first tabbable element in the trigger slot is the "accessible trigger."
  //
  updateAccessibleTrigger() {
    const t = this.trigger.assignedElements({ flatten: !0 }).find((i) => yc(i).start);
    let A;
    if (t) {
      switch (t.tagName.toLowerCase()) {
        case "sl-button":
        case "sl-icon-button":
          A = t.button;
          break;
        default:
          A = t;
      }
      A.setAttribute("aria-haspopup", "true"), A.setAttribute("aria-expanded", this.open ? "true" : "false");
    }
  }
  /** Shows the dropdown panel. */
  async show() {
    if (!this.open)
      return this.open = !0, pe(this, "sl-after-show");
  }
  /** Hides the dropdown panel */
  async hide() {
    if (this.open)
      return this.open = !1, pe(this, "sl-after-hide");
  }
  /**
   * Instructs the dropdown menu to reposition. Useful when the position or size of the trigger changes when the menu
   * is activated.
   */
  reposition() {
    this.popup.reposition();
  }
  addOpenListeners() {
    this.panel.addEventListener("sl-select", this.handlePanelSelect), this.panel.addEventListener("keydown", this.handleKeyDown), document.addEventListener("keydown", this.handleDocumentKeyDown), document.addEventListener("mousedown", this.handleDocumentMouseDown);
  }
  removeOpenListeners() {
    this.panel && (this.panel.removeEventListener("sl-select", this.handlePanelSelect), this.panel.removeEventListener("keydown", this.handleKeyDown)), document.removeEventListener("keydown", this.handleDocumentKeyDown), document.removeEventListener("mousedown", this.handleDocumentMouseDown);
  }
  async handleOpenChange() {
    if (this.disabled) {
      this.open = !1;
      return;
    }
    if (this.updateAccessibleTrigger(), this.open) {
      this.emit("sl-show"), this.addOpenListeners(), await zt(this), this.panel.hidden = !1, this.popup.active = !0;
      const { keyframes: e, options: t } = Lt(this, "dropdown.show", { dir: this.localize.dir() });
      await Jt(this.popup.popup, e, t), this.emit("sl-after-show");
    } else {
      this.emit("sl-hide"), this.removeOpenListeners(), await zt(this);
      const { keyframes: e, options: t } = Lt(this, "dropdown.hide", { dir: this.localize.dir() });
      await Jt(this.popup.popup, e, t), this.panel.hidden = !0, this.popup.active = !1, this.emit("sl-after-hide");
    }
  }
  render() {
    return _`
      <sl-popup
        part="base"
        id="dropdown"
        placement=${this.placement}
        distance=${this.distance}
        skidding=${this.skidding}
        strategy=${this.hoist ? "fixed" : "absolute"}
        flip
        shift
        auto-size="vertical"
        auto-size-padding="10"
        class=${Qt({
      dropdown: !0,
      "dropdown--open": this.open
    })}
      >
        <slot
          name="trigger"
          slot="anchor"
          part="trigger"
          class="dropdown__trigger"
          @click=${this.handleTriggerClick}
          @keydown=${this.handleTriggerKeyDown}
          @keyup=${this.handleTriggerKeyUp}
          @slotchange=${this.handleTriggerSlotChange}
        ></slot>

        <slot
          part="panel"
          class="dropdown__panel"
          aria-hidden=${this.open ? "false" : "true"}
          aria-labelledby="dropdown"
        ></slot>
      </sl-popup>
    `;
  }
};
Et.styles = HQ;
I([
  X(".dropdown")
], Et.prototype, "popup", 2);
I([
  X(".dropdown__trigger")
], Et.prototype, "trigger", 2);
I([
  X(".dropdown__panel")
], Et.prototype, "panel", 2);
I([
  d({ type: Boolean, reflect: !0 })
], Et.prototype, "open", 2);
I([
  d({ reflect: !0 })
], Et.prototype, "placement", 2);
I([
  d({ type: Boolean, reflect: !0 })
], Et.prototype, "disabled", 2);
I([
  d({ attribute: "stay-open-on-select", type: Boolean, reflect: !0 })
], Et.prototype, "stayOpenOnSelect", 2);
I([
  d({ attribute: !1 })
], Et.prototype, "containingElement", 2);
I([
  d({ type: Number })
], Et.prototype, "distance", 2);
I([
  d({ type: Number })
], Et.prototype, "skidding", 2);
I([
  d({ type: Boolean })
], Et.prototype, "hoist", 2);
I([
  z("open", { waitUntilFirstUpdate: !0 })
], Et.prototype, "handleOpenChange", 1);
Et = I([
  st("sl-dropdown")
], Et);
Ot("dropdown.show", {
  keyframes: [
    { opacity: 0, scale: 0.9 },
    { opacity: 1, scale: 1 }
  ],
  options: { duration: 100, easing: "ease" }
});
Ot("dropdown.hide", {
  keyframes: [
    { opacity: 1, scale: 1 },
    { opacity: 0, scale: 0.9 }
  ],
  options: { duration: 100, easing: "ease" }
});
var _Q = V`
  ${it}

  :host {
    display: block;
    position: relative;
    background: var(--sl-panel-background-color);
    border: solid var(--sl-panel-border-width) var(--sl-panel-border-color);
    border-radius: var(--sl-border-radius-medium);
    padding: var(--sl-spacing-x-small) 0;
    overflow: auto;
    overscroll-behavior: none;
  }

  ::slotted(sl-divider) {
    --spacing: var(--sl-spacing-x-small);
  }
`, Ls = class extends K {
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "menu");
  }
  handleClick(e) {
    const A = e.target.closest("sl-menu-item");
    !A || A.disabled || A.inert || (A.type === "checkbox" && (A.checked = !A.checked), this.emit("sl-select", { detail: { item: A } }));
  }
  handleKeyDown(e) {
    if (e.key === "Enter") {
      const t = this.getCurrentItem();
      e.preventDefault(), t?.click();
    }
    if (e.key === " " && e.preventDefault(), ["ArrowDown", "ArrowUp", "Home", "End"].includes(e.key)) {
      const t = this.getAllItems(), A = this.getCurrentItem();
      let i = A ? t.indexOf(A) : 0;
      t.length > 0 && (e.preventDefault(), e.key === "ArrowDown" ? i++ : e.key === "ArrowUp" ? i-- : e.key === "Home" ? i = 0 : e.key === "End" && (i = t.length - 1), i < 0 && (i = t.length - 1), i > t.length - 1 && (i = 0), this.setCurrentItem(t[i]), t[i].focus());
    }
  }
  handleMouseDown(e) {
    const t = e.target;
    this.isMenuItem(t) && this.setCurrentItem(t);
  }
  handleSlotChange() {
    const e = this.getAllItems();
    e.length > 0 && this.setCurrentItem(e[0]);
  }
  isMenuItem(e) {
    var t;
    return e.tagName.toLowerCase() === "sl-menu-item" || ["menuitem", "menuitemcheckbox", "menuitemradio"].includes((t = e.getAttribute("role")) != null ? t : "");
  }
  /** @internal Gets all slotted menu items, ignoring dividers, headers, and other elements. */
  getAllItems() {
    return [...this.defaultSlot.assignedElements({ flatten: !0 })].filter((e) => !(e.inert || !this.isMenuItem(e)));
  }
  /**
   * @internal Gets the current menu item, which is the menu item that has `tabindex="0"` within the roving tab index.
   * The menu item may or may not have focus, but for keyboard interaction purposes it's considered the "active" item.
   */
  getCurrentItem() {
    return this.getAllItems().find((e) => e.getAttribute("tabindex") === "0");
  }
  /**
   * @internal Sets the current menu item to the specified element. This sets `tabindex="0"` on the target element and
   * `tabindex="-1"` to all other items. This method must be called prior to setting focus on a menu item.
   */
  setCurrentItem(e) {
    this.getAllItems().forEach((A) => {
      A.setAttribute("tabindex", A === e ? "0" : "-1");
    });
  }
  render() {
    return _`
      <slot
        @slotchange=${this.handleSlotChange}
        @click=${this.handleClick}
        @keydown=${this.handleKeyDown}
        @mousedown=${this.handleMouseDown}
      ></slot>
    `;
  }
};
Ls.styles = _Q;
I([
  X("slot")
], Ls.prototype, "defaultSlot", 2);
Ls = I([
  st("sl-menu")
], Ls);
var TQ = V`
  ${it}

  :host {
    display: block;
  }

  :host([inert]) {
    display: none;
  }

  .menu-item {
    position: relative;
    display: flex;
    align-items: stretch;
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-medium);
    font-weight: var(--sl-font-weight-normal);
    line-height: var(--sl-line-height-normal);
    letter-spacing: var(--sl-letter-spacing-normal);
    color: var(--sl-color-neutral-700);
    padding: var(--sl-spacing-2x-small) var(--sl-spacing-2x-small);
    transition: var(--sl-transition-fast) fill;
    user-select: none;
    white-space: nowrap;
    cursor: pointer;
  }

  .menu-item.menu-item--disabled {
    outline: none;
    opacity: 0.5;
    cursor: not-allowed;
  }

  .menu-item .menu-item__label {
    flex: 1 1 auto;
    display: inline-block;
  }

  .menu-item .menu-item__prefix {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
  }

  .menu-item .menu-item__prefix::slotted(*) {
    margin-inline-end: var(--sl-spacing-x-small);
  }

  .menu-item .menu-item__suffix {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
  }

  .menu-item .menu-item__suffix::slotted(*) {
    margin-inline-start: var(--sl-spacing-x-small);
  }

  :host(:focus-visible) {
    outline: none;
  }

  :host(:hover:not([aria-disabled='true'], :focus-visible)) .menu-item {
    background-color: var(--sl-color-neutral-100);
    color: var(--sl-color-neutral-1000);
  }

  :host(:focus-visible) .menu-item {
    outline: none;
    background-color: var(--sl-color-primary-600);
    color: var(--sl-color-neutral-0);
    opacity: 1;
  }

  .menu-item .menu-item__check,
  .menu-item .menu-item__chevron {
    flex: 0 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.5em;
    visibility: hidden;
  }

  .menu-item--checked .menu-item__check,
  .menu-item--has-submenu .menu-item__chevron {
    visibility: visible;
  }

  @media (forced-colors: active) {
    :host(:hover:not([aria-disabled='true'])) .menu-item,
    :host(:focus-visible) .menu-item {
      outline: dashed 1px SelectedItem;
      outline-offset: -1px;
    }
  }
`, Rt = class extends K {
  constructor() {
    super(...arguments), this.type = "normal", this.checked = !1, this.value = "", this.disabled = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.handleHostClick = this.handleHostClick.bind(this), this.addEventListener("click", this.handleHostClick);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeEventListener("click", this.handleHostClick);
  }
  handleDefaultSlotChange() {
    const e = this.getTextLabel();
    if (typeof this.cachedTextLabel > "u") {
      this.cachedTextLabel = e;
      return;
    }
    e !== this.cachedTextLabel && (this.cachedTextLabel = e, this.emit("slotchange", { bubbles: !0, composed: !1, cancelable: !1 }));
  }
  handleHostClick(e) {
    this.disabled && (e.preventDefault(), e.stopImmediatePropagation());
  }
  handleCheckedChange() {
    if (this.checked && this.type !== "checkbox") {
      this.checked = !1, console.error('The checked attribute can only be used on menu items with type="checkbox"', this);
      return;
    }
    this.type === "checkbox" ? this.setAttribute("aria-checked", this.checked ? "true" : "false") : this.removeAttribute("aria-checked");
  }
  handleDisabledChange() {
    this.setAttribute("aria-disabled", this.disabled ? "true" : "false");
  }
  handleTypeChange() {
    this.type === "checkbox" ? (this.setAttribute("role", "menuitemcheckbox"), this.setAttribute("aria-checked", this.checked ? "true" : "false")) : (this.setAttribute("role", "menuitem"), this.removeAttribute("aria-checked"));
  }
  /** Returns a text label based on the contents of the menu item's default slot. */
  getTextLabel() {
    return NQ(this.defaultSlot);
  }
  render() {
    return _`
      <div
        part="base"
        class=${Qt({
      "menu-item": !0,
      "menu-item--checked": this.checked,
      "menu-item--disabled": this.disabled,
      "menu-item--has-submenu": !1
      // reserved for future use
    })}
      >
        <span part="checked-icon" class="menu-item__check">
          <sl-icon name="check" library="system" aria-hidden="true"></sl-icon>
        </span>

        <slot name="prefix" part="prefix" class="menu-item__prefix"></slot>

        <slot part="label" class="menu-item__label" @slotchange=${this.handleDefaultSlotChange}></slot>

        <slot name="suffix" part="suffix" class="menu-item__suffix"></slot>

        <span class="menu-item__chevron">
          <sl-icon name="chevron-right" library="system" aria-hidden="true"></sl-icon>
        </span>
      </div>
    `;
  }
};
Rt.styles = TQ;
I([
  X("slot:not([name])")
], Rt.prototype, "defaultSlot", 2);
I([
  X(".menu-item")
], Rt.prototype, "menuItem", 2);
I([
  d()
], Rt.prototype, "type", 2);
I([
  d({ type: Boolean, reflect: !0 })
], Rt.prototype, "checked", 2);
I([
  d()
], Rt.prototype, "value", 2);
I([
  d({ type: Boolean, reflect: !0 })
], Rt.prototype, "disabled", 2);
I([
  z("checked")
], Rt.prototype, "handleCheckedChange", 1);
I([
  z("disabled")
], Rt.prototype, "handleDisabledChange", 1);
I([
  z("type")
], Rt.prototype, "handleTypeChange", 1);
Rt = I([
  st("sl-menu-item")
], Rt);
var OQ = V`
  ${it}

  :host {
    display: block;
  }

  .menu-label {
    display: inline-block;
    font-family: var(--sl-font-sans);
    font-size: var(--sl-font-size-small);
    font-weight: var(--sl-font-weight-semibold);
    line-height: var(--sl-line-height-normal);
    letter-spacing: var(--sl-letter-spacing-normal);
    color: var(--sl-color-neutral-500);
    padding: var(--sl-spacing-2x-small) var(--sl-spacing-x-large);
    user-select: none;
  }
`, Or = class extends K {
  render() {
    return _` <slot part="base" class="menu-label"></slot> `;
  }
};
Or.styles = OQ;
Or = I([
  st("sl-menu-label")
], Or);
var $Q = V`
  ${it}

  :host {
    --color: var(--sl-panel-border-color);
    --width: var(--sl-panel-border-width);
    --spacing: var(--sl-spacing-medium);
  }

  :host(:not([vertical])) {
    display: block;
    border-top: solid var(--width) var(--color);
    margin: var(--spacing) 0;
  }

  :host([vertical]) {
    display: inline-block;
    height: 100%;
    border-left: solid var(--width) var(--color);
    margin: 0 var(--spacing);
  }
`, mi = class extends K {
  constructor() {
    super(...arguments), this.vertical = !1;
  }
  connectedCallback() {
    super.connectedCallback(), this.setAttribute("role", "separator");
  }
  handleVerticalChange() {
    this.setAttribute("aria-orientation", this.vertical ? "vertical" : "horizontal");
  }
};
mi.styles = $Q;
I([
  d({ type: Boolean, reflect: !0 })
], mi.prototype, "vertical", 2);
I([
  z("vertical")
], mi.prototype, "handleVerticalChange", 1);
mi = I([
  st("sl-divider")
], mi);
const oe = function() {
  if (typeof globalThis < "u")
    return globalThis;
  if (typeof global < "u")
    return global;
  if (typeof self < "u")
    return self;
  if (typeof window < "u")
    return window;
  try {
    return new Function("return this")();
  } catch {
    return {};
  }
}();
oe.trustedTypes === void 0 && (oe.trustedTypes = { createPolicy: (e, t) => t });
const vc = {
  configurable: !1,
  enumerable: !1,
  writable: !1
};
oe.FAST === void 0 && Reflect.defineProperty(oe, "FAST", Object.assign({ value: /* @__PURE__ */ Object.create(null) }, vc));
const bi = oe.FAST;
if (bi.getById === void 0) {
  const e = /* @__PURE__ */ Object.create(null);
  Reflect.defineProperty(bi, "getById", Object.assign({ value(t, A) {
    let i = e[t];
    return i === void 0 && (i = A ? e[t] = A() : null), i;
  } }, vc));
}
const ds = Object.freeze([]);
function mc() {
  const e = /* @__PURE__ */ new WeakMap();
  return function(t) {
    let A = e.get(t);
    if (A === void 0) {
      let i = Reflect.getPrototypeOf(t);
      for (; A === void 0 && i !== null; )
        A = e.get(i), i = Reflect.getPrototypeOf(i);
      A = A === void 0 ? [] : A.slice(0), e.set(t, A);
    }
    return A;
  };
}
const Wo = oe.FAST.getById(1, () => {
  const e = [], t = [];
  function A() {
    if (t.length)
      throw t.shift();
  }
  function i(r) {
    try {
      r.call();
    } catch (n) {
      t.push(n), setTimeout(A, 0);
    }
  }
  function s() {
    let n = 0;
    for (; n < e.length; )
      if (i(e[n]), n++, n > 1024) {
        for (let l = 0, a = e.length - n; l < a; l++)
          e[l] = e[l + n];
        e.length -= n, n = 0;
      }
    e.length = 0;
  }
  function o(r) {
    e.length < 1 && oe.requestAnimationFrame(s), e.push(r);
  }
  return Object.freeze({
    enqueue: o,
    process: s
  });
}), bc = oe.trustedTypes.createPolicy("fast-html", {
  createHTML: (e) => e
});
let Xo = bc;
const Ii = `fast-${Math.random().toString(36).substring(2, 8)}`, Dc = `${Ii}{`, bn = `}${Ii}`, R = Object.freeze({
  /**
   * Indicates whether the DOM supports the adoptedStyleSheets feature.
   */
  supportsAdoptedStyleSheets: Array.isArray(document.adoptedStyleSheets) && "replace" in CSSStyleSheet.prototype,
  /**
   * Sets the HTML trusted types policy used by the templating engine.
   * @param policy - The policy to set for HTML.
   * @remarks
   * This API can only be called once, for security reasons. It should be
   * called by the application developer at the start of their program.
   */
  setHTMLPolicy(e) {
    if (Xo !== bc)
      throw new Error("The HTML policy can only be set once.");
    Xo = e;
  },
  /**
   * Turns a string into trusted HTML using the configured trusted types policy.
   * @param html - The string to turn into trusted HTML.
   * @remarks
   * Used internally by the template engine when creating templates
   * and setting innerHTML.
   */
  createHTML(e) {
    return Xo.createHTML(e);
  },
  /**
   * Determines if the provided node is a template marker used by the runtime.
   * @param node - The node to test.
   */
  isMarker(e) {
    return e && e.nodeType === 8 && e.data.startsWith(Ii);
  },
  /**
   * Given a marker node, extract the {@link HTMLDirective} index from the placeholder.
   * @param node - The marker node to extract the index from.
   */
  extractDirectiveIndexFromMarker(e) {
    return parseInt(e.data.replace(`${Ii}:`, ""));
  },
  /**
   * Creates a placeholder string suitable for marking out a location *within*
   * an attribute value or HTML content.
   * @param index - The directive index to create the placeholder for.
   * @remarks
   * Used internally by binding directives.
   */
  createInterpolationPlaceholder(e) {
    return `${Dc}${e}${bn}`;
  },
  /**
   * Creates a placeholder that manifests itself as an attribute on an
   * element.
   * @param attributeName - The name of the custom attribute.
   * @param index - The directive index to create the placeholder for.
   * @remarks
   * Used internally by attribute directives such as `ref`, `slotted`, and `children`.
   */
  createCustomAttributePlaceholder(e, t) {
    return `${e}="${this.createInterpolationPlaceholder(t)}"`;
  },
  /**
   * Creates a placeholder that manifests itself as a marker within the DOM structure.
   * @param index - The directive index to create the placeholder for.
   * @remarks
   * Used internally by structural directives such as `repeat`.
   */
  createBlockPlaceholder(e) {
    return `<!--${Ii}:${e}-->`;
  },
  /**
   * Schedules DOM update work in the next async batch.
   * @param callable - The callable function or object to queue.
   */
  queueUpdate: Wo.enqueue,
  /**
   * Immediately processes all work previously scheduled
   * through queueUpdate.
   * @remarks
   * This also forces nextUpdate promises
   * to resolve.
   */
  processUpdates: Wo.process,
  /**
   * Resolves with the next DOM update.
   */
  nextUpdate() {
    return new Promise(Wo.enqueue);
  },
  /**
   * Sets an attribute value on an element.
   * @param element - The element to set the attribute value on.
   * @param attributeName - The attribute name to set.
   * @param value - The value of the attribute to set.
   * @remarks
   * If the value is `null` or `undefined`, the attribute is removed, otherwise
   * it is set to the provided value using the standard `setAttribute` API.
   */
  setAttribute(e, t, A) {
    A == null ? e.removeAttribute(t) : e.setAttribute(t, A);
  },
  /**
   * Sets a boolean attribute value.
   * @param element - The element to set the boolean attribute value on.
   * @param attributeName - The attribute name to set.
   * @param value - The value of the attribute to set.
   * @remarks
   * If the value is true, the attribute is added; otherwise it is removed.
   */
  setBooleanAttribute(e, t, A) {
    A ? e.setAttribute(t, "") : e.removeAttribute(t);
  },
  /**
   * Removes all the child nodes of the provided parent node.
   * @param parent - The node to remove the children from.
   */
  removeChildNodes(e) {
    for (let t = e.firstChild; t !== null; t = e.firstChild)
      e.removeChild(t);
  },
  /**
   * Creates a TreeWalker configured to walk a template fragment.
   * @param fragment - The fragment to walk.
   */
  createTemplateWalker(e) {
    return document.createTreeWalker(
      e,
      133,
      // element, text, comment
      null,
      !1
    );
  }
});
class $r {
  /**
   * Creates an instance of SubscriberSet for the specified source.
   * @param source - The object source that subscribers will receive notifications from.
   * @param initialSubscriber - An initial subscriber to changes.
   */
  constructor(t, A) {
    this.sub1 = void 0, this.sub2 = void 0, this.spillover = void 0, this.source = t, this.sub1 = A;
  }
  /**
   * Checks whether the provided subscriber has been added to this set.
   * @param subscriber - The subscriber to test for inclusion in this set.
   */
  has(t) {
    return this.spillover === void 0 ? this.sub1 === t || this.sub2 === t : this.spillover.indexOf(t) !== -1;
  }
  /**
   * Subscribes to notification of changes in an object's state.
   * @param subscriber - The object that is subscribing for change notification.
   */
  subscribe(t) {
    const A = this.spillover;
    if (A === void 0) {
      if (this.has(t))
        return;
      if (this.sub1 === void 0) {
        this.sub1 = t;
        return;
      }
      if (this.sub2 === void 0) {
        this.sub2 = t;
        return;
      }
      this.spillover = [this.sub1, this.sub2, t], this.sub1 = void 0, this.sub2 = void 0;
    } else
      A.indexOf(t) === -1 && A.push(t);
  }
  /**
   * Unsubscribes from notification of changes in an object's state.
   * @param subscriber - The object that is unsubscribing from change notification.
   */
  unsubscribe(t) {
    const A = this.spillover;
    if (A === void 0)
      this.sub1 === t ? this.sub1 = void 0 : this.sub2 === t && (this.sub2 = void 0);
    else {
      const i = A.indexOf(t);
      i !== -1 && A.splice(i, 1);
    }
  }
  /**
   * Notifies all subscribers.
   * @param args - Data passed along to subscribers during notification.
   */
  notify(t) {
    const A = this.spillover, i = this.source;
    if (A === void 0) {
      const s = this.sub1, o = this.sub2;
      s !== void 0 && s.handleChange(i, t), o !== void 0 && o.handleChange(i, t);
    } else
      for (let s = 0, o = A.length; s < o; ++s)
        A[s].handleChange(i, t);
  }
}
class kc {
  /**
   * Creates an instance of PropertyChangeNotifier for the specified source.
   * @param source - The object source that subscribers will receive notifications from.
   */
  constructor(t) {
    this.subscribers = {}, this.sourceSubscribers = null, this.source = t;
  }
  /**
   * Notifies all subscribers, based on the specified property.
   * @param propertyName - The property name, passed along to subscribers during notification.
   */
  notify(t) {
    var A;
    const i = this.subscribers[t];
    i !== void 0 && i.notify(t), (A = this.sourceSubscribers) === null || A === void 0 || A.notify(t);
  }
  /**
   * Subscribes to notification of changes in an object's state.
   * @param subscriber - The object that is subscribing for change notification.
   * @param propertyToWatch - The name of the property that the subscriber is interested in watching for changes.
   */
  subscribe(t, A) {
    var i;
    if (A) {
      let s = this.subscribers[A];
      s === void 0 && (this.subscribers[A] = s = new $r(this.source)), s.subscribe(t);
    } else
      this.sourceSubscribers = (i = this.sourceSubscribers) !== null && i !== void 0 ? i : new $r(this.source), this.sourceSubscribers.subscribe(t);
  }
  /**
   * Unsubscribes from notification of changes in an object's state.
   * @param subscriber - The object that is unsubscribing from change notification.
   * @param propertyToUnwatch - The name of the property that the subscriber is no longer interested in watching.
   */
  unsubscribe(t, A) {
    var i;
    if (A) {
      const s = this.subscribers[A];
      s !== void 0 && s.unsubscribe(t);
    } else
      (i = this.sourceSubscribers) === null || i === void 0 || i.unsubscribe(t);
  }
}
const At = bi.getById(2, () => {
  const e = /(:|&&|\|\||if)/, t = /* @__PURE__ */ new WeakMap(), A = R.queueUpdate;
  let i, s = (a) => {
    throw new Error("Must call enableArrayObservation before observing arrays.");
  };
  function o(a) {
    let c = a.$fastController || t.get(a);
    return c === void 0 && (Array.isArray(a) ? c = s(a) : t.set(a, c = new kc(a))), c;
  }
  const r = mc();
  class n {
    constructor(c) {
      this.name = c, this.field = `_${c}`, this.callback = `${c}Changed`;
    }
    getValue(c) {
      return i !== void 0 && i.watch(c, this.name), c[this.field];
    }
    setValue(c, g) {
      const h = this.field, u = c[h];
      if (u !== g) {
        c[h] = g;
        const C = c[this.callback];
        typeof C == "function" && C.call(c, u, g), o(c).notify(this.name);
      }
    }
  }
  class l extends $r {
    constructor(c, g, h = !1) {
      super(c, g), this.binding = c, this.isVolatileBinding = h, this.needsRefresh = !0, this.needsQueue = !0, this.first = this, this.last = null, this.propertySource = void 0, this.propertyName = void 0, this.notifier = void 0, this.next = void 0;
    }
    observe(c, g) {
      this.needsRefresh && this.last !== null && this.disconnect();
      const h = i;
      i = this.needsRefresh ? this : void 0, this.needsRefresh = this.isVolatileBinding;
      const u = this.binding(c, g);
      return i = h, u;
    }
    disconnect() {
      if (this.last !== null) {
        let c = this.first;
        for (; c !== void 0; )
          c.notifier.unsubscribe(this, c.propertyName), c = c.next;
        this.last = null, this.needsRefresh = this.needsQueue = !0;
      }
    }
    watch(c, g) {
      const h = this.last, u = o(c), C = h === null ? this.first : {};
      if (C.propertySource = c, C.propertyName = g, C.notifier = u, u.subscribe(this, g), h !== null) {
        if (!this.needsRefresh) {
          let B;
          i = void 0, B = h.propertySource[h.propertyName], i = this, c === B && (this.needsRefresh = !0);
        }
        h.next = C;
      }
      this.last = C;
    }
    handleChange() {
      this.needsQueue && (this.needsQueue = !1, A(this));
    }
    call() {
      this.last !== null && (this.needsQueue = !0, this.notify(this));
    }
    records() {
      let c = this.first;
      return {
        next: () => {
          const g = c;
          return g === void 0 ? { value: void 0, done: !0 } : (c = c.next, {
            value: g,
            done: !1
          });
        },
        [Symbol.iterator]: function() {
          return this;
        }
      };
    }
  }
  return Object.freeze({
    /**
     * @internal
     * @param factory - The factory used to create array observers.
     */
    setArrayObserverFactory(a) {
      s = a;
    },
    /**
     * Gets a notifier for an object or Array.
     * @param source - The object or Array to get the notifier for.
     */
    getNotifier: o,
    /**
     * Records a property change for a source object.
     * @param source - The object to record the change against.
     * @param propertyName - The property to track as changed.
     */
    track(a, c) {
      i !== void 0 && i.watch(a, c);
    },
    /**
     * Notifies watchers that the currently executing property getter or function is volatile
     * with respect to its observable dependencies.
     */
    trackVolatile() {
      i !== void 0 && (i.needsRefresh = !0);
    },
    /**
     * Notifies subscribers of a source object of changes.
     * @param source - the object to notify of changes.
     * @param args - The change args to pass to subscribers.
     */
    notify(a, c) {
      o(a).notify(c);
    },
    /**
     * Defines an observable property on an object or prototype.
     * @param target - The target object to define the observable on.
     * @param nameOrAccessor - The name of the property to define as observable;
     * or a custom accessor that specifies the property name and accessor implementation.
     */
    defineProperty(a, c) {
      typeof c == "string" && (c = new n(c)), r(a).push(c), Reflect.defineProperty(a, c.name, {
        enumerable: !0,
        get: function() {
          return c.getValue(this);
        },
        set: function(g) {
          c.setValue(this, g);
        }
      });
    },
    /**
     * Finds all the observable accessors defined on the target,
     * including its prototype chain.
     * @param target - The target object to search for accessor on.
     */
    getAccessors: r,
    /**
     * Creates a {@link BindingObserver} that can watch the
     * provided {@link Binding} for changes.
     * @param binding - The binding to observe.
     * @param initialSubscriber - An initial subscriber to changes in the binding value.
     * @param isVolatileBinding - Indicates whether the binding's dependency list must be re-evaluated on every value evaluation.
     */
    binding(a, c, g = this.isVolatileBinding(a)) {
      return new l(a, c, g);
    },
    /**
     * Determines whether a binding expression is volatile and needs to have its dependency list re-evaluated
     * on every evaluation of the value.
     * @param binding - The binding to inspect.
     */
    isVolatileBinding(a) {
      return e.test(a.toString());
    }
  });
});
function mt(e, t) {
  At.defineProperty(e, t);
}
const fl = bi.getById(3, () => {
  let e = null;
  return {
    get() {
      return e;
    },
    set(t) {
      e = t;
    }
  };
});
class Di {
  constructor() {
    this.index = 0, this.length = 0, this.parent = null, this.parentContext = null;
  }
  /**
   * The current event within an event handler.
   */
  get event() {
    return fl.get();
  }
  /**
   * Indicates whether the current item within a repeat context
   * has an even index.
   */
  get isEven() {
    return this.index % 2 === 0;
  }
  /**
   * Indicates whether the current item within a repeat context
   * has an odd index.
   */
  get isOdd() {
    return this.index % 2 !== 0;
  }
  /**
   * Indicates whether the current item within a repeat context
   * is the first item in the collection.
   */
  get isFirst() {
    return this.index === 0;
  }
  /**
   * Indicates whether the current item within a repeat context
   * is somewhere in the middle of the collection.
   */
  get isInMiddle() {
    return !this.isFirst && !this.isLast;
  }
  /**
   * Indicates whether the current item within a repeat context
   * is the last item in the collection.
   */
  get isLast() {
    return this.index === this.length - 1;
  }
  /**
   * Sets the event for the current execution context.
   * @param event - The event to set.
   * @internal
   */
  static setEvent(t) {
    fl.set(t);
  }
}
At.defineProperty(Di.prototype, "index");
At.defineProperty(Di.prototype, "length");
const ui = Object.seal(new Di());
class Dn {
  constructor() {
    this.targetIndex = 0;
  }
}
class Sc extends Dn {
  constructor() {
    super(...arguments), this.createPlaceholder = R.createInterpolationPlaceholder;
  }
}
class xc extends Dn {
  /**
   *
   * @param name - The name of the behavior; used as a custom attribute on the element.
   * @param behavior - The behavior to instantiate and attach to the element.
   * @param options - Options to pass to the behavior during creation.
   */
  constructor(t, A, i) {
    super(), this.name = t, this.behavior = A, this.options = i;
  }
  /**
   * Creates a placeholder string based on the directive's index within the template.
   * @param index - The index of the directive within the template.
   * @remarks
   * Creates a custom attribute placeholder.
   */
  createPlaceholder(t) {
    return R.createCustomAttributePlaceholder(this.name, t);
  }
  /**
   * Creates a behavior for the provided target node.
   * @param target - The node instance to create the behavior for.
   * @remarks
   * Creates an instance of the `behavior` type this directive was constructed with
   * and passes the target and options to that `behavior`'s constructor.
   */
  createBehavior(t) {
    return new this.behavior(t, this.options);
  }
}
function PQ(e, t) {
  this.source = e, this.context = t, this.bindingObserver === null && (this.bindingObserver = At.binding(this.binding, this, this.isBindingVolatile)), this.updateTarget(this.bindingObserver.observe(e, t));
}
function qQ(e, t) {
  this.source = e, this.context = t, this.target.addEventListener(this.targetName, this);
}
function VQ() {
  this.bindingObserver.disconnect(), this.source = null, this.context = null;
}
function zQ() {
  this.bindingObserver.disconnect(), this.source = null, this.context = null;
  const e = this.target.$fastView;
  e !== void 0 && e.isComposed && (e.unbind(), e.needsBindOnly = !0);
}
function KQ() {
  this.target.removeEventListener(this.targetName, this), this.source = null, this.context = null;
}
function jQ(e) {
  R.setAttribute(this.target, this.targetName, e);
}
function ZQ(e) {
  R.setBooleanAttribute(this.target, this.targetName, e);
}
function WQ(e) {
  if (e == null && (e = ""), e.create) {
    this.target.textContent = "";
    let t = this.target.$fastView;
    t === void 0 ? t = e.create() : this.target.$fastTemplate !== e && (t.isComposed && (t.remove(), t.unbind()), t = e.create()), t.isComposed ? t.needsBindOnly && (t.needsBindOnly = !1, t.bind(this.source, this.context)) : (t.isComposed = !0, t.bind(this.source, this.context), t.insertBefore(this.target), this.target.$fastView = t, this.target.$fastTemplate = e);
  } else {
    const t = this.target.$fastView;
    t !== void 0 && t.isComposed && (t.isComposed = !1, t.remove(), t.needsBindOnly ? t.needsBindOnly = !1 : t.unbind()), this.target.textContent = e;
  }
}
function XQ(e) {
  this.target[this.targetName] = e;
}
function tE(e) {
  const t = this.classVersions || /* @__PURE__ */ Object.create(null), A = this.target;
  let i = this.version || 0;
  if (e != null && e.length) {
    const s = e.split(/\s+/);
    for (let o = 0, r = s.length; o < r; ++o) {
      const n = s[o];
      n !== "" && (t[n] = i, A.classList.add(n));
    }
  }
  if (this.classVersions = t, this.version = i + 1, i !== 0) {
    i -= 1;
    for (const s in t)
      t[s] === i && A.classList.remove(s);
  }
}
class kn extends Sc {
  /**
   * Creates an instance of BindingDirective.
   * @param binding - A binding that returns the data used to update the DOM.
   */
  constructor(t) {
    super(), this.binding = t, this.bind = PQ, this.unbind = VQ, this.updateTarget = jQ, this.isBindingVolatile = At.isVolatileBinding(this.binding);
  }
  /**
   * Gets/sets the name of the attribute or property that this
   * binding is targeting.
   */
  get targetName() {
    return this.originalTargetName;
  }
  set targetName(t) {
    if (this.originalTargetName = t, t !== void 0)
      switch (t[0]) {
        case ":":
          if (this.cleanedTargetName = t.substr(1), this.updateTarget = XQ, this.cleanedTargetName === "innerHTML") {
            const A = this.binding;
            this.binding = (i, s) => R.createHTML(A(i, s));
          }
          break;
        case "?":
          this.cleanedTargetName = t.substr(1), this.updateTarget = ZQ;
          break;
        case "@":
          this.cleanedTargetName = t.substr(1), this.bind = qQ, this.unbind = KQ;
          break;
        default:
          this.cleanedTargetName = t, t === "class" && (this.updateTarget = tE);
          break;
      }
  }
  /**
   * Makes this binding target the content of an element rather than
   * a particular attribute or property.
   */
  targetAtContent() {
    this.updateTarget = WQ, this.unbind = zQ;
  }
  /**
   * Creates the runtime BindingBehavior instance based on the configuration
   * information stored in the BindingDirective.
   * @param target - The target node that the binding behavior should attach to.
   */
  createBehavior(t) {
    return new eE(t, this.binding, this.isBindingVolatile, this.bind, this.unbind, this.updateTarget, this.cleanedTargetName);
  }
}
class eE {
  /**
   * Creates an instance of BindingBehavior.
   * @param target - The target of the data updates.
   * @param binding - The binding that returns the latest value for an update.
   * @param isBindingVolatile - Indicates whether the binding has volatile dependencies.
   * @param bind - The operation to perform during binding.
   * @param unbind - The operation to perform during unbinding.
   * @param updateTarget - The operation to perform when updating.
   * @param targetName - The name of the target attribute or property to update.
   */
  constructor(t, A, i, s, o, r, n) {
    this.source = null, this.context = null, this.bindingObserver = null, this.target = t, this.binding = A, this.isBindingVolatile = i, this.bind = s, this.unbind = o, this.updateTarget = r, this.targetName = n;
  }
  /** @internal */
  handleChange() {
    this.updateTarget(this.bindingObserver.observe(this.source, this.context));
  }
  /** @internal */
  handleEvent(t) {
    Di.setEvent(t);
    const A = this.binding(this.source, this.context);
    Di.setEvent(null), A !== !0 && t.preventDefault();
  }
}
let tr = null;
class Sn {
  addFactory(t) {
    t.targetIndex = this.targetIndex, this.behaviorFactories.push(t);
  }
  captureContentBinding(t) {
    t.targetAtContent(), this.addFactory(t);
  }
  reset() {
    this.behaviorFactories = [], this.targetIndex = -1;
  }
  release() {
    tr = this;
  }
  static borrow(t) {
    const A = tr || new Sn();
    return A.directives = t, A.reset(), tr = null, A;
  }
}
function AE(e) {
  if (e.length === 1)
    return e[0];
  let t;
  const A = e.length, i = e.map((r) => typeof r == "string" ? () => r : (t = r.targetName || t, r.binding)), s = (r, n) => {
    let l = "";
    for (let a = 0; a < A; ++a)
      l += i[a](r, n);
    return l;
  }, o = new kn(s);
  return o.targetName = t, o;
}
const iE = bn.length;
function Nc(e, t) {
  const A = t.split(Dc);
  if (A.length === 1)
    return null;
  const i = [];
  for (let s = 0, o = A.length; s < o; ++s) {
    const r = A[s], n = r.indexOf(bn);
    let l;
    if (n === -1)
      l = r;
    else {
      const a = parseInt(r.substring(0, n));
      i.push(e.directives[a]), l = r.substring(n + iE);
    }
    l !== "" && i.push(l);
  }
  return i;
}
function pl(e, t, A = !1) {
  const i = t.attributes;
  for (let s = 0, o = i.length; s < o; ++s) {
    const r = i[s], n = r.value, l = Nc(e, n);
    let a = null;
    l === null ? A && (a = new kn(() => n), a.targetName = r.name) : a = AE(l), a !== null && (t.removeAttributeNode(r), s--, o--, e.addFactory(a));
  }
}
function sE(e, t, A) {
  const i = Nc(e, t.textContent);
  if (i !== null) {
    let s = t;
    for (let o = 0, r = i.length; o < r; ++o) {
      const n = i[o], l = o === 0 ? t : s.parentNode.insertBefore(document.createTextNode(""), s.nextSibling);
      typeof n == "string" ? l.textContent = n : (l.textContent = " ", e.captureContentBinding(n)), s = l, e.targetIndex++, l !== t && A.nextNode();
    }
    e.targetIndex--;
  }
}
function oE(e, t) {
  const A = e.content;
  document.adoptNode(A);
  const i = Sn.borrow(t);
  pl(i, e, !0);
  const s = i.behaviorFactories;
  i.reset();
  const o = R.createTemplateWalker(A);
  let r;
  for (; r = o.nextNode(); )
    switch (i.targetIndex++, r.nodeType) {
      case 1:
        pl(i, r);
        break;
      case 3:
        sE(i, r, o);
        break;
      case 8:
        R.isMarker(r) && i.addFactory(t[R.extractDirectiveIndexFromMarker(r)]);
    }
  let n = 0;
  // If the first node in a fragment is a marker, that means it's an unstable first node,
  // because something like a when, repeat, etc. could add nodes before the marker.
  // To mitigate this, we insert a stable first node. However, if we insert a node,
  // that will alter the result of the TreeWalker. So, we also need to offset the target index.
  (R.isMarker(A.firstChild) || // Or if there is only one node and a directive, it means the template's content
  // is *only* the directive. In that case, HTMLView.dispose() misses any nodes inserted by
  // the directive. Inserting a new node ensures proper disposal of nodes added by the directive.
  A.childNodes.length === 1 && t.length) && (A.insertBefore(document.createComment(""), A.firstChild), n = -1);
  const l = i.behaviorFactories;
  return i.release(), {
    fragment: A,
    viewBehaviorFactories: l,
    hostBehaviorFactories: s,
    targetOffset: n
  };
}
const er = document.createRange();
class rE {
  /**
   * Constructs an instance of HTMLView.
   * @param fragment - The html fragment that contains the nodes for this view.
   * @param behaviors - The behaviors to be applied to this view.
   */
  constructor(t, A) {
    this.fragment = t, this.behaviors = A, this.source = null, this.context = null, this.firstChild = t.firstChild, this.lastChild = t.lastChild;
  }
  /**
   * Appends the view's DOM nodes to the referenced node.
   * @param node - The parent node to append the view's DOM nodes to.
   */
  appendTo(t) {
    t.appendChild(this.fragment);
  }
  /**
   * Inserts the view's DOM nodes before the referenced node.
   * @param node - The node to insert the view's DOM before.
   */
  insertBefore(t) {
    if (this.fragment.hasChildNodes())
      t.parentNode.insertBefore(this.fragment, t);
    else {
      const A = this.lastChild;
      if (t.previousSibling === A)
        return;
      const i = t.parentNode;
      let s = this.firstChild, o;
      for (; s !== A; )
        o = s.nextSibling, i.insertBefore(s, t), s = o;
      i.insertBefore(A, t);
    }
  }
  /**
   * Removes the view's DOM nodes.
   * The nodes are not disposed and the view can later be re-inserted.
   */
  remove() {
    const t = this.fragment, A = this.lastChild;
    let i = this.firstChild, s;
    for (; i !== A; )
      s = i.nextSibling, t.appendChild(i), i = s;
    t.appendChild(A);
  }
  /**
   * Removes the view and unbinds its behaviors, disposing of DOM nodes afterward.
   * Once a view has been disposed, it cannot be inserted or bound again.
   */
  dispose() {
    const t = this.firstChild.parentNode, A = this.lastChild;
    let i = this.firstChild, s;
    for (; i !== A; )
      s = i.nextSibling, t.removeChild(i), i = s;
    t.removeChild(A);
    const o = this.behaviors, r = this.source;
    for (let n = 0, l = o.length; n < l; ++n)
      o[n].unbind(r);
  }
  /**
   * Binds a view's behaviors to its binding source.
   * @param source - The binding source for the view's binding behaviors.
   * @param context - The execution context to run the behaviors within.
   */
  bind(t, A) {
    const i = this.behaviors;
    if (this.source !== t)
      if (this.source !== null) {
        const s = this.source;
        this.source = t, this.context = A;
        for (let o = 0, r = i.length; o < r; ++o) {
          const n = i[o];
          n.unbind(s), n.bind(t, A);
        }
      } else {
        this.source = t, this.context = A;
        for (let s = 0, o = i.length; s < o; ++s)
          i[s].bind(t, A);
      }
  }
  /**
   * Unbinds a view's behaviors from its binding source.
   */
  unbind() {
    if (this.source === null)
      return;
    const t = this.behaviors, A = this.source;
    for (let i = 0, s = t.length; i < s; ++i)
      t[i].unbind(A);
    this.source = null;
  }
  /**
   * Efficiently disposes of a contiguous range of synthetic view instances.
   * @param views - A contiguous range of views to be disposed.
   */
  static disposeContiguousBatch(t) {
    if (t.length !== 0) {
      er.setStartBefore(t[0].firstChild), er.setEndAfter(t[t.length - 1].lastChild), er.deleteContents();
      for (let A = 0, i = t.length; A < i; ++A) {
        const s = t[A], o = s.behaviors, r = s.source;
        for (let n = 0, l = o.length; n < l; ++n)
          o[n].unbind(r);
      }
    }
  }
}
class wl {
  /**
   * Creates an instance of ViewTemplate.
   * @param html - The html representing what this template will instantiate, including placeholders for directives.
   * @param directives - The directives that will be connected to placeholders in the html.
   */
  constructor(t, A) {
    this.behaviorCount = 0, this.hasHostBehaviors = !1, this.fragment = null, this.targetOffset = 0, this.viewBehaviorFactories = null, this.hostBehaviorFactories = null, this.html = t, this.directives = A;
  }
  /**
   * Creates an HTMLView instance based on this template definition.
   * @param hostBindingTarget - The element that host behaviors will be bound to.
   */
  create(t) {
    if (this.fragment === null) {
      let a;
      const c = this.html;
      if (typeof c == "string") {
        a = document.createElement("template"), a.innerHTML = R.createHTML(c);
        const h = a.content.firstElementChild;
        h !== null && h.tagName === "TEMPLATE" && (a = h);
      } else
        a = c;
      const g = oE(a, this.directives);
      this.fragment = g.fragment, this.viewBehaviorFactories = g.viewBehaviorFactories, this.hostBehaviorFactories = g.hostBehaviorFactories, this.targetOffset = g.targetOffset, this.behaviorCount = this.viewBehaviorFactories.length + this.hostBehaviorFactories.length, this.hasHostBehaviors = this.hostBehaviorFactories.length > 0;
    }
    const A = this.fragment.cloneNode(!0), i = this.viewBehaviorFactories, s = new Array(this.behaviorCount), o = R.createTemplateWalker(A);
    let r = 0, n = this.targetOffset, l = o.nextNode();
    for (let a = i.length; r < a; ++r) {
      const c = i[r], g = c.targetIndex;
      for (; l !== null; )
        if (n === g) {
          s[r] = c.createBehavior(l);
          break;
        } else
          l = o.nextNode(), n++;
    }
    if (this.hasHostBehaviors) {
      const a = this.hostBehaviorFactories;
      for (let c = 0, g = a.length; c < g; ++c, ++r)
        s[r] = a[c].createBehavior(t);
    }
    return new rE(A, s);
  }
  /**
   * Creates an HTMLView from this template, binds it to the source, and then appends it to the host.
   * @param source - The data source to bind the template to.
   * @param host - The Element where the template will be rendered.
   * @param hostBindingTarget - An HTML element to target the host bindings at if different from the
   * host that the template is being attached to.
   */
  render(t, A, i) {
    typeof A == "string" && (A = document.getElementById(A)), i === void 0 && (i = A);
    const s = this.create(i);
    return s.bind(t, ui), s.appendTo(A), s;
  }
}
const nE = (
  /* eslint-disable-next-line no-control-regex */
  /([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/
);
function Vt(e, ...t) {
  const A = [];
  let i = "";
  for (let s = 0, o = e.length - 1; s < o; ++s) {
    const r = e[s];
    let n = t[s];
    if (i += r, n instanceof wl) {
      const l = n;
      n = () => l;
    }
    if (typeof n == "function" && (n = new kn(n)), n instanceof Sc) {
      const l = nE.exec(r);
      l !== null && (n.targetName = l[2]);
    }
    n instanceof Dn ? (i += n.createPlaceholder(A.length), A.push(n)) : i += n;
  }
  return i += e[e.length - 1], new wl(i, A);
}
class Ct {
  constructor() {
    this.targets = /* @__PURE__ */ new WeakSet();
  }
  /** @internal */
  addStylesTo(t) {
    this.targets.add(t);
  }
  /** @internal */
  removeStylesFrom(t) {
    this.targets.delete(t);
  }
  /** @internal */
  isAttachedTo(t) {
    return this.targets.has(t);
  }
  /**
   * Associates behaviors with this set of styles.
   * @param behaviors - The behaviors to associate.
   */
  withBehaviors(...t) {
    return this.behaviors = this.behaviors === null ? t : this.behaviors.concat(t), this;
  }
}
Ct.create = (() => {
  if (R.supportsAdoptedStyleSheets) {
    const e = /* @__PURE__ */ new Map();
    return (t) => (
      // eslint-disable-next-line @typescript-eslint/no-use-before-define
      new aE(t, e)
    );
  }
  return (e) => new cE(e);
})();
function xn(e) {
  return e.map((t) => t instanceof Ct ? xn(t.styles) : [t]).reduce((t, A) => t.concat(A), []);
}
function Fc(e) {
  return e.map((t) => t instanceof Ct ? t.behaviors : null).reduce((t, A) => A === null ? t : (t === null && (t = []), t.concat(A)), null);
}
let Rc = (e, t) => {
  e.adoptedStyleSheets = [...e.adoptedStyleSheets, ...t];
}, Uc = (e, t) => {
  e.adoptedStyleSheets = e.adoptedStyleSheets.filter((A) => t.indexOf(A) === -1);
};
if (R.supportsAdoptedStyleSheets)
  try {
    document.adoptedStyleSheets.push(), document.adoptedStyleSheets.splice(), Rc = (e, t) => {
      e.adoptedStyleSheets.push(...t);
    }, Uc = (e, t) => {
      for (const A of t) {
        const i = e.adoptedStyleSheets.indexOf(A);
        i !== -1 && e.adoptedStyleSheets.splice(i, 1);
      }
    };
  } catch {
  }
class aE extends Ct {
  constructor(t, A) {
    super(), this.styles = t, this.styleSheetCache = A, this._styleSheets = void 0, this.behaviors = Fc(t);
  }
  get styleSheets() {
    if (this._styleSheets === void 0) {
      const t = this.styles, A = this.styleSheetCache;
      this._styleSheets = xn(t).map((i) => {
        if (i instanceof CSSStyleSheet)
          return i;
        let s = A.get(i);
        return s === void 0 && (s = new CSSStyleSheet(), s.replaceSync(i), A.set(i, s)), s;
      });
    }
    return this._styleSheets;
  }
  addStylesTo(t) {
    Rc(t, this.styleSheets), super.addStylesTo(t);
  }
  removeStylesFrom(t) {
    Uc(t, this.styleSheets), super.removeStylesFrom(t);
  }
}
let lE = 0;
function gE() {
  return `fast-style-class-${++lE}`;
}
class cE extends Ct {
  constructor(t) {
    super(), this.styles = t, this.behaviors = null, this.behaviors = Fc(t), this.styleSheets = xn(t), this.styleClass = gE();
  }
  addStylesTo(t) {
    const A = this.styleSheets, i = this.styleClass;
    t = this.normalizeTarget(t);
    for (let s = 0; s < A.length; s++) {
      const o = document.createElement("style");
      o.innerHTML = A[s], o.className = i, t.append(o);
    }
    super.addStylesTo(t);
  }
  removeStylesFrom(t) {
    t = this.normalizeTarget(t);
    const A = t.querySelectorAll(`.${this.styleClass}`);
    for (let i = 0, s = A.length; i < s; ++i)
      t.removeChild(A[i]);
    super.removeStylesFrom(t);
  }
  isAttachedTo(t) {
    return super.isAttachedTo(this.normalizeTarget(t));
  }
  normalizeTarget(t) {
    return t === document ? document.body : t;
  }
}
const Js = Object.freeze({
  /**
   * Locates all attribute configurations associated with a type.
   */
  locate: mc()
}), hE = {
  toView(e) {
    return e ? "true" : "false";
  },
  fromView(e) {
    return !(e == null || e === "false" || e === !1 || e === 0);
  }
};
class Ys {
  /**
   * Creates an instance of AttributeDefinition.
   * @param Owner - The class constructor that owns this attribute.
   * @param name - The name of the property associated with the attribute.
   * @param attribute - The name of the attribute in HTML.
   * @param mode - The {@link AttributeMode} that describes the behavior of this attribute.
   * @param converter - A {@link ValueConverter} that integrates with the property getter/setter
   * to convert values to and from a DOM string.
   */
  constructor(t, A, i = A.toLowerCase(), s = "reflect", o) {
    this.guards = /* @__PURE__ */ new Set(), this.Owner = t, this.name = A, this.attribute = i, this.mode = s, this.converter = o, this.fieldName = `_${A}`, this.callbackName = `${A}Changed`, this.hasCallback = this.callbackName in t.prototype, s === "boolean" && o === void 0 && (this.converter = hE);
  }
  /**
   * Sets the value of the attribute/property on the source element.
   * @param source - The source element to access.
   * @param value - The value to set the attribute/property to.
   */
  setValue(t, A) {
    const i = t[this.fieldName], s = this.converter;
    s !== void 0 && (A = s.fromView(A)), i !== A && (t[this.fieldName] = A, this.tryReflectToAttribute(t), this.hasCallback && t[this.callbackName](i, A), t.$fastController.notify(this.name));
  }
  /**
   * Gets the value of the attribute/property on the source element.
   * @param source - The source element to access.
   */
  getValue(t) {
    return At.track(t, this.name), t[this.fieldName];
  }
  /** @internal */
  onAttributeChangedCallback(t, A) {
    this.guards.has(t) || (this.guards.add(t), this.setValue(t, A), this.guards.delete(t));
  }
  tryReflectToAttribute(t) {
    const A = this.mode, i = this.guards;
    i.has(t) || A === "fromView" || R.queueUpdate(() => {
      i.add(t);
      const s = t[this.fieldName];
      switch (A) {
        case "reflect":
          const o = this.converter;
          R.setAttribute(t, this.attribute, o !== void 0 ? o.toView(s) : s);
          break;
        case "boolean":
          R.setBooleanAttribute(t, this.attribute, s);
          break;
      }
      i.delete(t);
    });
  }
  /**
   * Collects all attribute definitions associated with the owner.
   * @param Owner - The class constructor to collect attribute for.
   * @param attributeLists - Any existing attributes to collect and merge with those associated with the owner.
   * @internal
   */
  static collect(t, ...A) {
    const i = [];
    A.push(Js.locate(t));
    for (let s = 0, o = A.length; s < o; ++s) {
      const r = A[s];
      if (r !== void 0)
        for (let n = 0, l = r.length; n < l; ++n) {
          const a = r[n];
          typeof a == "string" ? i.push(new Ys(t, a)) : i.push(new Ys(t, a.property, a.attribute, a.mode, a.converter));
        }
    }
    return i;
  }
}
function j(e, t) {
  let A;
  function i(s, o) {
    arguments.length > 1 && (A.property = o), Js.locate(s.constructor).push(A);
  }
  if (arguments.length > 1) {
    A = {}, i(e, t);
    return;
  }
  return A = e === void 0 ? {} : e, i;
}
const yl = { mode: "open" }, vl = {}, Pr = bi.getById(4, () => {
  const e = /* @__PURE__ */ new Map();
  return Object.freeze({
    register(t) {
      return e.has(t.type) ? !1 : (e.set(t.type, t), !0);
    },
    getByType(t) {
      return e.get(t);
    }
  });
});
class oo {
  /**
   * Creates an instance of FASTElementDefinition.
   * @param type - The type this definition is being created for.
   * @param nameOrConfig - The name of the element to define or a config object
   * that describes the element to define.
   */
  constructor(t, A = t.definition) {
    typeof A == "string" && (A = { name: A }), this.type = t, this.name = A.name, this.template = A.template;
    const i = Ys.collect(t, A.attributes), s = new Array(i.length), o = {}, r = {};
    for (let n = 0, l = i.length; n < l; ++n) {
      const a = i[n];
      s[n] = a.attribute, o[a.name] = a, r[a.attribute] = a;
    }
    this.attributes = i, this.observedAttributes = s, this.propertyLookup = o, this.attributeLookup = r, this.shadowOptions = A.shadowOptions === void 0 ? yl : A.shadowOptions === null ? void 0 : Object.assign(Object.assign({}, yl), A.shadowOptions), this.elementOptions = A.elementOptions === void 0 ? vl : Object.assign(Object.assign({}, vl), A.elementOptions), this.styles = A.styles === void 0 ? void 0 : Array.isArray(A.styles) ? Ct.create(A.styles) : A.styles instanceof Ct ? A.styles : Ct.create([A.styles]);
  }
  /**
   * Indicates if this element has been defined in at least one registry.
   */
  get isDefined() {
    return !!Pr.getByType(this.type);
  }
  /**
   * Defines a custom element based on this definition.
   * @param registry - The element registry to define the element in.
   */
  define(t = customElements) {
    const A = this.type;
    if (Pr.register(this)) {
      const i = this.attributes, s = A.prototype;
      for (let o = 0, r = i.length; o < r; ++o)
        At.defineProperty(s, i[o]);
      Reflect.defineProperty(A, "observedAttributes", {
        value: this.observedAttributes,
        enumerable: !0
      });
    }
    return t.get(this.name) || t.define(this.name, A, this.elementOptions), this;
  }
}
oo.forType = Pr.getByType;
const Gc = /* @__PURE__ */ new WeakMap(), IE = {
  bubbles: !0,
  composed: !0,
  cancelable: !0
};
function Ar(e) {
  return e.shadowRoot || Gc.get(e) || null;
}
class Nn extends kc {
  /**
   * Creates a Controller to control the specified element.
   * @param element - The element to be controlled by this controller.
   * @param definition - The element definition metadata that instructs this
   * controller in how to handle rendering and other platform integrations.
   * @internal
   */
  constructor(t, A) {
    super(t), this.boundObservables = null, this.behaviors = null, this.needsInitialization = !0, this._template = null, this._styles = null, this._isConnected = !1, this.$fastController = this, this.view = null, this.element = t, this.definition = A;
    const i = A.shadowOptions;
    if (i !== void 0) {
      const o = t.attachShadow(i);
      i.mode === "closed" && Gc.set(t, o);
    }
    const s = At.getAccessors(t);
    if (s.length > 0) {
      const o = this.boundObservables = /* @__PURE__ */ Object.create(null);
      for (let r = 0, n = s.length; r < n; ++r) {
        const l = s[r].name, a = t[l];
        a !== void 0 && (delete t[l], o[l] = a);
      }
    }
  }
  /**
   * Indicates whether or not the custom element has been
   * connected to the document.
   */
  get isConnected() {
    return At.track(this, "isConnected"), this._isConnected;
  }
  setIsConnected(t) {
    this._isConnected = t, At.notify(this, "isConnected");
  }
  /**
   * Gets/sets the template used to render the component.
   * @remarks
   * This value can only be accurately read after connect but can be set at any time.
   */
  get template() {
    return this._template;
  }
  set template(t) {
    this._template !== t && (this._template = t, this.needsInitialization || this.renderTemplate(t));
  }
  /**
   * Gets/sets the primary styles used for the component.
   * @remarks
   * This value can only be accurately read after connect but can be set at any time.
   */
  get styles() {
    return this._styles;
  }
  set styles(t) {
    this._styles !== t && (this._styles !== null && this.removeStyles(this._styles), this._styles = t, !this.needsInitialization && t !== null && this.addStyles(t));
  }
  /**
   * Adds styles to this element. Providing an HTMLStyleElement will attach the element instance to the shadowRoot.
   * @param styles - The styles to add.
   */
  addStyles(t) {
    const A = Ar(this.element) || this.element.getRootNode();
    if (t instanceof HTMLStyleElement)
      A.append(t);
    else if (!t.isAttachedTo(A)) {
      const i = t.behaviors;
      t.addStylesTo(A), i !== null && this.addBehaviors(i);
    }
  }
  /**
   * Removes styles from this element. Providing an HTMLStyleElement will detach the element instance from the shadowRoot.
   * @param styles - the styles to remove.
   */
  removeStyles(t) {
    const A = Ar(this.element) || this.element.getRootNode();
    if (t instanceof HTMLStyleElement)
      A.removeChild(t);
    else if (t.isAttachedTo(A)) {
      const i = t.behaviors;
      t.removeStylesFrom(A), i !== null && this.removeBehaviors(i);
    }
  }
  /**
   * Adds behaviors to this element.
   * @param behaviors - The behaviors to add.
   */
  addBehaviors(t) {
    const A = this.behaviors || (this.behaviors = /* @__PURE__ */ new Map()), i = t.length, s = [];
    for (let o = 0; o < i; ++o) {
      const r = t[o];
      A.has(r) ? A.set(r, A.get(r) + 1) : (A.set(r, 1), s.push(r));
    }
    if (this._isConnected) {
      const o = this.element;
      for (let r = 0; r < s.length; ++r)
        s[r].bind(o, ui);
    }
  }
  /**
   * Removes behaviors from this element.
   * @param behaviors - The behaviors to remove.
   * @param force - Forces unbinding of behaviors.
   */
  removeBehaviors(t, A = !1) {
    const i = this.behaviors;
    if (i === null)
      return;
    const s = t.length, o = [];
    for (let r = 0; r < s; ++r) {
      const n = t[r];
      if (i.has(n)) {
        const l = i.get(n) - 1;
        l === 0 || A ? i.delete(n) && o.push(n) : i.set(n, l);
      }
    }
    if (this._isConnected) {
      const r = this.element;
      for (let n = 0; n < o.length; ++n)
        o[n].unbind(r);
    }
  }
  /**
   * Runs connected lifecycle behavior on the associated element.
   */
  onConnectedCallback() {
    if (this._isConnected)
      return;
    const t = this.element;
    this.needsInitialization ? this.finishInitialization() : this.view !== null && this.view.bind(t, ui);
    const A = this.behaviors;
    if (A !== null)
      for (const [i] of A)
        i.bind(t, ui);
    this.setIsConnected(!0);
  }
  /**
   * Runs disconnected lifecycle behavior on the associated element.
   */
  onDisconnectedCallback() {
    if (!this._isConnected)
      return;
    this.setIsConnected(!1);
    const t = this.view;
    t !== null && t.unbind();
    const A = this.behaviors;
    if (A !== null) {
      const i = this.element;
      for (const [s] of A)
        s.unbind(i);
    }
  }
  /**
   * Runs the attribute changed callback for the associated element.
   * @param name - The name of the attribute that changed.
   * @param oldValue - The previous value of the attribute.
   * @param newValue - The new value of the attribute.
   */
  onAttributeChangedCallback(t, A, i) {
    const s = this.definition.attributeLookup[t];
    s !== void 0 && s.onAttributeChangedCallback(this.element, i);
  }
  /**
   * Emits a custom HTML event.
   * @param type - The type name of the event.
   * @param detail - The event detail object to send with the event.
   * @param options - The event options. By default bubbles and composed.
   * @remarks
   * Only emits events if connected.
   */
  emit(t, A, i) {
    return this._isConnected ? this.element.dispatchEvent(new CustomEvent(t, Object.assign(Object.assign({ detail: A }, IE), i))) : !1;
  }
  finishInitialization() {
    const t = this.element, A = this.boundObservables;
    if (A !== null) {
      const s = Object.keys(A);
      for (let o = 0, r = s.length; o < r; ++o) {
        const n = s[o];
        t[n] = A[n];
      }
      this.boundObservables = null;
    }
    const i = this.definition;
    this._template === null && (this.element.resolveTemplate ? this._template = this.element.resolveTemplate() : i.template && (this._template = i.template || null)), this._template !== null && this.renderTemplate(this._template), this._styles === null && (this.element.resolveStyles ? this._styles = this.element.resolveStyles() : i.styles && (this._styles = i.styles || null)), this._styles !== null && this.addStyles(this._styles), this.needsInitialization = !1;
  }
  renderTemplate(t) {
    const A = this.element, i = Ar(A) || A;
    this.view !== null ? (this.view.dispose(), this.view = null) : this.needsInitialization || R.removeChildNodes(i), t && (this.view = t.render(A, i, A));
  }
  /**
   * Locates or creates a controller for the specified element.
   * @param element - The element to return the controller for.
   * @remarks
   * The specified element must have a {@link FASTElementDefinition}
   * registered either through the use of the {@link customElement}
   * decorator or a call to `FASTElement.define`.
   */
  static forCustomElement(t) {
    const A = t.$fastController;
    if (A !== void 0)
      return A;
    const i = oo.forType(t.constructor);
    if (i === void 0)
      throw new Error("Missing FASTElement definition.");
    return t.$fastController = new Nn(t, i);
  }
}
function ml(e) {
  return class extends e {
    constructor() {
      super(), Nn.forCustomElement(this);
    }
    $emit(t, A, i) {
      return this.$fastController.emit(t, A, i);
    }
    connectedCallback() {
      this.$fastController.onConnectedCallback();
    }
    disconnectedCallback() {
      this.$fastController.onDisconnectedCallback();
    }
    attributeChangedCallback(t, A, i) {
      this.$fastController.onAttributeChangedCallback(t, A, i);
    }
  };
}
const ro = Object.assign(ml(HTMLElement), {
  /**
   * Creates a new FASTElement base class inherited from the
   * provided base type.
   * @param BaseType - The base element type to inherit from.
   */
  from(e) {
    return ml(e);
  },
  /**
   * Defines a platform custom element based on the provided type and definition.
   * @param type - The custom element type to define.
   * @param nameOrDef - The name of the element to define or a definition object
   * that describes the element to define.
   */
  define(e, t) {
    return new oo(e, t).define().type;
  }
});
class Fn {
  /**
   * Creates a CSS fragment to interpolate into the CSS document.
   * @returns - the string to interpolate into CSS
   */
  createCSS() {
    return "";
  }
  /**
   * Creates a behavior to bind to the host element.
   * @returns - the behavior to bind to the host element, or undefined.
   */
  createBehavior() {
  }
}
function Mc(e, t) {
  const A = [];
  let i = "";
  const s = [];
  for (let o = 0, r = e.length - 1; o < r; ++o) {
    i += e[o];
    let n = t[o];
    if (n instanceof Fn) {
      const l = n.createBehavior();
      n = n.createCSS(), l && s.push(l);
    }
    n instanceof Ct || n instanceof CSSStyleSheet ? (i.trim() !== "" && (A.push(i), i = ""), A.push(n)) : i += n;
  }
  return i += e[e.length - 1], i.trim() !== "" && A.push(i), {
    styles: A,
    behaviors: s
  };
}
function rA(e, ...t) {
  const { styles: A, behaviors: i } = Mc(e, t), s = Ct.create(A);
  return i.length && s.withBehaviors(...i), s;
}
class uE extends Fn {
  constructor(t, A) {
    super(), this.behaviors = A, this.css = "";
    const i = t.reduce((s, o) => (typeof o == "string" ? this.css += o : s.push(o), s), []);
    i.length && (this.styles = Ct.create(i));
  }
  createBehavior() {
    return this;
  }
  createCSS() {
    return this.css;
  }
  bind(t) {
    this.styles && t.$fastController.addStyles(this.styles), this.behaviors.length && t.$fastController.addBehaviors(this.behaviors);
  }
  unbind(t) {
    this.styles && t.$fastController.removeStyles(this.styles), this.behaviors.length && t.$fastController.removeBehaviors(this.behaviors);
  }
}
function dE(e, ...t) {
  const { styles: A, behaviors: i } = Mc(e, t);
  return new uE(A, i);
}
class CE {
  /**
   * Creates an instance of RefBehavior.
   * @param target - The element to reference.
   * @param propertyName - The name of the property to assign the reference to.
   */
  constructor(t, A) {
    this.target = t, this.propertyName = A;
  }
  /**
   * Bind this behavior to the source.
   * @param source - The source to bind to.
   * @param context - The execution context that the binding is operating within.
   */
  bind(t) {
    t[this.propertyName] = this.target;
  }
  /**
   * Unbinds this behavior from the source.
   * @param source - The source to unbind from.
   */
  /* eslint-disable-next-line @typescript-eslint/no-empty-function */
  unbind() {
  }
}
function re(e) {
  return new xc("fast-ref", CE, e);
}
const Lc = (e) => typeof e == "function", BE = () => null;
function bl(e) {
  return e === void 0 ? BE : Lc(e) ? e : () => e;
}
function ts(e, t, A) {
  const i = Lc(e) ? e : () => e, s = bl(t), o = bl(A);
  return (r, n) => i(r, n) ? s(r, n) : o(r, n);
}
class QE {
  /**
   * Creates an instance of NodeObservationBehavior.
   * @param target - The target to assign the nodes property on.
   * @param options - The options to use in configuring node observation.
   */
  constructor(t, A) {
    this.target = t, this.options = A, this.source = null;
  }
  /**
   * Bind this behavior to the source.
   * @param source - The source to bind to.
   * @param context - The execution context that the binding is operating within.
   */
  bind(t) {
    const A = this.options.property;
    this.shouldUpdate = At.getAccessors(t).some((i) => i.name === A), this.source = t, this.updateTarget(this.computeNodes()), this.shouldUpdate && this.observe();
  }
  /**
   * Unbinds this behavior from the source.
   * @param source - The source to unbind from.
   */
  unbind() {
    this.updateTarget(ds), this.source = null, this.shouldUpdate && this.disconnect();
  }
  /** @internal */
  handleEvent() {
    this.updateTarget(this.computeNodes());
  }
  computeNodes() {
    let t = this.getNodes();
    return this.options.filter !== void 0 && (t = t.filter(this.options.filter)), t;
  }
  updateTarget(t) {
    this.source[this.options.property] = t;
  }
}
class EE extends QE {
  /**
   * Creates an instance of SlottedBehavior.
   * @param target - The slot element target to observe.
   * @param options - The options to use when observing the slot.
   */
  constructor(t, A) {
    super(t, A);
  }
  /**
   * Begins observation of the nodes.
   */
  observe() {
    this.target.addEventListener("slotchange", this);
  }
  /**
   * Disconnects observation of the nodes.
   */
  disconnect() {
    this.target.removeEventListener("slotchange", this);
  }
  /**
   * Retrieves the nodes that should be assigned to the target.
   */
  getNodes() {
    return this.target.assignedNodes(this.options);
  }
}
function fE(e) {
  return typeof e == "string" && (e = { property: e }), new xc("fast-slotted", EE, e);
}
class pE {
  handleStartContentChange() {
    this.startContainer.classList.toggle("start", this.start.assignedNodes().length > 0);
  }
  handleEndContentChange() {
    this.endContainer.classList.toggle("end", this.end.assignedNodes().length > 0);
  }
}
const wE = (e, t) => Vt`
    <span
        part="end"
        ${re("endContainer")}
        class=${(A) => t.end ? "end" : void 0}
    >
        <slot name="end" ${re("end")} @slotchange="${(A) => A.handleEndContentChange()}">
            ${t.end || ""}
        </slot>
    </span>
`, yE = (e, t) => Vt`
    <span
        part="start"
        ${re("startContainer")}
        class="${(A) => t.start ? "start" : void 0}"
    >
        <slot
            name="start"
            ${re("start")}
            @slotchange="${(A) => A.handleStartContentChange()}"
        >
            ${t.start || ""}
        </slot>
    </span>
`;
Vt`
    <span part="end" ${re("endContainer")}>
        <slot
            name="end"
            ${re("end")}
            @slotchange="${(e) => e.handleEndContentChange()}"
        ></slot>
    </span>
`;
Vt`
    <span part="start" ${re("startContainer")}>
        <slot
            name="start"
            ${re("start")}
            @slotchange="${(e) => e.handleStartContentChange()}"
        ></slot>
    </span>
`;
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
function S(e, t, A, i) {
  var s = arguments.length, o = s < 3 ? t : i === null ? i = Object.getOwnPropertyDescriptor(t, A) : i, r;
  if (typeof Reflect == "object" && typeof Reflect.decorate == "function")
    o = Reflect.decorate(e, t, A, i);
  else
    for (var n = e.length - 1; n >= 0; n--)
      (r = e[n]) && (o = (s < 3 ? r(o) : s > 3 ? r(t, A, o) : r(t, A)) || o);
  return s > 3 && o && Object.defineProperty(t, A, o), o;
}
const ir = /* @__PURE__ */ new Map();
"metadata" in Reflect || (Reflect.metadata = function(e, t) {
  return function(A) {
    Reflect.defineMetadata(e, t, A);
  };
}, Reflect.defineMetadata = function(e, t, A) {
  let i = ir.get(A);
  i === void 0 && ir.set(A, i = /* @__PURE__ */ new Map()), i.set(e, t);
}, Reflect.getOwnMetadata = function(e, t) {
  const A = ir.get(t);
  if (A !== void 0)
    return A.get(e);
});
class vE {
  /**
   *
   * @param container - The container to create resolvers for.
   * @param key - The key to register resolvers under.
   */
  constructor(t, A) {
    this.container = t, this.key = A;
  }
  /**
   * Creates a resolver for an existing object instance.
   * @param value - The instance to resolve.
   * @returns The resolver.
   */
  instance(t) {
    return this.registerResolver(0, t);
  }
  /**
   * Creates a resolver that enforces a singleton lifetime.
   * @param value - The type to create and cache the singleton for.
   * @returns The resolver.
   */
  singleton(t) {
    return this.registerResolver(1, t);
  }
  /**
   * Creates a resolver that creates a new instance for every dependency request.
   * @param value - The type to create instances of.
   * @returns - The resolver.
   */
  transient(t) {
    return this.registerResolver(2, t);
  }
  /**
   * Creates a resolver that invokes a callback function for every dependency resolution
   * request, allowing custom logic to return the dependency.
   * @param value - The callback to call during resolution.
   * @returns The resolver.
   */
  callback(t) {
    return this.registerResolver(3, t);
  }
  /**
   * Creates a resolver that invokes a callback function the first time that a dependency
   * resolution is requested. The returned value is then cached and provided for all
   * subsequent requests.
   * @param value - The callback to call during the first resolution.
   * @returns The resolver.
   */
  cachedCallback(t) {
    return this.registerResolver(3, Yc(t));
  }
  /**
   * Aliases the current key to a different key.
   * @param destinationKey - The key to point the alias to.
   * @returns The resolver.
   */
  aliasTo(t) {
    return this.registerResolver(5, t);
  }
  registerResolver(t, A) {
    const { container: i, key: s } = this;
    return this.container = this.key = void 0, i.registerResolver(s, new xt(s, t, A));
  }
}
function WA(e) {
  const t = e.slice(), A = Object.keys(e), i = A.length;
  let s;
  for (let o = 0; o < i; ++o)
    s = A[o], Hc(s) || (t[s] = e[s]);
  return t;
}
const mE = Object.freeze({
  /**
   * Disables auto-registration and throws for all un-registered dependencies.
   * @param key - The key to create the resolver for.
   */
  none(e) {
    throw Error(`${e.toString()} not registered, did you forget to add @singleton()?`);
  },
  /**
   * Provides default singleton resolution behavior during auto-registration.
   * @param key - The key to create the resolver for.
   * @returns The resolver.
   */
  singleton(e) {
    return new xt(e, 1, e);
  },
  /**
   * Provides default transient resolution behavior during auto-registration.
   * @param key - The key to create the resolver for.
   * @returns The resolver.
   */
  transient(e) {
    return new xt(e, 2, e);
  }
}), sr = Object.freeze({
  /**
   * The default configuration used when creating a DOM-disconnected container.
   * @remarks
   * The default creates a root container, with no parent container. It does not handle
   * owner requests and it uses singleton resolution behavior for auto-registration.
   */
  default: Object.freeze({
    parentLocator: () => null,
    responsibleForOwnerRequests: !1,
    defaultResolver: mE.singleton
  })
}), Dl = /* @__PURE__ */ new Map();
function kl(e) {
  return (t) => Reflect.getOwnMetadata(e, t);
}
let Sl = null;
const H = Object.freeze({
  /**
   * Creates a new dependency injection container.
   * @param config - The configuration for the container.
   * @returns A newly created dependency injection container.
   */
  createContainer(e) {
    return new di(null, Object.assign({}, sr.default, e));
  },
  /**
   * Finds the dependency injection container responsible for providing dependencies
   * to the specified node.
   * @param node - The node to find the responsible container for.
   * @returns The container responsible for providing dependencies to the node.
   * @remarks
   * This will be the same as the parent container if the specified node
   * does not itself host a container configured with responsibleForOwnerRequests.
   */
  findResponsibleContainer(e) {
    const t = e.$$container$$;
    return t && t.responsibleForOwnerRequests ? t : H.findParentContainer(e);
  },
  /**
   * Find the dependency injection container up the DOM tree from this node.
   * @param node - The node to find the parent container for.
   * @returns The parent container of this node.
   * @remarks
   * This will be the same as the responsible container if the specified node
   * does not itself host a container configured with responsibleForOwnerRequests.
   */
  findParentContainer(e) {
    const t = new CustomEvent(Jc, {
      bubbles: !0,
      composed: !0,
      cancelable: !0,
      detail: { container: void 0 }
    });
    return e.dispatchEvent(t), t.detail.container || H.getOrCreateDOMContainer();
  },
  /**
   * Returns a dependency injection container if one is explicitly owned by the specified
   * node. If one is not owned, then a new container is created and assigned to the node.
   * @param node - The node to find or create the container for.
   * @param config - The configuration for the container if one needs to be created.
   * @returns The located or created container.
   * @remarks
   * This API does not search for a responsible or parent container. It looks only for a container
   * directly defined on the specified node and creates one at that location if one does not
   * already exist.
   */
  getOrCreateDOMContainer(e, t) {
    return e ? e.$$container$$ || new di(e, Object.assign({}, sr.default, t, {
      parentLocator: H.findParentContainer
    })) : Sl || (Sl = new di(null, Object.assign({}, sr.default, t, {
      parentLocator: () => null
    })));
  },
  /**
   * Gets the "design:paramtypes" metadata for the specified type.
   * @param Type - The type to get the metadata for.
   * @returns The metadata array or undefined if no metadata is found.
   */
  getDesignParamtypes: kl("design:paramtypes"),
  /**
   * Gets the "di:paramtypes" metadata for the specified type.
   * @param Type - The type to get the metadata for.
   * @returns The metadata array or undefined if no metadata is found.
   */
  getAnnotationParamtypes: kl("di:paramtypes"),
  /**
   *
   * @param Type - Gets the "di:paramtypes" metadata for the specified type. If none is found,
   * an empty metadata array is created and added.
   * @returns The metadata array.
   */
  getOrCreateAnnotationParamTypes(e) {
    let t = this.getAnnotationParamtypes(e);
    return t === void 0 && Reflect.defineMetadata("di:paramtypes", t = [], e), t;
  },
  /**
   * Gets the dependency keys representing what is needed to instantiate the specified type.
   * @param Type - The type to get the dependencies for.
   * @returns An array of dependency keys.
   */
  getDependencies(e) {
    let t = Dl.get(e);
    if (t === void 0) {
      const A = e.inject;
      if (A === void 0) {
        const i = H.getDesignParamtypes(e), s = H.getAnnotationParamtypes(e);
        if (i === void 0)
          if (s === void 0) {
            const o = Object.getPrototypeOf(e);
            typeof o == "function" && o !== Function.prototype ? t = WA(H.getDependencies(o)) : t = [];
          } else
            t = WA(s);
        else if (s === void 0)
          t = WA(i);
        else {
          t = WA(i);
          let o = s.length, r;
          for (let a = 0; a < o; ++a)
            r = s[a], r !== void 0 && (t[a] = r);
          const n = Object.keys(s);
          o = n.length;
          let l;
          for (let a = 0; a < o; ++a)
            l = n[a], Hc(l) || (t[l] = s[l]);
        }
      } else
        t = WA(A);
      Dl.set(e, t);
    }
    return t;
  },
  /**
   * Defines a property on a web component class. The value of this property will
   * be resolved from the dependency injection container responsible for the element
   * instance, based on where it is connected in the DOM.
   * @param target - The target to define the property on.
   * @param propertyName - The name of the property to define.
   * @param key - The dependency injection key.
   * @param respectConnection - Indicates whether or not to update the property value if the
   * hosting component is disconnected and then re-connected at a different location in the DOM.
   * @remarks
   * The respectConnection option is only applicable to elements that descend from FASTElement.
   */
  defineProperty(e, t, A, i = !1) {
    const s = `$di_${t}`;
    Reflect.defineProperty(e, t, {
      get: function() {
        let o = this[s];
        if (o === void 0 && (o = (this instanceof HTMLElement ? H.findResponsibleContainer(this) : H.getOrCreateDOMContainer()).get(A), this[s] = o, i && this instanceof ro)) {
          const n = this.$fastController, l = () => {
            const c = H.findResponsibleContainer(this).get(A), g = this[s];
            c !== g && (this[s] = o, n.notify(t));
          };
          n.subscribe({ handleChange: l }, "isConnected");
        }
        return o;
      }
    });
  },
  /**
   * Creates a dependency injection key.
   * @param nameConfigOrCallback - A friendly name for the key or a lambda that configures a
   * default resolution for the dependency.
   * @param configuror - If a friendly name was provided for the first parameter, then an optional
   * lambda that configures a default resolution for the dependency can be provided second.
   * @returns The created key.
   * @remarks
   * The created key can be used as a property decorator or constructor parameter decorator,
   * in addition to its standard use in an inject array or through direct container APIs.
   */
  createInterface(e, t) {
    const A = typeof e == "function" ? e : t, i = typeof e == "string" ? e : e && "friendlyName" in e && e.friendlyName || Rl, s = typeof e == "string" ? !1 : e && "respectConnection" in e && e.respectConnection || !1, o = function(r, n, l) {
      if (r == null || new.target !== void 0)
        throw new Error(`No registration for interface: '${o.friendlyName}'`);
      if (n)
        H.defineProperty(r, n, o, s);
      else {
        const a = H.getOrCreateAnnotationParamTypes(r);
        a[l] = o;
      }
    };
    return o.$isInterface = !0, o.friendlyName = i ?? "(anonymous)", A != null && (o.register = function(r, n) {
      return A(new vE(r, n ?? o));
    }), o.toString = function() {
      return `InterfaceSymbol<${o.friendlyName}>`;
    }, o;
  },
  /**
   * A decorator that specifies what to inject into its target.
   * @param dependencies - The dependencies to inject.
   * @returns The decorator to be applied to the target class.
   * @remarks
   * The decorator can be used to decorate a class, listing all of the classes dependencies.
   * Or it can be used to decorate a constructor paramter, indicating what to inject for that
   * parameter.
   * Or it can be used for a web component property, indicating what that property should resolve to.
   */
  inject(...e) {
    return function(t, A, i) {
      if (typeof i == "number") {
        const s = H.getOrCreateAnnotationParamTypes(t), o = e[0];
        o !== void 0 && (s[i] = o);
      } else if (A)
        H.defineProperty(t, A, e[0]);
      else {
        const s = i ? H.getOrCreateAnnotationParamTypes(i.value) : H.getOrCreateAnnotationParamTypes(t);
        let o;
        for (let r = 0; r < e.length; ++r)
          o = e[r], o !== void 0 && (s[r] = o);
      }
    };
  },
  /**
   * Registers the `target` class as a transient dependency; each time the dependency is resolved
   * a new instance will be created.
   *
   * @param target - The class / constructor function to register as transient.
   * @returns The same class, with a static `register` method that takes a container and returns the appropriate resolver.
   *
   * @example
   * On an existing class
   * ```ts
   * class Foo { }
   * DI.transient(Foo);
   * ```
   *
   * @example
   * Inline declaration
   *
   * ```ts
   * const Foo = DI.transient(class { });
   * // Foo is now strongly typed with register
   * Foo.register(container);
   * ```
   *
   * @public
   */
  transient(e) {
    return e.register = function(A) {
      return ki.transient(e, e).register(A);
    }, e.registerInRequestor = !1, e;
  },
  /**
   * Registers the `target` class as a singleton dependency; the class will only be created once. Each
   * consecutive time the dependency is resolved, the same instance will be returned.
   *
   * @param target - The class / constructor function to register as a singleton.
   * @returns The same class, with a static `register` method that takes a container and returns the appropriate resolver.
   * @example
   * On an existing class
   * ```ts
   * class Foo { }
   * DI.singleton(Foo);
   * ```
   *
   * @example
   * Inline declaration
   * ```ts
   * const Foo = DI.singleton(class { });
   * // Foo is now strongly typed with register
   * Foo.register(container);
   * ```
   *
   * @public
   */
  singleton(e, t = DE) {
    return e.register = function(i) {
      return ki.singleton(e, e).register(i);
    }, e.registerInRequestor = t.scoped, e;
  }
}), bE = H.createInterface("Container");
H.inject;
const DE = { scoped: !1 };
class xt {
  constructor(t, A, i) {
    this.key = t, this.strategy = A, this.state = i, this.resolving = !1;
  }
  get $isResolver() {
    return !0;
  }
  register(t) {
    return t.registerResolver(this.key, this);
  }
  resolve(t, A) {
    switch (this.strategy) {
      case 0:
        return this.state;
      case 1: {
        if (this.resolving)
          throw new Error(`Cyclic dependency found: ${this.state.name}`);
        return this.resolving = !0, this.state = t.getFactory(this.state).construct(A), this.strategy = 0, this.resolving = !1, this.state;
      }
      case 2: {
        const i = t.getFactory(this.state);
        if (i === null)
          throw new Error(`Resolver for ${String(this.key)} returned a null factory`);
        return i.construct(A);
      }
      case 3:
        return this.state(t, A, this);
      case 4:
        return this.state[0].resolve(t, A);
      case 5:
        return A.get(this.state);
      default:
        throw new Error(`Invalid resolver strategy specified: ${this.strategy}.`);
    }
  }
  getFactory(t) {
    var A, i, s;
    switch (this.strategy) {
      case 1:
      case 2:
        return t.getFactory(this.state);
      case 5:
        return (s = (i = (A = t.getResolver(this.state)) === null || A === void 0 ? void 0 : A.getFactory) === null || i === void 0 ? void 0 : i.call(A, t)) !== null && s !== void 0 ? s : null;
      default:
        return null;
    }
  }
}
function xl(e) {
  return this.get(e);
}
function kE(e, t) {
  return t(e);
}
class SE {
  constructor(t, A) {
    this.Type = t, this.dependencies = A, this.transformers = null;
  }
  construct(t, A) {
    let i;
    return A === void 0 ? i = new this.Type(...this.dependencies.map(xl, t)) : i = new this.Type(...this.dependencies.map(xl, t), ...A), this.transformers == null ? i : this.transformers.reduce(kE, i);
  }
  registerTransformer(t) {
    (this.transformers || (this.transformers = [])).push(t);
  }
}
const xE = {
  $isResolver: !0,
  resolve(e, t) {
    return t;
  }
};
function Cs(e) {
  return typeof e.register == "function";
}
function NE(e) {
  return Cs(e) && typeof e.registerInRequestor == "boolean";
}
function Nl(e) {
  return NE(e) && e.registerInRequestor;
}
function FE(e) {
  return e.prototype !== void 0;
}
const RE = /* @__PURE__ */ new Set([
  "Array",
  "ArrayBuffer",
  "Boolean",
  "DataView",
  "Date",
  "Error",
  "EvalError",
  "Float32Array",
  "Float64Array",
  "Function",
  "Int8Array",
  "Int16Array",
  "Int32Array",
  "Map",
  "Number",
  "Object",
  "Promise",
  "RangeError",
  "ReferenceError",
  "RegExp",
  "Set",
  "SharedArrayBuffer",
  "String",
  "SyntaxError",
  "TypeError",
  "Uint8Array",
  "Uint8ClampedArray",
  "Uint16Array",
  "Uint32Array",
  "URIError",
  "WeakMap",
  "WeakSet"
]), Jc = "__DI_LOCATE_PARENT__", or = /* @__PURE__ */ new Map();
class di {
  constructor(t, A) {
    this.owner = t, this.config = A, this._parent = void 0, this.registerDepth = 0, this.context = null, t !== null && (t.$$container$$ = this), this.resolvers = /* @__PURE__ */ new Map(), this.resolvers.set(bE, xE), t instanceof Node && t.addEventListener(Jc, (i) => {
      i.composedPath()[0] !== this.owner && (i.detail.container = this, i.stopImmediatePropagation());
    });
  }
  get parent() {
    return this._parent === void 0 && (this._parent = this.config.parentLocator(this.owner)), this._parent;
  }
  get depth() {
    return this.parent === null ? 0 : this.parent.depth + 1;
  }
  get responsibleForOwnerRequests() {
    return this.config.responsibleForOwnerRequests;
  }
  registerWithContext(t, ...A) {
    return this.context = t, this.register(...A), this.context = null, this;
  }
  register(...t) {
    if (++this.registerDepth === 100)
      throw new Error("Unable to autoregister dependency");
    let A, i, s, o, r;
    const n = this.context;
    for (let l = 0, a = t.length; l < a; ++l)
      if (A = t[l], !!Ul(A))
        if (Cs(A))
          A.register(this, n);
        else if (FE(A))
          ki.singleton(A, A).register(this);
        else
          for (i = Object.keys(A), o = 0, r = i.length; o < r; ++o)
            s = A[i[o]], Ul(s) && (Cs(s) ? s.register(this, n) : this.register(s));
    return --this.registerDepth, this;
  }
  registerResolver(t, A) {
    es(t);
    const i = this.resolvers, s = i.get(t);
    return s == null ? i.set(t, A) : s instanceof xt && s.strategy === 4 ? s.state.push(A) : i.set(t, new xt(t, 4, [s, A])), A;
  }
  registerTransformer(t, A) {
    const i = this.getResolver(t);
    if (i == null)
      return !1;
    if (i.getFactory) {
      const s = i.getFactory(this);
      return s == null ? !1 : (s.registerTransformer(A), !0);
    }
    return !1;
  }
  getResolver(t, A = !0) {
    if (es(t), t.resolve !== void 0)
      return t;
    let i = this, s;
    for (; i != null; )
      if (s = i.resolvers.get(t), s == null) {
        if (i.parent == null) {
          const o = Nl(t) ? this : i;
          return A ? this.jitRegister(t, o) : null;
        }
        i = i.parent;
      } else
        return s;
    return null;
  }
  has(t, A = !1) {
    return this.resolvers.has(t) ? !0 : A && this.parent != null ? this.parent.has(t, !0) : !1;
  }
  get(t) {
    if (es(t), t.$isResolver)
      return t.resolve(this, this);
    let A = this, i;
    for (; A != null; )
      if (i = A.resolvers.get(t), i == null) {
        if (A.parent == null) {
          const s = Nl(t) ? this : A;
          return i = this.jitRegister(t, s), i.resolve(A, this);
        }
        A = A.parent;
      } else
        return i.resolve(A, this);
    throw new Error(`Unable to resolve key: ${t}`);
  }
  getAll(t, A = !1) {
    es(t);
    const i = this;
    let s = i, o;
    if (A) {
      let r = ds;
      for (; s != null; )
        o = s.resolvers.get(t), o != null && (r = r.concat(
          /* eslint-disable-next-line @typescript-eslint/no-non-null-assertion */
          Fl(o, s, i)
        )), s = s.parent;
      return r;
    } else
      for (; s != null; )
        if (o = s.resolvers.get(t), o == null) {
          if (s = s.parent, s == null)
            return ds;
        } else
          return Fl(o, s, i);
    return ds;
  }
  getFactory(t) {
    let A = or.get(t);
    if (A === void 0) {
      if (UE(t))
        throw new Error(`${t.name} is a native function and therefore cannot be safely constructed by DI. If this is intentional, please use a callback or cachedCallback resolver.`);
      or.set(t, A = new SE(t, H.getDependencies(t)));
    }
    return A;
  }
  registerFactory(t, A) {
    or.set(t, A);
  }
  createChild(t) {
    return new di(null, Object.assign({}, this.config, t, { parentLocator: () => this }));
  }
  jitRegister(t, A) {
    if (typeof t != "function")
      throw new Error(`Attempted to jitRegister something that is not a constructor: '${t}'. Did you forget to register this dependency?`);
    if (RE.has(t.name))
      throw new Error(`Attempted to jitRegister an intrinsic type: ${t.name}. Did you forget to add @inject(Key)`);
    if (Cs(t)) {
      const i = t.register(A);
      if (!(i instanceof Object) || i.resolve == null) {
        const s = A.resolvers.get(t);
        if (s != null)
          return s;
        throw new Error("A valid resolver was not returned from the static register method");
      }
      return i;
    } else {
      if (t.$isInterface)
        throw new Error(`Attempted to jitRegister an interface: ${t.friendlyName}`);
      {
        const i = this.config.defaultResolver(t, A);
        return A.resolvers.set(t, i), i;
      }
    }
  }
}
const rr = /* @__PURE__ */ new WeakMap();
function Yc(e) {
  return function(t, A, i) {
    if (rr.has(i))
      return rr.get(i);
    const s = e(t, A, i);
    return rr.set(i, s), s;
  };
}
const ki = Object.freeze({
  /**
   * Allows you to pass an instance.
   * Every time you request this {@link Key} you will get this instance back.
   *
   * @example
   * ```
   * Registration.instance(Foo, new Foo()));
   * ```
   *
   * @param key - The key to register the instance under.
   * @param value - The instance to return when the key is requested.
   */
  instance(e, t) {
    return new xt(e, 0, t);
  },
  /**
   * Creates an instance from the class.
   * Every time you request this {@link Key} you will get the same one back.
   *
   * @example
   * ```
   * Registration.singleton(Foo, Foo);
   * ```
   *
   * @param key - The key to register the singleton under.
   * @param value - The class to instantiate as a singleton when first requested.
   */
  singleton(e, t) {
    return new xt(e, 1, t);
  },
  /**
   * Creates an instance from a class.
   * Every time you request this {@link Key} you will get a new instance.
   *
   * @example
   * ```
   * Registration.instance(Foo, Foo);
   * ```
   *
   * @param key - The key to register the instance type under.
   * @param value - The class to instantiate each time the key is requested.
   */
  transient(e, t) {
    return new xt(e, 2, t);
  },
  /**
   * Delegates to a callback function to provide the dependency.
   * Every time you request this {@link Key} the callback will be invoked to provide
   * the dependency.
   *
   * @example
   * ```
   * Registration.callback(Foo, () => new Foo());
   * Registration.callback(Bar, (c: Container) => new Bar(c.get(Foo)));
   * ```
   *
   * @param key - The key to register the callback for.
   * @param callback - The function that is expected to return the dependency.
   */
  callback(e, t) {
    return new xt(e, 3, t);
  },
  /**
   * Delegates to a callback function to provide the dependency and then caches the
   * dependency for future requests.
   *
   * @example
   * ```
   * Registration.cachedCallback(Foo, () => new Foo());
   * Registration.cachedCallback(Bar, (c: Container) => new Bar(c.get(Foo)));
   * ```
   *
   * @param key - The key to register the callback for.
   * @param callback - The function that is expected to return the dependency.
   * @remarks
   * If you pass the same Registration to another container, the same cached value will be used.
   * Should all references to the resolver returned be removed, the cache will expire.
   */
  cachedCallback(e, t) {
    return new xt(e, 3, Yc(t));
  },
  /**
   * Creates an alternate {@link Key} to retrieve an instance by.
   *
   * @example
   * ```
   * Register.singleton(Foo, Foo)
   * Register.aliasTo(Foo, MyFoos);
   *
   * container.getAll(MyFoos) // contains an instance of Foo
   * ```
   *
   * @param originalKey - The original key that has been registered.
   * @param aliasKey - The alias to the original key.
   */
  aliasTo(e, t) {
    return new xt(t, 5, e);
  }
});
function es(e) {
  if (e == null)
    throw new Error("key/value cannot be null or undefined. Are you trying to inject/register something that doesn't exist with DI?");
}
function Fl(e, t, A) {
  if (e instanceof xt && e.strategy === 4) {
    const i = e.state;
    let s = i.length;
    const o = new Array(s);
    for (; s--; )
      o[s] = i[s].resolve(t, A);
    return o;
  }
  return [e.resolve(t, A)];
}
const Rl = "(anonymous)";
function Ul(e) {
  return typeof e == "object" && e !== null || typeof e == "function";
}
const UE = function() {
  const e = /* @__PURE__ */ new WeakMap();
  let t = !1, A = "", i = 0;
  return function(s) {
    return t = e.get(s), t === void 0 && (A = s.toString(), i = A.length, t = // 29 is the length of 'function () { [native code] }' which is the smallest length of a native function string
    i >= 29 && // 100 seems to be a safe upper bound of the max length of a native function. In Chrome and FF it's 56, in Edge it's 61.
    i <= 100 && // This whole heuristic *could* be tricked by a comment. Do we need to care about that?
    A.charCodeAt(i - 1) === 125 && // }
    // TODO: the spec is a little vague about the precise constraints, so we do need to test this across various browsers to make sure just one whitespace is a safe assumption.
    A.charCodeAt(i - 2) <= 32 && // whitespace
    A.charCodeAt(i - 3) === 93 && // ]
    A.charCodeAt(i - 4) === 101 && // e
    A.charCodeAt(i - 5) === 100 && // d
    A.charCodeAt(i - 6) === 111 && // o
    A.charCodeAt(i - 7) === 99 && // c
    A.charCodeAt(i - 8) === 32 && //
    A.charCodeAt(i - 9) === 101 && // e
    A.charCodeAt(i - 10) === 118 && // v
    A.charCodeAt(i - 11) === 105 && // i
    A.charCodeAt(i - 12) === 116 && // t
    A.charCodeAt(i - 13) === 97 && // a
    A.charCodeAt(i - 14) === 110 && // n
    A.charCodeAt(i - 15) === 88, e.set(s, t)), t;
  };
}(), As = {};
function Hc(e) {
  switch (typeof e) {
    case "number":
      return e >= 0 && (e | 0) === e;
    case "string": {
      const t = As[e];
      if (t !== void 0)
        return t;
      const A = e.length;
      if (A === 0)
        return As[e] = !1;
      let i = 0;
      for (let s = 0; s < A; ++s)
        if (i = e.charCodeAt(s), s === 0 && i === 48 && A > 1 || i < 48 || i > 57)
          return As[e] = !1;
      return As[e] = !0;
    }
    default:
      return !1;
  }
}
function Gl(e) {
  return `${e.toLowerCase()}:presentation`;
}
const is = /* @__PURE__ */ new Map(), _c = Object.freeze({
  /**
   * Defines a component presentation for an element.
   * @param tagName - The element name to define the presentation for.
   * @param presentation - The presentation that will be applied to matching elements.
   * @param container - The dependency injection container to register the configuration in.
   * @public
   */
  define(e, t, A) {
    const i = Gl(e);
    is.get(i) === void 0 ? is.set(i, t) : is.set(i, !1), A.register(ki.instance(i, t));
  },
  /**
   * Finds a component presentation for the specified element name,
   * searching the DOM hierarchy starting from the provided element.
   * @param tagName - The name of the element to locate the presentation for.
   * @param element - The element to begin the search from.
   * @returns The component presentation or null if none is found.
   * @public
   */
  forTag(e, t) {
    const A = Gl(e), i = is.get(A);
    return i === !1 ? H.findResponsibleContainer(t).get(A) : i || null;
  }
});
class GE {
  /**
   * Creates an instance of DefaultComponentPresentation.
   * @param template - The template to apply to the element.
   * @param styles - The styles to apply to the element.
   * @public
   */
  constructor(t, A) {
    this.template = t || null, this.styles = A === void 0 ? null : Array.isArray(A) ? Ct.create(A) : A instanceof Ct ? A : Ct.create([A]);
  }
  /**
   * Applies the presentation details to the specified element.
   * @param element - The element to apply the presentation details to.
   * @public
   */
  applyTo(t) {
    const A = t.$fastController;
    A.template === null && (A.template = this.template), A.styles === null && (A.styles = this.styles);
  }
}
class ne extends ro {
  constructor() {
    super(...arguments), this._presentation = void 0;
  }
  /**
   * A property which resolves the ComponentPresentation instance
   * for the current component.
   * @public
   */
  get $presentation() {
    return this._presentation === void 0 && (this._presentation = _c.forTag(this.tagName, this)), this._presentation;
  }
  templateChanged() {
    this.template !== void 0 && (this.$fastController.template = this.template);
  }
  stylesChanged() {
    this.styles !== void 0 && (this.$fastController.styles = this.styles);
  }
  /**
   * The connected callback for this FASTElement.
   * @remarks
   * This method is invoked by the platform whenever this FoundationElement
   * becomes connected to the document.
   * @public
   */
  connectedCallback() {
    this.$presentation !== null && this.$presentation.applyTo(this), super.connectedCallback();
  }
  /**
   * Defines an element registry function with a set of element definition defaults.
   * @param elementDefinition - The definition of the element to create the registry
   * function for.
   * @public
   */
  static compose(t) {
    return (A = {}) => new ME(this === ne ? class extends ne {
    } : this, t, A);
  }
}
S([
  mt
], ne.prototype, "template", void 0);
S([
  mt
], ne.prototype, "styles", void 0);
function XA(e, t, A) {
  return typeof e == "function" ? e(t, A) : e;
}
class ME {
  constructor(t, A, i) {
    this.type = t, this.elementDefinition = A, this.overrideDefinition = i, this.definition = Object.assign(Object.assign({}, this.elementDefinition), this.overrideDefinition);
  }
  register(t, A) {
    const i = this.definition, s = this.overrideDefinition, r = `${i.prefix || A.elementPrefix}-${i.baseName}`;
    A.tryDefineElement({
      name: r,
      type: this.type,
      baseClass: this.elementDefinition.baseClass,
      callback: (n) => {
        const l = new GE(XA(i.template, n, i), XA(i.styles, n, i));
        n.definePresentation(l);
        let a = XA(i.shadowOptions, n, i);
        n.shadowRootMode && (a ? s.shadowOptions || (a.mode = n.shadowRootMode) : a !== null && (a = { mode: n.shadowRootMode })), n.defineElement({
          elementOptions: XA(i.elementOptions, n, i),
          shadowOptions: a,
          attributes: XA(i.attributes, n, i)
        });
      }
    });
  }
}
function LE(e, ...t) {
  const A = Js.locate(e);
  t.forEach((i) => {
    Object.getOwnPropertyNames(i.prototype).forEach((o) => {
      o !== "constructor" && Object.defineProperty(
        e.prototype,
        o,
        /* eslint-disable-next-line @typescript-eslint/no-non-null-assertion */
        Object.getOwnPropertyDescriptor(i.prototype, o)
      );
    }), Js.locate(i).forEach((o) => A.push(o));
  });
}
function JE() {
  return !!(typeof window < "u" && window.document && window.document.createElement);
}
function Ml(...e) {
  return e.every((t) => t instanceof HTMLElement);
}
function YE() {
  const e = document.querySelector('meta[property="csp-nonce"]');
  return e ? e.getAttribute("content") : null;
}
let Fe;
function HE() {
  if (typeof Fe == "boolean")
    return Fe;
  if (!JE())
    return Fe = !1, Fe;
  const e = document.createElement("style"), t = YE();
  t !== null && e.setAttribute("nonce", t), document.head.appendChild(e);
  try {
    e.sheet.insertRule("foo:focus-visible {color:inherit}", 0), Fe = !0;
  } catch {
    Fe = !1;
  } finally {
    document.head.removeChild(e);
  }
  return Fe;
}
const Ll = "resize", Jl = "scroll";
var Yl;
(function(e) {
  e[e.alt = 18] = "alt", e[e.arrowDown = 40] = "arrowDown", e[e.arrowLeft = 37] = "arrowLeft", e[e.arrowRight = 39] = "arrowRight", e[e.arrowUp = 38] = "arrowUp", e[e.back = 8] = "back", e[e.backSlash = 220] = "backSlash", e[e.break = 19] = "break", e[e.capsLock = 20] = "capsLock", e[e.closeBracket = 221] = "closeBracket", e[e.colon = 186] = "colon", e[e.colon2 = 59] = "colon2", e[e.comma = 188] = "comma", e[e.ctrl = 17] = "ctrl", e[e.delete = 46] = "delete", e[e.end = 35] = "end", e[e.enter = 13] = "enter", e[e.equals = 187] = "equals", e[e.equals2 = 61] = "equals2", e[e.equals3 = 107] = "equals3", e[e.escape = 27] = "escape", e[e.forwardSlash = 191] = "forwardSlash", e[e.function1 = 112] = "function1", e[e.function10 = 121] = "function10", e[e.function11 = 122] = "function11", e[e.function12 = 123] = "function12", e[e.function2 = 113] = "function2", e[e.function3 = 114] = "function3", e[e.function4 = 115] = "function4", e[e.function5 = 116] = "function5", e[e.function6 = 117] = "function6", e[e.function7 = 118] = "function7", e[e.function8 = 119] = "function8", e[e.function9 = 120] = "function9", e[e.home = 36] = "home", e[e.insert = 45] = "insert", e[e.menu = 93] = "menu", e[e.minus = 189] = "minus", e[e.minus2 = 109] = "minus2", e[e.numLock = 144] = "numLock", e[e.numPad0 = 96] = "numPad0", e[e.numPad1 = 97] = "numPad1", e[e.numPad2 = 98] = "numPad2", e[e.numPad3 = 99] = "numPad3", e[e.numPad4 = 100] = "numPad4", e[e.numPad5 = 101] = "numPad5", e[e.numPad6 = 102] = "numPad6", e[e.numPad7 = 103] = "numPad7", e[e.numPad8 = 104] = "numPad8", e[e.numPad9 = 105] = "numPad9", e[e.numPadDivide = 111] = "numPadDivide", e[e.numPadDot = 110] = "numPadDot", e[e.numPadMinus = 109] = "numPadMinus", e[e.numPadMultiply = 106] = "numPadMultiply", e[e.numPadPlus = 107] = "numPadPlus", e[e.openBracket = 219] = "openBracket", e[e.pageDown = 34] = "pageDown", e[e.pageUp = 33] = "pageUp", e[e.period = 190] = "period", e[e.print = 44] = "print", e[e.quote = 222] = "quote", e[e.scrollLock = 145] = "scrollLock", e[e.shift = 16] = "shift", e[e.space = 32] = "space", e[e.tab = 9] = "tab", e[e.tilde = 192] = "tilde", e[e.windowsLeft = 91] = "windowsLeft", e[e.windowsOpera = 219] = "windowsOpera", e[e.windowsRight = 92] = "windowsRight";
})(Yl || (Yl = {}));
const _E = "ArrowDown", TE = "ArrowLeft", OE = "ArrowRight", $E = "ArrowUp", PE = "Enter", qE = "Home", VE = "End", zE = " ";
var ve;
(function(e) {
  e.ltr = "ltr", e.rtl = "rtl";
})(ve || (ve = {}));
var G;
(function(e) {
  e.Canvas = "Canvas", e.CanvasText = "CanvasText", e.LinkText = "LinkText", e.VisitedText = "VisitedText", e.ActiveText = "ActiveText", e.ButtonFace = "ButtonFace", e.ButtonText = "ButtonText", e.Field = "Field", e.FieldText = "FieldText", e.Highlight = "Highlight", e.HighlightText = "HighlightText", e.GrayText = "GrayText";
})(G || (G = {}));
const qr = (e) => {
  const t = e.closest("[dir]");
  return t !== null && t.dir === "rtl" ? ve.rtl : ve.ltr;
};
class KE {
  constructor() {
    this.intersectionDetector = null, this.observedElements = /* @__PURE__ */ new Map(), this.requestPosition = (t, A) => {
      var i;
      if (this.intersectionDetector !== null) {
        if (this.observedElements.has(t)) {
          (i = this.observedElements.get(t)) === null || i === void 0 || i.push(A);
          return;
        }
        this.observedElements.set(t, [A]), this.intersectionDetector.observe(t);
      }
    }, this.cancelRequestPosition = (t, A) => {
      const i = this.observedElements.get(t);
      if (i !== void 0) {
        const s = i.indexOf(A);
        s !== -1 && i.splice(s, 1);
      }
    }, this.initializeIntersectionDetector = () => {
      oe.IntersectionObserver && (this.intersectionDetector = new IntersectionObserver(this.handleIntersection, {
        root: null,
        rootMargin: "0px",
        threshold: [0, 1]
      }));
    }, this.handleIntersection = (t) => {
      if (this.intersectionDetector === null)
        return;
      const A = [], i = [];
      t.forEach((s) => {
        var o;
        (o = this.intersectionDetector) === null || o === void 0 || o.unobserve(s.target);
        const r = this.observedElements.get(s.target);
        r !== void 0 && (r.forEach((n) => {
          let l = A.indexOf(n);
          l === -1 && (l = A.length, A.push(n), i.push([])), i[l].push(s);
        }), this.observedElements.delete(s.target));
      }), A.forEach((s, o) => {
        s(i[o]);
      });
    }, this.initializeIntersectionDetector();
  }
}
class F extends ne {
  constructor() {
    super(...arguments), this.anchor = "", this.viewport = "", this.horizontalPositioningMode = "uncontrolled", this.horizontalDefaultPosition = "unset", this.horizontalViewportLock = !1, this.horizontalInset = !1, this.horizontalScaling = "content", this.verticalPositioningMode = "uncontrolled", this.verticalDefaultPosition = "unset", this.verticalViewportLock = !1, this.verticalInset = !1, this.verticalScaling = "content", this.fixedPlacement = !1, this.autoUpdateMode = "anchor", this.anchorElement = null, this.viewportElement = null, this.initialLayoutComplete = !1, this.resizeDetector = null, this.baseHorizontalOffset = 0, this.baseVerticalOffset = 0, this.pendingPositioningUpdate = !1, this.pendingReset = !1, this.currentDirection = ve.ltr, this.regionVisible = !1, this.forceUpdate = !1, this.updateThreshold = 0.5, this.update = () => {
      this.pendingPositioningUpdate || this.requestPositionUpdates();
    }, this.startObservers = () => {
      this.stopObservers(), this.anchorElement !== null && (this.requestPositionUpdates(), this.resizeDetector !== null && (this.resizeDetector.observe(this.anchorElement), this.resizeDetector.observe(this)));
    }, this.requestPositionUpdates = () => {
      this.anchorElement === null || this.pendingPositioningUpdate || (F.intersectionService.requestPosition(this, this.handleIntersection), F.intersectionService.requestPosition(this.anchorElement, this.handleIntersection), this.viewportElement !== null && F.intersectionService.requestPosition(this.viewportElement, this.handleIntersection), this.pendingPositioningUpdate = !0);
    }, this.stopObservers = () => {
      this.pendingPositioningUpdate && (this.pendingPositioningUpdate = !1, F.intersectionService.cancelRequestPosition(this, this.handleIntersection), this.anchorElement !== null && F.intersectionService.cancelRequestPosition(this.anchorElement, this.handleIntersection), this.viewportElement !== null && F.intersectionService.cancelRequestPosition(this.viewportElement, this.handleIntersection)), this.resizeDetector !== null && this.resizeDetector.disconnect();
    }, this.getViewport = () => typeof this.viewport != "string" || this.viewport === "" ? document.documentElement : document.getElementById(this.viewport), this.getAnchor = () => document.getElementById(this.anchor), this.handleIntersection = (t) => {
      this.pendingPositioningUpdate && (this.pendingPositioningUpdate = !1, this.applyIntersectionEntries(t) && this.updateLayout());
    }, this.applyIntersectionEntries = (t) => {
      const A = t.find((o) => o.target === this), i = t.find((o) => o.target === this.anchorElement), s = t.find((o) => o.target === this.viewportElement);
      return A === void 0 || s === void 0 || i === void 0 ? !1 : !this.regionVisible || this.forceUpdate || this.regionRect === void 0 || this.anchorRect === void 0 || this.viewportRect === void 0 || this.isRectDifferent(this.anchorRect, i.boundingClientRect) || this.isRectDifferent(this.viewportRect, s.boundingClientRect) || this.isRectDifferent(this.regionRect, A.boundingClientRect) ? (this.regionRect = A.boundingClientRect, this.anchorRect = i.boundingClientRect, this.viewportElement === document.documentElement ? this.viewportRect = new DOMRectReadOnly(s.boundingClientRect.x + document.documentElement.scrollLeft, s.boundingClientRect.y + document.documentElement.scrollTop, s.boundingClientRect.width, s.boundingClientRect.height) : this.viewportRect = s.boundingClientRect, this.updateRegionOffset(), this.forceUpdate = !1, !0) : !1;
    }, this.updateRegionOffset = () => {
      this.anchorRect && this.regionRect && (this.baseHorizontalOffset = this.baseHorizontalOffset + (this.anchorRect.left - this.regionRect.left) + (this.translateX - this.baseHorizontalOffset), this.baseVerticalOffset = this.baseVerticalOffset + (this.anchorRect.top - this.regionRect.top) + (this.translateY - this.baseVerticalOffset));
    }, this.isRectDifferent = (t, A) => Math.abs(t.top - A.top) > this.updateThreshold || Math.abs(t.right - A.right) > this.updateThreshold || Math.abs(t.bottom - A.bottom) > this.updateThreshold || Math.abs(t.left - A.left) > this.updateThreshold, this.handleResize = (t) => {
      this.update();
    }, this.reset = () => {
      this.pendingReset && (this.pendingReset = !1, this.anchorElement === null && (this.anchorElement = this.getAnchor()), this.viewportElement === null && (this.viewportElement = this.getViewport()), this.currentDirection = qr(this), this.startObservers());
    }, this.updateLayout = () => {
      let t, A;
      if (this.horizontalPositioningMode !== "uncontrolled") {
        const o = this.getPositioningOptions(this.horizontalInset);
        if (this.horizontalDefaultPosition === "center")
          A = "center";
        else if (this.horizontalDefaultPosition !== "unset") {
          let h = this.horizontalDefaultPosition;
          if (h === "start" || h === "end") {
            const u = qr(this);
            if (u !== this.currentDirection) {
              this.currentDirection = u, this.initialize();
              return;
            }
            this.currentDirection === ve.ltr ? h = h === "start" ? "left" : "right" : h = h === "start" ? "right" : "left";
          }
          switch (h) {
            case "left":
              A = this.horizontalInset ? "insetStart" : "start";
              break;
            case "right":
              A = this.horizontalInset ? "insetEnd" : "end";
              break;
          }
        }
        const r = this.horizontalThreshold !== void 0 ? this.horizontalThreshold : this.regionRect !== void 0 ? this.regionRect.width : 0, n = this.anchorRect !== void 0 ? this.anchorRect.left : 0, l = this.anchorRect !== void 0 ? this.anchorRect.right : 0, a = this.anchorRect !== void 0 ? this.anchorRect.width : 0, c = this.viewportRect !== void 0 ? this.viewportRect.left : 0, g = this.viewportRect !== void 0 ? this.viewportRect.right : 0;
        (A === void 0 || this.horizontalPositioningMode !== "locktodefault" && this.getAvailableSpace(A, n, l, a, c, g) < r) && (A = this.getAvailableSpace(o[0], n, l, a, c, g) > this.getAvailableSpace(o[1], n, l, a, c, g) ? o[0] : o[1]);
      }
      if (this.verticalPositioningMode !== "uncontrolled") {
        const o = this.getPositioningOptions(this.verticalInset);
        if (this.verticalDefaultPosition === "center")
          t = "center";
        else if (this.verticalDefaultPosition !== "unset")
          switch (this.verticalDefaultPosition) {
            case "top":
              t = this.verticalInset ? "insetStart" : "start";
              break;
            case "bottom":
              t = this.verticalInset ? "insetEnd" : "end";
              break;
          }
        const r = this.verticalThreshold !== void 0 ? this.verticalThreshold : this.regionRect !== void 0 ? this.regionRect.height : 0, n = this.anchorRect !== void 0 ? this.anchorRect.top : 0, l = this.anchorRect !== void 0 ? this.anchorRect.bottom : 0, a = this.anchorRect !== void 0 ? this.anchorRect.height : 0, c = this.viewportRect !== void 0 ? this.viewportRect.top : 0, g = this.viewportRect !== void 0 ? this.viewportRect.bottom : 0;
        (t === void 0 || this.verticalPositioningMode !== "locktodefault" && this.getAvailableSpace(t, n, l, a, c, g) < r) && (t = this.getAvailableSpace(o[0], n, l, a, c, g) > this.getAvailableSpace(o[1], n, l, a, c, g) ? o[0] : o[1]);
      }
      const i = this.getNextRegionDimension(A, t), s = this.horizontalPosition !== A || this.verticalPosition !== t;
      if (this.setHorizontalPosition(A, i), this.setVerticalPosition(t, i), this.updateRegionStyle(), !this.initialLayoutComplete) {
        this.initialLayoutComplete = !0, this.requestPositionUpdates();
        return;
      }
      this.regionVisible || (this.regionVisible = !0, this.style.removeProperty("pointer-events"), this.style.removeProperty("opacity"), this.classList.toggle("loaded", !0), this.$emit("loaded", this, { bubbles: !1 })), this.updatePositionClasses(), s && this.$emit("positionchange", this, { bubbles: !1 });
    }, this.updateRegionStyle = () => {
      this.style.width = this.regionWidth, this.style.height = this.regionHeight, this.style.transform = `translate(${this.translateX}px, ${this.translateY}px)`;
    }, this.updatePositionClasses = () => {
      this.classList.toggle("top", this.verticalPosition === "start"), this.classList.toggle("bottom", this.verticalPosition === "end"), this.classList.toggle("inset-top", this.verticalPosition === "insetStart"), this.classList.toggle("inset-bottom", this.verticalPosition === "insetEnd"), this.classList.toggle("vertical-center", this.verticalPosition === "center"), this.classList.toggle("left", this.horizontalPosition === "start"), this.classList.toggle("right", this.horizontalPosition === "end"), this.classList.toggle("inset-left", this.horizontalPosition === "insetStart"), this.classList.toggle("inset-right", this.horizontalPosition === "insetEnd"), this.classList.toggle("horizontal-center", this.horizontalPosition === "center");
    }, this.setHorizontalPosition = (t, A) => {
      if (t === void 0 || this.regionRect === void 0 || this.anchorRect === void 0 || this.viewportRect === void 0)
        return;
      let i = 0;
      switch (this.horizontalScaling) {
        case "anchor":
        case "fill":
          i = this.horizontalViewportLock ? this.viewportRect.width : A.width, this.regionWidth = `${i}px`;
          break;
        case "content":
          i = this.regionRect.width, this.regionWidth = "unset";
          break;
      }
      let s = 0;
      switch (t) {
        case "start":
          this.translateX = this.baseHorizontalOffset - i, this.horizontalViewportLock && this.anchorRect.left > this.viewportRect.right && (this.translateX = this.translateX - (this.anchorRect.left - this.viewportRect.right));
          break;
        case "insetStart":
          this.translateX = this.baseHorizontalOffset - i + this.anchorRect.width, this.horizontalViewportLock && this.anchorRect.right > this.viewportRect.right && (this.translateX = this.translateX - (this.anchorRect.right - this.viewportRect.right));
          break;
        case "insetEnd":
          this.translateX = this.baseHorizontalOffset, this.horizontalViewportLock && this.anchorRect.left < this.viewportRect.left && (this.translateX = this.translateX - (this.anchorRect.left - this.viewportRect.left));
          break;
        case "end":
          this.translateX = this.baseHorizontalOffset + this.anchorRect.width, this.horizontalViewportLock && this.anchorRect.right < this.viewportRect.left && (this.translateX = this.translateX - (this.anchorRect.right - this.viewportRect.left));
          break;
        case "center":
          if (s = (this.anchorRect.width - i) / 2, this.translateX = this.baseHorizontalOffset + s, this.horizontalViewportLock) {
            const o = this.anchorRect.left + s, r = this.anchorRect.right - s;
            o < this.viewportRect.left && !(r > this.viewportRect.right) ? this.translateX = this.translateX - (o - this.viewportRect.left) : r > this.viewportRect.right && !(o < this.viewportRect.left) && (this.translateX = this.translateX - (r - this.viewportRect.right));
          }
          break;
      }
      this.horizontalPosition = t;
    }, this.setVerticalPosition = (t, A) => {
      if (t === void 0 || this.regionRect === void 0 || this.anchorRect === void 0 || this.viewportRect === void 0)
        return;
      let i = 0;
      switch (this.verticalScaling) {
        case "anchor":
        case "fill":
          i = this.verticalViewportLock ? this.viewportRect.height : A.height, this.regionHeight = `${i}px`;
          break;
        case "content":
          i = this.regionRect.height, this.regionHeight = "unset";
          break;
      }
      let s = 0;
      switch (t) {
        case "start":
          this.translateY = this.baseVerticalOffset - i, this.verticalViewportLock && this.anchorRect.top > this.viewportRect.bottom && (this.translateY = this.translateY - (this.anchorRect.top - this.viewportRect.bottom));
          break;
        case "insetStart":
          this.translateY = this.baseVerticalOffset - i + this.anchorRect.height, this.verticalViewportLock && this.anchorRect.bottom > this.viewportRect.bottom && (this.translateY = this.translateY - (this.anchorRect.bottom - this.viewportRect.bottom));
          break;
        case "insetEnd":
          this.translateY = this.baseVerticalOffset, this.verticalViewportLock && this.anchorRect.top < this.viewportRect.top && (this.translateY = this.translateY - (this.anchorRect.top - this.viewportRect.top));
          break;
        case "end":
          this.translateY = this.baseVerticalOffset + this.anchorRect.height, this.verticalViewportLock && this.anchorRect.bottom < this.viewportRect.top && (this.translateY = this.translateY - (this.anchorRect.bottom - this.viewportRect.top));
          break;
        case "center":
          if (s = (this.anchorRect.height - i) / 2, this.translateY = this.baseVerticalOffset + s, this.verticalViewportLock) {
            const o = this.anchorRect.top + s, r = this.anchorRect.bottom - s;
            o < this.viewportRect.top && !(r > this.viewportRect.bottom) ? this.translateY = this.translateY - (o - this.viewportRect.top) : r > this.viewportRect.bottom && !(o < this.viewportRect.top) && (this.translateY = this.translateY - (r - this.viewportRect.bottom));
          }
      }
      this.verticalPosition = t;
    }, this.getPositioningOptions = (t) => t ? ["insetStart", "insetEnd"] : ["start", "end"], this.getAvailableSpace = (t, A, i, s, o, r) => {
      const n = A - o, l = r - (A + s);
      switch (t) {
        case "start":
          return n;
        case "insetStart":
          return n + s;
        case "insetEnd":
          return l + s;
        case "end":
          return l;
        case "center":
          return Math.min(n, l) * 2 + s;
      }
    }, this.getNextRegionDimension = (t, A) => {
      const i = {
        height: this.regionRect !== void 0 ? this.regionRect.height : 0,
        width: this.regionRect !== void 0 ? this.regionRect.width : 0
      };
      return t !== void 0 && this.horizontalScaling === "fill" ? i.width = this.getAvailableSpace(t, this.anchorRect !== void 0 ? this.anchorRect.left : 0, this.anchorRect !== void 0 ? this.anchorRect.right : 0, this.anchorRect !== void 0 ? this.anchorRect.width : 0, this.viewportRect !== void 0 ? this.viewportRect.left : 0, this.viewportRect !== void 0 ? this.viewportRect.right : 0) : this.horizontalScaling === "anchor" && (i.width = this.anchorRect !== void 0 ? this.anchorRect.width : 0), A !== void 0 && this.verticalScaling === "fill" ? i.height = this.getAvailableSpace(A, this.anchorRect !== void 0 ? this.anchorRect.top : 0, this.anchorRect !== void 0 ? this.anchorRect.bottom : 0, this.anchorRect !== void 0 ? this.anchorRect.height : 0, this.viewportRect !== void 0 ? this.viewportRect.top : 0, this.viewportRect !== void 0 ? this.viewportRect.bottom : 0) : this.verticalScaling === "anchor" && (i.height = this.anchorRect !== void 0 ? this.anchorRect.height : 0), i;
    }, this.startAutoUpdateEventListeners = () => {
      window.addEventListener(Ll, this.update, { passive: !0 }), window.addEventListener(Jl, this.update, {
        passive: !0,
        capture: !0
      }), this.resizeDetector !== null && this.viewportElement !== null && this.resizeDetector.observe(this.viewportElement);
    }, this.stopAutoUpdateEventListeners = () => {
      window.removeEventListener(Ll, this.update), window.removeEventListener(Jl, this.update), this.resizeDetector !== null && this.viewportElement !== null && this.resizeDetector.unobserve(this.viewportElement);
    };
  }
  anchorChanged() {
    this.initialLayoutComplete && (this.anchorElement = this.getAnchor());
  }
  viewportChanged() {
    this.initialLayoutComplete && (this.viewportElement = this.getViewport());
  }
  horizontalPositioningModeChanged() {
    this.requestReset();
  }
  horizontalDefaultPositionChanged() {
    this.updateForAttributeChange();
  }
  horizontalViewportLockChanged() {
    this.updateForAttributeChange();
  }
  horizontalInsetChanged() {
    this.updateForAttributeChange();
  }
  horizontalThresholdChanged() {
    this.updateForAttributeChange();
  }
  horizontalScalingChanged() {
    this.updateForAttributeChange();
  }
  verticalPositioningModeChanged() {
    this.requestReset();
  }
  verticalDefaultPositionChanged() {
    this.updateForAttributeChange();
  }
  verticalViewportLockChanged() {
    this.updateForAttributeChange();
  }
  verticalInsetChanged() {
    this.updateForAttributeChange();
  }
  verticalThresholdChanged() {
    this.updateForAttributeChange();
  }
  verticalScalingChanged() {
    this.updateForAttributeChange();
  }
  fixedPlacementChanged() {
    this.$fastController.isConnected && this.initialLayoutComplete && this.initialize();
  }
  autoUpdateModeChanged(t, A) {
    this.$fastController.isConnected && this.initialLayoutComplete && (t === "auto" && this.stopAutoUpdateEventListeners(), A === "auto" && this.startAutoUpdateEventListeners());
  }
  anchorElementChanged() {
    this.requestReset();
  }
  viewportElementChanged() {
    this.$fastController.isConnected && this.initialLayoutComplete && this.initialize();
  }
  /**
   * @internal
   */
  connectedCallback() {
    super.connectedCallback(), this.autoUpdateMode === "auto" && this.startAutoUpdateEventListeners(), this.initialize();
  }
  /**
   * @internal
   */
  disconnectedCallback() {
    super.disconnectedCallback(), this.autoUpdateMode === "auto" && this.stopAutoUpdateEventListeners(), this.stopObservers(), this.disconnectResizeDetector();
  }
  /**
   * @internal
   */
  adoptedCallback() {
    this.initialize();
  }
  /**
   * destroys the instance's resize observer
   */
  disconnectResizeDetector() {
    this.resizeDetector !== null && (this.resizeDetector.disconnect(), this.resizeDetector = null);
  }
  /**
   * initializes the instance's resize observer
   */
  initializeResizeDetector() {
    this.disconnectResizeDetector(), this.resizeDetector = new window.ResizeObserver(this.handleResize);
  }
  /**
   * react to attribute changes that don't require a reset
   */
  updateForAttributeChange() {
    this.$fastController.isConnected && this.initialLayoutComplete && (this.forceUpdate = !0, this.update());
  }
  /**
   * fully initializes the component
   */
  initialize() {
    this.initializeResizeDetector(), this.anchorElement === null && (this.anchorElement = this.getAnchor()), this.requestReset();
  }
  /**
   * Request a reset if there are currently no open requests
   */
  requestReset() {
    this.$fastController.isConnected && this.pendingReset === !1 && (this.setInitialState(), R.queueUpdate(() => this.reset()), this.pendingReset = !0);
  }
  /**
   * sets the starting configuration for component internal values
   */
  setInitialState() {
    this.initialLayoutComplete = !1, this.regionVisible = !1, this.translateX = 0, this.translateY = 0, this.baseHorizontalOffset = 0, this.baseVerticalOffset = 0, this.viewportRect = void 0, this.regionRect = void 0, this.anchorRect = void 0, this.verticalPosition = void 0, this.horizontalPosition = void 0, this.style.opacity = "0", this.style.pointerEvents = "none", this.forceUpdate = !1, this.style.position = this.fixedPlacement ? "fixed" : "absolute", this.updatePositionClasses(), this.updateRegionStyle();
  }
}
F.intersectionService = new KE();
S([
  j
], F.prototype, "anchor", void 0);
S([
  j
], F.prototype, "viewport", void 0);
S([
  j({ attribute: "horizontal-positioning-mode" })
], F.prototype, "horizontalPositioningMode", void 0);
S([
  j({ attribute: "horizontal-default-position" })
], F.prototype, "horizontalDefaultPosition", void 0);
S([
  j({ attribute: "horizontal-viewport-lock", mode: "boolean" })
], F.prototype, "horizontalViewportLock", void 0);
S([
  j({ attribute: "horizontal-inset", mode: "boolean" })
], F.prototype, "horizontalInset", void 0);
S([
  j({ attribute: "horizontal-threshold" })
], F.prototype, "horizontalThreshold", void 0);
S([
  j({ attribute: "horizontal-scaling" })
], F.prototype, "horizontalScaling", void 0);
S([
  j({ attribute: "vertical-positioning-mode" })
], F.prototype, "verticalPositioningMode", void 0);
S([
  j({ attribute: "vertical-default-position" })
], F.prototype, "verticalDefaultPosition", void 0);
S([
  j({ attribute: "vertical-viewport-lock", mode: "boolean" })
], F.prototype, "verticalViewportLock", void 0);
S([
  j({ attribute: "vertical-inset", mode: "boolean" })
], F.prototype, "verticalInset", void 0);
S([
  j({ attribute: "vertical-threshold" })
], F.prototype, "verticalThreshold", void 0);
S([
  j({ attribute: "vertical-scaling" })
], F.prototype, "verticalScaling", void 0);
S([
  j({ attribute: "fixed-placement", mode: "boolean" })
], F.prototype, "fixedPlacement", void 0);
S([
  j({ attribute: "auto-update-mode" })
], F.prototype, "autoUpdateMode", void 0);
S([
  mt
], F.prototype, "anchorElement", void 0);
S([
  mt
], F.prototype, "viewportElement", void 0);
S([
  mt
], F.prototype, "initialLayoutComplete", void 0);
function Vr(e) {
  const t = e.parentElement;
  if (t)
    return t;
  {
    const A = e.getRootNode();
    if (A.host instanceof HTMLElement)
      return A.host;
  }
  return null;
}
function jE(e, t) {
  let A = t;
  for (; A !== null; ) {
    if (A === e)
      return !0;
    A = Vr(A);
  }
  return !1;
}
const se = document.createElement("div");
function ZE(e) {
  return e instanceof ro;
}
class Rn {
  setProperty(t, A) {
    R.queueUpdate(() => this.target.setProperty(t, A));
  }
  removeProperty(t) {
    R.queueUpdate(() => this.target.removeProperty(t));
  }
}
class WE extends Rn {
  constructor(t) {
    super();
    const A = new CSSStyleSheet();
    this.target = A.cssRules[A.insertRule(":host{}")].style, t.$fastController.addStyles(Ct.create([A]));
  }
}
class XE extends Rn {
  constructor() {
    super();
    const t = new CSSStyleSheet();
    this.target = t.cssRules[t.insertRule(":root{}")].style, document.adoptedStyleSheets = [
      ...document.adoptedStyleSheets,
      t
    ];
  }
}
class tf extends Rn {
  constructor() {
    super(), this.style = document.createElement("style"), document.head.appendChild(this.style);
    const { sheet: t } = this.style;
    if (t) {
      const A = t.insertRule(":root{}", t.cssRules.length);
      this.target = t.cssRules[A].style;
    }
  }
}
class Tc {
  constructor(t) {
    this.store = /* @__PURE__ */ new Map(), this.target = null;
    const A = t.$fastController;
    this.style = document.createElement("style"), A.addStyles(this.style), At.getNotifier(A).subscribe(this, "isConnected"), this.handleChange(A, "isConnected");
  }
  targetChanged() {
    if (this.target !== null)
      for (const [t, A] of this.store.entries())
        this.target.setProperty(t, A);
  }
  setProperty(t, A) {
    this.store.set(t, A), R.queueUpdate(() => {
      this.target !== null && this.target.setProperty(t, A);
    });
  }
  removeProperty(t) {
    this.store.delete(t), R.queueUpdate(() => {
      this.target !== null && this.target.removeProperty(t);
    });
  }
  handleChange(t, A) {
    const { sheet: i } = this.style;
    if (i) {
      const s = i.insertRule(":host{}", i.cssRules.length);
      this.target = i.cssRules[s].style;
    } else
      this.target = null;
  }
}
S([
  mt
], Tc.prototype, "target", void 0);
class ef {
  constructor(t) {
    this.target = t.style;
  }
  setProperty(t, A) {
    R.queueUpdate(() => this.target.setProperty(t, A));
  }
  removeProperty(t) {
    R.queueUpdate(() => this.target.removeProperty(t));
  }
}
class tt {
  setProperty(t, A) {
    tt.properties[t] = A;
    for (const i of tt.roots.values())
      nA.getOrCreate(tt.normalizeRoot(i)).setProperty(t, A);
  }
  removeProperty(t) {
    delete tt.properties[t];
    for (const A of tt.roots.values())
      nA.getOrCreate(tt.normalizeRoot(A)).removeProperty(t);
  }
  static registerRoot(t) {
    const { roots: A } = tt;
    if (!A.has(t)) {
      A.add(t);
      const i = nA.getOrCreate(this.normalizeRoot(t));
      for (const s in tt.properties)
        i.setProperty(s, tt.properties[s]);
    }
  }
  static unregisterRoot(t) {
    const { roots: A } = tt;
    if (A.has(t)) {
      A.delete(t);
      const i = nA.getOrCreate(tt.normalizeRoot(t));
      for (const s in tt.properties)
        i.removeProperty(s);
    }
  }
  /**
   * Returns the document when provided the default element,
   * otherwise is a no-op
   * @param root - the root to normalize
   */
  static normalizeRoot(t) {
    return t === se ? document : t;
  }
}
tt.roots = /* @__PURE__ */ new Set();
tt.properties = {};
const nr = /* @__PURE__ */ new WeakMap(), Af = R.supportsAdoptedStyleSheets ? WE : Tc, nA = Object.freeze({
  getOrCreate(e) {
    if (nr.has(e))
      return nr.get(e);
    let t;
    return e === se ? t = new tt() : e instanceof Document ? t = R.supportsAdoptedStyleSheets ? new XE() : new tf() : ZE(e) ? t = new Af(e) : t = new ef(e), nr.set(e, t), t;
  }
});
class ut extends Fn {
  constructor(t) {
    super(), this.subscribers = /* @__PURE__ */ new WeakMap(), this._appliedTo = /* @__PURE__ */ new Set(), this.name = t.name, t.cssCustomPropertyName !== null && (this.cssCustomProperty = `--${t.cssCustomPropertyName}`, this.cssVar = `var(${this.cssCustomProperty})`), this.id = ut.uniqueId(), ut.tokensById.set(this.id, this);
  }
  get appliedTo() {
    return [...this._appliedTo];
  }
  static from(t) {
    return new ut({
      name: typeof t == "string" ? t : t.name,
      cssCustomPropertyName: typeof t == "string" ? t : t.cssCustomPropertyName === void 0 ? t.name : t.cssCustomPropertyName
    });
  }
  static isCSSDesignToken(t) {
    return typeof t.cssCustomProperty == "string";
  }
  static isDerivedDesignTokenValue(t) {
    return typeof t == "function";
  }
  /**
   * Gets a token by ID. Returns undefined if the token was not found.
   * @param id - The ID of the token
   * @returns
   */
  static getTokenById(t) {
    return ut.tokensById.get(t);
  }
  getOrCreateSubscriberSet(t = this) {
    return this.subscribers.get(t) || this.subscribers.set(t, /* @__PURE__ */ new Set()) && this.subscribers.get(t);
  }
  createCSS() {
    return this.cssVar || "";
  }
  getValueFor(t) {
    const A = O.getOrCreate(t).get(this);
    if (A !== void 0)
      return A;
    throw new Error(`Value could not be retrieved for token named "${this.name}". Ensure the value is set for ${t} or an ancestor of ${t}.`);
  }
  setValueFor(t, A) {
    return this._appliedTo.add(t), A instanceof ut && (A = this.alias(A)), O.getOrCreate(t).set(this, A), this;
  }
  deleteValueFor(t) {
    return this._appliedTo.delete(t), O.existsFor(t) && O.getOrCreate(t).delete(this), this;
  }
  withDefault(t) {
    return this.setValueFor(se, t), this;
  }
  subscribe(t, A) {
    const i = this.getOrCreateSubscriberSet(A);
    A && !O.existsFor(A) && O.getOrCreate(A), i.has(t) || i.add(t);
  }
  unsubscribe(t, A) {
    const i = this.subscribers.get(A || this);
    i && i.has(t) && i.delete(t);
  }
  /**
   * Notifies subscribers that the value for an element has changed.
   * @param element - The element to emit a notification for
   */
  notify(t) {
    const A = Object.freeze({ token: this, target: t });
    this.subscribers.has(this) && this.subscribers.get(this).forEach((i) => i.handleChange(A)), this.subscribers.has(t) && this.subscribers.get(t).forEach((i) => i.handleChange(A));
  }
  /**
   * Alias the token to the provided token.
   * @param token - the token to alias to
   */
  alias(t) {
    return (A) => t.getValueFor(A);
  }
}
ut.uniqueId = (() => {
  let e = 0;
  return () => (e++, e.toString(16));
})();
ut.tokensById = /* @__PURE__ */ new Map();
class sf {
  startReflection(t, A) {
    t.subscribe(this, A), this.handleChange({ token: t, target: A });
  }
  stopReflection(t, A) {
    t.unsubscribe(this, A), this.remove(t, A);
  }
  handleChange(t) {
    const { token: A, target: i } = t;
    this.add(A, i);
  }
  add(t, A) {
    nA.getOrCreate(A).setProperty(t.cssCustomProperty, this.resolveCSSValue(O.getOrCreate(A).get(t)));
  }
  remove(t, A) {
    nA.getOrCreate(A).removeProperty(t.cssCustomProperty);
  }
  resolveCSSValue(t) {
    return t && typeof t.createCSS == "function" ? t.createCSS() : t;
  }
}
class of {
  constructor(t, A, i) {
    this.source = t, this.token = A, this.node = i, this.dependencies = /* @__PURE__ */ new Set(), this.observer = At.binding(t, this, !1), this.observer.handleChange = this.observer.call, this.handleChange();
  }
  disconnect() {
    this.observer.disconnect();
  }
  /**
   * @internal
   */
  handleChange() {
    this.node.store.set(this.token, this.observer.observe(this.node.target, ui));
  }
}
class rf {
  constructor() {
    this.values = /* @__PURE__ */ new Map();
  }
  set(t, A) {
    this.values.get(t) !== A && (this.values.set(t, A), At.getNotifier(this).notify(t.id));
  }
  get(t) {
    return At.track(this, t.id), this.values.get(t);
  }
  delete(t) {
    this.values.delete(t);
  }
  all() {
    return this.values.entries();
  }
}
const ti = /* @__PURE__ */ new WeakMap(), ei = /* @__PURE__ */ new WeakMap();
class O {
  constructor(t) {
    this.target = t, this.store = new rf(), this.children = [], this.assignedValues = /* @__PURE__ */ new Map(), this.reflecting = /* @__PURE__ */ new Set(), this.bindingObservers = /* @__PURE__ */ new Map(), this.tokenValueChangeHandler = {
      handleChange: (A, i) => {
        const s = ut.getTokenById(i);
        if (s && (s.notify(this.target), ut.isCSSDesignToken(s))) {
          const o = this.parent, r = this.isReflecting(s);
          if (o) {
            const n = o.get(s), l = A.get(s);
            n !== l && !r ? this.reflectToCSS(s) : n === l && r && this.stopReflectToCSS(s);
          } else
            r || this.reflectToCSS(s);
        }
      }
    }, ti.set(t, this), At.getNotifier(this.store).subscribe(this.tokenValueChangeHandler), t instanceof ro ? t.$fastController.addBehaviors([this]) : t.isConnected && this.bind();
  }
  /**
   * Returns a DesignTokenNode for an element.
   * Creates a new instance if one does not already exist for a node,
   * otherwise returns the cached instance
   *
   * @param target - The HTML element to retrieve a DesignTokenNode for
   */
  static getOrCreate(t) {
    return ti.get(t) || new O(t);
  }
  /**
   * Determines if a DesignTokenNode has been created for a target
   * @param target - The element to test
   */
  static existsFor(t) {
    return ti.has(t);
  }
  /**
   * Searches for and return the nearest parent DesignTokenNode.
   * Null is returned if no node is found or the node provided is for a default element.
   */
  static findParent(t) {
    if (se !== t.target) {
      let A = Vr(t.target);
      for (; A !== null; ) {
        if (ti.has(A))
          return ti.get(A);
        A = Vr(A);
      }
      return O.getOrCreate(se);
    }
    return null;
  }
  /**
   * Finds the closest node with a value explicitly assigned for a token, otherwise null.
   * @param token - The token to look for
   * @param start - The node to start looking for value assignment
   * @returns
   */
  static findClosestAssignedNode(t, A) {
    let i = A;
    do {
      if (i.has(t))
        return i;
      i = i.parent ? i.parent : i.target !== se ? O.getOrCreate(se) : null;
    } while (i !== null);
    return null;
  }
  /**
   * The parent DesignTokenNode, or null.
   */
  get parent() {
    return ei.get(this) || null;
  }
  /**
   * Checks if a token has been assigned an explicit value the node.
   * @param token - the token to check.
   */
  has(t) {
    return this.assignedValues.has(t);
  }
  /**
   * Gets the value of a token for a node
   * @param token - The token to retrieve the value for
   * @returns
   */
  get(t) {
    const A = this.store.get(t);
    if (A !== void 0)
      return A;
    const i = this.getRaw(t);
    if (i !== void 0)
      return this.hydrate(t, i), this.get(t);
  }
  /**
   * Retrieves the raw assigned value of a token from the nearest assigned node.
   * @param token - The token to retrieve a raw value for
   * @returns
   */
  getRaw(t) {
    var A;
    return this.assignedValues.has(t) ? this.assignedValues.get(t) : (A = O.findClosestAssignedNode(t, this)) === null || A === void 0 ? void 0 : A.getRaw(t);
  }
  /**
   * Sets a token to a value for a node
   * @param token - The token to set
   * @param value - The value to set the token to
   */
  set(t, A) {
    ut.isDerivedDesignTokenValue(this.assignedValues.get(t)) && this.tearDownBindingObserver(t), this.assignedValues.set(t, A), ut.isDerivedDesignTokenValue(A) ? this.setupBindingObserver(t, A) : this.store.set(t, A);
  }
  /**
   * Deletes a token value for the node.
   * @param token - The token to delete the value for
   */
  delete(t) {
    this.assignedValues.delete(t), this.tearDownBindingObserver(t);
    const A = this.getRaw(t);
    A ? this.hydrate(t, A) : this.store.delete(t);
  }
  /**
   * Invoked when the DesignTokenNode.target is attached to the document
   */
  bind() {
    const t = O.findParent(this);
    t && t.appendChild(this);
    for (const A of this.assignedValues.keys())
      A.notify(this.target);
  }
  /**
   * Invoked when the DesignTokenNode.target is detached from the document
   */
  unbind() {
    this.parent && ei.get(this).removeChild(this);
  }
  /**
   * Appends a child to a parent DesignTokenNode.
   * @param child - The child to append to the node
   */
  appendChild(t) {
    t.parent && ei.get(t).removeChild(t);
    const A = this.children.filter((i) => t.contains(i));
    ei.set(t, this), this.children.push(t), A.forEach((i) => t.appendChild(i)), At.getNotifier(this.store).subscribe(t);
    for (const [i, s] of this.store.all())
      t.hydrate(i, this.bindingObservers.has(i) ? this.getRaw(i) : s);
  }
  /**
   * Removes a child from a node.
   * @param child - The child to remove.
   */
  removeChild(t) {
    const A = this.children.indexOf(t);
    return A !== -1 && this.children.splice(A, 1), At.getNotifier(this.store).unsubscribe(t), t.parent === this ? ei.delete(t) : !1;
  }
  /**
   * Tests whether a provided node is contained by
   * the calling node.
   * @param test - The node to test
   */
  contains(t) {
    return jE(this.target, t.target);
  }
  /**
   * Instructs the node to reflect a design token for the provided token.
   * @param token - The design token to reflect
   */
  reflectToCSS(t) {
    this.isReflecting(t) || (this.reflecting.add(t), O.cssCustomPropertyReflector.startReflection(t, this.target));
  }
  /**
   * Stops reflecting a DesignToken to CSS
   * @param token - The design token to stop reflecting
   */
  stopReflectToCSS(t) {
    this.isReflecting(t) && (this.reflecting.delete(t), O.cssCustomPropertyReflector.stopReflection(t, this.target));
  }
  /**
   * Determines if a token is being reflected to CSS for a node.
   * @param token - The token to check for reflection
   * @returns
   */
  isReflecting(t) {
    return this.reflecting.has(t);
  }
  /**
   * Handle changes to upstream tokens
   * @param source - The parent DesignTokenNode
   * @param property - The token ID that changed
   */
  handleChange(t, A) {
    const i = ut.getTokenById(A);
    i && this.hydrate(i, this.getRaw(i));
  }
  /**
   * Hydrates a token with a DesignTokenValue, making retrieval available.
   * @param token - The token to hydrate
   * @param value - The value to hydrate
   */
  hydrate(t, A) {
    if (!this.has(t)) {
      const i = this.bindingObservers.get(t);
      ut.isDerivedDesignTokenValue(A) ? i ? i.source !== A && (this.tearDownBindingObserver(t), this.setupBindingObserver(t, A)) : this.setupBindingObserver(t, A) : (i && this.tearDownBindingObserver(t), this.store.set(t, A));
    }
  }
  /**
   * Sets up a binding observer for a derived token value that notifies token
   * subscribers on change.
   *
   * @param token - The token to notify when the binding updates
   * @param source - The binding source
   */
  setupBindingObserver(t, A) {
    const i = new of(A, t, this);
    return this.bindingObservers.set(t, i), i;
  }
  /**
   * Tear down a binding observer for a token.
   */
  tearDownBindingObserver(t) {
    return this.bindingObservers.has(t) ? (this.bindingObservers.get(t).disconnect(), this.bindingObservers.delete(t), !0) : !1;
  }
}
O.cssCustomPropertyReflector = new sf();
S([
  mt
], O.prototype, "children", void 0);
function nf(e) {
  return ut.from(e);
}
const no = Object.freeze({
  create: nf,
  /**
   * Informs DesignToken that an HTMLElement for which tokens have
   * been set has been connected to the document.
   *
   * The browser does not provide a reliable mechanism to observe an HTMLElement's connectedness
   * in all scenarios, so invoking this method manually is necessary when:
   *
   * 1. Token values are set for an HTMLElement.
   * 2. The HTMLElement does not inherit from FASTElement.
   * 3. The HTMLElement is not connected to the document when token values are set.
   *
   * @param element - The element to notify
   * @returns - true if notification was successful, otherwise false.
   */
  notifyConnection(e) {
    return !e.isConnected || !O.existsFor(e) ? !1 : (O.getOrCreate(e).bind(), !0);
  },
  /**
   * Informs DesignToken that an HTMLElement for which tokens have
   * been set has been disconnected to the document.
   *
   * The browser does not provide a reliable mechanism to observe an HTMLElement's connectedness
   * in all scenarios, so invoking this method manually is necessary when:
   *
   * 1. Token values are set for an HTMLElement.
   * 2. The HTMLElement does not inherit from FASTElement.
   *
   * @param element - The element to notify
   * @returns - true if notification was successful, otherwise false.
   */
  notifyDisconnection(e) {
    return e.isConnected || !O.existsFor(e) ? !1 : (O.getOrCreate(e).unbind(), !0);
  },
  /**
   * Registers and element or document as a DesignToken root.
   * {@link CSSDesignToken | CSSDesignTokens} with default values assigned via
   * {@link (DesignToken:interface).withDefault} will emit CSS custom properties to all
   * registered roots.
   * @param target - The root to register
   */
  registerRoot(e = se) {
    tt.registerRoot(e);
  },
  /**
   * Unregister an element or document as a DesignToken root.
   * @param target - The root to deregister
   */
  unregisterRoot(e = se) {
    tt.unregisterRoot(e);
  }
}), ar = Object.freeze({
  /**
   * Skip defining the element but still call the provided callback passed
   * to DesignSystemRegistrationContext.tryDefineElement
   */
  definitionCallbackOnly: null,
  /**
   * Ignore the duplicate element entirely.
   */
  ignoreDuplicate: Symbol()
}), lr = /* @__PURE__ */ new Map(), Bs = /* @__PURE__ */ new Map();
let IA = null;
const Ai = H.createInterface((e) => e.cachedCallback((t) => (IA === null && (IA = new $c(null, t)), IA))), Oc = Object.freeze({
  /**
   * Returns the HTML element name that the type is defined as.
   * @param type - The type to lookup.
   * @public
   */
  tagFor(e) {
    return Bs.get(e);
  },
  /**
   * Searches the DOM hierarchy for the design system that is responsible
   * for the provided element.
   * @param element - The element to locate the design system for.
   * @returns The located design system.
   * @public
   */
  responsibleFor(e) {
    const t = e.$$designSystem$$;
    return t || H.findResponsibleContainer(e).get(Ai);
  },
  /**
   * Gets the DesignSystem if one is explicitly defined on the provided element;
   * otherwise creates a design system defined directly on the element.
   * @param element - The element to get or create a design system for.
   * @returns The design system.
   * @public
   */
  getOrCreate(e) {
    if (!e)
      return IA === null && (IA = H.getOrCreateDOMContainer().get(Ai)), IA;
    const t = e.$$designSystem$$;
    if (t)
      return t;
    const A = H.getOrCreateDOMContainer(e);
    if (A.has(Ai, !1))
      return A.get(Ai);
    {
      const i = new $c(e, A);
      return A.register(ki.instance(Ai, i)), i;
    }
  }
});
function af(e, t, A) {
  return typeof e == "string" ? {
    name: e,
    type: t,
    callback: A
  } : e;
}
class $c {
  constructor(t, A) {
    this.owner = t, this.container = A, this.designTokensInitialized = !1, this.prefix = "fast", this.shadowRootMode = void 0, this.disambiguate = () => ar.definitionCallbackOnly, t !== null && (t.$$designSystem$$ = this);
  }
  withPrefix(t) {
    return this.prefix = t, this;
  }
  withShadowRootMode(t) {
    return this.shadowRootMode = t, this;
  }
  withElementDisambiguation(t) {
    return this.disambiguate = t, this;
  }
  withDesignTokenRoot(t) {
    return this.designTokenRoot = t, this;
  }
  register(...t) {
    const A = this.container, i = [], s = this.disambiguate, o = this.shadowRootMode, r = {
      elementPrefix: this.prefix,
      tryDefineElement(n, l, a) {
        const c = af(n, l, a), { name: g, callback: h, baseClass: u } = c;
        let { type: C } = c, B = g, E = lr.get(B), f = !0;
        for (; E; ) {
          const p = s(B, C, E);
          switch (p) {
            case ar.ignoreDuplicate:
              return;
            case ar.definitionCallbackOnly:
              f = !1, E = void 0;
              break;
            default:
              B = p, E = lr.get(B);
              break;
          }
        }
        f && ((Bs.has(C) || C === ne) && (C = class extends C {
        }), lr.set(B, C), Bs.set(C, B), u && Bs.set(u, B)), i.push(new lf(A, B, C, o, h, f));
      }
    };
    this.designTokensInitialized || (this.designTokensInitialized = !0, this.designTokenRoot !== null && no.registerRoot(this.designTokenRoot)), A.registerWithContext(r, ...t);
    for (const n of i)
      n.callback(n), n.willDefine && n.definition !== null && n.definition.define();
    return this;
  }
}
class lf {
  constructor(t, A, i, s, o, r) {
    this.container = t, this.name = A, this.type = i, this.shadowRootMode = s, this.callback = o, this.willDefine = r, this.definition = null;
  }
  definePresentation(t) {
    _c.define(this.name, t, this.container);
  }
  defineElement(t) {
    this.definition = new oo(this.type, Object.assign(Object.assign({}, t), { name: this.name }));
  }
  tagFor(t) {
    return Oc.tagFor(t);
  }
}
const dt = {
  /**
   * The menu item has a "menuitem" role
   */
  menuitem: "menuitem",
  /**
   * The menu item has a "menuitemcheckbox" role
   */
  menuitemcheckbox: "menuitemcheckbox",
  /**
   * The menu item has a "menuitemradio" role
   */
  menuitemradio: "menuitemradio"
}, gf = {
  [dt.menuitem]: "menuitem",
  [dt.menuitemcheckbox]: "menuitemcheckbox",
  [dt.menuitemradio]: "menuitemradio"
};
class Gt extends ne {
  constructor() {
    super(...arguments), this.role = dt.menuitem, this.hasSubmenu = !1, this.currentDirection = ve.ltr, this.focusSubmenuOnLoad = !1, this.handleMenuItemKeyDown = (t) => {
      if (t.defaultPrevented)
        return !1;
      switch (t.key) {
        case PE:
        case zE:
          return this.invoke(), !1;
        case OE:
          return this.expandAndFocus(), !1;
        case TE:
          if (this.expanded)
            return this.expanded = !1, this.focus(), !1;
      }
      return !0;
    }, this.handleMenuItemClick = (t) => (t.defaultPrevented || this.disabled || this.invoke(), !1), this.submenuLoaded = () => {
      this.focusSubmenuOnLoad && (this.focusSubmenuOnLoad = !1, this.hasSubmenu && (this.submenu.focus(), this.setAttribute("tabindex", "-1")));
    }, this.handleMouseOver = (t) => (this.disabled || !this.hasSubmenu || this.expanded || (this.expanded = !0), !1), this.handleMouseOut = (t) => (!this.expanded || this.contains(document.activeElement) || (this.expanded = !1), !1), this.expandAndFocus = () => {
      this.hasSubmenu && (this.focusSubmenuOnLoad = !0, this.expanded = !0);
    }, this.invoke = () => {
      if (!this.disabled)
        switch (this.role) {
          case dt.menuitemcheckbox:
            this.checked = !this.checked;
            break;
          case dt.menuitem:
            this.updateSubmenu(), this.hasSubmenu ? this.expandAndFocus() : this.$emit("change");
            break;
          case dt.menuitemradio:
            this.checked || (this.checked = !0);
            break;
        }
    }, this.updateSubmenu = () => {
      this.submenu = this.domChildren().find((t) => t.getAttribute("role") === "menu"), this.hasSubmenu = this.submenu !== void 0;
    };
  }
  expandedChanged(t) {
    if (this.$fastController.isConnected) {
      if (this.submenu === void 0)
        return;
      this.expanded === !1 ? this.submenu.collapseExpandedItem() : this.currentDirection = qr(this), this.$emit("expanded-change", this, { bubbles: !1 });
    }
  }
  checkedChanged(t, A) {
    this.$fastController.isConnected && this.$emit("change");
  }
  /**
   * @internal
   */
  connectedCallback() {
    super.connectedCallback(), R.queueUpdate(() => {
      this.updateSubmenu();
    }), this.startColumnCount || (this.startColumnCount = 1), this.observer = new MutationObserver(this.updateSubmenu);
  }
  /**
   * @internal
   */
  disconnectedCallback() {
    super.disconnectedCallback(), this.submenu = void 0, this.observer !== void 0 && (this.observer.disconnect(), this.observer = void 0);
  }
  /**
   * get an array of valid DOM children
   */
  domChildren() {
    return Array.from(this.children).filter((t) => !t.hasAttribute("hidden"));
  }
}
S([
  j({ mode: "boolean" })
], Gt.prototype, "disabled", void 0);
S([
  j({ mode: "boolean" })
], Gt.prototype, "expanded", void 0);
S([
  mt
], Gt.prototype, "startColumnCount", void 0);
S([
  j
], Gt.prototype, "role", void 0);
S([
  j({ mode: "boolean" })
], Gt.prototype, "checked", void 0);
S([
  mt
], Gt.prototype, "submenuRegion", void 0);
S([
  mt
], Gt.prototype, "hasSubmenu", void 0);
S([
  mt
], Gt.prototype, "currentDirection", void 0);
S([
  mt
], Gt.prototype, "submenu", void 0);
LE(Gt, pE);
const cf = (e, t) => Vt`
    <template
        role="${(A) => A.role}"
        aria-haspopup="${(A) => A.hasSubmenu ? "menu" : void 0}"
        aria-checked="${(A) => A.role !== dt.menuitem ? A.checked : void 0}"
        aria-disabled="${(A) => A.disabled}"
        aria-expanded="${(A) => A.expanded}"
        @keydown="${(A, i) => A.handleMenuItemKeyDown(i.event)}"
        @click="${(A, i) => A.handleMenuItemClick(i.event)}"
        @mouseover="${(A, i) => A.handleMouseOver(i.event)}"
        @mouseout="${(A, i) => A.handleMouseOut(i.event)}"
        class="${(A) => A.disabled ? "disabled" : ""} ${(A) => A.expanded ? "expanded" : ""} ${(A) => `indent-${A.startColumnCount}`}"
    >
            ${ts((A) => A.role === dt.menuitemcheckbox, Vt`
                    <div part="input-container" class="input-container">
                        <span part="checkbox" class="checkbox">
                            <slot name="checkbox-indicator">
                                ${t.checkboxIndicator || ""}
                            </slot>
                        </span>
                    </div>
                `)}
            ${ts((A) => A.role === dt.menuitemradio, Vt`
                    <div part="input-container" class="input-container">
                        <span part="radio" class="radio">
                            <slot name="radio-indicator">
                                ${t.radioIndicator || ""}
                            </slot>
                        </span>
                    </div>
                `)}
        </div>
        ${yE(e, t)}
        <span class="content" part="content">
            <slot></slot>
        </span>
        ${wE(e, t)}
        ${ts((A) => A.hasSubmenu, Vt`
                <div
                    part="expand-collapse-glyph-container"
                    class="expand-collapse-glyph-container"
                >
                    <span part="expand-collapse" class="expand-collapse">
                        <slot name="expand-collapse-indicator">
                            ${t.expandCollapseGlyph || ""}
                        </slot>
                    </span>
                </div>
            `)}
        ${ts((A) => A.expanded, Vt`
                <${e.tagFor(F)}
                    :anchorElement="${(A) => A}"
                    vertical-positioning-mode="dynamic"
                    vertical-default-position="bottom"
                    vertical-inset="true"
                    horizontal-positioning-mode="dynamic"
                    horizontal-default-position="end"
                    class="submenu-region"
                    dir="${(A) => A.currentDirection}"
                    @loaded="${(A) => A.submenuLoaded()}"
                    ${re("submenuRegion")}
                    part="submenu-region"
                >
                    <slot name="submenu"></slot>
                </${e.tagFor(F)}>
            `)}
    </template>
`, hf = (e, t) => Vt`
    <template
        slot="${(A) => A.slot ? A.slot : A.isNestedMenu() ? "submenu" : void 0}"
        role="menu"
        @keydown="${(A, i) => A.handleMenuKeyDown(i.event)}"
        @focusout="${(A, i) => A.handleFocusOut(i.event)}"
    >
        <slot ${fE("items")}></slot>
    </template>
`;
let Un = class Pc extends ne {
  constructor() {
    super(...arguments), this.expandedItem = null, this.focusIndex = -1, this.isNestedMenu = () => this.parentElement !== null && Ml(this.parentElement) && this.parentElement.getAttribute("role") === "menuitem", this.handleFocusOut = (t) => {
      if (!this.contains(t.relatedTarget) && this.menuItems !== void 0) {
        this.collapseExpandedItem();
        const A = this.menuItems.findIndex(this.isFocusableElement);
        this.menuItems[this.focusIndex].setAttribute("tabindex", "-1"), this.menuItems[A].setAttribute("tabindex", "0"), this.focusIndex = A;
      }
    }, this.handleItemFocus = (t) => {
      const A = t.target;
      this.menuItems !== void 0 && A !== this.menuItems[this.focusIndex] && (this.menuItems[this.focusIndex].setAttribute("tabindex", "-1"), this.focusIndex = this.menuItems.indexOf(A), A.setAttribute("tabindex", "0"));
    }, this.handleExpandedChanged = (t) => {
      if (t.defaultPrevented || t.target === null || this.menuItems === void 0 || this.menuItems.indexOf(t.target) < 0)
        return;
      t.preventDefault();
      const A = t.target;
      if (this.expandedItem !== null && A === this.expandedItem && A.expanded === !1) {
        this.expandedItem = null;
        return;
      }
      A.expanded && (this.expandedItem !== null && this.expandedItem !== A && (this.expandedItem.expanded = !1), this.menuItems[this.focusIndex].setAttribute("tabindex", "-1"), this.expandedItem = A, this.focusIndex = this.menuItems.indexOf(A), A.setAttribute("tabindex", "0"));
    }, this.removeItemListeners = () => {
      this.menuItems !== void 0 && this.menuItems.forEach((t) => {
        t.removeEventListener("expanded-change", this.handleExpandedChanged), t.removeEventListener("focus", this.handleItemFocus);
      });
    }, this.setItems = () => {
      const t = this.domChildren();
      this.removeItemListeners(), this.menuItems = t;
      const A = this.menuItems.filter(this.isMenuItemElement);
      A.length && (this.focusIndex = 0);
      function i(o) {
        const r = o.getAttribute("role"), n = o.querySelector("[slot=start]");
        return r !== dt.menuitem && n === null || r === dt.menuitem && n !== null ? 1 : r !== dt.menuitem && n !== null ? 2 : 0;
      }
      const s = A.reduce((o, r) => {
        const n = i(r);
        return o > n ? o : n;
      }, 0);
      A.forEach((o, r) => {
        o.setAttribute("tabindex", r === 0 ? "0" : "-1"), o.addEventListener("expanded-change", this.handleExpandedChanged), o.addEventListener("focus", this.handleItemFocus), o instanceof Gt && (o.startColumnCount = s);
      });
    }, this.changeHandler = (t) => {
      if (this.menuItems === void 0)
        return;
      const A = t.target, i = this.menuItems.indexOf(A);
      if (i !== -1 && A.role === "menuitemradio" && A.checked === !0) {
        for (let o = i - 1; o >= 0; --o) {
          const r = this.menuItems[o], n = r.getAttribute("role");
          if (n === dt.menuitemradio && (r.checked = !1), n === "separator")
            break;
        }
        const s = this.menuItems.length - 1;
        for (let o = i + 1; o <= s; ++o) {
          const r = this.menuItems[o], n = r.getAttribute("role");
          if (n === dt.menuitemradio && (r.checked = !1), n === "separator")
            break;
        }
      }
    }, this.isMenuItemElement = (t) => Ml(t) && Pc.focusableElementRoles.hasOwnProperty(t.getAttribute("role")), this.isFocusableElement = (t) => this.isMenuItemElement(t);
  }
  itemsChanged(t, A) {
    this.$fastController.isConnected && this.menuItems !== void 0 && this.setItems();
  }
  /**
   * @internal
   */
  connectedCallback() {
    super.connectedCallback(), R.queueUpdate(() => {
      this.setItems();
    }), this.addEventListener("change", this.changeHandler);
  }
  /**
   * @internal
   */
  disconnectedCallback() {
    super.disconnectedCallback(), this.removeItemListeners(), this.menuItems = void 0, this.removeEventListener("change", this.changeHandler);
  }
  /**
   * Focuses the first item in the menu.
   *
   * @public
   */
  focus() {
    this.setFocus(0, 1);
  }
  /**
   * Collapses any expanded menu items.
   *
   * @public
   */
  collapseExpandedItem() {
    this.expandedItem !== null && (this.expandedItem.expanded = !1, this.expandedItem = null);
  }
  /**
   * @internal
   */
  handleMenuKeyDown(t) {
    if (!(t.defaultPrevented || this.menuItems === void 0))
      switch (t.key) {
        case _E:
          this.setFocus(this.focusIndex + 1, 1);
          return;
        case $E:
          this.setFocus(this.focusIndex - 1, -1);
          return;
        case VE:
          this.setFocus(this.menuItems.length - 1, -1);
          return;
        case qE:
          this.setFocus(0, 1);
          return;
        default:
          return !0;
      }
  }
  /**
   * get an array of valid DOM children
   */
  domChildren() {
    return Array.from(this.children).filter((t) => !t.hasAttribute("hidden"));
  }
  setFocus(t, A) {
    if (this.menuItems !== void 0)
      for (; t >= 0 && t < this.menuItems.length; ) {
        const i = this.menuItems[t];
        if (this.isFocusableElement(i)) {
          this.focusIndex > -1 && this.menuItems.length >= this.focusIndex - 1 && this.menuItems[this.focusIndex].setAttribute("tabindex", "-1"), this.focusIndex = t, i.setAttribute("tabindex", "0"), i.focus();
          break;
        }
        t += A;
      }
  }
};
Un.focusableElementRoles = gf;
S([
  mt
], Un.prototype, "items", void 0);
class If {
  /**
   *
   * @param query - The media query to operate from.
   */
  constructor(t) {
    this.listenerCache = /* @__PURE__ */ new WeakMap(), this.query = t;
  }
  /**
   * Binds the behavior to the element.
   * @param source - The element for which the behavior is bound.
   */
  bind(t) {
    const { query: A } = this, i = this.constructListener(t);
    i.bind(A)(), A.addListener(i), this.listenerCache.set(t, i);
  }
  /**
   * Unbinds the behavior from the element.
   * @param source - The element for which the behavior is unbinding.
   */
  unbind(t) {
    const A = this.listenerCache.get(t);
    A && (this.query.removeListener(A), this.listenerCache.delete(t));
  }
}
class _i extends If {
  /**
   * Constructs a {@link MatchMediaStyleSheetBehavior} instance.
   * @param query - The media query to operate from.
   * @param styles - The styles to coordinate with the query.
   */
  constructor(t, A) {
    super(t), this.styles = A;
  }
  /**
   * Defines a function to construct {@link MatchMediaStyleSheetBehavior | MatchMediaStyleSheetBehaviors} for
   * a provided query.
   * @param query - The media query to operate from.
   *
   * @public
   * @example
   *
   * ```ts
   * import { css } from "@microsoft/fast-element";
   * import { MatchMediaStyleSheetBehavior } from "@microsoft/fast-foundation";
   *
   * const landscapeBehavior = MatchMediaStyleSheetBehavior.with(
   *   window.matchMedia("(orientation: landscape)")
   * );
   * const styles = css`
   *   :host {
   *     width: 200px;
   *     height: 400px;
   *   }
   * `
   * .withBehaviors(landscapeBehavior(css`
   *   :host {
   *     width: 400px;
   *     height: 200px;
   *   }
   * `))
   * ```
   */
  static with(t) {
    return (A) => new _i(t, A);
  }
  /**
   * Constructs a match-media listener for a provided element.
   * @param source - the element for which to attach or detach styles.
   * @internal
   */
  constructListener(t) {
    let A = !1;
    const i = this.styles;
    return function() {
      const { matches: o } = this;
      o && !A ? (t.$fastController.addStyles(i), A = o) : !o && A && (t.$fastController.removeStyles(i), A = o);
    };
  }
  /**
   * Unbinds the behavior from the element.
   * @param source - The element for which the behavior is unbinding.
   * @internal
   */
  unbind(t) {
    super.unbind(t), t.$fastController.removeStyles(this.styles);
  }
}
const qc = _i.with(window.matchMedia("(forced-colors)"));
_i.with(window.matchMedia("(prefers-color-scheme: dark)"));
_i.with(window.matchMedia("(prefers-color-scheme: light)"));
const uf = "not-allowed", df = ":host([hidden]){display:none}";
function Vc(e) {
  return `${df}:host{display:${e}}`;
}
const Ie = HE() ? "focus-visible" : "focus";
function ie(e, t, A) {
  return isNaN(e) || e <= t ? t : e >= A ? A : e;
}
function gr(e, t, A) {
  return isNaN(e) || e <= t ? 0 : e >= A ? 1 : e / (A - t);
}
function Re(e, t, A) {
  return isNaN(e) ? t : t + e * (A - t);
}
function Hl(e) {
  return e * (Math.PI / 180);
}
function Cf(e) {
  return e * (180 / Math.PI);
}
function Bf(e) {
  const t = Math.round(ie(e, 0, 255)).toString(16);
  return t.length === 1 ? "0" + t : t;
}
function ht(e, t, A) {
  return isNaN(e) || e <= 0 ? t : e >= 1 ? A : t + e * (A - t);
}
function Gn(e, t, A) {
  if (e <= 0)
    return t % 360;
  if (e >= 1)
    return A % 360;
  const i = (t - A + 360) % 360, s = (A - t + 360) % 360;
  return i <= s ? (t - i * e + 360) % 360 : (t + i * e + 360) % 360;
}
function Z(e, t) {
  const A = Math.pow(10, t);
  return Math.round(e * A) / A;
}
class Pe {
  constructor(t, A, i) {
    this.h = t, this.s = A, this.l = i;
  }
  /**
   * Construct a {@link ColorHSL} from a config object.
   */
  static fromObject(t) {
    return t && !isNaN(t.h) && !isNaN(t.s) && !isNaN(t.l) ? new Pe(t.h, t.s, t.l) : null;
  }
  /**
   * Determines if a color is equal to another
   * @param rhs - the value to compare
   */
  equalValue(t) {
    return this.h === t.h && this.s === t.s && this.l === t.l;
  }
  /**
   * Returns a new {@link ColorHSL} rounded to the provided precision
   * @param precision - the precision to round to
   */
  roundToPrecision(t) {
    return new Pe(Z(this.h, t), Z(this.s, t), Z(this.l, t));
  }
  /**
   * Returns the {@link ColorHSL} formatted as an object.
   */
  toObject() {
    return { h: this.h, s: this.s, l: this.l };
  }
}
class Si {
  constructor(t, A, i) {
    this.h = t, this.s = A, this.v = i;
  }
  /**
   * Construct a {@link ColorHSV} from a config object.
   */
  static fromObject(t) {
    return t && !isNaN(t.h) && !isNaN(t.s) && !isNaN(t.v) ? new Si(t.h, t.s, t.v) : null;
  }
  /**
   * Determines if a color is equal to another
   * @param rhs - the value to compare
   */
  equalValue(t) {
    return this.h === t.h && this.s === t.s && this.v === t.v;
  }
  /**
   * Returns a new {@link ColorHSV} rounded to the provided precision
   * @param precision - the precision to round to
   */
  roundToPrecision(t) {
    return new Si(Z(this.h, t), Z(this.s, t), Z(this.v, t));
  }
  /**
   * Returns the {@link ColorHSV} formatted as an object.
   */
  toObject() {
    return { h: this.h, s: this.s, v: this.v };
  }
}
class lt {
  constructor(t, A, i) {
    this.l = t, this.a = A, this.b = i;
  }
  /**
   * Construct a {@link ColorLAB} from a config object.
   */
  static fromObject(t) {
    return t && !isNaN(t.l) && !isNaN(t.a) && !isNaN(t.b) ? new lt(t.l, t.a, t.b) : null;
  }
  /**
   * Determines if a color is equal to another
   * @param rhs - the value to compare
   */
  equalValue(t) {
    return this.l === t.l && this.a === t.a && this.b === t.b;
  }
  /**
   * Returns a new {@link ColorLAB} rounded to the provided precision
   * @param precision - the precision to round to
   */
  roundToPrecision(t) {
    return new lt(Z(this.l, t), Z(this.a, t), Z(this.b, t));
  }
  /**
   * Returns the {@link ColorLAB} formatted as an object.
   */
  toObject() {
    return { l: this.l, a: this.a, b: this.b };
  }
}
lt.epsilon = 216 / 24389;
lt.kappa = 24389 / 27;
class mA {
  constructor(t, A, i) {
    this.l = t, this.c = A, this.h = i;
  }
  /**
   * Construct a {@link ColorLCH} from a config object.
   * @param data - the config object
   */
  static fromObject(t) {
    return t && !isNaN(t.l) && !isNaN(t.c) && !isNaN(t.h) ? new mA(t.l, t.c, t.h) : null;
  }
  /**
   * Determines if one color is equal to another.
   * @param rhs - the color to compare
   */
  equalValue(t) {
    return this.l === t.l && this.c === t.c && this.h === t.h;
  }
  /**
   * Returns a new {@link ColorLCH} rounded to the provided precision
   * @param precision - the precision to round to
   */
  roundToPrecision(t) {
    return new mA(Z(this.l, t), Z(this.c, t), Z(this.h, t));
  }
  /**
   * Converts the {@link ColorLCH} to a config object.
   */
  toObject() {
    return { l: this.l, c: this.c, h: this.h };
  }
}
class $ {
  /**
   *
   * @param red - the red value
   * @param green - the green value
   * @param blue - the blue value
   * @param alpha - the alpha value
   */
  constructor(t, A, i, s) {
    this.r = t, this.g = A, this.b = i, this.a = typeof s == "number" && !isNaN(s) ? s : 1;
  }
  /**
   * Construct a {@link ColorRGBA64} from a {@link ColorRGBA64Config}
   * @param data - the config object
   */
  static fromObject(t) {
    return t && !isNaN(t.r) && !isNaN(t.g) && !isNaN(t.b) ? new $(t.r, t.g, t.b, t.a) : null;
  }
  /**
   * Determines if one color is equal to another.
   * @param rhs - the color to compare
   */
  equalValue(t) {
    return this.r === t.r && this.g === t.g && this.b === t.b && this.a === t.a;
  }
  /**
   * Returns the color formatted as a string; #RRGGBB
   */
  toStringHexRGB() {
    return "#" + [this.r, this.g, this.b].map(this.formatHexValue).join("");
  }
  /**
   * Returns the color formatted as a string; #RRGGBBAA
   */
  toStringHexRGBA() {
    return this.toStringHexRGB() + this.formatHexValue(this.a);
  }
  /**
   * Returns the color formatted as a string; #AARRGGBB
   */
  toStringHexARGB() {
    return "#" + [this.a, this.r, this.g, this.b].map(this.formatHexValue).join("");
  }
  /**
   * Returns the color formatted as a string; "rgb(0xRR, 0xGG, 0xBB)"
   */
  toStringWebRGB() {
    return `rgb(${Math.round(Re(this.r, 0, 255))},${Math.round(Re(this.g, 0, 255))},${Math.round(Re(this.b, 0, 255))})`;
  }
  /**
   * Returns the color formatted as a string; "rgba(0xRR, 0xGG, 0xBB, a)"
   * @remarks
   * Note that this follows the convention of putting alpha in the range [0.0,1.0] while the other three channels are [0,255]
   */
  toStringWebRGBA() {
    return `rgba(${Math.round(Re(this.r, 0, 255))},${Math.round(Re(this.g, 0, 255))},${Math.round(Re(this.b, 0, 255))},${ie(this.a, 0, 1)})`;
  }
  /**
   * Returns a new {@link ColorRGBA64} rounded to the provided precision
   * @param precision - the precision to round to
   */
  roundToPrecision(t) {
    return new $(Z(this.r, t), Z(this.g, t), Z(this.b, t), Z(this.a, t));
  }
  /**
   * Returns a new {@link ColorRGBA64} with channel values clamped between 0 and 1.
   */
  clamp() {
    return new $(ie(this.r, 0, 1), ie(this.g, 0, 1), ie(this.b, 0, 1), ie(this.a, 0, 1));
  }
  /**
   * Converts the {@link ColorRGBA64} to a {@link ColorRGBA64Config}.
   */
  toObject() {
    return { r: this.r, g: this.g, b: this.b, a: this.a };
  }
  formatHexValue(t) {
    return Bf(Re(t, 0, 255));
  }
}
class pt {
  constructor(t, A, i) {
    this.x = t, this.y = A, this.z = i;
  }
  /**
   * Construct a {@link ColorXYZ} from a config object.
   */
  static fromObject(t) {
    return t && !isNaN(t.x) && !isNaN(t.y) && !isNaN(t.z) ? new pt(t.x, t.y, t.z) : null;
  }
  /**
   * Determines if a color is equal to another
   * @param rhs - the value to compare
   */
  equalValue(t) {
    return this.x === t.x && this.y === t.y && this.z === t.z;
  }
  /**
   * Returns a new {@link ColorXYZ} rounded to the provided precision
   * @param precision - the precision to round to
   */
  roundToPrecision(t) {
    return new pt(Z(this.x, t), Z(this.y, t), Z(this.z, t));
  }
  /**
   * Returns the {@link ColorXYZ} formatted as an object.
   */
  toObject() {
    return { x: this.x, y: this.y, z: this.z };
  }
}
pt.whitePoint = new pt(0.95047, 1, 1.08883);
function zr(e) {
  return e.r * 0.2126 + e.g * 0.7152 + e.b * 0.0722;
}
function Kr(e) {
  function t(A) {
    return A <= 0.03928 ? A / 12.92 : Math.pow((A + 0.055) / 1.055, 2.4);
  }
  return zr(new $(t(e.r), t(e.g), t(e.b), 1));
}
const _l = (e, t) => (e + 0.05) / (t + 0.05);
function Tl(e, t) {
  const A = Kr(e), i = Kr(t);
  return A > i ? _l(A, i) : _l(i, A);
}
function xi(e) {
  const t = Math.max(e.r, e.g, e.b), A = Math.min(e.r, e.g, e.b), i = t - A;
  let s = 0;
  i !== 0 && (t === e.r ? s = 60 * ((e.g - e.b) / i % 6) : t === e.g ? s = 60 * ((e.b - e.r) / i + 2) : s = 60 * ((e.r - e.g) / i + 4)), s < 0 && (s += 360);
  const o = (t + A) / 2;
  let r = 0;
  return i !== 0 && (r = i / (1 - Math.abs(2 * o - 1))), new Pe(s, r, o);
}
function jr(e, t = 1) {
  const A = (1 - Math.abs(2 * e.l - 1)) * e.s, i = A * (1 - Math.abs(e.h / 60 % 2 - 1)), s = e.l - A / 2;
  let o = 0, r = 0, n = 0;
  return e.h < 60 ? (o = A, r = i, n = 0) : e.h < 120 ? (o = i, r = A, n = 0) : e.h < 180 ? (o = 0, r = A, n = i) : e.h < 240 ? (o = 0, r = i, n = A) : e.h < 300 ? (o = i, r = 0, n = A) : e.h < 360 && (o = A, r = 0, n = i), new $(o + s, r + s, n + s, t);
}
function Ol(e) {
  const t = Math.max(e.r, e.g, e.b), A = Math.min(e.r, e.g, e.b), i = t - A;
  let s = 0;
  i !== 0 && (t === e.r ? s = 60 * ((e.g - e.b) / i % 6) : t === e.g ? s = 60 * ((e.b - e.r) / i + 2) : s = 60 * ((e.r - e.g) / i + 4)), s < 0 && (s += 360);
  let o = 0;
  return t !== 0 && (o = i / t), new Si(s, o, t);
}
function Qf(e, t = 1) {
  const A = e.s * e.v, i = A * (1 - Math.abs(e.h / 60 % 2 - 1)), s = e.v - A;
  let o = 0, r = 0, n = 0;
  return e.h < 60 ? (o = A, r = i, n = 0) : e.h < 120 ? (o = i, r = A, n = 0) : e.h < 180 ? (o = 0, r = A, n = i) : e.h < 240 ? (o = 0, r = i, n = A) : e.h < 300 ? (o = i, r = 0, n = A) : e.h < 360 && (o = A, r = 0, n = i), new $(o + s, r + s, n + s, t);
}
function Ef(e) {
  let t = 0, A = 0;
  return e.h !== 0 && (t = Math.cos(Hl(e.h)) * e.c, A = Math.sin(Hl(e.h)) * e.c), new lt(e.l, t, A);
}
function ff(e) {
  let t = 0;
  (Math.abs(e.b) > 1e-3 || Math.abs(e.a) > 1e-3) && (t = Cf(Math.atan2(e.b, e.a))), t < 0 && (t += 360);
  const A = Math.sqrt(e.a * e.a + e.b * e.b);
  return new mA(e.l, A, t);
}
function pf(e) {
  const t = (e.l + 16) / 116, A = t + e.a / 500, i = t - e.b / 200, s = Math.pow(A, 3), o = Math.pow(t, 3), r = Math.pow(i, 3);
  let n = 0;
  s > lt.epsilon ? n = s : n = (116 * A - 16) / lt.kappa;
  let l = 0;
  e.l > lt.epsilon * lt.kappa ? l = o : l = e.l / lt.kappa;
  let a = 0;
  return r > lt.epsilon ? a = r : a = (116 * i - 16) / lt.kappa, n = pt.whitePoint.x * n, l = pt.whitePoint.y * l, a = pt.whitePoint.z * a, new pt(n, l, a);
}
function wf(e) {
  function t(l) {
    return l > lt.epsilon ? Math.pow(l, 1 / 3) : (lt.kappa * l + 16) / 116;
  }
  const A = t(e.x / pt.whitePoint.x), i = t(e.y / pt.whitePoint.y), s = t(e.z / pt.whitePoint.z), o = 116 * i - 16, r = 500 * (A - i), n = 200 * (i - s);
  return new lt(o, r, n);
}
function Zr(e) {
  function t(l) {
    return l <= 0.04045 ? l / 12.92 : Math.pow((l + 0.055) / 1.055, 2.4);
  }
  const A = t(e.r), i = t(e.g), s = t(e.b), o = A * 0.4124564 + i * 0.3575761 + s * 0.1804375, r = A * 0.2126729 + i * 0.7151522 + s * 0.072175, n = A * 0.0193339 + i * 0.119192 + s * 0.9503041;
  return new pt(o, r, n);
}
function zc(e, t = 1) {
  function A(r) {
    return r <= 31308e-7 ? r * 12.92 : 1.055 * Math.pow(r, 1 / 2.4) - 0.055;
  }
  const i = A(e.x * 3.2404542 - e.y * 1.5371385 - e.z * 0.4985314), s = A(e.x * -0.969266 + e.y * 1.8760108 + e.z * 0.041556), o = A(e.x * 0.0556434 - e.y * 0.2040259 + e.z * 1.0572252);
  return new $(i, s, o, t);
}
function Wr(e) {
  return wf(Zr(e));
}
function Kc(e, t = 1) {
  return zc(pf(e), t);
}
function Xr(e) {
  return ff(Wr(e));
}
function jc(e, t = 1) {
  return Kc(Ef(e), t);
}
function $l(e, t, A = 18) {
  const i = Xr(e);
  let s = i.c + t * A;
  return s < 0 && (s = 0), jc(new mA(i.l, s, i.h));
}
function cr(e, t) {
  return e * t;
}
function Pl(e, t) {
  return new $(cr(e.r, t.r), cr(e.g, t.g), cr(e.b, t.b), 1);
}
function hr(e, t) {
  return e < 0.5 ? ie(2 * t * e, 0, 1) : ie(1 - 2 * (1 - t) * (1 - e), 0, 1);
}
function ql(e, t) {
  return new $(hr(e.r, t.r), hr(e.g, t.g), hr(e.b, t.b), 1);
}
var Vl;
(function(e) {
  e[e.Burn = 0] = "Burn", e[e.Color = 1] = "Color", e[e.Darken = 2] = "Darken", e[e.Dodge = 3] = "Dodge", e[e.Lighten = 4] = "Lighten", e[e.Multiply = 5] = "Multiply", e[e.Overlay = 6] = "Overlay", e[e.Screen = 7] = "Screen";
})(Vl || (Vl = {}));
function yf(e, t, A) {
  return isNaN(e) || e <= 0 ? t : e >= 1 ? A : new $(ht(e, t.r, A.r), ht(e, t.g, A.g), ht(e, t.b, A.b), ht(e, t.a, A.a));
}
function vf(e, t, A) {
  return isNaN(e) || e <= 0 ? t : e >= 1 ? A : new Pe(Gn(e, t.h, A.h), ht(e, t.s, A.s), ht(e, t.l, A.l));
}
function mf(e, t, A) {
  return isNaN(e) || e <= 0 ? t : e >= 1 ? A : new Si(Gn(e, t.h, A.h), ht(e, t.s, A.s), ht(e, t.v, A.v));
}
function bf(e, t, A) {
  return isNaN(e) || e <= 0 ? t : e >= 1 ? A : new pt(ht(e, t.x, A.x), ht(e, t.y, A.y), ht(e, t.z, A.z));
}
function Df(e, t, A) {
  return isNaN(e) || e <= 0 ? t : e >= 1 ? A : new lt(ht(e, t.l, A.l), ht(e, t.a, A.a), ht(e, t.b, A.b));
}
function kf(e, t, A) {
  return isNaN(e) || e <= 0 ? t : e >= 1 ? A : new mA(ht(e, t.l, A.l), ht(e, t.c, A.c), Gn(e, t.h, A.h));
}
var wt;
(function(e) {
  e[e.RGB = 0] = "RGB", e[e.HSL = 1] = "HSL", e[e.HSV = 2] = "HSV", e[e.XYZ = 3] = "XYZ", e[e.LAB = 4] = "LAB", e[e.LCH = 5] = "LCH";
})(wt || (wt = {}));
function ri(e, t, A, i) {
  if (isNaN(e) || e <= 0)
    return A;
  if (e >= 1)
    return i;
  switch (t) {
    case wt.HSL:
      return jr(vf(e, xi(A), xi(i)));
    case wt.HSV:
      return Qf(mf(e, Ol(A), Ol(i)));
    case wt.XYZ:
      return zc(bf(e, Zr(A), Zr(i)));
    case wt.LAB:
      return Kc(Df(e, Wr(A), Wr(i)));
    case wt.LCH:
      return jc(kf(e, Xr(A), Xr(i)));
    default:
      return yf(e, A, i);
  }
}
class Ft {
  constructor(t) {
    if (t == null || t.length === 0)
      throw new Error("The stops argument must be non-empty");
    this.stops = this.sortColorScaleStops(t);
  }
  static createBalancedColorScale(t) {
    if (t == null || t.length === 0)
      throw new Error("The colors argument must be non-empty");
    const A = new Array(t.length);
    for (let i = 0; i < t.length; i++)
      i === 0 ? A[i] = { color: t[i], position: 0 } : i === t.length - 1 ? A[i] = { color: t[i], position: 1 } : A[i] = {
        color: t[i],
        position: i * (1 / (t.length - 1))
      };
    return new Ft(A);
  }
  getColor(t, A = wt.RGB) {
    if (this.stops.length === 1)
      return this.stops[0].color;
    if (t <= 0)
      return this.stops[0].color;
    if (t >= 1)
      return this.stops[this.stops.length - 1].color;
    let i = 0;
    for (let r = 0; r < this.stops.length; r++)
      this.stops[r].position <= t && (i = r);
    let s = i + 1;
    s >= this.stops.length && (s = this.stops.length - 1);
    const o = (t - this.stops[i].position) * (1 / (this.stops[s].position - this.stops[i].position));
    return ri(o, A, this.stops[i].color, this.stops[s].color);
  }
  trim(t, A, i = wt.RGB) {
    if (t < 0 || A > 1 || A < t)
      throw new Error("Invalid bounds");
    if (t === A)
      return new Ft([
        { color: this.getColor(t, i), position: 0 }
      ]);
    const s = [];
    for (let n = 0; n < this.stops.length; n++)
      this.stops[n].position >= t && this.stops[n].position <= A && s.push(this.stops[n]);
    if (s.length === 0)
      return new Ft([
        { color: this.getColor(t), position: t },
        { color: this.getColor(A), position: A }
      ]);
    s[0].position !== t && s.unshift({
      color: this.getColor(t),
      position: t
    }), s[s.length - 1].position !== A && s.push({
      color: this.getColor(A),
      position: A
    });
    const o = A - t, r = new Array(s.length);
    for (let n = 0; n < s.length; n++)
      r[n] = {
        color: s[n].color,
        position: (s[n].position - t) / o
      };
    return new Ft(r);
  }
  findNextColor(t, A, i = !1, s = wt.RGB, o = 5e-3, r = 32) {
    isNaN(t) || t <= 0 ? t = 0 : t >= 1 && (t = 1);
    const n = this.getColor(t, s), l = i ? 0 : 1, a = this.getColor(l, s);
    if (Tl(n, a) <= A)
      return l;
    let g = i ? 0 : t, h = i ? t : 0, u = l, C = 0;
    for (; C <= r; ) {
      u = Math.abs(h - g) / 2 + g;
      const B = this.getColor(u, s), E = Tl(n, B);
      if (Math.abs(E - A) <= o)
        return u;
      E > A ? i ? g = u : h = u : i ? h = u : g = u, C++;
    }
    return u;
  }
  clone() {
    const t = new Array(this.stops.length);
    for (let A = 0; A < t.length; A++)
      t[A] = {
        color: this.stops[A].color,
        position: this.stops[A].position
      };
    return new Ft(t);
  }
  sortColorScaleStops(t) {
    return t.sort((A, i) => {
      const s = A.position, o = i.position;
      return s < o ? -1 : s > o ? 1 : 0;
    });
  }
}
const Sf = /^#((?:[0-9a-f]{6}|[0-9a-f]{3}))$/i;
function MA(e) {
  const t = Sf.exec(e);
  if (t === null)
    return null;
  let A = t[1];
  if (A.length === 3) {
    const s = A.charAt(0), o = A.charAt(1), r = A.charAt(2);
    A = s.concat(s, o, o, r, r);
  }
  const i = parseInt(A, 16);
  return isNaN(i) ? null : new $(gr((i & 16711680) >>> 16, 0, 255), gr((i & 65280) >>> 8, 0, 255), gr(i & 255, 0, 255), 1);
}
class me {
  constructor(t) {
    this.config = Object.assign({}, me.defaultPaletteConfig, t), this.palette = [], this.updatePaletteColors();
  }
  updatePaletteGenerationValues(t) {
    let A = !1;
    for (const i in t)
      this.config[i] && (this.config[i].equalValue ? this.config[i].equalValue(t[i]) || (this.config[i] = t[i], A = !0) : t[i] !== this.config[i] && (this.config[i] = t[i], A = !0));
    return A && this.updatePaletteColors(), A;
  }
  updatePaletteColors() {
    const t = this.generatePaletteColorScale();
    for (let A = 0; A < this.config.steps; A++)
      this.palette[A] = t.getColor(A / (this.config.steps - 1), this.config.interpolationMode);
  }
  generatePaletteColorScale() {
    const t = xi(this.config.baseColor), i = new Ft([
      { position: 0, color: this.config.scaleColorLight },
      { position: 0.5, color: this.config.baseColor },
      { position: 1, color: this.config.scaleColorDark }
    ]).trim(this.config.clipLight, 1 - this.config.clipDark), s = i.getColor(0), o = i.getColor(1);
    let r = s, n = o;
    if (t.s >= this.config.saturationAdjustmentCutoff && (r = $l(r, this.config.saturationLight), n = $l(n, this.config.saturationDark)), this.config.multiplyLight !== 0) {
      const l = Pl(this.config.baseColor, r);
      r = ri(this.config.multiplyLight, this.config.interpolationMode, r, l);
    }
    if (this.config.multiplyDark !== 0) {
      const l = Pl(this.config.baseColor, n);
      n = ri(this.config.multiplyDark, this.config.interpolationMode, n, l);
    }
    if (this.config.overlayLight !== 0) {
      const l = ql(this.config.baseColor, r);
      r = ri(this.config.overlayLight, this.config.interpolationMode, r, l);
    }
    if (this.config.overlayDark !== 0) {
      const l = ql(this.config.baseColor, n);
      n = ri(this.config.overlayDark, this.config.interpolationMode, n, l);
    }
    return this.config.baseScalePosition ? this.config.baseScalePosition <= 0 ? new Ft([
      { position: 0, color: this.config.baseColor },
      { position: 1, color: n.clamp() }
    ]) : this.config.baseScalePosition >= 1 ? new Ft([
      { position: 0, color: r.clamp() },
      { position: 1, color: this.config.baseColor }
    ]) : new Ft([
      { position: 0, color: r.clamp() },
      {
        position: this.config.baseScalePosition,
        color: this.config.baseColor
      },
      { position: 1, color: n.clamp() }
    ]) : new Ft([
      { position: 0, color: r.clamp() },
      { position: 0.5, color: this.config.baseColor },
      { position: 1, color: n.clamp() }
    ]);
  }
}
me.defaultPaletteConfig = {
  baseColor: MA("#808080"),
  steps: 11,
  interpolationMode: wt.RGB,
  scaleColorLight: new $(1, 1, 1, 1),
  scaleColorDark: new $(0, 0, 0, 1),
  clipLight: 0.185,
  clipDark: 0.16,
  saturationAdjustmentCutoff: 0.05,
  saturationLight: 0.35,
  saturationDark: 1.25,
  overlayLight: 0,
  overlayDark: 0.25,
  multiplyLight: 0,
  multiplyDark: 0,
  baseScalePosition: 0.5
};
me.greyscalePaletteConfig = {
  baseColor: MA("#808080"),
  steps: 11,
  interpolationMode: wt.RGB,
  scaleColorLight: new $(1, 1, 1, 1),
  scaleColorDark: new $(0, 0, 0, 1),
  clipLight: 0,
  clipDark: 0,
  saturationAdjustmentCutoff: 0,
  saturationLight: 0,
  saturationDark: 0,
  overlayLight: 0,
  overlayDark: 0,
  multiplyLight: 0,
  multiplyDark: 0,
  baseScalePosition: 0.5
};
me.defaultPaletteConfig.scaleColorLight, me.defaultPaletteConfig.scaleColorDark;
class ao {
  constructor(t) {
    this.palette = [], this.config = Object.assign({}, ao.defaultPaletteConfig, t), this.regenPalettes();
  }
  regenPalettes() {
    let t = this.config.steps;
    (isNaN(t) || t < 3) && (t = 3);
    const A = 0.14, i = 0.06, s = new $(A, A, A, 1), o = 94, n = new me(Object.assign(Object.assign({}, me.greyscalePaletteConfig), { baseColor: s, baseScalePosition: (1 - A) * 100 / o, steps: t })).palette, l = zr(this.config.baseColor), a = xi(this.config.baseColor).l, c = (l + a) / 2, h = this.matchRelativeLuminanceIndex(c, n) / (t - 1), C = this.matchRelativeLuminanceIndex(A, n) / (t - 1), B = xi(this.config.baseColor), E = jr(Pe.fromObject({
      h: B.h,
      s: B.s,
      l: A
    })), f = jr(Pe.fromObject({
      h: B.h,
      s: B.s,
      l: i
    })), p = new Array(5);
    p[0] = {
      position: 0,
      color: new $(1, 1, 1, 1)
    }, p[1] = {
      position: h,
      color: this.config.baseColor
    }, p[2] = {
      position: C,
      color: E
    }, p[3] = {
      position: 0.99,
      color: f
    }, p[4] = {
      position: 1,
      color: new $(0, 0, 0, 1)
    };
    const D = new Ft(p);
    this.palette = new Array(t);
    for (let N = 0; N < t; N++) {
      const M = D.getColor(N / (t - 1), wt.RGB);
      this.palette[N] = M;
    }
  }
  matchRelativeLuminanceIndex(t, A) {
    let i = Number.MAX_VALUE, s = 0, o = 0;
    const r = A.length;
    for (; o < r; o++) {
      const n = Math.abs(zr(A[o]) - t);
      n < i && (i = n, s = o);
    }
    return s;
  }
}
ao.defaultPaletteConfig = {
  baseColor: MA("#808080"),
  steps: 94
};
function Zc(e, t) {
  const A = e.relativeLuminance > t.relativeLuminance ? e : t, i = e.relativeLuminance > t.relativeLuminance ? t : e;
  return (A.relativeLuminance + 0.05) / (i.relativeLuminance + 0.05);
}
const De = Object.freeze({
  create(e, t, A) {
    return new Hs(e, t, A);
  },
  from(e) {
    return new Hs(e.r, e.g, e.b);
  }
});
function xf(e) {
  const t = {
    r: 0,
    g: 0,
    b: 0,
    toColorString: () => "",
    contrast: () => 0,
    relativeLuminance: 0
  };
  for (const A in t)
    if (typeof t[A] != typeof e[A])
      return !1;
  return !0;
}
class Hs extends $ {
  /**
   *
   * @param red - Red channel expressed as a number between 0 and 1
   * @param green - Green channel expressed as a number between 0 and 1
   * @param blue - Blue channel expressed as a number between 0 and 1
   */
  constructor(t, A, i) {
    super(t, A, i, 1), this.toColorString = this.toStringHexRGB, this.contrast = Zc.bind(null, this), this.createCSS = this.toColorString, this.relativeLuminance = Kr(this);
  }
  static fromObject(t) {
    return new Hs(t.r, t.g, t.b);
  }
}
function tn(e, t, A = 0, i = e.length - 1) {
  if (i === A)
    return e[A];
  const s = Math.floor((i - A) / 2) + A;
  return t(e[s]) ? tn(
    e,
    t,
    A,
    s
    // include this index because it passed the search condition
  ) : tn(
    e,
    t,
    s + 1,
    // exclude this index because it failed the search condition
    i
  );
}
const Nf = (-0.1 + Math.sqrt(0.21)) / 2;
function Ff(e) {
  return e.relativeLuminance <= Nf;
}
function je(e) {
  return Ff(e) ? -1 : 1;
}
function Rf(e, t, A) {
  return typeof e == "number" ? _s.from(De.create(e, t, A)) : _s.from(e);
}
function Uf(e) {
  return xf(e) ? Ts.from(e) : Ts.from(De.create(e.r, e.g, e.b));
}
const _s = Object.freeze({
  create: Rf,
  from: Uf
});
class Ts {
  /**
   *
   * @param source - The source color for the palette
   * @param swatches - All swatches in the palette
   */
  constructor(t, A) {
    this.closestIndexCache = /* @__PURE__ */ new Map(), this.source = t, this.swatches = A, this.reversedSwatches = Object.freeze([...this.swatches].reverse()), this.lastIndex = this.swatches.length - 1;
  }
  /**
   * {@inheritdoc Palette.colorContrast}
   */
  colorContrast(t, A, i, s) {
    i === void 0 && (i = this.closestIndexOf(t));
    let o = this.swatches;
    const r = this.lastIndex;
    let n = i;
    s === void 0 && (s = je(t));
    const l = (a) => Zc(t, a) >= A;
    return s === -1 && (o = this.reversedSwatches, n = r - n), tn(o, l, n, r);
  }
  /**
   * {@inheritdoc Palette.get}
   */
  get(t) {
    return this.swatches[t] || this.swatches[ie(t, 0, this.lastIndex)];
  }
  /**
   * {@inheritdoc Palette.closestIndexOf}
   */
  closestIndexOf(t) {
    if (this.closestIndexCache.has(t.relativeLuminance))
      return this.closestIndexCache.get(t.relativeLuminance);
    let A = this.swatches.indexOf(t);
    if (A !== -1)
      return this.closestIndexCache.set(t.relativeLuminance, A), A;
    const i = this.swatches.reduce((s, o) => Math.abs(o.relativeLuminance - t.relativeLuminance) < Math.abs(s.relativeLuminance - t.relativeLuminance) ? o : s);
    return A = this.swatches.indexOf(i), this.closestIndexCache.set(t.relativeLuminance, A), A;
  }
  /**
   * Create a color palette from a provided swatch
   * @param source - The source swatch to create a palette from
   * @returns
   */
  static from(t) {
    return new Ts(t, Object.freeze(new ao({
      /* eslint-disable-next-line @typescript-eslint/no-non-null-assertion */
      baseColor: $.fromObject(t)
    }).palette.map((A) => {
      const i = MA(A.toStringHexRGB());
      return De.create(i.r, i.g, i.b);
    })));
  }
}
function Gf(e, t, A, i, s, o, r, n, l) {
  const a = e.source, c = t.closestIndexOf(A), g = Math.max(r, n, l), h = c >= g ? -1 : 1, C = e.closestIndexOf(a), B = C + h * -1 * i, E = B + h * s, f = B + h * o;
  return {
    rest: e.get(B),
    hover: e.get(C),
    active: e.get(E),
    focus: e.get(f)
  };
}
function Mf(e, t, A, i, s, o, r) {
  const n = e.source, l = e.closestIndexOf(n), a = je(t), c = l + (a === 1 ? Math.min(i, s) : Math.max(a * i, a * s)), g = e.colorContrast(t, A, c, a), h = e.closestIndexOf(g), u = h + a * Math.abs(i - s), C = a === 1 ? i < s : a * i > a * s;
  let B, E;
  return C ? (B = h, E = u) : (B = u, E = h), {
    rest: e.get(B),
    hover: e.get(E),
    active: e.get(B + a * o),
    focus: e.get(B + a * r)
  };
}
const zl = De.create(1, 1, 1), Lf = De.create(0, 0, 0), Jf = De.from(MA("#808080")), Yf = De.from(MA("#DA1A5F"));
function Hf(e, t) {
  return e.contrast(zl) >= t ? zl : Lf;
}
function _f(e, t, A, i, s, o) {
  const r = e.closestIndexOf(t), n = Math.max(A, i, s, o), l = r >= n ? -1 : 1;
  return {
    rest: e.get(r + l * A),
    hover: e.get(r + l * i),
    active: e.get(r + l * s),
    focus: e.get(r + l * o)
  };
}
function Tf(e, t, A, i, s, o) {
  const r = je(t), n = e.closestIndexOf(t);
  return {
    rest: e.get(n - r * A),
    hover: e.get(n - r * i),
    active: e.get(n - r * s),
    focus: e.get(n - r * o)
  };
}
function Of(e, t, A) {
  const i = e.closestIndexOf(t);
  return e.get(i - (i < A ? A * -1 : A));
}
function $f(e, t, A, i, s, o, r, n, l, a) {
  const c = Math.max(A, i, s, o, r, n, l, a), g = e.closestIndexOf(t), h = g >= c ? -1 : 1;
  return {
    rest: e.get(g + h * A),
    hover: e.get(g + h * i),
    active: e.get(g + h * s),
    focus: e.get(g + h * o)
  };
}
function Pf(e, t, A, i, s, o) {
  const r = je(t), n = e.closestIndexOf(e.colorContrast(t, 4.5)), l = n + r * Math.abs(A - i), a = r === 1 ? A < i : r * A > r * i;
  let c, g;
  return a ? (c = n, g = l) : (c = l, g = n), {
    rest: e.get(c),
    hover: e.get(g),
    active: e.get(c + r * s),
    focus: e.get(c + r * o)
  };
}
function qf(e, t) {
  return e.colorContrast(t, 3.5);
}
function Vf(e, t, A) {
  return e.colorContrast(A, 3.5, e.closestIndexOf(e.source), je(t) * -1);
}
function zf(e, t) {
  return e.colorContrast(t, 14);
}
function Kf(e, t) {
  return e.colorContrast(t, 4.5);
}
function lo(e) {
  return De.create(e, e, e);
}
const jf = {
  LightMode: 1,
  DarkMode: 0.23
};
function Zf(e, t, A) {
  return e.get(e.closestIndexOf(lo(t)) + A);
}
function Wf(e, t, A) {
  const i = e.closestIndexOf(lo(t)) - A;
  return e.get(i - A);
}
function Xf(e, t) {
  return e.get(e.closestIndexOf(lo(t)));
}
function Mn(e, t, A, i, s, o) {
  return Math.max(e.closestIndexOf(lo(t)) + A, i, s, o);
}
function tp(e, t, A, i, s, o) {
  return e.get(Mn(e, t, A, i, s, o));
}
function ep(e, t, A, i, s, o) {
  return e.get(Mn(e, t, A, i, s, o) + A);
}
function Ap(e, t, A, i, s, o) {
  return e.get(Mn(e, t, A, i, s, o) + A * 2);
}
function ip(e, t, A, i, s, o) {
  const r = e.closestIndexOf(t), n = je(t), l = r + n * A, a = l + n * (i - A), c = l + n * (s - A), g = l + n * (o - A);
  return {
    rest: e.get(l),
    hover: e.get(a),
    active: e.get(c),
    focus: e.get(g)
  };
}
function sp(e, t, A) {
  return e.get(e.closestIndexOf(t) + je(t) * A);
}
const { create: Q } = no;
function v(e) {
  return no.create({ name: e, cssCustomPropertyName: null });
}
const op = Q("body-font").withDefault('aktiv-grotesk, "Segoe UI", Arial, Helvetica, sans-serif'), Wc = Q("base-height-multiplier").withDefault(10);
Q("base-horizontal-spacing-multiplier").withDefault(3);
const LA = Q("base-layer-luminance").withDefault(jf.DarkMode), en = Q("control-corner-radius").withDefault(4), Xc = Q("density").withDefault(0), Ni = Q("design-unit").withDefault(4), Ir = Q("direction").withDefault(ve.ltr), rp = Q("disabled-opacity").withDefault(0.3), An = Q("stroke-width").withDefault(1), Kl = Q("focus-stroke-width").withDefault(2), np = Q("type-ramp-base-font-size").withDefault("14px"), ap = Q("type-ramp-base-line-height").withDefault("20px");
Q("type-ramp-minus-1-font-size").withDefault("12px");
Q("type-ramp-minus-1-line-height").withDefault("16px");
Q("type-ramp-minus-2-font-size").withDefault("10px");
Q("type-ramp-minus-2-line-height").withDefault("16px");
Q("type-ramp-plus-1-font-size").withDefault("16px");
Q("type-ramp-plus-1-line-height").withDefault("24px");
Q("type-ramp-plus-2-font-size").withDefault("20px");
Q("type-ramp-plus-2-line-height").withDefault("28px");
Q("type-ramp-plus-3-font-size").withDefault("28px");
Q("type-ramp-plus-3-line-height").withDefault("36px");
Q("type-ramp-plus-4-font-size").withDefault("34px");
Q("type-ramp-plus-4-line-height").withDefault("44px");
Q("type-ramp-plus-5-font-size").withDefault("46px");
Q("type-ramp-plus-5-line-height").withDefault("56px");
Q("type-ramp-plus-6-font-size").withDefault("60px");
Q("type-ramp-plus-6-line-height").withDefault("72px");
v("accent-fill-rest-delta").withDefault(0);
const lp = v("accent-fill-hover-delta").withDefault(4), gp = v("accent-fill-active-delta").withDefault(-5), cp = v("accent-fill-focus-delta").withDefault(0), hp = v("accent-foreground-rest-delta").withDefault(0), Ip = v("accent-foreground-hover-delta").withDefault(6), up = v("accent-foreground-active-delta").withDefault(-4), dp = v("accent-foreground-focus-delta").withDefault(0), JA = v("neutral-fill-rest-delta").withDefault(7), YA = v("neutral-fill-hover-delta").withDefault(10), HA = v("neutral-fill-active-delta").withDefault(5), th = v("neutral-fill-focus-delta").withDefault(0), Cp = v("neutral-fill-input-rest-delta").withDefault(0), Bp = v("neutral-fill-input-hover-delta").withDefault(0), Qp = v("neutral-fill-input-active-delta").withDefault(0), Ep = v("neutral-fill-input-focus-delta").withDefault(0), fp = v("neutral-fill-stealth-rest-delta").withDefault(0), pp = v("neutral-fill-stealth-hover-delta").withDefault(5), wp = v("neutral-fill-stealth-active-delta").withDefault(3), yp = v("neutral-fill-stealth-focus-delta").withDefault(0), vp = v("neutral-fill-strong-rest-delta").withDefault(0), mp = v("neutral-fill-strong-hover-delta").withDefault(8), bp = v("neutral-fill-strong-active-delta").withDefault(-5), Dp = v("neutral-fill-strong-focus-delta").withDefault(0), _A = v("neutral-fill-layer-rest-delta").withDefault(3), kp = v("neutral-stroke-rest-delta").withDefault(25), Sp = v("neutral-stroke-hover-delta").withDefault(40), xp = v("neutral-stroke-active-delta").withDefault(16), Np = v("neutral-stroke-focus-delta").withDefault(25), Fp = v("neutral-stroke-divider-rest-delta").withDefault(8), Rp = Q("neutral-color").withDefault(Jf), ct = v("neutral-palette").withDefault((e) => _s.from(Rp.getValueFor(e))), Up = Q("accent-color").withDefault(Yf), Ln = v("accent-palette").withDefault((e) => _s.from(Up.getValueFor(e))), Gp = v("neutral-layer-card-container-recipe").withDefault({
  evaluate: (e) => Zf(ct.getValueFor(e), LA.getValueFor(e), _A.getValueFor(e))
});
Q("neutral-layer-card-container").withDefault((e) => Gp.getValueFor(e).evaluate(e));
const Mp = v("neutral-layer-floating-recipe").withDefault({
  evaluate: (e) => Wf(ct.getValueFor(e), LA.getValueFor(e), _A.getValueFor(e))
}), Lp = Q("neutral-layer-floating").withDefault((e) => Mp.getValueFor(e).evaluate(e)), Jp = v("neutral-layer-1-recipe").withDefault({
  evaluate: (e) => Xf(ct.getValueFor(e), LA.getValueFor(e))
}), Yp = Q("neutral-layer-1").withDefault((e) => Jp.getValueFor(e).evaluate(e)), Hp = v("neutral-layer-2-recipe").withDefault({
  evaluate: (e) => tp(ct.getValueFor(e), LA.getValueFor(e), _A.getValueFor(e), JA.getValueFor(e), YA.getValueFor(e), HA.getValueFor(e))
});
Q("neutral-layer-2").withDefault((e) => Hp.getValueFor(e).evaluate(e));
const _p = v("neutral-layer-3-recipe").withDefault({
  evaluate: (e) => ep(ct.getValueFor(e), LA.getValueFor(e), _A.getValueFor(e), JA.getValueFor(e), YA.getValueFor(e), HA.getValueFor(e))
});
Q("neutral-layer-3").withDefault((e) => _p.getValueFor(e).evaluate(e));
const Tp = v("neutral-layer-4-recipe").withDefault({
  evaluate: (e) => Ap(ct.getValueFor(e), LA.getValueFor(e), _A.getValueFor(e), JA.getValueFor(e), YA.getValueFor(e), HA.getValueFor(e))
});
Q("neutral-layer-4").withDefault((e) => Tp.getValueFor(e).evaluate(e));
const ft = Q("fill-color").withDefault((e) => Yp.getValueFor(e));
var Fi;
(function(e) {
  e[e.normal = 4.5] = "normal", e[e.large = 7] = "large";
})(Fi || (Fi = {}));
const go = Q({
  name: "accent-fill-recipe",
  cssCustomPropertyName: null
}).withDefault({
  evaluate: (e, t) => Gf(Ln.getValueFor(e), ct.getValueFor(e), t || ft.getValueFor(e), lp.getValueFor(e), gp.getValueFor(e), cp.getValueFor(e), JA.getValueFor(e), YA.getValueFor(e), HA.getValueFor(e))
}), Ri = Q("accent-fill-rest").withDefault((e) => go.getValueFor(e).evaluate(e).rest), eh = Q("accent-fill-hover").withDefault((e) => go.getValueFor(e).evaluate(e).hover), Ah = Q("accent-fill-active").withDefault((e) => go.getValueFor(e).evaluate(e).active), ih = Q("accent-fill-focus").withDefault((e) => go.getValueFor(e).evaluate(e).focus), sh = (e) => (t, A) => Hf(A || Ri.getValueFor(t), e), co = v("foreground-on-accent-recipe").withDefault({
  evaluate: (e, t) => sh(Fi.normal)(e, t)
}), jl = Q("foreground-on-accent-rest").withDefault((e) => co.getValueFor(e).evaluate(e, Ri.getValueFor(e)));
Q("foreground-on-accent-hover").withDefault((e) => co.getValueFor(e).evaluate(e, eh.getValueFor(e)));
Q("foreground-on-accent-active").withDefault((e) => co.getValueFor(e).evaluate(e, Ah.getValueFor(e)));
Q("foreground-on-accent-focus").withDefault((e) => co.getValueFor(e).evaluate(e, ih.getValueFor(e)));
const ho = v("foreground-on-accent-large-recipe").withDefault({
  evaluate: (e, t) => sh(Fi.large)(e, t)
});
Q("foreground-on-accent-rest-large").withDefault((e) => ho.getValueFor(e).evaluate(e, Ri.getValueFor(e)));
Q("foreground-on-accent-hover-large").withDefault((e) => ho.getValueFor(e).evaluate(e, eh.getValueFor(e)));
Q("foreground-on-accent-active-large").withDefault((e) => ho.getValueFor(e).evaluate(e, Ah.getValueFor(e)));
Q("foreground-on-accent-focus-large").withDefault((e) => ho.getValueFor(e).evaluate(e, ih.getValueFor(e)));
const Op = (e) => (t, A) => Mf(Ln.getValueFor(t), A || ft.getValueFor(t), e, hp.getValueFor(t), Ip.getValueFor(t), up.getValueFor(t), dp.getValueFor(t)), Io = Q({
  name: "accent-foreground-recipe",
  cssCustomPropertyName: null
}).withDefault({
  evaluate: (e, t) => Op(Fi.normal)(e, t)
});
Q("accent-foreground-rest").withDefault((e) => Io.getValueFor(e).evaluate(e).rest);
Q("accent-foreground-hover").withDefault((e) => Io.getValueFor(e).evaluate(e).hover);
Q("accent-foreground-active").withDefault((e) => Io.getValueFor(e).evaluate(e).active);
Q("accent-foreground-focus").withDefault((e) => Io.getValueFor(e).evaluate(e).focus);
const uo = Q({
  name: "neutral-fill-recipe",
  cssCustomPropertyName: null
}).withDefault({
  evaluate: (e, t) => _f(ct.getValueFor(e), t || ft.getValueFor(e), JA.getValueFor(e), YA.getValueFor(e), HA.getValueFor(e), th.getValueFor(e))
}), $p = Q("neutral-fill-rest").withDefault((e) => uo.getValueFor(e).evaluate(e).rest);
Q("neutral-fill-hover").withDefault((e) => uo.getValueFor(e).evaluate(e).hover);
Q("neutral-fill-active").withDefault((e) => uo.getValueFor(e).evaluate(e).active);
Q("neutral-fill-focus").withDefault((e) => uo.getValueFor(e).evaluate(e).focus);
const Co = Q({
  name: "neutral-fill-input-recipe",
  cssCustomPropertyName: null
}).withDefault({
  evaluate: (e, t) => Tf(ct.getValueFor(e), t || ft.getValueFor(e), Cp.getValueFor(e), Bp.getValueFor(e), Qp.getValueFor(e), Ep.getValueFor(e))
});
Q("neutral-fill-input-rest").withDefault((e) => Co.getValueFor(e).evaluate(e).rest);
Q("neutral-fill-input-hover").withDefault((e) => Co.getValueFor(e).evaluate(e).hover);
Q("neutral-fill-input-active").withDefault((e) => Co.getValueFor(e).evaluate(e).active);
Q("neutral-fill-input-focus").withDefault((e) => Co.getValueFor(e).evaluate(e).focus);
const Bo = Q({
  name: "neutral-fill-stealth-recipe",
  cssCustomPropertyName: null
}).withDefault({
  evaluate: (e, t) => $f(ct.getValueFor(e), t || ft.getValueFor(e), fp.getValueFor(e), pp.getValueFor(e), wp.getValueFor(e), yp.getValueFor(e), JA.getValueFor(e), YA.getValueFor(e), HA.getValueFor(e), th.getValueFor(e))
}), Zl = Q("neutral-fill-stealth-rest").withDefault((e) => Bo.getValueFor(e).evaluate(e).rest), Pp = Q("neutral-fill-stealth-hover").withDefault((e) => Bo.getValueFor(e).evaluate(e).hover), qp = Q("neutral-fill-stealth-active").withDefault((e) => Bo.getValueFor(e).evaluate(e).active), Vp = Q("neutral-fill-stealth-focus").withDefault((e) => Bo.getValueFor(e).evaluate(e).focus), Qo = Q({
  name: "neutral-fill-strong-recipe",
  cssCustomPropertyName: null
}).withDefault({
  evaluate: (e, t) => Pf(ct.getValueFor(e), t || ft.getValueFor(e), vp.getValueFor(e), mp.getValueFor(e), bp.getValueFor(e), Dp.getValueFor(e))
});
Q("neutral-fill-strong-rest").withDefault((e) => Qo.getValueFor(e).evaluate(e).rest);
Q("neutral-fill-strong-hover").withDefault((e) => Qo.getValueFor(e).evaluate(e).hover);
Q("neutral-fill-strong-active").withDefault((e) => Qo.getValueFor(e).evaluate(e).active);
Q("neutral-fill-strong-focus").withDefault((e) => Qo.getValueFor(e).evaluate(e).focus);
const zp = v("neutral-fill-layer-recipe").withDefault({
  evaluate: (e, t) => Of(ct.getValueFor(e), t || ft.getValueFor(e), _A.getValueFor(e))
});
Q("neutral-fill-layer-rest").withDefault((e) => zp.getValueFor(e).evaluate(e));
const Kp = v("focus-stroke-outer-recipe").withDefault({
  evaluate: (e) => qf(ct.getValueFor(e), ft.getValueFor(e))
}), oh = Q("focus-stroke-outer").withDefault((e) => Kp.getValueFor(e).evaluate(e)), jp = v("focus-stroke-inner-recipe").withDefault({
  evaluate: (e) => Vf(Ln.getValueFor(e), ft.getValueFor(e), oh.getValueFor(e))
});
Q("focus-stroke-inner").withDefault((e) => jp.getValueFor(e).evaluate(e));
const Zp = v("neutral-foreground-hint-recipe").withDefault({
  evaluate: (e) => Kf(ct.getValueFor(e), ft.getValueFor(e))
}), Wp = Q("neutral-foreground-hint").withDefault((e) => Zp.getValueFor(e).evaluate(e)), Xp = v("neutral-foreground-recipe").withDefault({
  evaluate: (e) => zf(ct.getValueFor(e), ft.getValueFor(e))
}), ue = Q("neutral-foreground-rest").withDefault((e) => Xp.getValueFor(e).evaluate(e)), Eo = Q({
  name: "neutral-stroke-recipe",
  cssCustomPropertyName: null
}).withDefault({
  evaluate: (e) => ip(ct.getValueFor(e), ft.getValueFor(e), kp.getValueFor(e), Sp.getValueFor(e), xp.getValueFor(e), Np.getValueFor(e))
});
Q("neutral-stroke-rest").withDefault((e) => Eo.getValueFor(e).evaluate(e).rest);
Q("neutral-stroke-hover").withDefault((e) => Eo.getValueFor(e).evaluate(e).hover);
Q("neutral-stroke-active").withDefault((e) => Eo.getValueFor(e).evaluate(e).active);
Q("neutral-stroke-focus").withDefault((e) => Eo.getValueFor(e).evaluate(e).focus);
const t0 = v("neutral-stroke-divider-recipe").withDefault({
  evaluate: (e, t) => sp(ct.getValueFor(e), t || ft.getValueFor(e), Fp.getValueFor(e))
}), e0 = Q("neutral-stroke-divider-rest").withDefault((e) => t0.getValueFor(e).evaluate(e));
no.create({
  name: "height-number",
  cssCustomPropertyName: null
}).withDefault((e) => (Wc.getValueFor(e) + Xc.getValueFor(e)) * Ni.getValueFor(e));
const A0 = dE`(${Wc} + ${Xc}) * ${Ni}`, i0 = "0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0, 0, 0, calc(.11 * (2 - var(--background-luminance, 1))))", s0 = "0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0, 0, 0, calc(.13 * (2 - var(--background-luminance, 1))))", o0 = `box-shadow: ${i0}, ${s0};`;
class r0 {
  constructor(t, A) {
    this.cache = /* @__PURE__ */ new WeakMap(), this.ltr = t, this.rtl = A;
  }
  /**
   * @internal
   */
  bind(t) {
    this.attach(t);
  }
  /**
   * @internal
   */
  unbind(t) {
    const A = this.cache.get(t);
    A && Ir.unsubscribe(A);
  }
  attach(t) {
    const A = this.cache.get(t) || new n0(this.ltr, this.rtl, t), i = Ir.getValueFor(t);
    Ir.subscribe(A), A.attach(i), this.cache.set(t, A);
  }
}
class n0 {
  constructor(t, A, i) {
    this.ltr = t, this.rtl = A, this.source = i, this.attached = null;
  }
  handleChange({ target: t, token: A }) {
    this.attach(A.getValueFor(t));
  }
  attach(t) {
    this.attached !== this[t] && (this.attached !== null && this.source.$fastController.removeStyles(this.attached), this.attached = this[t], this.attached !== null && this.source.$fastController.addStyles(this.attached));
  }
}
const a0 = (e, t) => rA`
        ${Vc("grid")} :host {
            contain: layout;
            overflow: visible;
            font-family: ${op};
            outline: none;
            box-sizing: border-box;
            height: calc(${A0} * 1px);
            grid-template-columns: minmax(42px, auto) 1fr minmax(42px, auto);
            grid-template-rows: auto;
            justify-items: center;
            align-items: center;
            padding: 0;
            margin: 0 calc(${Ni} * 1px);
            white-space: nowrap;
            background: ${Zl};
            color: ${ue};
            fill: currentcolor;
            cursor: pointer;
            font-size: ${np};
            line-height: ${ap};
            border-radius: calc(${en} * 1px);
            border: calc(${Kl} * 1px) solid transparent;
        }

        :host(:hover) {
            position: relative;
            z-index: 1;
        }

        :host(.indent-0) {
            grid-template-columns: auto 1fr minmax(42px, auto);
        }
        :host(.indent-0) .content {
            grid-column: 1;
            grid-row: 1;
            margin-inline-start: 10px;
        }
        :host(.indent-0) .expand-collapse-glyph-container {
            grid-column: 5;
            grid-row: 1;
        }
        :host(.indent-2) {
            grid-template-columns: minmax(42px, auto) minmax(42px, auto) 1fr minmax(42px, auto) minmax(42px, auto);
        }
        :host(.indent-2) .content {
            grid-column: 3;
            grid-row: 1;
            margin-inline-start: 10px;
        }
        :host(.indent-2) .expand-collapse-glyph-container {
            grid-column: 5;
            grid-row: 1;
        }
        :host(.indent-2) .start {
            grid-column: 2;
        }
        :host(.indent-2) .end {
            grid-column: 4;
        }

        :host(:${Ie}) {
            border-color: ${oh};
            background: ${Vp};
            color: ${ue};
        }

        :host(:hover) {
            background: ${Pp};
            color: ${ue};
        }

        :host(:active) {
            background: ${qp};
        }

        :host([aria-checked="true"]),
        :host(.expanded) {
            background: ${$p};
            color: ${ue};
        }

        :host([disabled]) {
            cursor: ${uf};
            opacity: ${rp};
        }

        :host([disabled]:hover) {
            color: ${ue};
            fill: currentcolor;
            background: ${Zl};
        }

        :host([disabled]:hover) .start,
        :host([disabled]:hover) .end,
        :host([disabled]:hover)::slotted(svg) {
            fill: ${ue};
        }

        .expand-collapse-glyph {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            width: 16px;
            height: 16px;
            fill: currentcolor;
        }

        .content {
            grid-column-start: 2;
            justify-self: start;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .start,
        .end {
            display: flex;
            justify-content: center;
        }

        ::slotted(svg) {
            /* TODO: adaptive typography https://github.com/microsoft/fast/issues/2432 */
            width: 16px;
            height: 16px;
        }

        :host(:hover) .start,
        :host(:hover) .end,
        :host(:hover)::slotted(svg),
        :host(:active) .start,
        :host(:active) .end,
        :host(:active)::slotted(svg) {
            fill: ${ue};
        }

        :host(.indent-0[aria-haspopup="menu"]) {
            display: grid;
            grid-template-columns: minmax(42px, auto) auto 1fr minmax(42px, auto) minmax(42px, auto);
            align-items: center;
            min-height: 32px;
        }

        :host(.indent-1[aria-haspopup="menu"]),
        :host(.indent-1[role="menuitemcheckbox"]),
        :host(.indent-1[role="menuitemradio"]) {
            display: grid;
            grid-template-columns: minmax(42px, auto) auto 1fr minmax(42px, auto) minmax(42px, auto);
            align-items: center;
            min-height: 32px;
        }

        :host(.indent-2:not([aria-haspopup="menu"])) .end {
            grid-column: 5;
        }

        :host .input-container,
        :host .expand-collapse-glyph-container {
            display: none;
        }

        :host([aria-haspopup="menu"]) .expand-collapse-glyph-container,
        :host([role="menuitemcheckbox"]) .input-container,
        :host([role="menuitemradio"]) .input-container {
            display: grid;
            margin-inline-end: 10px;
        }

        :host([aria-haspopup="menu"]) .content,
        :host([role="menuitemcheckbox"]) .content,
        :host([role="menuitemradio"]) .content {
            grid-column-start: 3;
        }

        :host([aria-haspopup="menu"].indent-0) .content {
            grid-column-start: 1;
        }

        :host([aria-haspopup="menu"]) .end,
        :host([role="menuitemcheckbox"]) .end,
        :host([role="menuitemradio"]) .end {
            grid-column-start: 4;
        }

        :host .expand-collapse,
        :host .checkbox,
        :host .radio {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            width: 20px;
            height: 20px;
            box-sizing: border-box;
            outline: none;
            margin-inline-start: 10px;
        }

        :host .checkbox,
        :host .radio {
            border: calc(${An} * 1px) solid ${ue};
        }

        :host([aria-checked="true"]) .checkbox,
        :host([aria-checked="true"]) .radio {
            background: ${Ri};
            border-color: ${Ri};
        }

        :host .checkbox {
            border-radius: calc(${en} * 1px);
        }

        :host .radio {
            border-radius: 999px;
        }

        :host .checkbox-indicator,
        :host .radio-indicator,
        :host .expand-collapse-indicator,
        ::slotted([slot="checkbox-indicator"]),
        ::slotted([slot="radio-indicator"]),
        ::slotted([slot="expand-collapse-indicator"]) {
            display: none;
        }

        ::slotted([slot="end"]:not(svg)) {
            margin-inline-end: 10px;
            color: ${Wp}
        }

        :host([aria-checked="true"]) .checkbox-indicator,
        :host([aria-checked="true"]) ::slotted([slot="checkbox-indicator"]) {
            width: 100%;
            height: 100%;
            display: block;
            fill: ${jl};
            pointer-events: none;
        }

        :host([aria-checked="true"]) .radio-indicator {
            position: absolute;
            top: 4px;
            left: 4px;
            right: 4px;
            bottom: 4px;
            border-radius: 999px;
            display: block;
            background: ${jl};
            pointer-events: none;
        }

        :host([aria-checked="true"]) ::slotted([slot="radio-indicator"]) {
            display: block;
            pointer-events: none;
        }
    `.withBehaviors(qc(rA`
            :host {
                border-color: transparent;
                color: ${G.ButtonText};
                forced-color-adjust: none;
            }

            :host(:hover) {
                background: ${G.Highlight};
                color: ${G.HighlightText};
            }

            :host(:hover) .start,
            :host(:hover) .end,
            :host(:hover)::slotted(svg),
            :host(:active) .start,
            :host(:active) .end,
            :host(:active)::slotted(svg) {
                fill: ${G.HighlightText};
            }

            :host(.expanded) {
                background: ${G.Highlight};
                border-color: ${G.Highlight};
                color: ${G.HighlightText};
            }

            :host(:${Ie}) {
                background: ${G.Highlight};
                border-color: ${G.ButtonText};
                box-shadow: 0 0 0 calc(${Kl} * 1px) inset ${G.HighlightText};
                color: ${G.HighlightText};
                fill: currentcolor;
            }

            :host([disabled]),
            :host([disabled]:hover),
            :host([disabled]:hover) .start,
            :host([disabled]:hover) .end,
            :host([disabled]:hover)::slotted(svg) {
                background: ${G.Canvas};
                color: ${G.GrayText};
                fill: currentcolor;
                opacity: 1;
            }

            :host .expanded-toggle,
            :host .checkbox,
            :host .radio{
                border-color: ${G.ButtonText};
                background: ${G.HighlightText};
            }

            :host([checked="true"]) .checkbox,
            :host([checked="true"]) .radio {
                background: ${G.HighlightText};
                border-color: ${G.HighlightText};
            }

            :host(:hover) .expanded-toggle,
            :host(:hover) .checkbox,
            :host(:hover) .radio,
            :host(:${Ie}) .expanded-toggle,
            :host(:${Ie}) .checkbox,
            :host(:${Ie}) .radio,
            :host([checked="true"]:hover) .checkbox,
            :host([checked="true"]:hover) .radio,
            :host([checked="true"]:${Ie}) .checkbox,
            :host([checked="true"]:${Ie}) .radio {
                border-color: ${G.HighlightText};
            }

            :host([aria-checked="true"]) {
                background: ${G.Highlight};
                color: ${G.HighlightText};
            }

            :host([aria-checked="true"]) .checkbox-indicator,
            :host([aria-checked="true"]) ::slotted([slot="checkbox-indicator"]),
            :host([aria-checked="true"]) ::slotted([slot="radio-indicator"]) {
                fill: ${G.Highlight};
            }

            :host([aria-checked="true"]) .radio-indicator {
                background: ${G.Highlight};
            }

            ::slotted([slot="end"]:not(svg)) {
                color: ${G.ButtonText};
            }

            :host(:hover) ::slotted([slot="end"]:not(svg)),
            :host(:${Ie}) ::slotted([slot="end"]:not(svg)) {
                color: ${G.HighlightText};
            }
        `), new r0(rA`
                .expand-collapse-glyph {
                    transform: rotate(0deg);
                }
            `, rA`
                .expand-collapse-glyph {
                    transform: rotate(180deg);
                }
            `)), l0 = Gt.compose({
  baseName: "menu-item",
  template: cf,
  styles: a0,
  checkboxIndicator: (
    /* html */
    `
        <svg
            part="checkbox-indicator"
            class="checkbox-indicator"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M8.143 12.6697L15.235 4.5L16.8 5.90363L8.23812 15.7667L3.80005 11.2556L5.27591 9.7555L8.143 12.6697Z"
            />
        </svg>
    `
  ),
  expandCollapseGlyph: (
    /* html */
    `
        <svg
            viewBox="0 0 16 16"
            xmlns="http://www.w3.org/2000/svg"
            class="expand-collapse-glyph"
            part="expand-collapse-glyph"
        >
            <path
                d="M5.00001 12.3263C5.00124 12.5147 5.05566 12.699 5.15699 12.8578C5.25831 13.0167 5.40243 13.1437 5.57273 13.2242C5.74304 13.3047 5.9326 13.3354 6.11959 13.3128C6.30659 13.2902 6.4834 13.2152 6.62967 13.0965L10.8988 8.83532C11.0739 8.69473 11.2153 8.51658 11.3124 8.31402C11.4096 8.11146 11.46 7.88966 11.46 7.66499C11.46 7.44033 11.4096 7.21853 11.3124 7.01597C11.2153 6.81341 11.0739 6.63526 10.8988 6.49467L6.62967 2.22347C6.48274 2.10422 6.30501 2.02912 6.11712 2.00691C5.92923 1.9847 5.73889 2.01628 5.56823 2.09799C5.39757 2.17969 5.25358 2.30817 5.153 2.46849C5.05241 2.62882 4.99936 2.8144 5.00001 3.00369V12.3263Z"
            />
        </svg>
    `
  ),
  radioIndicator: (
    /* html */
    `
        <span part="radio-indicator" class="radio-indicator"></span>
    `
  )
}), g0 = (e, t) => rA`
        ${Vc("block")} :host {
            --elevation: 11;
            background: ${ft};
            border: calc(${An} * 1px) solid transparent;
            ${o0}
            margin: 0;
            border-radius: calc(${en} * 1px);
            padding: calc(${Ni} * 1px) 0;
            max-width: 368px;
            min-width: 64px;
        }

        :host([slot="submenu"]) {
            width: max-content;
            margin: 0 calc(${Ni} * 1px);
        }

        ::slotted(hr) {
            box-sizing: content-box;
            height: 0;
            margin: 0;
            border: none;
            border-top: calc(${An} * 1px) solid ${e0};
        }
    `.withBehaviors(qc(rA`
                :host {
                    background: ${G.Canvas};
                    border-color: ${G.CanvasText};
                }
            `));
class c0 extends Un {
  /**
   * @internal
   */
  connectedCallback() {
    super.connectedCallback(), ft.setValueFor(this, Lp);
  }
}
const h0 = c0.compose({
  baseName: "menu",
  template: hf,
  styles: g0
});
function I0(e) {
  return Oc.getOrCreate(e).withPrefix("fast");
}
I0().register(h0(), l0({}));
let bA = class extends q {
  constructor() {
    super(...arguments), this.appletsInfosAndGroupsProfiles = new Ke(this, () => dn(async () => vn(this.weServices, Array.from(this.weServices.attachmentTypes.keys()))), () => []);
  }
  async createAttachment(t) {
    try {
      const A = await this.attachmentsStore.client.getDnaHash(), i = await t.create([A, this.hash]);
      await this.attachmentsStore.client.addAttachment(this.hash, i), this.weServices.openViews.openHrl(i.hrl, i.context);
    } catch (A) {
      Ji(k("Error creating the attachment")), console.error(A);
    }
  }
  renderMenuItems() {
    switch (this.appletsInfosAndGroupsProfiles.value.status) {
      case "pending":
        return Array(3).map(() => w`<fast-menu-item><sl-skeleton></sl-skeleton></fast-menu-item>`);
      case "complete":
        const { appletsInfos: t, groupsProfiles: A } = this.appletsInfosAndGroupsProfiles.value.value, i = Array.from(this.weServices.attachmentTypes.entries());
        if (i.length === 0)
          return w`<fast-menu-item disabled
            >${k("There are no attachment types yet.")}</fast-menu-item
          >`;
        const s = {};
        for (const [o, r] of i)
          for (const [n, l] of Object.entries(r)) {
            const a = JSON.stringify({
              label: l.label,
              icon_src: l.icon_src
            });
            s[a] || (s[a] = new ks()), s[a].set(o, l);
          }
        return Object.entries(s).map(([o, r]) => {
          const { label: n, icon_src: l } = JSON.parse(o);
          return w`<fast-menu-item>
              <sl-icon slot="start" .src=${l}></sl-icon>
              ${n}
              <fast-menu slot="submenu">
                ${Array.from(r.entries()).map(([a, c]) => {
            var g, h;
            return w`
                    <fast-menu-item
                      @click=${() => this.createAttachment(c)}
                    >
                      <div class="row" style="align-items: center">
                        <span> ${(g = t.get(a)) === null || g === void 0 ? void 0 : g.appletName}</span>
                        <span style="margin-right: 8px">${k(" in ")}</span>
                        ${(h = t.get(a)) === null || h === void 0 ? void 0 : h.groupsIds.map((u) => {
              var C, B;
              return w`
                            <img
                              .src=${(C = A.get(u)) === null || C === void 0 ? void 0 : C.logo_src}
                              style="height: 32px; width: 32px; margin-right: 4px;"
                            />
                            <span>${(B = A.get(u)) === null || B === void 0 ? void 0 : B.name}</span>
                          `;
            })}
                      </div>
                    </fast-menu-item>
                  `;
          })}
              </fast-menu>
            </fast-menu-item>`;
        });
      case "error":
        return w`<display-error
          .headline=${k("Error fetching the attachment types")}
        ></display-error>`;
    }
  }
  render() {
    return w`
      <sl-dropdown>
        <sl-icon-button slot="trigger" .src=${fe(rB)}>
        </sl-icon-button>

        <fast-menu> ${this.renderMenuItems()} </fast-menu>
      </sl-dropdown>
    `;
  }
};
bA.styles = [Ut];
T([
  Tt({ context: mn, subscribe: !0 })
], bA.prototype, "attachmentsStore", void 0);
T([
  Tt({ context: Hi, subscribe: !0 })
], bA.prototype, "weServices", void 0);
T([
  W(NA("hash"))
], bA.prototype, "hash", void 0);
bA = T([
  Xt(),
  It("create-attachment")
], bA);
let Os = class extends q {
  render() {
    return w`
      <sl-card style="flex: 1">
        <div class="row" style="align-items: center" slot="header">
          <span style="flex: 1" class="title">${k("Attachments")}</span>

          <create-attachment .hash=${this.hash}></create-attachment>
        </div>

        <attachments-list .hash=${this.hash} style="flex: 1"></attachments-list>
      </sl-card>
    `;
  }
};
Os.styles = [
  Ut,
  ae`
      :host {
        display: flex;
      }
    `
];
T([
  W(NA("hash"))
], Os.prototype, "hash", void 0);
Os = T([
  Xt(),
  It("attachments-card")
], Os);
var rh = V`
  .form-control .form-control__label {
    display: none;
  }

  .form-control .form-control__help-text {
    display: none;
  }

  /* Label */
  .form-control--has-label .form-control__label {
    display: inline-block;
    color: var(--sl-input-label-color);
    margin-bottom: var(--sl-spacing-3x-small);
  }

  .form-control--has-label.form-control--small .form-control__label {
    font-size: var(--sl-input-label-font-size-small);
  }

  .form-control--has-label.form-control--medium .form-control__label {
    font-size: var(--sl-input-label-font-size-medium);
  }

  .form-control--has-label.form-control--large .form-control__label {
    font-size: var(--sl-input-label-font-size-large);
  }

  :host([required]) .form-control--has-label .form-control__label::after {
    content: var(--sl-input-required-content);
    margin-inline-start: var(--sl-input-required-content-offset);
    color: var(--sl-input-required-content-color);
  }

  /* Help text */
  .form-control--has-help-text .form-control__help-text {
    display: block;
    color: var(--sl-input-help-text-color);
    margin-top: var(--sl-spacing-3x-small);
  }

  .form-control--has-help-text.form-control--small .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-small);
  }

  .form-control--has-help-text.form-control--medium .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-medium);
  }

  .form-control--has-help-text.form-control--large .form-control__help-text {
    font-size: var(--sl-input-help-text-font-size-large);
  }

  .form-control--has-help-text.form-control--radio-group .form-control__help-text {
    margin-top: var(--sl-spacing-2x-small);
  }
`, u0 = V`
  ${it}
  ${rh}

  :host {
    display: block;
  }

  .textarea {
    display: flex;
    align-items: center;
    position: relative;
    width: 100%;
    font-family: var(--sl-input-font-family);
    font-weight: var(--sl-input-font-weight);
    line-height: var(--sl-line-height-normal);
    letter-spacing: var(--sl-input-letter-spacing);
    vertical-align: middle;
    transition: var(--sl-transition-fast) color, var(--sl-transition-fast) border, var(--sl-transition-fast) box-shadow,
      var(--sl-transition-fast) background-color;
    cursor: text;
  }

  /* Standard textareas */
  .textarea--standard {
    background-color: var(--sl-input-background-color);
    border: solid var(--sl-input-border-width) var(--sl-input-border-color);
  }

  .textarea--standard:hover:not(.textarea--disabled) {
    background-color: var(--sl-input-background-color-hover);
    border-color: var(--sl-input-border-color-hover);
  }
  .textarea--standard:hover:not(.textarea--disabled) .textarea__control {
    color: var(--sl-input-color-hover);
  }

  .textarea--standard.textarea--focused:not(.textarea--disabled) {
    background-color: var(--sl-input-background-color-focus);
    border-color: var(--sl-input-border-color-focus);
    color: var(--sl-input-color-focus);
    box-shadow: 0 0 0 var(--sl-focus-ring-width) var(--sl-input-focus-ring-color);
  }

  .textarea--standard.textarea--focused:not(.textarea--disabled) .textarea__control {
    color: var(--sl-input-color-focus);
  }

  .textarea--standard.textarea--disabled {
    background-color: var(--sl-input-background-color-disabled);
    border-color: var(--sl-input-border-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .textarea--standard.textarea--disabled .textarea__control {
    color: var(--sl-input-color-disabled);
  }

  .textarea--standard.textarea--disabled .textarea__control::placeholder {
    color: var(--sl-input-placeholder-color-disabled);
  }

  /* Filled textareas */
  .textarea--filled {
    border: none;
    background-color: var(--sl-input-filled-background-color);
    color: var(--sl-input-color);
  }

  .textarea--filled:hover:not(.textarea--disabled) {
    background-color: var(--sl-input-filled-background-color-hover);
  }

  .textarea--filled.textarea--focused:not(.textarea--disabled) {
    background-color: var(--sl-input-filled-background-color-focus);
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .textarea--filled.textarea--disabled {
    background-color: var(--sl-input-filled-background-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .textarea__control {
    flex: 1 1 auto;
    font-family: inherit;
    font-size: inherit;
    font-weight: inherit;
    line-height: 1.4;
    color: var(--sl-input-color);
    border: none;
    background: none;
    box-shadow: none;
    cursor: inherit;
    -webkit-appearance: none;
  }

  .textarea__control::-webkit-search-decoration,
  .textarea__control::-webkit-search-cancel-button,
  .textarea__control::-webkit-search-results-button,
  .textarea__control::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  .textarea__control::placeholder {
    color: var(--sl-input-placeholder-color);
    user-select: none;
  }

  .textarea__control:focus {
    outline: none;
  }

  /*
   * Size modifiers
   */

  .textarea--small {
    border-radius: var(--sl-input-border-radius-small);
    font-size: var(--sl-input-font-size-small);
  }

  .textarea--small .textarea__control {
    padding: 0.5em var(--sl-input-spacing-small);
  }

  .textarea--medium {
    border-radius: var(--sl-input-border-radius-medium);
    font-size: var(--sl-input-font-size-medium);
  }

  .textarea--medium .textarea__control {
    padding: 0.5em var(--sl-input-spacing-medium);
  }

  .textarea--large {
    border-radius: var(--sl-input-border-radius-large);
    font-size: var(--sl-input-font-size-large);
  }

  .textarea--large .textarea__control {
    padding: 0.5em var(--sl-input-spacing-large);
  }

  /*
   * Resize types
   */

  .textarea--resize-none .textarea__control {
    resize: none;
  }

  .textarea--resize-vertical .textarea__control {
    resize: vertical;
  }

  .textarea--resize-auto .textarea__control {
    height: auto;
    resize: none;
    overflow-y: hidden;
  }
`, d0 = (e) => e.strings === void 0, C0 = {}, B0 = (e, t = C0) => e._$AH = t, nh = hc(class extends Ic {
  constructor(e) {
    if (super(e), e.type !== Me.PROPERTY && e.type !== Me.ATTRIBUTE && e.type !== Me.BOOLEAN_ATTRIBUTE)
      throw Error("The `live` directive is not allowed on child or event bindings");
    if (!d0(e))
      throw Error("`live` bindings can only contain a single expression");
  }
  render(e) {
    return e;
  }
  update(e, [t]) {
    if (t === Yt || t === P)
      return t;
    const A = e.element, i = e.name;
    if (e.type === Me.PROPERTY) {
      if (t === A[i])
        return Yt;
    } else if (e.type === Me.BOOLEAN_ATTRIBUTE) {
      if (!!t === A.hasAttribute(i))
        return Yt;
    } else if (e.type === Me.ATTRIBUTE && A.getAttribute(i) === t + "")
      return Yt;
    return B0(e), t;
  }
});
/*! Bundled license information:

lit-html/directive-helpers.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directives/live.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
var ah = (e = "value") => (t, A) => {
  const i = t.constructor, s = i.prototype.attributeChangedCallback;
  i.prototype.attributeChangedCallback = function(o, r, n) {
    var l;
    const a = i.getPropertyOptions(e), c = typeof a.attribute == "string" ? a.attribute : e;
    if (o === c) {
      const g = a.converter || pi, u = (typeof g == "function" ? g : (l = g?.fromAttribute) != null ? l : pi.fromAttribute)(n, a.type);
      this[e] !== u && (this[A] = u);
    }
    s.call(this, o, r, n);
  };
}, x = class extends K {
  constructor() {
    super(...arguments), this.formControlController = new wn(this, {
      assumeInteractionOn: ["sl-blur", "sl-input"]
    }), this.hasSlotController = new GA(this, "help-text", "label"), this.hasFocus = !1, this.title = "", this.name = "", this.value = "", this.size = "medium", this.filled = !1, this.label = "", this.helpText = "", this.placeholder = "", this.rows = 4, this.resize = "vertical", this.disabled = !1, this.readonly = !1, this.form = "", this.required = !1, this.spellcheck = !0, this.defaultValue = "";
  }
  /** Gets the validity state object */
  get validity() {
    return this.input.validity;
  }
  /** Gets the validation message */
  get validationMessage() {
    return this.input.validationMessage;
  }
  connectedCallback() {
    super.connectedCallback(), this.resizeObserver = new ResizeObserver(() => this.setTextareaHeight()), this.updateComplete.then(() => {
      this.setTextareaHeight(), this.resizeObserver.observe(this.input);
    });
  }
  firstUpdated() {
    this.formControlController.updateValidity();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this.resizeObserver.unobserve(this.input);
  }
  handleBlur() {
    this.hasFocus = !1, this.emit("sl-blur");
  }
  handleChange() {
    this.value = this.input.value, this.setTextareaHeight(), this.emit("sl-change");
  }
  handleFocus() {
    this.hasFocus = !0, this.emit("sl-focus");
  }
  handleInput() {
    this.value = this.input.value, this.emit("sl-input");
  }
  handleInvalid(e) {
    this.formControlController.setValidity(!1), this.formControlController.emitInvalidEvent(e);
  }
  setTextareaHeight() {
    this.resize === "auto" ? (this.input.style.height = "auto", this.input.style.height = `${this.input.scrollHeight}px`) : this.input.style.height = void 0;
  }
  handleDisabledChange() {
    this.formControlController.setValidity(this.disabled);
  }
  handleRowsChange() {
    this.setTextareaHeight();
  }
  async handleValueChange() {
    await this.updateComplete, this.formControlController.updateValidity(), this.setTextareaHeight();
  }
  /** Sets focus on the textarea. */
  focus(e) {
    this.input.focus(e);
  }
  /** Removes focus from the textarea. */
  blur() {
    this.input.blur();
  }
  /** Selects all the text in the textarea. */
  select() {
    this.input.select();
  }
  /** Gets or sets the textarea's scroll position. */
  scrollPosition(e) {
    if (e) {
      typeof e.top == "number" && (this.input.scrollTop = e.top), typeof e.left == "number" && (this.input.scrollLeft = e.left);
      return;
    }
    return {
      top: this.input.scrollTop,
      left: this.input.scrollTop
    };
  }
  /** Sets the start and end positions of the text selection (0-based). */
  setSelectionRange(e, t, A = "none") {
    this.input.setSelectionRange(e, t, A);
  }
  /** Replaces a range of text with a new string. */
  setRangeText(e, t, A, i) {
    this.input.setRangeText(e, t, A, i), this.value !== this.input.value && (this.value = this.input.value), this.value !== this.input.value && (this.value = this.input.value, this.setTextareaHeight());
  }
  /** Checks for validity but does not show a validation message. Returns `true` when valid and `false` when invalid. */
  checkValidity() {
    return this.input.checkValidity();
  }
  /** Gets the associated form, if one exists. */
  getForm() {
    return this.formControlController.getForm();
  }
  /** Checks for validity and shows the browser's validation message if the control is invalid. */
  reportValidity() {
    return this.input.reportValidity();
  }
  /** Sets a custom validation message. Pass an empty string to restore validity. */
  setCustomValidity(e) {
    this.input.setCustomValidity(e), this.formControlController.updateValidity();
  }
  render() {
    const e = this.hasSlotController.test("label"), t = this.hasSlotController.test("help-text"), A = this.label ? !0 : !!e, i = this.helpText ? !0 : !!t;
    return _`
      <div
        part="form-control"
        class=${Qt({
      "form-control": !0,
      "form-control--small": this.size === "small",
      "form-control--medium": this.size === "medium",
      "form-control--large": this.size === "large",
      "form-control--has-label": A,
      "form-control--has-help-text": i
    })}
      >
        <label
          part="form-control-label"
          class="form-control__label"
          for="input"
          aria-hidden=${A ? "false" : "true"}
        >
          <slot name="label">${this.label}</slot>
        </label>

        <div part="form-control-input" class="form-control-input">
          <div
            part="base"
            class=${Qt({
      textarea: !0,
      "textarea--small": this.size === "small",
      "textarea--medium": this.size === "medium",
      "textarea--large": this.size === "large",
      "textarea--standard": !this.filled,
      "textarea--filled": this.filled,
      "textarea--disabled": this.disabled,
      "textarea--focused": this.hasFocus,
      "textarea--empty": !this.value,
      "textarea--resize-none": this.resize === "none",
      "textarea--resize-vertical": this.resize === "vertical",
      "textarea--resize-auto": this.resize === "auto"
    })}
          >
            <textarea
              part="textarea"
              id="input"
              class="textarea__control"
              title=${this.title}
              name=${m(this.name)}
              .value=${nh(this.value)}
              ?disabled=${this.disabled}
              ?readonly=${this.readonly}
              ?required=${this.required}
              placeholder=${m(this.placeholder)}
              rows=${m(this.rows)}
              minlength=${m(this.minlength)}
              maxlength=${m(this.maxlength)}
              autocapitalize=${m(this.autocapitalize)}
              autocorrect=${m(this.autocorrect)}
              ?autofocus=${this.autofocus}
              spellcheck=${m(this.spellcheck)}
              enterkeyhint=${m(this.enterkeyhint)}
              inputmode=${m(this.inputmode)}
              aria-describedby="help-text"
              @change=${this.handleChange}
              @input=${this.handleInput}
              @invalid=${this.handleInvalid}
              @focus=${this.handleFocus}
              @blur=${this.handleBlur}
            ></textarea>
          </div>
        </div>

        <slot
          name="help-text"
          part="form-control-help-text"
          id="help-text"
          class="form-control__help-text"
          aria-hidden=${i ? "false" : "true"}
        >
          ${this.helpText}
        </slot>
      </div>
    `;
  }
};
x.styles = u0;
I([
  X(".textarea__control")
], x.prototype, "input", 2);
I([
  FA()
], x.prototype, "hasFocus", 2);
I([
  d()
], x.prototype, "title", 2);
I([
  d()
], x.prototype, "name", 2);
I([
  d()
], x.prototype, "value", 2);
I([
  d({ reflect: !0 })
], x.prototype, "size", 2);
I([
  d({ type: Boolean, reflect: !0 })
], x.prototype, "filled", 2);
I([
  d()
], x.prototype, "label", 2);
I([
  d({ attribute: "help-text" })
], x.prototype, "helpText", 2);
I([
  d()
], x.prototype, "placeholder", 2);
I([
  d({ type: Number })
], x.prototype, "rows", 2);
I([
  d()
], x.prototype, "resize", 2);
I([
  d({ type: Boolean, reflect: !0 })
], x.prototype, "disabled", 2);
I([
  d({ type: Boolean, reflect: !0 })
], x.prototype, "readonly", 2);
I([
  d({ reflect: !0 })
], x.prototype, "form", 2);
I([
  d({ type: Boolean, reflect: !0 })
], x.prototype, "required", 2);
I([
  d({ type: Number })
], x.prototype, "minlength", 2);
I([
  d({ type: Number })
], x.prototype, "maxlength", 2);
I([
  d()
], x.prototype, "autocapitalize", 2);
I([
  d()
], x.prototype, "autocorrect", 2);
I([
  d()
], x.prototype, "autocomplete", 2);
I([
  d({ type: Boolean })
], x.prototype, "autofocus", 2);
I([
  d()
], x.prototype, "enterkeyhint", 2);
I([
  d({
    type: Boolean,
    converter: {
      // Allow "true|false" attribute values but keep the property boolean
      fromAttribute: (e) => !(!e || e === "false"),
      toAttribute: (e) => e ? "true" : "false"
    }
  })
], x.prototype, "spellcheck", 2);
I([
  d()
], x.prototype, "inputmode", 2);
I([
  ah()
], x.prototype, "defaultValue", 2);
I([
  z("disabled", { waitUntilFirstUpdate: !0 })
], x.prototype, "handleDisabledChange", 1);
I([
  z("rows", { waitUntilFirstUpdate: !0 })
], x.prototype, "handleRowsChange", 1);
I([
  z("value", { waitUntilFirstUpdate: !0 })
], x.prototype, "handleValueChange", 1);
x = I([
  st("sl-textarea")
], x);
var Q0 = V`
  ${it}
  ${rh}

  :host {
    display: block;
  }

  .input {
    flex: 1 1 auto;
    display: inline-flex;
    align-items: stretch;
    justify-content: start;
    position: relative;
    width: 100%;
    font-family: var(--sl-input-font-family);
    font-weight: var(--sl-input-font-weight);
    letter-spacing: var(--sl-input-letter-spacing);
    vertical-align: middle;
    overflow: hidden;
    cursor: text;
    transition: var(--sl-transition-fast) color, var(--sl-transition-fast) border, var(--sl-transition-fast) box-shadow,
      var(--sl-transition-fast) background-color;
  }

  /* Standard inputs */
  .input--standard {
    background-color: var(--sl-input-background-color);
    border: solid var(--sl-input-border-width) var(--sl-input-border-color);
  }

  .input--standard:hover:not(.input--disabled) {
    background-color: var(--sl-input-background-color-hover);
    border-color: var(--sl-input-border-color-hover);
  }

  .input--standard.input--focused:not(.input--disabled) {
    background-color: var(--sl-input-background-color-focus);
    border-color: var(--sl-input-border-color-focus);
    box-shadow: 0 0 0 var(--sl-focus-ring-width) var(--sl-input-focus-ring-color);
  }

  .input--standard.input--focused:not(.input--disabled) .input__control {
    color: var(--sl-input-color-focus);
  }

  .input--standard.input--disabled {
    background-color: var(--sl-input-background-color-disabled);
    border-color: var(--sl-input-border-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .input--standard.input--disabled .input__control {
    color: var(--sl-input-color-disabled);
  }

  .input--standard.input--disabled .input__control::placeholder {
    color: var(--sl-input-placeholder-color-disabled);
  }

  /* Filled inputs */
  .input--filled {
    border: none;
    background-color: var(--sl-input-filled-background-color);
    color: var(--sl-input-color);
  }

  .input--filled:hover:not(.input--disabled) {
    background-color: var(--sl-input-filled-background-color-hover);
  }

  .input--filled.input--focused:not(.input--disabled) {
    background-color: var(--sl-input-filled-background-color-focus);
    outline: var(--sl-focus-ring);
    outline-offset: var(--sl-focus-ring-offset);
  }

  .input--filled.input--disabled {
    background-color: var(--sl-input-filled-background-color-disabled);
    opacity: 0.5;
    cursor: not-allowed;
  }

  .input__control {
    flex: 1 1 auto;
    font-family: inherit;
    font-size: inherit;
    font-weight: inherit;
    min-width: 0;
    height: 100%;
    color: var(--sl-input-color);
    border: none;
    background: none;
    box-shadow: none;
    padding: 0;
    margin: 0;
    cursor: inherit;
    -webkit-appearance: none;
  }

  .input__control::-webkit-search-decoration,
  .input__control::-webkit-search-cancel-button,
  .input__control::-webkit-search-results-button,
  .input__control::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  .input__control:-webkit-autofill,
  .input__control:-webkit-autofill:hover,
  .input__control:-webkit-autofill:focus,
  .input__control:-webkit-autofill:active {
    box-shadow: 0 0 0 var(--sl-input-height-large) var(--sl-input-background-color-hover) inset !important;
    -webkit-text-fill-color: var(--sl-color-primary-500);
    caret-color: var(--sl-input-color);
  }

  .input--filled .input__control:-webkit-autofill,
  .input--filled .input__control:-webkit-autofill:hover,
  .input--filled .input__control:-webkit-autofill:focus,
  .input--filled .input__control:-webkit-autofill:active {
    box-shadow: 0 0 0 var(--sl-input-height-large) var(--sl-input-filled-background-color) inset !important;
  }

  .input__control::placeholder {
    color: var(--sl-input-placeholder-color);
    user-select: none;
  }

  .input:hover:not(.input--disabled) .input__control {
    color: var(--sl-input-color-hover);
  }

  .input__control:focus {
    outline: none;
  }

  .input__prefix,
  .input__suffix {
    display: inline-flex;
    flex: 0 0 auto;
    align-items: center;
    cursor: default;
  }

  .input__prefix::slotted(sl-icon),
  .input__suffix::slotted(sl-icon) {
    color: var(--sl-input-icon-color);
  }

  /*
   * Size modifiers
   */

  .input--small {
    border-radius: var(--sl-input-border-radius-small);
    font-size: var(--sl-input-font-size-small);
    height: var(--sl-input-height-small);
  }

  .input--small .input__control {
    height: calc(var(--sl-input-height-small) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-small);
  }

  .input--small .input__clear,
  .input--small .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-small) * 2);
  }

  .input--small .input__prefix::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-small);
  }

  .input--small .input__suffix::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-small);
  }

  .input--medium {
    border-radius: var(--sl-input-border-radius-medium);
    font-size: var(--sl-input-font-size-medium);
    height: var(--sl-input-height-medium);
  }

  .input--medium .input__control {
    height: calc(var(--sl-input-height-medium) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-medium);
  }

  .input--medium .input__clear,
  .input--medium .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-medium) * 2);
  }

  .input--medium .input__prefix::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-medium);
  }

  .input--medium .input__suffix::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-medium);
  }

  .input--large {
    border-radius: var(--sl-input-border-radius-large);
    font-size: var(--sl-input-font-size-large);
    height: var(--sl-input-height-large);
  }

  .input--large .input__control {
    height: calc(var(--sl-input-height-large) - var(--sl-input-border-width) * 2);
    padding: 0 var(--sl-input-spacing-large);
  }

  .input--large .input__clear,
  .input--large .input__password-toggle {
    width: calc(1em + var(--sl-input-spacing-large) * 2);
  }

  .input--large .input__prefix::slotted(*) {
    margin-inline-start: var(--sl-input-spacing-large);
  }

  .input--large .input__suffix::slotted(*) {
    margin-inline-end: var(--sl-input-spacing-large);
  }

  /*
   * Pill modifier
   */

  .input--pill.input--small {
    border-radius: var(--sl-input-height-small);
  }

  .input--pill.input--medium {
    border-radius: var(--sl-input-height-medium);
  }

  .input--pill.input--large {
    border-radius: var(--sl-input-height-large);
  }

  /*
   * Clearable + Password Toggle
   */

  .input__clear,
  .input__password-toggle {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: inherit;
    color: var(--sl-input-icon-color);
    border: none;
    background: none;
    padding: 0;
    transition: var(--sl-transition-fast) color;
    cursor: pointer;
  }

  .input__clear:hover,
  .input__password-toggle:hover {
    color: var(--sl-input-icon-color-hover);
  }

  .input__clear:focus,
  .input__password-toggle:focus {
    outline: none;
  }

  .input--empty .input__clear {
    visibility: hidden;
  }

  /* Don't show the browser's password toggle in Edge */
  ::-ms-reveal {
    display: none;
  }

  /* Hide the built-in number spinner */
  .input--no-spin-buttons input[type='number']::-webkit-outer-spin-button,
  .input--no-spin-buttons input[type='number']::-webkit-inner-spin-button {
    -webkit-appearance: none;
    display: none;
  }

  .input--no-spin-buttons input[type='number'] {
    -moz-appearance: textfield;
  }
`, b = class extends K {
  constructor() {
    super(...arguments), this.formControlController = new wn(this, {
      assumeInteractionOn: ["sl-blur", "sl-input"]
    }), this.hasSlotController = new GA(this, "help-text", "label"), this.localize = new be(this), this.hasFocus = !1, this.title = "", this.type = "text", this.name = "", this.value = "", this.defaultValue = "", this.size = "medium", this.filled = !1, this.pill = !1, this.label = "", this.helpText = "", this.clearable = !1, this.disabled = !1, this.placeholder = "", this.readonly = !1, this.passwordToggle = !1, this.passwordVisible = !1, this.noSpinButtons = !1, this.form = "", this.required = !1, this.spellcheck = !0;
  }
  //
  // NOTE: We use an in-memory input for these getters/setters instead of the one in the template because the properties
  // can be set before the component is rendered.
  //
  /** Gets or sets the current value as a `Date` object. Returns `null` if the value can't be converted. */
  get valueAsDate() {
    const e = document.createElement("input");
    return e.type = "date", e.value = this.value, e.valueAsDate;
  }
  set valueAsDate(e) {
    const t = document.createElement("input");
    t.type = "date", t.valueAsDate = e, this.value = t.value;
  }
  /** Gets or sets the current value as a number. Returns `NaN` if the value can't be converted. */
  get valueAsNumber() {
    const e = document.createElement("input");
    return e.type = "number", e.value = this.value, e.valueAsNumber;
  }
  set valueAsNumber(e) {
    const t = document.createElement("input");
    t.type = "number", t.valueAsNumber = e, this.value = t.value;
  }
  /** Gets the validity state object */
  get validity() {
    return this.input.validity;
  }
  /** Gets the validation message */
  get validationMessage() {
    return this.input.validationMessage;
  }
  firstUpdated() {
    this.formControlController.updateValidity();
  }
  handleBlur() {
    this.hasFocus = !1, this.emit("sl-blur");
  }
  handleChange() {
    this.value = this.input.value, this.emit("sl-change");
  }
  handleClearClick(e) {
    this.value = "", this.emit("sl-clear"), this.emit("sl-input"), this.emit("sl-change"), this.input.focus(), e.stopPropagation();
  }
  handleFocus() {
    this.hasFocus = !0, this.emit("sl-focus");
  }
  handleInput() {
    this.value = this.input.value, this.formControlController.updateValidity(), this.emit("sl-input");
  }
  handleInvalid(e) {
    this.formControlController.setValidity(!1), this.formControlController.emitInvalidEvent(e);
  }
  handleKeyDown(e) {
    const t = e.metaKey || e.ctrlKey || e.shiftKey || e.altKey;
    e.key === "Enter" && !t && setTimeout(() => {
      !e.defaultPrevented && !e.isComposing && this.formControlController.submit();
    });
  }
  handlePasswordToggle() {
    this.passwordVisible = !this.passwordVisible;
  }
  handleDisabledChange() {
    this.formControlController.setValidity(this.disabled);
  }
  handleStepChange() {
    this.input.step = String(this.step), this.formControlController.updateValidity();
  }
  async handleValueChange() {
    await this.updateComplete, this.formControlController.updateValidity();
  }
  /** Sets focus on the input. */
  focus(e) {
    this.input.focus(e);
  }
  /** Removes focus from the input. */
  blur() {
    this.input.blur();
  }
  /** Selects all the text in the input. */
  select() {
    this.input.select();
  }
  /** Sets the start and end positions of the text selection (0-based). */
  setSelectionRange(e, t, A = "none") {
    this.input.setSelectionRange(e, t, A);
  }
  /** Replaces a range of text with a new string. */
  setRangeText(e, t, A, i) {
    this.input.setRangeText(e, t, A, i), this.value !== this.input.value && (this.value = this.input.value);
  }
  /** Displays the browser picker for an input element (only works if the browser supports it for the input type). */
  showPicker() {
    "showPicker" in HTMLInputElement.prototype && this.input.showPicker();
  }
  /** Increments the value of a numeric input type by the value of the step attribute. */
  stepUp() {
    this.input.stepUp(), this.value !== this.input.value && (this.value = this.input.value);
  }
  /** Decrements the value of a numeric input type by the value of the step attribute. */
  stepDown() {
    this.input.stepDown(), this.value !== this.input.value && (this.value = this.input.value);
  }
  /** Checks for validity but does not show a validation message. Returns `true` when valid and `false` when invalid. */
  checkValidity() {
    return this.input.checkValidity();
  }
  /** Gets the associated form, if one exists. */
  getForm() {
    return this.formControlController.getForm();
  }
  /** Checks for validity and shows the browser's validation message if the control is invalid. */
  reportValidity() {
    return this.input.reportValidity();
  }
  /** Sets a custom validation message. Pass an empty string to restore validity. */
  setCustomValidity(e) {
    this.input.setCustomValidity(e), this.formControlController.updateValidity();
  }
  render() {
    const e = this.hasSlotController.test("label"), t = this.hasSlotController.test("help-text"), A = this.label ? !0 : !!e, i = this.helpText ? !0 : !!t, s = this.clearable && !this.disabled && !this.readonly && (typeof this.value == "number" || this.value.length > 0);
    return _`
      <div
        part="form-control"
        class=${Qt({
      "form-control": !0,
      "form-control--small": this.size === "small",
      "form-control--medium": this.size === "medium",
      "form-control--large": this.size === "large",
      "form-control--has-label": A,
      "form-control--has-help-text": i
    })}
      >
        <label
          part="form-control-label"
          class="form-control__label"
          for="input"
          aria-hidden=${A ? "false" : "true"}
        >
          <slot name="label">${this.label}</slot>
        </label>

        <div part="form-control-input" class="form-control-input">
          <div
            part="base"
            class=${Qt({
      input: !0,
      // Sizes
      "input--small": this.size === "small",
      "input--medium": this.size === "medium",
      "input--large": this.size === "large",
      // States
      "input--pill": this.pill,
      "input--standard": !this.filled,
      "input--filled": this.filled,
      "input--disabled": this.disabled,
      "input--focused": this.hasFocus,
      "input--empty": !this.value,
      "input--no-spin-buttons": this.noSpinButtons
    })}
          >
            <slot name="prefix" part="prefix" class="input__prefix"></slot>
            <input
              part="input"
              id="input"
              class="input__control"
              type=${this.type === "password" && this.passwordVisible ? "text" : this.type}
              title=${this.title}
              name=${m(this.name)}
              ?disabled=${this.disabled}
              ?readonly=${this.readonly}
              ?required=${this.required}
              placeholder=${m(this.placeholder)}
              minlength=${m(this.minlength)}
              maxlength=${m(this.maxlength)}
              min=${m(this.min)}
              max=${m(this.max)}
              step=${m(this.step)}
              .value=${nh(this.value)}
              autocapitalize=${m(this.autocapitalize)}
              autocomplete=${m(this.autocomplete)}
              autocorrect=${m(this.autocorrect)}
              ?autofocus=${this.autofocus}
              spellcheck=${this.spellcheck}
              pattern=${m(this.pattern)}
              enterkeyhint=${m(this.enterkeyhint)}
              inputmode=${m(this.inputmode)}
              aria-describedby="help-text"
              @change=${this.handleChange}
              @input=${this.handleInput}
              @invalid=${this.handleInvalid}
              @keydown=${this.handleKeyDown}
              @focus=${this.handleFocus}
              @blur=${this.handleBlur}
            />

            ${s ? _`
                    <button
                      part="clear-button"
                      class="input__clear"
                      type="button"
                      aria-label=${this.localize.term("clearEntry")}
                      @click=${this.handleClearClick}
                      tabindex="-1"
                    >
                      <slot name="clear-icon">
                        <sl-icon name="x-circle-fill" library="system"></sl-icon>
                      </slot>
                    </button>
                  ` : ""}
            ${this.passwordToggle && !this.disabled ? _`
                    <button
                      part="password-toggle-button"
                      class="input__password-toggle"
                      type="button"
                      aria-label=${this.localize.term(this.passwordVisible ? "hidePassword" : "showPassword")}
                      @click=${this.handlePasswordToggle}
                      tabindex="-1"
                    >
                      ${this.passwordVisible ? _`
                            <slot name="show-password-icon">
                              <sl-icon name="eye-slash" library="system"></sl-icon>
                            </slot>
                          ` : _`
                            <slot name="hide-password-icon">
                              <sl-icon name="eye" library="system"></sl-icon>
                            </slot>
                          `}
                    </button>
                  ` : ""}

            <slot name="suffix" part="suffix" class="input__suffix"></slot>
          </div>
        </div>

        <slot
          name="help-text"
          part="form-control-help-text"
          id="help-text"
          class="form-control__help-text"
          aria-hidden=${i ? "false" : "true"}
        >
          ${this.helpText}
        </slot>
        </div>
      </div>
    `;
  }
};
b.styles = Q0;
I([
  X(".input__control")
], b.prototype, "input", 2);
I([
  FA()
], b.prototype, "hasFocus", 2);
I([
  d()
], b.prototype, "title", 2);
I([
  d({ reflect: !0 })
], b.prototype, "type", 2);
I([
  d()
], b.prototype, "name", 2);
I([
  d()
], b.prototype, "value", 2);
I([
  ah()
], b.prototype, "defaultValue", 2);
I([
  d({ reflect: !0 })
], b.prototype, "size", 2);
I([
  d({ type: Boolean, reflect: !0 })
], b.prototype, "filled", 2);
I([
  d({ type: Boolean, reflect: !0 })
], b.prototype, "pill", 2);
I([
  d()
], b.prototype, "label", 2);
I([
  d({ attribute: "help-text" })
], b.prototype, "helpText", 2);
I([
  d({ type: Boolean })
], b.prototype, "clearable", 2);
I([
  d({ type: Boolean, reflect: !0 })
], b.prototype, "disabled", 2);
I([
  d()
], b.prototype, "placeholder", 2);
I([
  d({ type: Boolean, reflect: !0 })
], b.prototype, "readonly", 2);
I([
  d({ attribute: "password-toggle", type: Boolean })
], b.prototype, "passwordToggle", 2);
I([
  d({ attribute: "password-visible", type: Boolean })
], b.prototype, "passwordVisible", 2);
I([
  d({ attribute: "no-spin-buttons", type: Boolean })
], b.prototype, "noSpinButtons", 2);
I([
  d({ reflect: !0 })
], b.prototype, "form", 2);
I([
  d({ type: Boolean, reflect: !0 })
], b.prototype, "required", 2);
I([
  d()
], b.prototype, "pattern", 2);
I([
  d({ type: Number })
], b.prototype, "minlength", 2);
I([
  d({ type: Number })
], b.prototype, "maxlength", 2);
I([
  d()
], b.prototype, "min", 2);
I([
  d()
], b.prototype, "max", 2);
I([
  d()
], b.prototype, "step", 2);
I([
  d()
], b.prototype, "autocapitalize", 2);
I([
  d()
], b.prototype, "autocorrect", 2);
I([
  d()
], b.prototype, "autocomplete", 2);
I([
  d({ type: Boolean })
], b.prototype, "autofocus", 2);
I([
  d()
], b.prototype, "enterkeyhint", 2);
I([
  d({
    type: Boolean,
    converter: {
      // Allow "true|false" attribute values but keep the property boolean
      fromAttribute: (e) => !(!e || e === "false"),
      toAttribute: (e) => e ? "true" : "false"
    }
  })
], b.prototype, "spellcheck", 2);
I([
  d()
], b.prototype, "inputmode", 2);
I([
  z("disabled", { waitUntilFirstUpdate: !0 })
], b.prototype, "handleDisabledChange", 1);
I([
  z("step", { waitUntilFirstUpdate: !0 })
], b.prototype, "handleStepChange", 1);
I([
  z("value", { waitUntilFirstUpdate: !0 })
], b.prototype, "handleValueChange", 1);
b = I([
  st("sl-input")
], b);
const TA = "hc_zome_posts/store";
var E0 = Object.defineProperty, f0 = Object.getOwnPropertyDescriptor, Ti = (e, t, A, i) => {
  for (var s = i > 1 ? void 0 : i ? f0(t, A) : t, o = e.length - 1, r; o >= 0; o--)
    (r = e[o]) && (s = (i ? r(t, A, s) : r(s)) || s);
  return i && s && E0(t, A, s), s;
};
let qe = class extends q {
  constructor() {
    super(...arguments), this.committing = !1;
  }
  firstUpdated() {
    this.shadowRoot?.querySelector("form").reset();
  }
  async updatePost(e) {
    const t = {
      title: e.title,
      content: e.content
    };
    try {
      this.committing = !0;
      const A = await this.postsStore.client.updatePost(
        this.originalPostHash,
        this.currentRecord.actionHash,
        t
      );
      this.dispatchEvent(new CustomEvent("post-updated", {
        composed: !0,
        bubbles: !0,
        detail: {
          originalPostHash: this.originalPostHash,
          previousPostHash: this.currentRecord.actionHash,
          updatedPostHash: A.actionHash
        }
      }));
    } catch (A) {
      console.error(A), Ji(k("Error updating the post"));
    }
    this.committing = !1;
  }
  render() {
    return w`
      <sl-card>
        <span slot="header">${k("Edit Post")}</span>

        <form 
          style="display: flex; flex: 1; flex-direction: column;"
          ${jg((e) => this.updatePost(e))}
        >  
          <div style="margin-bottom: 16px">
        <sl-input name="title" .label=${k("Title")}  required .defaultValue=${this.currentRecord.entry.title}></sl-input>          </div>

          <div style="margin-bottom: 16px">
        <sl-textarea name="content" .label=${k("Content")}  required .defaultValue=${this.currentRecord.entry.content}></sl-textarea>          </div>



          <div style="display: flex; flex-direction: row">
            <sl-button
              @click=${() => this.dispatchEvent(new CustomEvent("edit-canceled", {
      bubbles: !0,
      composed: !0
    }))}
              style="flex: 1;"
            >${k("Cancel")}</sl-button>
            <sl-button
              type="submit"
              variant="primary"
              style="flex: 1;"
              .loading=${this.committing}
            >${k("Save")}</sl-button>

          </div>
        </form>
      </sl-card>`;
  }
};
qe.styles = [Ut];
Ti([
  W(NA("original-post-hash"))
], qe.prototype, "originalPostHash", 2);
Ti([
  W()
], qe.prototype, "currentRecord", 2);
Ti([
  Tt({ context: TA })
], qe.prototype, "postsStore", 2);
Ti([
  Mi()
], qe.prototype, "committing", 2);
qe = Ti([
  Xt(),
  It("edit-post")
], qe);
var p0 = Object.defineProperty, w0 = Object.getOwnPropertyDescriptor, fo = (e, t, A, i) => {
  for (var s = i > 1 ? void 0 : i ? w0(t, A) : t, o = e.length - 1, r; o >= 0; o--)
    (r = e[o]) && (s = (i ? r(t, A, s) : r(s)) || s);
  return i && s && p0(t, A, s), s;
};
let DA = class extends q {
  constructor() {
    super(...arguments), this._post = new Ke(
      this,
      () => this.postsStore.posts.get(this.postHash)
    ), this._editing = !1;
  }
  async deletePost() {
    try {
      await this.postsStore.client.deletePost(this.postHash), this.dispatchEvent(
        new CustomEvent("post-deleted", {
          bubbles: !0,
          composed: !0,
          detail: {
            postHash: this.postHash
          }
        })
      );
    } catch (e) {
      console.error(e), Ji(k("Error deleting the post"));
    }
  }
  renderDetail(e) {
    return w`
      <sl-card>
        <div slot="header" style="display: flex; flex-direction: row">
          <span style="font-size: 18px; flex: 1;">${k("Post")}</span>

          <sl-icon-button
            style="margin-left: 8px"
            .src=${fe(lB)}
            @click=${() => {
      this._editing = !0;
    }}
          ></sl-icon-button>
          <sl-icon-button
            style="margin-left: 8px"
            .src=${fe(aB)}
            @click=${() => this.deletePost()}
          ></sl-icon-button>
        </div>

        <div style="display: flex; flex-direction: column">
          <div
            style="display: flex; flex-direction: column; margin-bottom: 16px"
          >
            <span style="margin-bottom: 8px"
              ><strong>${k("Title")}:</strong></span
            >
            <span style="white-space: pre-line"
              >${e.entry.title}</span
            >
          </div>

          <div
            style="display: flex; flex-direction: column; margin-bottom: 16px"
          >
            <span style="margin-bottom: 8px"
              ><strong>${k("Content")}:</strong></span
            >
            <span style="white-space: pre-line"
              >${e.entry.content}</span
            >
          </div>
        </div>
      </sl-card>
      <attachments-card></attachments-card>
    `;
  }
  render() {
    switch (this._post.value.status) {
      case "pending":
        return w`<sl-card>
          <div
            style="display: flex; flex: 1; align-items: center; justify-content: center"
          >
            <sl-spinner style="font-size: 2rem;"></sl-spinner>
          </div>
        </sl-card>`;
      case "complete":
        const e = this._post.value.value;
        return e ? this._editing ? w`<edit-post
            .originalPostHash=${this.postHash}
            .currentRecord=${e}
            @post-updated=${async () => {
          this._editing = !1;
        }}
            @edit-canceled=${() => {
          this._editing = !1;
        }}
            style="display: flex; flex: 1;"
          ></edit-post>` : this.renderDetail(e) : w`<span>${k("The requested post doesn't exist")}</span>`;
      case "error":
        return w`<sl-card>
          <display-error
            .headline=${k("Error fetching the post")}
            .error=${this._post.value.error.data.data}
          ></display-error>
        </sl-card>`;
    }
  }
};
DA.styles = [Ut];
fo([
  W(NA("post-hash"))
], DA.prototype, "postHash", 2);
fo([
  Tt({ context: TA, subscribe: !0 })
], DA.prototype, "postsStore", 2);
fo([
  Mi()
], DA.prototype, "_editing", 2);
DA = fo([
  Xt(),
  It("post-detail")
], DA);
var y0 = Object.defineProperty, v0 = Object.getOwnPropertyDescriptor, lh = (e, t, A, i) => {
  for (var s = i > 1 ? void 0 : i ? v0(t, A) : t, o = e.length - 1, r; o >= 0; o--)
    (r = e[o]) && (s = (i ? r(t, A, s) : r(s)) || s);
  return i && s && y0(t, A, s), s;
};
let $s = class extends q {
  render() {
    return w`<slot></slot>`;
  }
};
$s.styles = ae`
    :host {
      display: contents;
    }
  `;
lh([
  to({ context: TA }),
  W({ type: Object })
], $s.prototype, "store", 2);
$s = lh([
  It("posts-context")
], $s);
const m0 = "hc_zome_profiles/store";
let Ps = class extends q {
  render() {
    return w`<slot></slot>`;
  }
};
Ps.styles = ae`
    :host {
      display: contents;
    }
  `;
T([
  to({ context: m0 }),
  W({ type: Object })
], Ps.prototype, "store", void 0);
Ps = T([
  It("profiles-context")
], Ps);
let qs = class extends q {
  render() {
    return w`<slot></slot>`;
  }
};
qs.styles = ae`
    :host {
      display: contents;
    }
  `;
T([
  to({ context: Hi }),
  W({ type: Object })
], qs.prototype, "services", void 0);
qs = T([
  It("we-services-context")
], qs);
var b0 = Object.defineProperty, D0 = Object.getOwnPropertyDescriptor, Jn = (e, t, A, i) => {
  for (var s = i > 1 ? void 0 : i ? D0(t, A) : t, o = e.length - 1, r; o >= 0; o--)
    (r = e[o]) && (s = (i ? r(t, A, s) : r(s)) || s);
  return i && s && b0(t, A, s), s;
};
let Ui = class extends q {
  constructor() {
    super(...arguments), this._post = new Ke(this, () => this.postsStore.posts.get(this.postHash));
  }
  renderSummary(e) {
    return w`
      <div style="display: flex; flex-direction: column">

          <div style="display: flex; flex-direction: column; margin-bottom: 16px">
	    <span style="margin-bottom: 8px"><strong>${k("Title")}:</strong></span>
 	    <span style="white-space: pre-line">${e.entry.title}</span>
	  </div>

          <div style="display: flex; flex-direction: column; margin-bottom: 16px">
	    <span style="margin-bottom: 8px"><strong>${k("Content")}:</strong></span>
 	    <span style="white-space: pre-line">${e.entry.content}</span>
	  </div>

      </div>
    `;
  }
  renderPost() {
    switch (this._post.value.status) {
      case "pending":
        return w`<div
          style="display: flex; flex: 1; align-items: center; justify-content: center"
        >
            <sl-spinner style="font-size: 2rem;"></sl-spinner>
        </div>`;
      case "complete":
        return this._post.value.value ? this.renderSummary(this._post.value.value) : w`<span>${k("The requested post doesn't exist")}</span>`;
      case "error":
        return w`<display-error
          .headline=${k("Error fetching the post")}
          .error=${this._post.value.error.data.data}
        ></display-error>`;
    }
  }
  render() {
    return w`<sl-card style="flex: 1; cursor: grab;" @click=${() => this.dispatchEvent(new CustomEvent("post-selected", {
      composed: !0,
      bubbles: !0,
      detail: {
        postHash: this.postHash
      }
    }))}>
        ${this.renderPost()}
    </sl-card>`;
  }
};
Ui.styles = [Ut];
Jn([
  W(NA("post-hash"))
], Ui.prototype, "postHash", 2);
Jn([
  Tt({ context: TA, subscribe: !0 })
], Ui.prototype, "postsStore", 2);
Ui = Jn([
  Xt(),
  It("post-summary")
], Ui);
var k0 = Object.defineProperty, S0 = Object.getOwnPropertyDescriptor, gh = (e, t, A, i) => {
  for (var s = i > 1 ? void 0 : i ? S0(t, A) : t, o = e.length - 1, r; o >= 0; o--)
    (r = e[o]) && (s = (i ? r(t, A, s) : r(s)) || s);
  return i && s && k0(t, A, s), s;
};
let Vs = class extends q {
  constructor() {
    super(...arguments), this._allPosts = new Ke(this, () => this.postsStore.allPosts);
  }
  renderList(e) {
    return e.length === 0 ? w` <div class="column center-content">
        <sl-icon
          .src=${fe(Wg)}
          style="color: grey; height: 64px; width: 64px; margin-bottom: 16px"
        ></sl-icon>
        <span class="placeholder">${k("No posts found")}</span>
      </div>` : w`
      <div style="display: flex; flex-direction: column; flex: 1">
        ${e.map(
      (t) => w`<post-summary
              .postHash=${t}
              style="margin-bottom: 16px;"
            ></post-summary>`
    )}
      </div>
    `;
  }
  render() {
    switch (this._allPosts.value.status) {
      case "pending":
        return w`<div
          style="display: flex; flex: 1; align-items: center; justify-content: center"
        >
          <sl-spinner style="font-size: 2rem;"></sl-spinner>
        </div>`;
      case "complete":
        return this.renderList(this._allPosts.value.value);
      case "error":
        return w`<display-error
          .headline=${k("Error fetching the posts")}
          .error=${this._allPosts.value.error}
        ></display-error>`;
    }
  }
};
Vs.styles = [Ut];
gh([
  Tt({ context: TA, subscribe: !0 })
], Vs.prototype, "postsStore", 2);
Vs = gh([
  Xt(),
  It("all-posts")
], Vs);
var x0 = Object.defineProperty, N0 = Object.getOwnPropertyDescriptor, po = (e, t, A, i) => {
  for (var s = i > 1 ? void 0 : i ? N0(t, A) : t, o = e.length - 1, r; o >= 0; o--)
    (r = e[o]) && (s = (i ? r(t, A, s) : r(s)) || s);
  return i && s && x0(t, A, s), s;
};
let kA = class extends q {
  constructor() {
    super(...arguments), this.committing = !1;
  }
  async createPost(e) {
    if (this.committing)
      return;
    const t = {
      title: e.title,
      content: e.content
    };
    try {
      this.committing = !0;
      const A = await this.postsStore.client.createPost(t);
      this.dispatchEvent(new CustomEvent("post-created", {
        composed: !0,
        bubbles: !0,
        detail: {
          postHash: A.actionHash
        }
      })), this.form.reset();
    } catch (A) {
      console.error(A), Ji(k("Error creating the post"));
    }
    this.committing = !1;
  }
  render() {
    return w`
      <sl-card style="flex: 1;">
        <span slot="header">${k("Create Post")}</span>

        <form 
          id="create-form"
          style="display: flex; flex: 1; flex-direction: column;"
          ${jg((e) => this.createPost(e))}
        >  
          <div style="margin-bottom: 16px;">
          <sl-input name="title" .label=${k("Title")}  required></sl-input>          </div>

          <div style="margin-bottom: 16px;">
          <sl-textarea name="content" .label=${k("Content")}  required></sl-textarea>          </div>


          <sl-button
            variant="primary"
            type="submit"
            .loading=${this.committing}
          >${k("Create Post")}</sl-button>
        </form> 
      </sl-card>`;
  }
};
kA.styles = [Ut];
po([
  Tt({ context: TA, subscribe: !0 })
], kA.prototype, "postsStore", 2);
po([
  Mi()
], kA.prototype, "committing", 2);
po([
  Fh("#create-form")
], kA.prototype, "form", 2);
kA = po([
  Xt(),
  It("create-post")
], kA);
var F0 = Object.defineProperty, R0 = Object.getOwnPropertyDescriptor, U0 = (e, t, A, i) => {
  for (var s = i > 1 ? void 0 : i ? R0(t, A) : t, o = e.length - 1, r; o >= 0; o--)
    (r = e[o]) && (s = (i ? r(t, A, s) : r(s)) || s);
  return i && s && F0(t, A, s), s;
};
let sn = class extends q {
  render() {
    return w`
      <create-post></create-post>
      <all-posts></all-posts>
    `;
  }
};
sn.styles = [
  ae`
      :host {
        display: flex;
        flex: 1;
      }
    `,
  Ut
];
sn = U0([
  Xt(),
  It("applet-main")
], sn);
var G0 = Object.defineProperty, M0 = Object.getOwnPropertyDescriptor, Yn = (e, t, A, i) => {
  for (var s = i > 1 ? void 0 : i ? M0(t, A) : t, o = e.length - 1, r; o >= 0; o--)
    (r = e[o]) && (s = (i ? r(t, A, s) : r(s)) || s);
  return i && s && G0(t, A, s), s;
};
let Gi = class extends q {
  constructor() {
    super(...arguments), this.appletsInfo = new Ke(
      this,
      () => dn(
        async () => vn(
          this.weServices,
          Array.from(this.applets.keys())
        )
      ),
      () => []
    );
  }
  render() {
    return w``;
  }
};
Gi.styles = [
  ae`
      :host {
        display: flex;
        flex: 1;
      }
    `,
  Ut
];
Yn([
  W()
], Gi.prototype, "applets", 2);
Yn([
  Tt({ context: Hi, subscribe: !0 })
], Gi.prototype, "weServices", 2);
Gi = Yn([
  Xt(),
  It("cross-applet-main")
], Gi);
class L0 {
  constructor(t) {
    this.client = t, this.posts = new Vg(
      (A) => Nr(async () => this.client.getPost(A), 4e3)
    ), this.allPosts = Nr(async () => (await this.client.getAllPosts()).map((i) => i.actionHash), 4e3);
  }
}
class on extends qg {
  constructor(t, A, i = "posts") {
    super(t, A, i), this.client = t, this.roleName = A, this.zomeName = i;
  }
  /** Post */
  async createPost(t) {
    const A = await this.callZome("create_post", t);
    return new ji(A);
  }
  async getPost(t) {
    const A = await this.callZome("get_post", t);
    return A ? new ji(A) : void 0;
  }
  deletePost(t) {
    return this.callZome("delete_post", t);
  }
  async updatePost(t, A, i) {
    const s = await this.callZome("update_post", {
      original_post_hash: t,
      previous_post_hash: A,
      updated_post: i
    });
    return new ji(s);
  }
  /** All Posts */
  async getAllPosts() {
    return (await this.callZome("get_all_posts", null)).map((A) => new ji(A));
  }
}
function J0(e) {
  for (var t = e.length, A = 0, i = 0; i < t; ) {
    var s = e.charCodeAt(i++);
    if (s & 4294967168)
      if (!(s & 4294965248))
        A += 2;
      else {
        if (s >= 55296 && s <= 56319 && i < t) {
          var o = e.charCodeAt(i);
          (o & 64512) === 56320 && (++i, s = ((s & 1023) << 10) + (o & 1023) + 65536);
        }
        s & 4294901760 ? A += 4 : A += 3;
      }
    else {
      A++;
      continue;
    }
  }
  return A;
}
function Y0(e, t, A) {
  for (var i = e.length, s = A, o = 0; o < i; ) {
    var r = e.charCodeAt(o++);
    if (r & 4294967168)
      if (!(r & 4294965248))
        t[s++] = r >> 6 & 31 | 192;
      else {
        if (r >= 55296 && r <= 56319 && o < i) {
          var n = e.charCodeAt(o);
          (n & 64512) === 56320 && (++o, r = ((r & 1023) << 10) + (n & 1023) + 65536);
        }
        r & 4294901760 ? (t[s++] = r >> 18 & 7 | 240, t[s++] = r >> 12 & 63 | 128, t[s++] = r >> 6 & 63 | 128) : (t[s++] = r >> 12 & 15 | 224, t[s++] = r >> 6 & 63 | 128);
      }
    else {
      t[s++] = r;
      continue;
    }
    t[s++] = r & 63 | 128;
  }
}
var H0 = new TextEncoder(), _0 = 50;
function T0(e, t, A) {
  H0.encodeInto(e, t.subarray(A));
}
function O0(e, t, A) {
  e.length > _0 ? T0(e, t, A) : Y0(e, t, A);
}
var $0 = 4096;
function ch(e, t, A) {
  for (var i = t, s = i + A, o = [], r = ""; i < s; ) {
    var n = e[i++];
    if (!(n & 128))
      o.push(n);
    else if ((n & 224) === 192) {
      var l = e[i++] & 63;
      o.push((n & 31) << 6 | l);
    } else if ((n & 240) === 224) {
      var l = e[i++] & 63, a = e[i++] & 63;
      o.push((n & 31) << 12 | l << 6 | a);
    } else if ((n & 248) === 240) {
      var l = e[i++] & 63, a = e[i++] & 63, c = e[i++] & 63, g = (n & 7) << 18 | l << 12 | a << 6 | c;
      g > 65535 && (g -= 65536, o.push(g >>> 10 & 1023 | 55296), g = 56320 | g & 1023), o.push(g);
    } else
      o.push(n);
    o.length >= $0 && (r += String.fromCharCode.apply(String, o), o.length = 0);
  }
  return o.length > 0 && (r += String.fromCharCode.apply(String, o)), r;
}
var P0 = new TextDecoder(), q0 = 200;
function V0(e, t, A) {
  var i = e.subarray(t, t + A);
  return P0.decode(i);
}
function z0(e, t, A) {
  return A > q0 ? V0(e, t, A) : ch(e, t, A);
}
var ss = (
  /** @class */
  function() {
    function e(t, A) {
      this.type = t, this.data = A;
    }
    return e;
  }()
), K0 = globalThis && globalThis.__extends || function() {
  var e = function(t, A) {
    return e = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(i, s) {
      i.__proto__ = s;
    } || function(i, s) {
      for (var o in s)
        Object.prototype.hasOwnProperty.call(s, o) && (i[o] = s[o]);
    }, e(t, A);
  };
  return function(t, A) {
    if (typeof A != "function" && A !== null)
      throw new TypeError("Class extends value " + String(A) + " is not a constructor or null");
    e(t, A);
    function i() {
      this.constructor = t;
    }
    t.prototype = A === null ? Object.create(A) : (i.prototype = A.prototype, new i());
  };
}(), qt = (
  /** @class */
  function(e) {
    K0(t, e);
    function t(A) {
      var i = e.call(this, A) || this, s = Object.create(t.prototype);
      return Object.setPrototypeOf(i, s), Object.defineProperty(i, "name", {
        configurable: !0,
        enumerable: !1,
        value: t.name
      }), i;
    }
    return t;
  }(Error)
), ii = 4294967295;
function j0(e, t, A) {
  var i = A / 4294967296, s = A;
  e.setUint32(t, i), e.setUint32(t + 4, s);
}
function hh(e, t, A) {
  var i = Math.floor(A / 4294967296), s = A;
  e.setUint32(t, i), e.setUint32(t + 4, s);
}
function Ih(e, t) {
  var A = e.getInt32(t), i = e.getUint32(t + 4);
  return A * 4294967296 + i;
}
function Z0(e, t) {
  var A = e.getUint32(t), i = e.getUint32(t + 4);
  return A * 4294967296 + i;
}
var W0 = -1, X0 = 4294967296 - 1, tw = 17179869184 - 1;
function ew(e) {
  var t = e.sec, A = e.nsec;
  if (t >= 0 && A >= 0 && t <= tw)
    if (A === 0 && t <= X0) {
      var i = new Uint8Array(4), s = new DataView(i.buffer);
      return s.setUint32(0, t), i;
    } else {
      var o = t / 4294967296, r = t & 4294967295, i = new Uint8Array(8), s = new DataView(i.buffer);
      return s.setUint32(0, A << 2 | o & 3), s.setUint32(4, r), i;
    }
  else {
    var i = new Uint8Array(12), s = new DataView(i.buffer);
    return s.setUint32(0, A), hh(s, 4, t), i;
  }
}
function Aw(e) {
  var t = e.getTime(), A = Math.floor(t / 1e3), i = (t - A * 1e3) * 1e6, s = Math.floor(i / 1e9);
  return {
    sec: A + s,
    nsec: i - s * 1e9
  };
}
function iw(e) {
  if (e instanceof Date) {
    var t = Aw(e);
    return ew(t);
  } else
    return null;
}
function sw(e) {
  var t = new DataView(e.buffer, e.byteOffset, e.byteLength);
  switch (e.byteLength) {
    case 4: {
      var A = t.getUint32(0), i = 0;
      return { sec: A, nsec: i };
    }
    case 8: {
      var s = t.getUint32(0), o = t.getUint32(4), A = (s & 3) * 4294967296 + o, i = s >>> 2;
      return { sec: A, nsec: i };
    }
    case 12: {
      var A = Ih(t, 4), i = t.getUint32(0);
      return { sec: A, nsec: i };
    }
    default:
      throw new qt("Unrecognized data size for timestamp (expected 4, 8, or 12): ".concat(e.length));
  }
}
function ow(e) {
  var t = sw(e);
  return new Date(t.sec * 1e3 + t.nsec / 1e6);
}
var rw = {
  type: W0,
  encode: iw,
  decode: ow
}, uh = (
  /** @class */
  function() {
    function e() {
      this.builtInEncoders = [], this.builtInDecoders = [], this.encoders = [], this.decoders = [], this.register(rw);
    }
    return e.prototype.register = function(t) {
      var A = t.type, i = t.encode, s = t.decode;
      if (A >= 0)
        this.encoders[A] = i, this.decoders[A] = s;
      else {
        var o = 1 + A;
        this.builtInEncoders[o] = i, this.builtInDecoders[o] = s;
      }
    }, e.prototype.tryToEncode = function(t, A) {
      for (var i = 0; i < this.builtInEncoders.length; i++) {
        var s = this.builtInEncoders[i];
        if (s != null) {
          var o = s(t, A);
          if (o != null) {
            var r = -1 - i;
            return new ss(r, o);
          }
        }
      }
      for (var i = 0; i < this.encoders.length; i++) {
        var s = this.encoders[i];
        if (s != null) {
          var o = s(t, A);
          if (o != null) {
            var r = i;
            return new ss(r, o);
          }
        }
      }
      return t instanceof ss ? t : null;
    }, e.prototype.decode = function(t, A, i) {
      var s = A < 0 ? this.builtInDecoders[-1 - A] : this.decoders[A];
      return s ? s(t, A, i) : new ss(A, t);
    }, e.defaultCodec = new e(), e;
  }()
);
function zs(e) {
  return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : e instanceof ArrayBuffer ? new Uint8Array(e) : Uint8Array.from(e);
}
function nw(e) {
  if (e instanceof ArrayBuffer)
    return new DataView(e);
  var t = zs(e);
  return new DataView(t.buffer, t.byteOffset, t.byteLength);
}
var aw = 100, lw = 2048, gw = (
  /** @class */
  function() {
    function e(t) {
      var A, i, s, o, r, n, l, a;
      this.extensionCodec = (A = t?.extensionCodec) !== null && A !== void 0 ? A : uh.defaultCodec, this.context = t?.context, this.useBigInt64 = (i = t?.useBigInt64) !== null && i !== void 0 ? i : !1, this.maxDepth = (s = t?.maxDepth) !== null && s !== void 0 ? s : aw, this.initialBufferSize = (o = t?.initialBufferSize) !== null && o !== void 0 ? o : lw, this.sortKeys = (r = t?.sortKeys) !== null && r !== void 0 ? r : !1, this.forceFloat32 = (n = t?.forceFloat32) !== null && n !== void 0 ? n : !1, this.ignoreUndefined = (l = t?.ignoreUndefined) !== null && l !== void 0 ? l : !1, this.forceIntegerToFloat = (a = t?.forceIntegerToFloat) !== null && a !== void 0 ? a : !1, this.pos = 0, this.view = new DataView(new ArrayBuffer(this.initialBufferSize)), this.bytes = new Uint8Array(this.view.buffer);
    }
    return e.prototype.reinitializeState = function() {
      this.pos = 0;
    }, e.prototype.encodeSharedRef = function(t) {
      return this.reinitializeState(), this.doEncode(t, 1), this.bytes.subarray(0, this.pos);
    }, e.prototype.encode = function(t) {
      return this.reinitializeState(), this.doEncode(t, 1), this.bytes.slice(0, this.pos);
    }, e.prototype.doEncode = function(t, A) {
      if (A > this.maxDepth)
        throw new Error("Too deep objects in depth ".concat(A));
      t == null ? this.encodeNil() : typeof t == "boolean" ? this.encodeBoolean(t) : typeof t == "number" ? this.forceIntegerToFloat ? this.encodeNumberAsFloat(t) : this.encodeNumber(t) : typeof t == "string" ? this.encodeString(t) : this.useBigInt64 && typeof t == "bigint" ? this.encodeBigInt64(t) : this.encodeObject(t, A);
    }, e.prototype.ensureBufferSizeToWrite = function(t) {
      var A = this.pos + t;
      this.view.byteLength < A && this.resizeBuffer(A * 2);
    }, e.prototype.resizeBuffer = function(t) {
      var A = new ArrayBuffer(t), i = new Uint8Array(A), s = new DataView(A);
      i.set(this.bytes), this.view = s, this.bytes = i;
    }, e.prototype.encodeNil = function() {
      this.writeU8(192);
    }, e.prototype.encodeBoolean = function(t) {
      t === !1 ? this.writeU8(194) : this.writeU8(195);
    }, e.prototype.encodeNumber = function(t) {
      !this.forceIntegerToFloat && Number.isSafeInteger(t) ? t >= 0 ? t < 128 ? this.writeU8(t) : t < 256 ? (this.writeU8(204), this.writeU8(t)) : t < 65536 ? (this.writeU8(205), this.writeU16(t)) : t < 4294967296 ? (this.writeU8(206), this.writeU32(t)) : this.useBigInt64 ? this.encodeNumberAsFloat(t) : (this.writeU8(207), this.writeU64(t)) : t >= -32 ? this.writeU8(224 | t + 32) : t >= -128 ? (this.writeU8(208), this.writeI8(t)) : t >= -32768 ? (this.writeU8(209), this.writeI16(t)) : t >= -2147483648 ? (this.writeU8(210), this.writeI32(t)) : this.useBigInt64 ? this.encodeNumberAsFloat(t) : (this.writeU8(211), this.writeI64(t)) : this.encodeNumberAsFloat(t);
    }, e.prototype.encodeNumberAsFloat = function(t) {
      this.forceFloat32 ? (this.writeU8(202), this.writeF32(t)) : (this.writeU8(203), this.writeF64(t));
    }, e.prototype.encodeBigInt64 = function(t) {
      t >= BigInt(0) ? (this.writeU8(207), this.writeBigUint64(t)) : (this.writeU8(211), this.writeBigInt64(t));
    }, e.prototype.writeStringHeader = function(t) {
      if (t < 32)
        this.writeU8(160 + t);
      else if (t < 256)
        this.writeU8(217), this.writeU8(t);
      else if (t < 65536)
        this.writeU8(218), this.writeU16(t);
      else if (t < 4294967296)
        this.writeU8(219), this.writeU32(t);
      else
        throw new Error("Too long string: ".concat(t, " bytes in UTF-8"));
    }, e.prototype.encodeString = function(t) {
      var A = 5, i = J0(t);
      this.ensureBufferSizeToWrite(A + i), this.writeStringHeader(i), O0(t, this.bytes, this.pos), this.pos += i;
    }, e.prototype.encodeObject = function(t, A) {
      var i = this.extensionCodec.tryToEncode(t, this.context);
      if (i != null)
        this.encodeExtension(i);
      else if (Array.isArray(t))
        this.encodeArray(t, A);
      else if (ArrayBuffer.isView(t))
        this.encodeBinary(t);
      else if (typeof t == "object")
        this.encodeMap(t, A);
      else
        throw new Error("Unrecognized object: ".concat(Object.prototype.toString.apply(t)));
    }, e.prototype.encodeBinary = function(t) {
      var A = t.byteLength;
      if (A < 256)
        this.writeU8(196), this.writeU8(A);
      else if (A < 65536)
        this.writeU8(197), this.writeU16(A);
      else if (A < 4294967296)
        this.writeU8(198), this.writeU32(A);
      else
        throw new Error("Too large binary: ".concat(A));
      var i = zs(t);
      this.writeU8a(i);
    }, e.prototype.encodeArray = function(t, A) {
      var i = t.length;
      if (i < 16)
        this.writeU8(144 + i);
      else if (i < 65536)
        this.writeU8(220), this.writeU16(i);
      else if (i < 4294967296)
        this.writeU8(221), this.writeU32(i);
      else
        throw new Error("Too large array: ".concat(i));
      for (var s = 0, o = t; s < o.length; s++) {
        var r = o[s];
        this.doEncode(r, A + 1);
      }
    }, e.prototype.countWithoutUndefined = function(t, A) {
      for (var i = 0, s = 0, o = A; s < o.length; s++) {
        var r = o[s];
        t[r] !== void 0 && i++;
      }
      return i;
    }, e.prototype.encodeMap = function(t, A) {
      var i = Object.keys(t);
      this.sortKeys && i.sort();
      var s = this.ignoreUndefined ? this.countWithoutUndefined(t, i) : i.length;
      if (s < 16)
        this.writeU8(128 + s);
      else if (s < 65536)
        this.writeU8(222), this.writeU16(s);
      else if (s < 4294967296)
        this.writeU8(223), this.writeU32(s);
      else
        throw new Error("Too large map object: ".concat(s));
      for (var o = 0, r = i; o < r.length; o++) {
        var n = r[o], l = t[n];
        this.ignoreUndefined && l === void 0 || (this.encodeString(n), this.doEncode(l, A + 1));
      }
    }, e.prototype.encodeExtension = function(t) {
      var A = t.data.length;
      if (A === 1)
        this.writeU8(212);
      else if (A === 2)
        this.writeU8(213);
      else if (A === 4)
        this.writeU8(214);
      else if (A === 8)
        this.writeU8(215);
      else if (A === 16)
        this.writeU8(216);
      else if (A < 256)
        this.writeU8(199), this.writeU8(A);
      else if (A < 65536)
        this.writeU8(200), this.writeU16(A);
      else if (A < 4294967296)
        this.writeU8(201), this.writeU32(A);
      else
        throw new Error("Too large extension object: ".concat(A));
      this.writeI8(t.type), this.writeU8a(t.data);
    }, e.prototype.writeU8 = function(t) {
      this.ensureBufferSizeToWrite(1), this.view.setUint8(this.pos, t), this.pos++;
    }, e.prototype.writeU8a = function(t) {
      var A = t.length;
      this.ensureBufferSizeToWrite(A), this.bytes.set(t, this.pos), this.pos += A;
    }, e.prototype.writeI8 = function(t) {
      this.ensureBufferSizeToWrite(1), this.view.setInt8(this.pos, t), this.pos++;
    }, e.prototype.writeU16 = function(t) {
      this.ensureBufferSizeToWrite(2), this.view.setUint16(this.pos, t), this.pos += 2;
    }, e.prototype.writeI16 = function(t) {
      this.ensureBufferSizeToWrite(2), this.view.setInt16(this.pos, t), this.pos += 2;
    }, e.prototype.writeU32 = function(t) {
      this.ensureBufferSizeToWrite(4), this.view.setUint32(this.pos, t), this.pos += 4;
    }, e.prototype.writeI32 = function(t) {
      this.ensureBufferSizeToWrite(4), this.view.setInt32(this.pos, t), this.pos += 4;
    }, e.prototype.writeF32 = function(t) {
      this.ensureBufferSizeToWrite(4), this.view.setFloat32(this.pos, t), this.pos += 4;
    }, e.prototype.writeF64 = function(t) {
      this.ensureBufferSizeToWrite(8), this.view.setFloat64(this.pos, t), this.pos += 8;
    }, e.prototype.writeU64 = function(t) {
      this.ensureBufferSizeToWrite(8), j0(this.view, this.pos, t), this.pos += 8;
    }, e.prototype.writeI64 = function(t) {
      this.ensureBufferSizeToWrite(8), hh(this.view, this.pos, t), this.pos += 8;
    }, e.prototype.writeBigUint64 = function(t) {
      this.ensureBufferSizeToWrite(8), this.view.setBigUint64(this.pos, t), this.pos += 8;
    }, e.prototype.writeBigInt64 = function(t) {
      this.ensureBufferSizeToWrite(8), this.view.setBigInt64(this.pos, t), this.pos += 8;
    }, e;
  }()
);
function Wl(e, t) {
  var A = new gw(t);
  return A.encodeSharedRef(e);
}
function ur(e) {
  return "".concat(e < 0 ? "-" : "", "0x").concat(Math.abs(e).toString(16).padStart(2, "0"));
}
var cw = 16, hw = 16, Iw = (
  /** @class */
  function() {
    function e(t, A) {
      t === void 0 && (t = cw), A === void 0 && (A = hw), this.maxKeyLength = t, this.maxLengthPerKey = A, this.hit = 0, this.miss = 0, this.caches = [];
      for (var i = 0; i < this.maxKeyLength; i++)
        this.caches.push([]);
    }
    return e.prototype.canBeCached = function(t) {
      return t > 0 && t <= this.maxKeyLength;
    }, e.prototype.find = function(t, A, i) {
      var s = this.caches[i - 1];
      t:
        for (var o = 0, r = s; o < r.length; o++) {
          for (var n = r[o], l = n.bytes, a = 0; a < i; a++)
            if (l[a] !== t[A + a])
              continue t;
          return n.str;
        }
      return null;
    }, e.prototype.store = function(t, A) {
      var i = this.caches[t.length - 1], s = { bytes: t, str: A };
      i.length >= this.maxLengthPerKey ? i[Math.random() * i.length | 0] = s : i.push(s);
    }, e.prototype.decode = function(t, A, i) {
      var s = this.find(t, A, i);
      if (s != null)
        return this.hit++, s;
      this.miss++;
      var o = ch(t, A, i), r = Uint8Array.prototype.slice.call(t, A, A + i);
      return this.store(r, o), o;
    }, e;
  }()
), uw = globalThis && globalThis.__awaiter || function(e, t, A, i) {
  function s(o) {
    return o instanceof A ? o : new A(function(r) {
      r(o);
    });
  }
  return new (A || (A = Promise))(function(o, r) {
    function n(c) {
      try {
        a(i.next(c));
      } catch (g) {
        r(g);
      }
    }
    function l(c) {
      try {
        a(i.throw(c));
      } catch (g) {
        r(g);
      }
    }
    function a(c) {
      c.done ? o(c.value) : s(c.value).then(n, l);
    }
    a((i = i.apply(e, t || [])).next());
  });
}, dr = globalThis && globalThis.__generator || function(e, t) {
  var A = { label: 0, sent: function() {
    if (o[0] & 1)
      throw o[1];
    return o[1];
  }, trys: [], ops: [] }, i, s, o, r;
  return r = { next: n(0), throw: n(1), return: n(2) }, typeof Symbol == "function" && (r[Symbol.iterator] = function() {
    return this;
  }), r;
  function n(a) {
    return function(c) {
      return l([a, c]);
    };
  }
  function l(a) {
    if (i)
      throw new TypeError("Generator is already executing.");
    for (; r && (r = 0, a[0] && (A = 0)), A; )
      try {
        if (i = 1, s && (o = a[0] & 2 ? s.return : a[0] ? s.throw || ((o = s.return) && o.call(s), 0) : s.next) && !(o = o.call(s, a[1])).done)
          return o;
        switch (s = 0, o && (a = [a[0] & 2, o.value]), a[0]) {
          case 0:
          case 1:
            o = a;
            break;
          case 4:
            return A.label++, { value: a[1], done: !1 };
          case 5:
            A.label++, s = a[1], a = [0];
            continue;
          case 7:
            a = A.ops.pop(), A.trys.pop();
            continue;
          default:
            if (o = A.trys, !(o = o.length > 0 && o[o.length - 1]) && (a[0] === 6 || a[0] === 2)) {
              A = 0;
              continue;
            }
            if (a[0] === 3 && (!o || a[1] > o[0] && a[1] < o[3])) {
              A.label = a[1];
              break;
            }
            if (a[0] === 6 && A.label < o[1]) {
              A.label = o[1], o = a;
              break;
            }
            if (o && A.label < o[2]) {
              A.label = o[2], A.ops.push(a);
              break;
            }
            o[2] && A.ops.pop(), A.trys.pop();
            continue;
        }
        a = t.call(e, A);
      } catch (c) {
        a = [6, c], s = 0;
      } finally {
        i = o = 0;
      }
    if (a[0] & 5)
      throw a[1];
    return { value: a[0] ? a[1] : void 0, done: !0 };
  }
}, Xl = globalThis && globalThis.__asyncValues || function(e) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var t = e[Symbol.asyncIterator], A;
  return t ? t.call(e) : (e = typeof __values == "function" ? __values(e) : e[Symbol.iterator](), A = {}, i("next"), i("throw"), i("return"), A[Symbol.asyncIterator] = function() {
    return this;
  }, A);
  function i(o) {
    A[o] = e[o] && function(r) {
      return new Promise(function(n, l) {
        r = e[o](r), s(n, l, r.done, r.value);
      });
    };
  }
  function s(o, r, n, l) {
    Promise.resolve(l).then(function(a) {
      o({ value: a, done: n });
    }, r);
  }
}, uA = globalThis && globalThis.__await || function(e) {
  return this instanceof uA ? (this.v = e, this) : new uA(e);
}, dw = globalThis && globalThis.__asyncGenerator || function(e, t, A) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var i = A.apply(e, t || []), s, o = [];
  return s = {}, r("next"), r("throw"), r("return"), s[Symbol.asyncIterator] = function() {
    return this;
  }, s;
  function r(h) {
    i[h] && (s[h] = function(u) {
      return new Promise(function(C, B) {
        o.push([h, u, C, B]) > 1 || n(h, u);
      });
    });
  }
  function n(h, u) {
    try {
      l(i[h](u));
    } catch (C) {
      g(o[0][3], C);
    }
  }
  function l(h) {
    h.value instanceof uA ? Promise.resolve(h.value.v).then(a, c) : g(o[0][2], h);
  }
  function a(h) {
    n("next", h);
  }
  function c(h) {
    n("throw", h);
  }
  function g(h, u) {
    h(u), o.shift(), o.length && n(o[0][0], o[0][1]);
  }
}, tg = "array", os = "map_key", Cw = "map_value", Bw = function(e) {
  return typeof e == "string" || typeof e == "number";
}, si = -1, Hn = new DataView(new ArrayBuffer(0)), Qw = new Uint8Array(Hn.buffer);
try {
  Hn.getInt8(0);
} catch (e) {
  if (!(e instanceof RangeError))
    throw new Error("This module is not supported in the current JavaScript engine because DataView does not throw RangeError on out-of-bounds access");
}
var rn = RangeError, eg = new rn("Insufficient data"), Ew = new Iw(), fw = (
  /** @class */
  function() {
    function e(t) {
      var A, i, s, o, r, n, l;
      this.totalPos = 0, this.pos = 0, this.view = Hn, this.bytes = Qw, this.headByte = si, this.stack = [], this.extensionCodec = (A = t?.extensionCodec) !== null && A !== void 0 ? A : uh.defaultCodec, this.context = t?.context, this.useBigInt64 = (i = t?.useBigInt64) !== null && i !== void 0 ? i : !1, this.maxStrLength = (s = t?.maxStrLength) !== null && s !== void 0 ? s : ii, this.maxBinLength = (o = t?.maxBinLength) !== null && o !== void 0 ? o : ii, this.maxArrayLength = (r = t?.maxArrayLength) !== null && r !== void 0 ? r : ii, this.maxMapLength = (n = t?.maxMapLength) !== null && n !== void 0 ? n : ii, this.maxExtLength = (l = t?.maxExtLength) !== null && l !== void 0 ? l : ii, this.keyDecoder = t?.keyDecoder !== void 0 ? t.keyDecoder : Ew;
    }
    return e.prototype.reinitializeState = function() {
      this.totalPos = 0, this.headByte = si, this.stack.length = 0;
    }, e.prototype.setBuffer = function(t) {
      this.bytes = zs(t), this.view = nw(this.bytes), this.pos = 0;
    }, e.prototype.appendBuffer = function(t) {
      if (this.headByte === si && !this.hasRemaining(1))
        this.setBuffer(t);
      else {
        var A = this.bytes.subarray(this.pos), i = zs(t), s = new Uint8Array(A.length + i.length);
        s.set(A), s.set(i, A.length), this.setBuffer(s);
      }
    }, e.prototype.hasRemaining = function(t) {
      return this.view.byteLength - this.pos >= t;
    }, e.prototype.createExtraByteError = function(t) {
      var A = this, i = A.view, s = A.pos;
      return new RangeError("Extra ".concat(i.byteLength - s, " of ").concat(i.byteLength, " byte(s) found at buffer[").concat(t, "]"));
    }, e.prototype.decode = function(t) {
      this.reinitializeState(), this.setBuffer(t);
      var A = this.doDecodeSync();
      if (this.hasRemaining(1))
        throw this.createExtraByteError(this.pos);
      return A;
    }, e.prototype.decodeMulti = function(t) {
      return dr(this, function(A) {
        switch (A.label) {
          case 0:
            this.reinitializeState(), this.setBuffer(t), A.label = 1;
          case 1:
            return this.hasRemaining(1) ? [4, this.doDecodeSync()] : [3, 3];
          case 2:
            return A.sent(), [3, 1];
          case 3:
            return [
              2
              /*return*/
            ];
        }
      });
    }, e.prototype.decodeAsync = function(t) {
      var A, i, s, o, r, n, l;
      return uw(this, void 0, void 0, function() {
        var a, c, g, h, u, C, B, E;
        return dr(this, function(f) {
          switch (f.label) {
            case 0:
              a = !1, f.label = 1;
            case 1:
              f.trys.push([1, 6, 7, 12]), A = !0, i = Xl(t), f.label = 2;
            case 2:
              return [4, i.next()];
            case 3:
              if (s = f.sent(), o = s.done, !!o)
                return [3, 5];
              l = s.value, A = !1;
              try {
                if (g = l, a)
                  throw this.createExtraByteError(this.totalPos);
                this.appendBuffer(g);
                try {
                  c = this.doDecodeSync(), a = !0;
                } catch (p) {
                  if (!(p instanceof rn))
                    throw p;
                }
                this.totalPos += this.pos;
              } finally {
                A = !0;
              }
              f.label = 4;
            case 4:
              return [3, 2];
            case 5:
              return [3, 12];
            case 6:
              return h = f.sent(), r = { error: h }, [3, 12];
            case 7:
              return f.trys.push([7, , 10, 11]), !A && !o && (n = i.return) ? [4, n.call(i)] : [3, 9];
            case 8:
              f.sent(), f.label = 9;
            case 9:
              return [3, 11];
            case 10:
              if (r)
                throw r.error;
              return [
                7
                /*endfinally*/
              ];
            case 11:
              return [
                7
                /*endfinally*/
              ];
            case 12:
              if (a) {
                if (this.hasRemaining(1))
                  throw this.createExtraByteError(this.totalPos);
                return [2, c];
              }
              throw u = this, C = u.headByte, B = u.pos, E = u.totalPos, new RangeError("Insufficient data in parsing ".concat(ur(C), " at ").concat(E, " (").concat(B, " in the current buffer)"));
          }
        });
      });
    }, e.prototype.decodeArrayStream = function(t) {
      return this.decodeMultiAsync(t, !0);
    }, e.prototype.decodeStream = function(t) {
      return this.decodeMultiAsync(t, !1);
    }, e.prototype.decodeMultiAsync = function(t, A) {
      return dw(this, arguments, function() {
        var s, o, r, n, l, a, c, g, h, u, C, B;
        return dr(this, function(E) {
          switch (E.label) {
            case 0:
              s = A, o = -1, E.label = 1;
            case 1:
              E.trys.push([1, 15, 16, 21]), r = !0, n = Xl(t), E.label = 2;
            case 2:
              return [4, uA(n.next())];
            case 3:
              if (l = E.sent(), h = l.done, !!h)
                return [3, 14];
              B = l.value, r = !1, E.label = 4;
            case 4:
              if (E.trys.push([4, , 12, 13]), a = B, A && o === 0)
                throw this.createExtraByteError(this.totalPos);
              this.appendBuffer(a), s && (o = this.readArraySize(), s = !1, this.complete()), E.label = 5;
            case 5:
              E.trys.push([5, 10, , 11]), E.label = 6;
            case 6:
              return [4, uA(this.doDecodeSync())];
            case 7:
              return [4, E.sent()];
            case 8:
              return E.sent(), --o === 0 ? [3, 9] : [3, 6];
            case 9:
              return [3, 11];
            case 10:
              if (c = E.sent(), !(c instanceof rn))
                throw c;
              return [3, 11];
            case 11:
              return this.totalPos += this.pos, [3, 13];
            case 12:
              return r = !0, [
                7
                /*endfinally*/
              ];
            case 13:
              return [3, 2];
            case 14:
              return [3, 21];
            case 15:
              return g = E.sent(), u = { error: g }, [3, 21];
            case 16:
              return E.trys.push([16, , 19, 20]), !r && !h && (C = n.return) ? [4, uA(C.call(n))] : [3, 18];
            case 17:
              E.sent(), E.label = 18;
            case 18:
              return [3, 20];
            case 19:
              if (u)
                throw u.error;
              return [
                7
                /*endfinally*/
              ];
            case 20:
              return [
                7
                /*endfinally*/
              ];
            case 21:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    }, e.prototype.doDecodeSync = function() {
      t:
        for (; ; ) {
          var t = this.readHeadByte(), A = void 0;
          if (t >= 224)
            A = t - 256;
          else if (t < 192)
            if (t < 128)
              A = t;
            else if (t < 144) {
              var i = t - 128;
              if (i !== 0) {
                this.pushMapState(i), this.complete();
                continue t;
              } else
                A = {};
            } else if (t < 160) {
              var i = t - 144;
              if (i !== 0) {
                this.pushArrayState(i), this.complete();
                continue t;
              } else
                A = [];
            } else {
              var s = t - 160;
              A = this.decodeUtf8String(s, 0);
            }
          else if (t === 192)
            A = null;
          else if (t === 194)
            A = !1;
          else if (t === 195)
            A = !0;
          else if (t === 202)
            A = this.readF32();
          else if (t === 203)
            A = this.readF64();
          else if (t === 204)
            A = this.readU8();
          else if (t === 205)
            A = this.readU16();
          else if (t === 206)
            A = this.readU32();
          else if (t === 207)
            this.useBigInt64 ? A = this.readU64AsBigInt() : A = this.readU64();
          else if (t === 208)
            A = this.readI8();
          else if (t === 209)
            A = this.readI16();
          else if (t === 210)
            A = this.readI32();
          else if (t === 211)
            this.useBigInt64 ? A = this.readI64AsBigInt() : A = this.readI64();
          else if (t === 217) {
            var s = this.lookU8();
            A = this.decodeUtf8String(s, 1);
          } else if (t === 218) {
            var s = this.lookU16();
            A = this.decodeUtf8String(s, 2);
          } else if (t === 219) {
            var s = this.lookU32();
            A = this.decodeUtf8String(s, 4);
          } else if (t === 220) {
            var i = this.readU16();
            if (i !== 0) {
              this.pushArrayState(i), this.complete();
              continue t;
            } else
              A = [];
          } else if (t === 221) {
            var i = this.readU32();
            if (i !== 0) {
              this.pushArrayState(i), this.complete();
              continue t;
            } else
              A = [];
          } else if (t === 222) {
            var i = this.readU16();
            if (i !== 0) {
              this.pushMapState(i), this.complete();
              continue t;
            } else
              A = {};
          } else if (t === 223) {
            var i = this.readU32();
            if (i !== 0) {
              this.pushMapState(i), this.complete();
              continue t;
            } else
              A = {};
          } else if (t === 196) {
            var i = this.lookU8();
            A = this.decodeBinary(i, 1);
          } else if (t === 197) {
            var i = this.lookU16();
            A = this.decodeBinary(i, 2);
          } else if (t === 198) {
            var i = this.lookU32();
            A = this.decodeBinary(i, 4);
          } else if (t === 212)
            A = this.decodeExtension(1, 0);
          else if (t === 213)
            A = this.decodeExtension(2, 0);
          else if (t === 214)
            A = this.decodeExtension(4, 0);
          else if (t === 215)
            A = this.decodeExtension(8, 0);
          else if (t === 216)
            A = this.decodeExtension(16, 0);
          else if (t === 199) {
            var i = this.lookU8();
            A = this.decodeExtension(i, 1);
          } else if (t === 200) {
            var i = this.lookU16();
            A = this.decodeExtension(i, 2);
          } else if (t === 201) {
            var i = this.lookU32();
            A = this.decodeExtension(i, 4);
          } else
            throw new qt("Unrecognized type byte: ".concat(ur(t)));
          this.complete();
          for (var o = this.stack; o.length > 0; ) {
            var r = o[o.length - 1];
            if (r.type === tg)
              if (r.array[r.position] = A, r.position++, r.position === r.size)
                o.pop(), A = r.array;
              else
                continue t;
            else if (r.type === os) {
              if (!Bw(A))
                throw new qt("The type of key must be string or number but " + typeof A);
              if (A === "__proto__")
                throw new qt("The key __proto__ is not allowed");
              r.key = A, r.type = Cw;
              continue t;
            } else if (r.map[r.key] = A, r.readCount++, r.readCount === r.size)
              o.pop(), A = r.map;
            else {
              r.key = null, r.type = os;
              continue t;
            }
          }
          return A;
        }
    }, e.prototype.readHeadByte = function() {
      return this.headByte === si && (this.headByte = this.readU8()), this.headByte;
    }, e.prototype.complete = function() {
      this.headByte = si;
    }, e.prototype.readArraySize = function() {
      var t = this.readHeadByte();
      switch (t) {
        case 220:
          return this.readU16();
        case 221:
          return this.readU32();
        default: {
          if (t < 160)
            return t - 144;
          throw new qt("Unrecognized array type byte: ".concat(ur(t)));
        }
      }
    }, e.prototype.pushMapState = function(t) {
      if (t > this.maxMapLength)
        throw new qt("Max length exceeded: map length (".concat(t, ") > maxMapLengthLength (").concat(this.maxMapLength, ")"));
      this.stack.push({
        type: os,
        size: t,
        key: null,
        readCount: 0,
        map: {}
      });
    }, e.prototype.pushArrayState = function(t) {
      if (t > this.maxArrayLength)
        throw new qt("Max length exceeded: array length (".concat(t, ") > maxArrayLength (").concat(this.maxArrayLength, ")"));
      this.stack.push({
        type: tg,
        size: t,
        array: new Array(t),
        position: 0
      });
    }, e.prototype.decodeUtf8String = function(t, A) {
      var i;
      if (t > this.maxStrLength)
        throw new qt("Max length exceeded: UTF-8 byte length (".concat(t, ") > maxStrLength (").concat(this.maxStrLength, ")"));
      if (this.bytes.byteLength < this.pos + A + t)
        throw eg;
      var s = this.pos + A, o;
      return this.stateIsMapKey() && (!((i = this.keyDecoder) === null || i === void 0) && i.canBeCached(t)) ? o = this.keyDecoder.decode(this.bytes, s, t) : o = z0(this.bytes, s, t), this.pos += A + t, o;
    }, e.prototype.stateIsMapKey = function() {
      if (this.stack.length > 0) {
        var t = this.stack[this.stack.length - 1];
        return t.type === os;
      }
      return !1;
    }, e.prototype.decodeBinary = function(t, A) {
      if (t > this.maxBinLength)
        throw new qt("Max length exceeded: bin length (".concat(t, ") > maxBinLength (").concat(this.maxBinLength, ")"));
      if (!this.hasRemaining(t + A))
        throw eg;
      var i = this.pos + A, s = this.bytes.subarray(i, i + t);
      return this.pos += A + t, s;
    }, e.prototype.decodeExtension = function(t, A) {
      if (t > this.maxExtLength)
        throw new qt("Max length exceeded: ext length (".concat(t, ") > maxExtLength (").concat(this.maxExtLength, ")"));
      var i = this.view.getInt8(this.pos + A), s = this.decodeBinary(
        t,
        A + 1
        /* extType */
      );
      return this.extensionCodec.decode(s, i, this.context);
    }, e.prototype.lookU8 = function() {
      return this.view.getUint8(this.pos);
    }, e.prototype.lookU16 = function() {
      return this.view.getUint16(this.pos);
    }, e.prototype.lookU32 = function() {
      return this.view.getUint32(this.pos);
    }, e.prototype.readU8 = function() {
      var t = this.view.getUint8(this.pos);
      return this.pos++, t;
    }, e.prototype.readI8 = function() {
      var t = this.view.getInt8(this.pos);
      return this.pos++, t;
    }, e.prototype.readU16 = function() {
      var t = this.view.getUint16(this.pos);
      return this.pos += 2, t;
    }, e.prototype.readI16 = function() {
      var t = this.view.getInt16(this.pos);
      return this.pos += 2, t;
    }, e.prototype.readU32 = function() {
      var t = this.view.getUint32(this.pos);
      return this.pos += 4, t;
    }, e.prototype.readI32 = function() {
      var t = this.view.getInt32(this.pos);
      return this.pos += 4, t;
    }, e.prototype.readU64 = function() {
      var t = Z0(this.view, this.pos);
      return this.pos += 8, t;
    }, e.prototype.readI64 = function() {
      var t = Ih(this.view, this.pos);
      return this.pos += 8, t;
    }, e.prototype.readU64AsBigInt = function() {
      var t = this.view.getBigUint64(this.pos);
      return this.pos += 8, t;
    }, e.prototype.readI64AsBigInt = function() {
      var t = this.view.getBigInt64(this.pos);
      return this.pos += 8, t;
    }, e.prototype.readF32 = function() {
      var t = this.view.getFloat32(this.pos);
      return this.pos += 4, t;
    }, e.prototype.readF64 = function() {
      var t = this.view.getFloat64(this.pos);
      return this.pos += 8, t;
    }, e;
  }()
);
function pw(e, t) {
  var A = new fw(t);
  return A.decode(e);
}
class ww extends qg {
  constructor(t, A, i = "attachments") {
    super(t, A, i), this.client = t, this.roleName = A, this.zomeName = i;
  }
  async getDnaHash() {
    const t = await this.client.appInfo();
    return eB(this.roleName, t)[0];
  }
  addAttachment(t, A) {
    return this.callZome("add_attachment", {
      hash: t,
      hrl_with_context: {
        hrl: {
          dna_hash: A.hrl[0],
          resource_hash: A.hrl[1]
        },
        context: Wl(A.context)
      }
    });
  }
  async getAttachments(t) {
    return (await this.callZome("get_attachments", t)).map((i) => ({
      hrl: [i.hrl.dna_hash, i.hrl.resource_hash],
      context: pw(i.context)
    }));
  }
  removeAttachment(t, A) {
    return this.callZome("remove_attachment", {
      hash: t,
      hrl_with_context: {
        hrl: {
          dna_hash: A.hrl[0],
          resource_hash: A.hrl[1]
        },
        context: Wl(A.context)
      }
    });
  }
}
class yw {
  constructor(t) {
    this.client = t, this.attachments = new Vg((A) => Nr(() => this.client.getAttachments(A), 2e3));
  }
}
let Ks = class extends q {
  render() {
    return w`<slot></slot>`;
  }
};
Ks.styles = ae`
    :host {
      display: contents;
    }
  `;
T([
  to({ context: mn }),
  W({ type: Object })
], Ks.prototype, "store", void 0);
Ks = T([
  It("attachments-context")
], Ks);
function Ag(e, t, A, i) {
  const s = new L0(new on(e, "forum"));
  return w`
    <posts-context .store=${s}>
      <we-services-context .services=${A}>
        <attachments-context
          .store=${new yw(new ww(e, "forum"))}
        >
          ${i}
        </attachments-context>
      </we-services-context>
    </posts-context>
  `;
}
async function vw(e, t, A, i) {
  return {
    main: (s) => fs(
      Ag(
        e,
        A,
        i,
        w`
            <applet-main
              @post-selected=${async (o) => {
          const n = (await e.appInfo()).cell_info.forum[0][at.Provisioned].cell_id[0];
          i.openViews.openHrl([n, o.detail.postHash], {});
        }}
            ></applet-main>
          `
      ),
      s
    ),
    blocks: {},
    entries: {
      forum: {
        posts_integrity: {
          post: {
            info: async (s) => ({
              name: "",
              icon_src: ""
            }),
            view: (s, o, r) => fs(
              Ag(
                e,
                A,
                i,
                w` <post-detail .postHash=${o[1]}></post-detail> `
              ),
              s
            )
          }
        }
      }
    }
  };
}
async function mw(e, t) {
  return {
    main: (A) => fs(
      w`
          <we-services-context .services=${t}>
            <cross-applet-main .applets=${e}></cross-applet-main>
          </we-services-context>
        `,
      A
    ),
    blocks: {}
  };
}
const ey = {
  appletViews: vw,
  crossAppletViews: mw,
  attachmentTypes: async (e) => ({
    post: {
      async create(t) {
        const i = await new on(e, "forum").createPost({
          title: `Post about hrl://${sA(
            t[0]
          )}/${sA(t[1])}`,
          content: ""
        });
        return { hrl: [(await e.appInfo()).cell_info.forum[0][at.Provisioned].cell_id[0], i.actionHash], context: null };
      },
      icon_src: fe(gB),
      label: k("Post")
    }
  }),
  search: async (e, t) => {
    const i = (await e.appInfo()).cell_info.forum[0][at.Provisioned].cell_id[0];
    return (await new on(e, "forum").getAllPosts()).filter(
      (n) => n.entry.title.includes(t)
    ).map((n) => ({
      hrl: [i, n.actionHash],
      context: null
    }));
  }
};
export {
  ey as default
};
